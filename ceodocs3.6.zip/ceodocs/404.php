<?php get_header();?>
<section class="ceo-page-404">
	<div class="ceo-container ceo-padding-large">
		<div class="ceo-text-center">
			<img src="<?php bloginfo('template_url'); ?>/static/images/404.png" alt="404">
			<p>Sorry，页面丢失了，要不返回首页吧？</p>
			<a href="<?php bloginfo('url'); ?>">返回首页<i class="ceofont ceoicon-share-forward-fill"></i></a>
		</div>
	</div>
</section>
<?php get_footer(); ?>