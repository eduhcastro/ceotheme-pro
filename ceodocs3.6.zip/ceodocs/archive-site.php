<?php 
$title = _ceo('site-title');
$bg = _ceo('site-bg');
get_header();
?>
<div class="ceo-site-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);">
    <div class="ceo-container">
        <div class="title">
            <h1><?php echo $title; ?></h1>
        </div>
        <?php include TEMPLATEPATH.'/pages/site/top.php'; ?>
    </div>
</div>
<div class="ceo-pages-site">
    <div class="ceo-grid-collapse" ceo-grid>
        <div class="ceo-width-auto ceo-visible@s">
        <?php include TEMPLATEPATH.'/pages/site/nav.php'; ?>
        </div>
        <div class="ceo-width-expand">
        <?php include TEMPLATEPATH.'/pages/site/index.php' ;?>
        </div>
    </div>
</div>
<?php get_footer(); ?>