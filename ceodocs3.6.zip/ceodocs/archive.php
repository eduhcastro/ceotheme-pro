<?php 
$title = _ceo('site-title');
$bg = _ceo('site-bg');
get_header();
?>
<div class="ceo-site-bg" style="background: url(<?php echo $bg; ?>) center no-repeat;">
    <div class="ceo-container">
        <div class="title">
            <h1><?php echo $title; ?></h1>
        </div>
        <?php include TEMPLATEPATH.'/pages/site/top.php'; ?>
    </div>
</div>
<div class="ceo-margin-medium">
    <div class="ceo-container">
    	<section class="site-classification-box card">
    		<h3 class="ceo-text-bolder section-title"><?php single_cat_title(); ?></h3>
    		<ul class="ceo-child-width-1-2 ceo-child-width-1-3@s ceo-child-width-1-4@m ceo-child-width-1-5@l ceo-child-width-1-5@xl ceo-grid-ceosmls" ceo-grid>
    			<?php while (have_posts()) : the_post(); ?>
    			<li>
    				<?php include(TEMPLATEPATH . '/pages/site/card.php'); ?>
    			</li>
    			<?php endwhile; ?> 
    		</ul>
    	</section>
    </div>
</div>
<?php get_footer(); ?>