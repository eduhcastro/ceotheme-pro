<?php
get_header();
$bg = _ceo('author-bg');

global $wpdb;
$wpdb->collection = $wpdb->prefix.'collection';
$user_id        = get_the_author_ID();
if(!empty($author)){
    $user_id=$author;
}

$args['user_id'] = $user_id;

$author_comments = get_comments($args);
$all_collections = $wpdb->get_results( $wpdb->prepare("select post_id from $wpdb->collection where user_id = %d LIMIT 0,10", $user_id ) );

if( $all_collections ){
	foreach ($all_collections as $key => $value) {
		$collections_posts[] = $value->post_id;
	}

	$args = array(
		'post_type' => 'post',
		'post__in' => $collections_posts,
		'ignore_sticky_posts' => 1,
	);
	$collection_posts = new WP_Query($args);
}

$tabType = $_GET['type'] ?? 1;

?>
<section class="ceo-author-home">
	<div class="author-bg ceo-background-cover ceo-background-muted ceo-panel" style="background-image: url(<?php echo $bg; ?>)">
	    <div class="ceo-container">
	        <div class="author-btn">
                <div class="box">
                    <div class="ceo-grid-small" ceo-grid>
                        <?php do_action('ceo_profile_after_description', $author);?>
                    </div>
                </div>
            </div>
	        <div class="author-info">
            	<div class="img">
            	    <div class="imgbox">
            		    <?php echo get_avatar( $user_id , 100 ); ?>
            			<?php if(user_can(get_the_author_meta( 'ID' ),'author') || user_can(get_the_author_meta( 'ID' ),'editor') || user_can(get_the_author_meta( 'ID' ),'administrator')){ ?>
            			<i ceo-tooltip="认证作者"></i>
                        <?php }?>
        			</div>
            	</div>
        	    <div class="desc">
        		    <p class="name"><?php the_author_nickname(); ?></p>
            	    <p class="text">
            	        <?php
                            if(!get_the_author_meta('user_description', $user_id)){
                                echo '这家伙很懒，只想把你留下。';
                            }else {
                                echo the_author_meta('user_description', $user_id);
                            }
                    	?>
            	    </p>
            	    <ul class="data">
                        <li><span><?php echo CeoShopCoreUser::getProductCount($user_id, 2); ?></span><p>作品</p></li>
                        <li><span><?php echo CeoShopCoreUser::getProductCount($user_id, 1); ?></span><p>文章</p></li>
                		<li><span><?php echo CeoShopCoreUser::getFollowerCount($user_id); ?></span><p>粉丝</p></li>
                		<li><span><?php echo cx_posts_views($user_id); ?></span><p>人气</p></li>
                		<li><span><?php echo count_collection_posts($user_id) ?></span><p>收藏</p></li>
                		<li><span><?php echo count($author_comments); ?></span><p>评论</p></li>
                	</ul>
                </div>
            </div>
	    </div>
	</div>
</section>

<section class="ceo-default-list">
    <div class="ceo-container ceo-margin-medium-bottom">
	    <div class="default-box">
    	    <ul class="nav">
                <li <?php if ($tabType == 1) echo 'class="ceo-active"' ?>><a href="<?php echo home_url(add_query_arg(['type' => 1])) ?>">作品</a></li>
                <li <?php if ($tabType == 2) echo 'class="ceo-active"' ?>><a href="<?php echo home_url(add_query_arg(['type' => 2])) ?>">文章</a></li>
            </ul>
            
            <?php if ($tabType == 1): ?>
            <?php get_template_part( 'template-parts/default/author', 'works' ); ?>
            <?php elseif ($tabType == 2): ?>
            <?php get_template_part( 'template-parts/default/author', 'article' ); ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php add_action('get_footer', function () { wp_enqueue_script('js2021', get_template_directory_uri() . '/static/js/js21.js', ['jquery']); }); ?>
<?php get_footer(); ?>