<?php get_header(); ?>

<?php ceo_category_layout(); ?>

<?php get_footer(); ?>