<?php $foot_img = _ceo('foot_img') ?>
		</main>
		    <!--底部banner模块-->
		    <?php get_template_part( 'template-parts/footer/footer', 'banner' ); ?>
			<!--右下角跟随模块-->
			<?php get_template_part( 'template-parts/footer/footer', 'follow' ); ?>
			<!--底部主模块-->
			<footer class="ceo-footer">
                <div class="foot-cop">
                    <div class="ceo-flex ceo-flex-middle ceo-container">
                        <div class="ceo-flex-1">
                            <div class="foot-cop-s">
                                <span><?php echo _ceo('cop_text'); ?></span>
                                <?php if(_ceo('theme_cop') == true): ?>
                                <span>Theme By <a href="https://www.ceotheme.com/" target="_blank">CeoTheme</a></span>
                                <?php endif; ?>
                            </div>
                            <div class="foot-cop-x">
                                <?php if(_ceo('foot_xml_set') == true): ?>
                                <span><a href="<?php echo _ceo('foot_xml'); ?>" target="_blank"><i class="ceofont ceoicon-map-pin-fill" aria-hidden="true"></i> 网站地图</a>
                                </span>
                                <?php endif; ?>
                                
                                <?php if(_ceo('foot_gongan') == true): ?>
        						<span class="ceo-margin-small-right ceo-gongan"><a href="http://www.beian.gov.cn/" target="_blank" rel="noreferrer nofollow"><img src="<?php bloginfo('template_url'); ?>/static/images/ceo-110.png" height="6"><?php echo _ceo('foot_gongan_beianhao'); ?></a>
        						</span>
        						<?php endif; ?>
        						
                                <?php if(_ceo('show_beian') == true): ?>
                                <span class="ceo-display-inline-block"><a href="https://beian.miit.gov.cn/" target="_blank" rel="noreferrer nofollow"><?php echo _ceo('beian'); ?></a>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
    			        <div class="foot-cop-y">
    			            <?php
        			            if ($foot_img) {
    							foreach ( $foot_img as $key => $value) {
							?>
                            <li>
                                <a href="<?php echo $value['link'] ?>" target="_blank" rel="noreferrer nofollow">
                                    <img src="<?php echo $value['img'] ?>" alt="<?php echo $value['title'] ?>">
                                </a>
                            </li>
                            <?php } } ?>
    			        </div>
                    </div>
                </div>
                <?php if( is_user_logged_in() ){ ?>
		        <?php }else{ ?>
		        <?php get_template_part( 'template-parts/navbar/navbar', 'login' ); ?>
		        <?php } ?>
			    <?php wp_footer(); ?>
		    </footer>
		</div>
		<?php get_template_part( 'template-parts/footer/footer', 'js' ); ?>
		<?php if(_ceo('ceo_app_foo') == true): ?>
		<?php get_template_part( 'template-parts/footer/footer', 'nav' ); ?>
		<?php endif; ?>
        <!-- CeoDocs主题 -->
        <div id="ceoshop-member-box"></div>
</body>
</html>