<?php

/*
 * CeoDocs是一款极简大气的WordPress付费素材下载主题。
 * 正版唯一购买地址：https://www.ceotheme.com/
 * CeoDocs主题官方演示站点：http://ceodocs.ceotheme.com/
 * 作者总裁QQ：110300260 （总裁）
 * CeoDocs主题是一款轻量级、且简洁大气、付费素材下载类型主题，定位于办公素材行业，当然也适用于各类素材网站，同时也适用于网页素材网页特效下载网站等。
 * CeoTheme总裁主题制作的CeoDocs主题正版用户可享受该主题不限制域名，不限制数量，无限授权，仅限本人享有此特权，外泄主题包将取消授权资格！
 * 开发者不易，感谢支持，在线客户服务+技术支持为您服务。
 */

/*
 * ------------------------------------------------------------------------------
 * PHP多版本兼容
 * ------------------------------------------------------------------------------
 */
error_reporting(0);

if (file_exists(TEMPLATEPATH.'/inc/functions/functions.php')) {
    require_once TEMPLATEPATH.'/inc/functions/functions.php';
}else{
    if (extension_loaded('swoole_loader') && function_exists('swoole_loader_version') && w_parse_version_float(swoole_loader_version())>=3.1) {
        $php_v = substr(PHP_VERSION,0,3);
        require_once TEMPLATEPATH.'/inc/functions/functions.'.$php_v.'.php';
    }else{
        $_theme = get_template_directory_uri();
        wp_safe_redirect($_theme.'/help/swoole-compiler-loader.php');die;
    }
}

function w_parse_version_float($version) {
    $versionList = [];
    if (is_string($version)) {
        $rawVersionList = explode('.', $version);
        if (isset($rawVersionList[0])) {
            $versionList[] = $rawVersionList[0];
        }
        if (isset($rawVersionList[1])) {
            $versionList[] = $rawVersionList[1];
        }
    }
    return (float) implode('.',$versionList);
}

/*
==================（重要）请勿修改上方代码==================
************************************************************
==================二次开发功能请添加在下面==================
*/
