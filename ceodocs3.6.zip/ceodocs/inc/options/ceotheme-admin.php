<?php if (! defined('ABSPATH')) { die; }
/*
 * CeoDocs是一款极简大气的WordPress付费素材下载主题。
 * 正版唯一购买地址：https://www.ceotheme.com/
 * CeoDocs主题官方演示站点：http://ceodocs.ceotheme.com/
 * 作者总裁QQ：110300260 （总裁）
 * CeoDocs主题是一款轻量级、且简洁大气、付费素材下载类型主题，定位于办公素材行业，当然也适用于各类素材网站，同时也适用于网页素材网页特效下载网站等。
 * CeoTheme总裁主题制作的CeoDocs主题正版用户可享受该主题不限制域名，不限制数量，无限授权，仅限本人享有此特权，外泄主题包将取消授权资格！
 * 开发者不易，感谢支持，在线客户服务+技术支持为您服务。
 */


if (class_exists('CSF')) {
    $ceotheme = 'ceodocs';
    CSF::createOptions($ceotheme, array(
        'menu_title'      => 'CeoDocs主题设置',
        'menu_slug'       => 'my-framework',
        'framework_title' => '<i class="fa fa-laptop"></i> CeoDocs主题  │ <small><a href="https://www.ceotheme.com" target="_blank" class="wb-btn" style="text-decoration:none;color:#ffffff;">Theme By 总裁主题 CeoTheme.com</a></small>',
    ));

    /*
     * ------------------------------------------------------------------------------
     * 基础设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id'      => 'ceotheme_basic',
        'icon'    => 'fa fa-cog',
        'title'   => '基础设置',
    ));
    CSF::createSection($ceotheme, array(
        'parent'  => 'ceotheme_basic',
        'title'   => '网站基础设置',
        'fields'  => array(
            array(
                'id'           => 'head_logo',
                'type'         => 'upload',
                'title'        => '网站LOGO图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceotheme-logo.png',
            ),
            array(
                'id'           => 'head_logo_b',
                'type'         => 'upload',
                'title'        => '透明LOGO图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceotheme-logo-n.png',
            ),
            array(
                'id'           => 'favicon',
                'type'         => 'upload',
                'title'        => '网站favicon.ico图标',
                'desc'         => '浏览器/收藏夹图标 <a href="https://ico.ceotheme.com/" target="_blank" style="color: #0a8eff;">点击这里立即生成</a> 网站favicon.ico图标',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
            ),
            array(
                'id'           => 'logo_website',
                'type'         => 'switcher',
                'title'        => '网站收藏提示',
                'desc'         =>'开启或关闭网站收藏提示',
                'default'      => true
            ),
            array(
                'id'           => 'ceo_color',
                'type'         => 'color',
                'title'        => '主配色',
                'default'      => '#215dff',
            ),
            array(
                'id'           => 'ceo_color_shallow',
                'type'         => 'color',
                'title'        => '浅配色',
                'default'      => 'rgba(0,87,255,0.1)',
            ),
        ),
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_basic',
        'title'  => '网站SEO设置',
        'fields' => array(
            array(
                'id'       => 'website_title',
                'type'     => 'text',
                'title'    => '网站标题',
            ),
            array(
                'id'       => 'website_keywords',
                'type'     => 'text',
                'title'    => '网站关键词',
            ),
            array(
                'id'       => 'website_description',
                'type'     => 'textarea',
                'title'    => '网站描述',
            ),
            array(
                'id'       => 'category',
                'type'     => 'switcher',
                'title'    => '去掉分类目录中的category',
                'default'  => true,
                'subtitle' => '去掉分类目录中的category，精简URL，有利于SEO，推荐去掉',
            ),
            array(
                'id'       => 'website_description_length',
                'type'     => 'number',
                'title'    => '内容页SEO描述字符数',
                'default'  => 180,
            ),
        )
    ));

    /*
     * ------------------------------------------------------------------------------
     * 顶部设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id'     => 'ceotheme_top',
        'icon'   => 'fa fa-paper-plane',
        'title'  => '顶部设置',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_top',
        'title'  => '顶部基础设置',
        'fields' => array(
            array(
                'id'        => 'navbar_style',
                'type'      => 'image_select',
                'title'     => '顶部导航样式',
                'desc'		=> '[ 样式一：首页导航透明背景 ] [ 样式二：全站导航白色背景 ]',
                'options'   => array(
                    '1' => get_template_directory_uri() . '/static/admin-img/ceo-navbar-1.jpg',
                    '2' => get_template_directory_uri() . '/static/admin-img/ceo-navbar-2.jpg',
                ),
                'default'   => '1',
            ),
            array(
                'id'        => 'navbar_logo_group',
                'type'      => 'switcher',
                'title'     => 'LOGO右侧按钮组',
                'desc'      => '开启或关闭LOGO右侧按钮组',
                'default'   => true
            ),
            array(
                'id'        => 'navbar_logo_group_set',
                'type'      => 'fieldset',
                'dependency'=> array('navbar_logo_group', '==', true),
                'title'     => 'LOGO右侧按钮组配置',
                'fields'    => array(
                    array(
                        'id'          => 'icon',
                        'type'        => 'text',
                        'title'       => '主按钮图标',
                        'default'     => 'ceoicon-computer-line',
                        'desc'        => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'          => 'title',
                        'type'        => 'text',
                        'title'       => '主按钮标题',
                        'default'     => '旗下产品',
                    ),
                    array(
                        'id'          => 'link',
                        'type'        => 'text',
                        'title'       => '主按钮链接',
                        'default'     => '/',
                    ),
                    array(
                        'id'          => 'module',
                        'type'        => 'text',
                        'title'       => '模块顶部标题',
                        'default'     => '旗下产品矩阵',
                    ),
                    array(
                        'id'          => 'desc',
                        'type'        => 'text',
                        'title'       => '模块底部描述',
                        'default'     => '总裁主题旗下产品矩阵，欢迎体验~',
                    ),
                    array(
                        'id'          => 'btn',
                        'type'        => 'group',
                        'accordion_title_number' => true,
                        'title'       => '按钮组配置',
                        'button_title'=> '添加按钮组',
                        'fields'      => array(
                            array(
                                'id'          => 'title',
                                'type'        => 'text',
                                'title'       => '标题',
                                'default'     => '总裁主题',
                            ),
                            array(
                                'id'          => 'link',
                                'type'        => 'text',
                                'title'       => '链接',
                                'default'     => 'https://www.ceotheme.com',
                            ),
                            array(
                                'id'           => 'img',
                                'type'         => 'upload',
                                'title'        => '按钮图标',
                                'desc'         => '图标尺寸48x48（等比例）',
                                'placeholder'  => 'http://',
                                'button_title' => '上传',
                                'remove_title' => '删除',
                            ),
                        )
                    ),
                ),
            ),
            array(
                'id'         => 'navbar_search',
                'type'       => 'switcher',
                'title'      => '顶部导航搜索框',
                'desc'       => '开启或关闭顶部导航搜索框',
                'default'    => true
            ),
            array(
                'id'         => 'navbar_info',
                'type'       => 'switcher',
                'title'      => '导航右侧活动组',
                'desc'       => '开启或关闭导航右侧活动组',
                'default'    => true
            ),
            array(
                'id'         => 'navbar_info_set',
                'type'       => 'fieldset',
                'dependency' => array('navbar_info', '==', true),
                'title'      => '导航右侧活动组配置',
                'fields'     => array(
                    array(
                        'id'          => 'title',
                        'type'        => 'text',
                        'title'       => '主按钮标题',
                        'default'     => '有奖活动',
                    ),
                    array(
                        'id'          => 'link',
                        'type'        => 'text',
                        'title'       => '主按钮链接',
                        'default'     => '/',
                    ),
                    array(
                        'id'          => 'btn',
                        'type'        => 'group',
                        'accordion_title_number' => true,
                        'title'       => '活动内容配置',
                        'button_title'=> '添加',
                        'fields'      => array(
                            array(
                                'id'          => 'title',
                                'type'        => 'text',
                                'title'       => '标题',
                                'default'     => '',
                            ),
                            array(
                                'id'          => 'link',
                                'type'        => 'text',
                                'title'       => '链接',
                                'default'     => '',
                            ),
                            array(
                                'id'           => 'img',
                                'type'         => 'upload',
                                'title'        => '图片',
                                'desc'         => '图片尺寸280x105',
                                'placeholder'  => 'http://',
                                'button_title' => '上传',
                                'remove_title' => '删除',
                            ),
                        )
                    ),
                ),
            ),
            array(
                'id'         => 'navbar_vip',
                'type'       => 'switcher',
                'title'      => '导航右侧VIP按钮',
                'desc'       => '开启或关闭导航右侧VIP按钮',
                'default'    => true
            ),
            array(
                'id'         => 'navbar_vip_set',
                'type'       => 'fieldset',
                'dependency' => array('navbar_vip', '==', true),
                'title'      => '导航右侧VIP按钮配置',
                'fields'     => array(
                    array(
                        'id'          => 'title',
                        'type'        => 'text',
                        'title'       => '主按钮标题',
                        'default'     => '升级会员',
                    ),
                    array(
                        'id'          => 'link',
                        'type'        => 'text',
                        'title'       => '主按钮链接',
                        'default'     => '/vip',
                    ),
                    array(
                        'id'          => 'moduletitle',
                        'type'        => 'text',
                        'title'       => '弹窗模块标题',
                        'default'     => '加入VIP即可获得',
                    ),
                    array(
                        'id'          => 'moduledesc',
                        'type'        => 'text',
                        'title'       => '弹窗模块描述',
                        'default'     => '每日新增海量热点模版|免费下载',
                    ),
                    array(
                        'id'          => 'group',
                        'type'        => 'group',
                        'accordion_title_number' => true,
                        'title'       => 'VIP权益内容',
                        'button_title'=> '添加',
                        'fields'      => array(
                            array(
                                'id'           => 'title',
                                'type'         => 'text',
                                'title'        => '标题',
                                'default'      => '',
                            ),
                            array(
                                'id'           => 'img',
                                'type'         => 'upload',
                                'title'        => '图片',
                                'desc'         => '建议图标尺寸24x24（等比例）',
                                'placeholder'  => 'http://',
                                'button_title' => '上传',
                                'remove_title' => '删除',
                            ),
                        ),
                        'default' => array(
                            array(
                                'title' => '海量素材',
                                'img'   => get_template_directory_uri() . '/static/images/ceo-navbar-vip-1.png',
                            ),
                            array(
                                'title' => '高速下载',
                                'img'   => get_template_directory_uri() . '/static/images/ceo-navbar-vip-2.png',
                            ),
                            array(
                                'title' => '免费下载',
                                'img'   => get_template_directory_uri() . '/static/images/ceo-navbar-vip-3.png',
                            ),
                            array(
                                'title' => '优享新品',
                                'img'   => get_template_directory_uri() . '/static/images/ceo-navbar-vip-4.png',
                            ),
                        ),
                    ),
                    array(
                        'id'          => 'btntitle',
                        'type'        => 'text',
                        'title'       => '弹窗按钮标题',
                        'default'     => '加入全站通VIP',
                    ),
                    array(
                        'id'          => 'btndesc',
                        'type'        => 'text',
                        'title'       => '弹窗按钮宣传语',
                        'default'     => '超值优惠低至0.1元/天',
                    ),
                    array(
                        'id'          => 'btnlink',
                        'type'        => 'text',
                        'title'       => '弹窗按钮链接',
                        'default'     => '/vip',
                    ),
                ),
            ),
            array(
                'id'         => 'navbar_delivery',
                'type'       => 'switcher',
                'title'      => '导航右侧投稿按钮',
                'desc'       => '开启或关闭导航右侧投稿按钮',
                'default'    => true
            ),
            array(
                'id'         => 'navbar_delivery_set',
                'type'       => 'fieldset',
                'dependency' => array('navbar_delivery', '==', true),
                'title'      => '导航右侧投稿按钮配置',
                'fields'     => array(
                    array(
                        'id'          => 'title',
                        'type'        => 'text',
                        'title'       => '按钮标题',
                        'default'     => '工作台',
                    ),
                    array(
                        'id'          => 'link',
                        'type'        => 'text',
                        'title'       => '按钮链接',
                        'default'     => '/tougao',
                    ),
                    array(
                        'id'          => 'icon',
                        'type'        => 'text',
                        'title'       => '按钮图标',
                        'default'     => 'ceoicon-macbook-line',
                        'desc'        => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent'  => 'ceotheme_top',
        'title'   => '顶部合集菜单',
        'fields'  => array(
            array(
                'id'          => 'navbar_whole',
                'type'        => 'switcher',
                'title'       => '顶部导航合集菜单',
                'desc'        => '开启或关闭顶部导航合集菜单',
                'default'     => true
            ),
            array(
                'id'          => 'navbar_whole_title',
                'type'        => 'text',
                'dependency'  => array('navbar_whole', '==', true),
                'title'       => '合集菜单标题',
                'default'     => '模板中心',
            ),
            array(
                'id'          => 'navbar_whole_set',
                'type'        => 'group',
                'accordion_title_number' => true,
                'dependency'  => array('navbar_whole', '==', true),
                'title'       => '合集菜单配置',
                'button_title'=> '添加',
                'fields'      => array(
                    array(
                        'id'           => 'antitle',
                        'type'         => 'text',
                        'title'        => '标题',
                        'default'      => '',
                    ),
                    array(
                        'id'           => 'anlink',
                        'type'         => 'text',
                        'title'        => '链接',
                        'default'      => '',
                    ),
                    array(
                        'id'           => 'img',
                        'type'         => 'upload',
                        'title'        => '图标',
                        'desc'         => '建议图标尺寸26x26（等比例）',
                        'placeholder'  => 'http://',
                        'button_title' => '上传',
                        'remove_title' => '删除',
                    ),
                    array(
                        'id'           => 'group',
                        'type'         => 'group',
                        'max'          => '8',
                        'accordion_title_number' => true,
                        'title'        => '子菜单配置',
                        'desc'         => '每组不超过8个菜单，如果分类菜单超过8个，建议在第8个以（更多）代替',
                        'button_title' => '添加',
                        'fields'       => array(
                            array(
                                'id'     => 'title',
                                'type'   => 'text',
                                'title'  => '标题',
                            ),
                            array(
                                'id'     => 'link',
                                'type'   => 'text',
                                'title'  => '链接',
                            ),
                        ),
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent'  => 'ceotheme_top',
        'title'   => '顶部用户弹窗',
        'fields'  => array(
            array(
                'id'         => 'navbar_user',
                'type'       => 'switcher',
                'title'      => '顶部导航登录注册按钮',
                'desc'       => '开启或关闭顶部导航登录注册按钮（关闭后将隐藏以下所有内容）',
                'default'    => true
            ),
            array(
                'id'         => 'navbar_user_desc',
                'type'       => 'switcher',
                'title'      => '登录注册按钮宣传语',
                'desc'       => '开启或关闭登录注册按钮宣传语',
                'default'    => true,
            ),
            array(
                'id'         => 'navbar_user_desc_set',
                'dependency' => array('navbar_user_desc', '==', true),
                'type'       => 'text',
                'title'      => '宣传语内容',
                'default'    => '欢迎登录体验更多功能',
            ),
            array(
                'type'       => 'notice',
                'style'      => 'warning',
                'content'    => '以下默认参数正常情况下无需修改！',
            ),
            array(
                'id'         => 'navbar_user_vip',
                'type'       => 'switcher',
                'title'      => '升级VIP模块',
                'desc'       => '开启或关闭VIP级别/升级VIP模块',
                'default'    => true,
            ),
            array(
                'id'         => 'navbar_user_vip_set',
                'type'       => 'fieldset',
                'dependency' => array('navbar_user_vip', '==', true),
                'title'      => 'VIP模块设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => 'VIP标题',
                        'default' => '升级VIP',
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '升级链接',
                        'default' => '/member/center/',
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => 'VIP描述',
                        'default' => '升级VIP尊享全站海量下载！',
                    ),
                ),
            ),
            array(
                'id'         => 'navbar_user_delivery_set',
                'type'       => 'fieldset',
                'title'      => '创作中心按钮设置',
                'fields'     => array(
                    array(
                        'id'      => 'icon',
                        'type'    => 'text',
                        'title'   => '按钮图标',
                        'default' => 'ceoicon-upload-cloud-2-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '按钮标题',
                        'default' => '创作中心',
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '按钮链接',
                        'default' => '/tougao',
                    ),
                ),
            ),
            array(
                'id'         => 'navbar_user_shop_set',
                'type'       => 'fieldset',
                'title'      => '商城中心按钮设置',
                'fields'     => array(
                    array(
                        'id'      => 'icon',
                        'type'    => 'text',
                        'title'   => '按钮图标',
                        'default' => 'ceoicon-user-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '按钮标题',
                        'default' => '商城中心',
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '按钮链接',
                        'default' => '/member/center/',
                    ),
                ),
            ),
        )
    ));

    /*
     * ------------------------------------------------------------------------------
     * 注册登录
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id'     => 'ceotheme_login',
        'icon'   => 'fa fa-share-alt',
        'title'  => '注册登录',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_login',
        'title'  => '基础设置 ',
        'fields' => array(
            array(
                'id'      => 'navbar_login',
                'type'    => 'button_set',
                'title'   => '登录注册模式',
                'options' => array(
                    '1' => '弹窗模式',
                    '2' => '页面模式',
                ),
                'default' => '1',
                'desc'    => '（默认弹窗模式）选择弹窗模式时可在任意界面弹出登录注册框，页面模式则跳转登录注册页面。',
            ),
            
            array(
                'id'         => 'login_slide',
                'type'       => 'group',
                'title'      => '左侧幻灯片设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'url',
                        'type'    => 'text',
                        'title'   => '图片链接',
                        'default' =>'/',
                    ),
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '幻灯片图片',
                        'desc'    => '建议尺寸：宽375px*高640px',
                    ),
                ),
                'default' => array(
                    array(
                        'img'     => get_template_directory_uri() . '/static/images/ceo-login-bg.jpg',
                    ),
                ),
            ),
            array(
                'id'           => 'login_page_img',
                'type'         => 'upload',
                'title'        => '页面模式登录注册背景图片',
                'desc'         => '建议尺寸：宽500px*高711px',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo-login-bg.jpg',
            ),
            array(
                'id'         => 'login_set',
                'type'       => 'fieldset',
                'title'      => '基础设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '注册登录协议标题',
                        'default' => '用户协议',
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '协议链接',
                    ),
                ),
            ),
            array(
                'id'         => 'login_allow_mail_suffix',
                'type'       => 'textarea',
                'title'      => '仅允许指定邮箱后缀注册',
                'desc'       => '邮箱后缀一行一个，可填写多个，如：@qq.com；留空则不限制',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （人机验证设置）',
            ),
            array(
                'id' => 'login_verify',
                'type' => 'switcher',
                'title' => '表单登录注册人机验证',
                'default' => false,
                'desc'    => '开启或关闭表单登录注册人机验证功能（开启则需要进行人机验证才能登录注册，关闭则无需）注意：开启后需要先配置人机验证功能',
            ),
            array(
                'id' => 'login_verify_type',
                'type' => 'radio',
                'title' => '选择人机验证方式',
                'inline' => true,
                'options' => array(
                    '1' => '腾讯云验证码',
                    '2' => 'vaptcha验证',
                ),
                'default' => '1',
                'dependency' => array('login_verify', '==', true)
            ),
        )
    ));
    
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_login',
        'title'  => 'QQ设置 ',
        'fields' => array(
            array(
                'id'      => 'qq_login',
                'type'    => 'switcher',
                'title'   => 'QQ登录',
                'default' => false,
            ),
            array(
                'type'       => 'content',
                'content'    => 'QQ登录申请：<a href="https://connect.qq.com" target="_blank">点击去申请</a>',
                'dependency' => array('qq_login', '==', true),
            ),
            array(
                'type'       => 'content',
                'content'    => 'QQ回调地址：'. get_stylesheet_directory_uri() . '/qq.php',
                'dependency' => array( 'qq_login', '==', true ),
            ),
            array(
                'id'         => 'qq_app_id',
                'type'       => 'text',
                'title'      => 'QQ-APP ID',
                'attributes' => array('style'=> 'width: 100%;'),
                'dependency' => array( 'qq_login', '==', true ),
            ),
            array(
                'id'         => 'qq_app_key',
                'type'       => 'text',
                'title'      => 'QQ-APP KEY',
                'attributes' => array('style'=> 'width: 100%;'),
                'dependency' => array( 'qq_login', '==', true ),
            ),
            array(
                'id'         => 'qq_reg_prefix',
                'type'       => 'text',
                'title'      => 'ID默认前缀',
                'desc'       => '留空则默认：CEO',
                'attributes' => array('style' => 'width: 100%;'),
                'dependency' => array('qq_login', '==', true),
            ),
            array(
                'id'         => 'qq_reg_suffix',
                'type'       => 'text',
                'title'      => '邮箱默认后缀',
                'desc'       => '留空则默认：@ceo.com',
                'attributes' => array('style' => 'width: 100%;'),
                'dependency' => array('qq_login', '==', true),
            ),
        )
    ));
    
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_login',
        'title'  => '微信登录 ',
        'fields' => array(
            // 微信登录
            array(
                'id'      => 'weixin_login',
                'type'    => 'switcher',
                'title'   => '微信登录（开放平台模式）',
                'default' => false,
            ),
            array(
                'type'       => 'content',
                'content'    => '微信登录申请：<a href="https://open.weixin.qq.com/" target="_blank">点击去申请</a>',
                'dependency' => array('weixin_login', '==', true),
            ),
            array(
                'id'         => 'oauth_weixin',
                'type'       => 'fieldset',
                'title'      => '微信登录配情',
                'fields'     => array(
                    array(
                        'id'         => 'backurl',
                        'type'       => 'text',
                        'title'      => '开放平台 回调地址',
                        'attributes' => array(
                            'readonly' => 'readonly',
                        ),
                        'default' => esc_url(home_url('')).'/oauth/weixin/callback',
                        'desc'    => '更换域名时请重置当前分区即可刷新为最新回调地址，操作前注意备份appid参数<br />注意：回调地址只需填写网站域名，无需填写http://或https://<br />例：www.ceotheme.com',
                    ),
                    array(
                        'id'      => 'appid',
                        'type'    => 'text',
                        'title'   => '开放平台 Appid',
                        'default' => '',
                    ),
                    array(
                        'id'      => 'appkey',
                        'type'    => 'text',
                        'title'   => '开放平台 AppSecret',
                        'default' => '',
                        'attributes'  => array(
                            'type'      => 'password',
                            'autocomplete' => 'off',
                        ),
                    ),
                ),
                'dependency' => array('weixin_login', '==', 'true'),
            ),
            array(
                'id'         => 'weixin_reg_prefix',
                'type'       => 'text',
                'title'      => 'ID默认前缀',
                'desc'       => '留空则默认：CEO',
                'attributes' => array('style' => 'width: 100%;'),
                'dependency' => array('weixin_login', '==', true),
            ),
            array(
                'id'         => 'weixin_reg_suffix',
                'type'       => 'text',
                'title'      => '邮箱默认后缀',
                'desc'       => '留空则默认：@ceo.com',
                'attributes' => array('style' => 'width: 100%;'),
                'dependency' => array('weixin_login', '==', true),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （微信公众号登录设置）',
            ),

            // 微信公众号登录
            array(
                'id'      => 'is_oauth_mpweixin',
                'type'    => 'switcher',
                'title'   => '微信公众号登录（公众号模式）',
                'desc'    => '总裁主题提示您：需要认证微信服务号，配置以下信息后，用户首次使用微信注册登录需要在你的网站扫码关注公众号后自动注册并登录，第二次登录直接扫码即可登录，同时可以直接在公众号内登录',
                'default' => false,
            ),
            array(
                'type'       => 'content',
                'content'    => '微信公众号登录申请：<a href="https://mp.weixin.qq.com/" target="_blank">点击去申请</a>',
                'dependency' => array('is_oauth_mpweixin', '==', true),
            ),
            array(
                'id'         => 'oauth_mpweixin',
                'type'       => 'fieldset',
                'title'      => '配置详情',
                'fields'     => array(
                    array(
                        'id'      => 'mp_appid',
                        'type'    => 'text',
                        'title'   => '公众号Appid',
                        'default' => '',
                    ),
                    array(
                        'id'      => 'mp_appsecret',
                        'type'    => 'text',
                        'title'   => '公众号appsecret',
                        'default' => '',
                        'attributes'  => array(
                            'type'         => 'password',
                            'autocomplete' => 'off',
                        ),
                    ),
                    array(
                        'id'      => 'mp_token',
                        'type'    => 'text',
                        'title'   => '公众号Token',
                        'default' => '',
                        'attributes'  => array(
                            'type'         => 'password',
                            'autocomplete' => 'off',
                        ),
                    ),

                    array(
                        'id'         => 'mp_backurl',
                        'type'       => 'text',
                        'title'      => '授权回调页面域名',
                        'attributes' => array(
                            'readonly' => 'readonly',
                        ),
                        'default'    => esc_url(home_url('/oauth/mpweixin/callback')),
                        'desc'       => '更换域名时请重置当前分区即可刷新为最新回调地址，操作前注意备份appid参数',
                    ),
                    array(
                        'id'         => 'mp_msg',
                        'type'       => 'textarea',
                        'title'      => '关注后自动回复的消息',
                        'default'    => '您好，感谢关注我们！发送“签到”可获得奖励，发生关键词可搜索站内相关文章~',
                    ),

                ),
                'dependency' => array('is_oauth_mpweixin', '==', 'true'),
            ),
            array(
                'id'         => 'mp_reg_prefix',
                'type'       => 'text',
                'title'      => 'ID默认前缀',
                'desc'       => '留空则默认：CEO',
                'attributes' => array('style' => 'width: 100%;'),
                'dependency' => array('is_oauth_mpweixin', '==', true),
            ),
            array(
                'id'         => 'mp_reg_suffix',
                'type'       => 'text',
                'title'      => '邮箱默认后缀',
                'desc'       => '留空则默认：@ceo.com',
                'attributes' => array('style' => 'width: 100%;'),
                'dependency' => array('is_oauth_mpweixin', '==', true),
            ),
            array(
                'id'         => 'mpweixin_menu',
                'type'       => 'repeater',
                'title'      => '自定义公众号菜单',
                'desc'       => '总裁主题提示您：<br>
自定义公众号菜单可创建3个一级菜单，每个一级菜单可创建5个二级菜单。<br>
一级菜单不超过4个汉字，二级菜单不超过8个汉字，超过的文字会被以“...”代替。<br>',
                'dependency' => array('is_oauth_mpweixin', '==', 'true'),
                'fields'     => array(
                    array(
                        'id'      => 'menu_name',
                        'type'    => 'text',
                        'title'   => '菜单名称',
                        'default' => '',
                    ),
                    array(
                        'id'      => 'menu_url',
                        'type'    => 'text',
                        'title'   => '菜单链接',
                        'default' => '',
                        'desc'    => '如果设置了二级菜单，那么一级菜单的菜单链接将会失效，这是公众号的规则。',
                    ),
                    array(
                        'id'      => 'mpweixin_menu_sub',
                        'type'    => 'repeater',
                        'title'   => '二级菜单',
                        'fields'  => array(
                            array(
                                'id'       => 'menu_name',
                                'type'     => 'text',
                                'title'    => '菜单名称',
                                'default'  => '',
                            ),
                            array(
                                'id'       => 'menu_url',
                                'type'     => 'text',
                                'title'    => '菜单链接',
                                'validate' => 'csf_validate_url',
                                'default'  => '',
                            ),
                            array(
                                'type'     => 'notice',
                                'style'    => 'warning',
                                'content'  => '分割线',
                            ),
                        ),
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
            array(
                'id'        => 'mpweixin_menu_update',
                'type'      => 'subheading',
                'title'     => '刷新公众号菜单',
                'dependency'=> array('is_oauth_mpweixin', '==', 'true'),
                'content'   => '<a href="admin-ajax.php?action=mpweixin_menu_update" target="_blank"><input type="button" value="点击刷新公众号菜单"></a> <br /><br />一：创建好公众号菜单，二：点击右上角保存，三：在点击刷新公众号菜单按钮',
            ),
        )
    ));
    
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_login',
        'title'  => '微博登录 ',
        'fields' => array(
            array(
                'id'         => 'weibo_login',
                'type'       => 'switcher',
                'title'      => '微博登录',
                'default'    => false,
            ),
            array(
                'type'       => 'content',
                'content'    => '微博登录申请：<a href="https://open.weibo.com/authentication/" target="_blank">点击去申请</a>',
                'dependency' => array('weibo_login', '==', true),
            ),
            array(
                'type'       => 'content',
                'content'    => '微博回调地址：'. get_page_link( get_option('joy_framework')['login_page'] ) .'/?type=sina',
                'dependency' => array( 'weibo_login', '==', true ),
            ),
            array(
                'id'         => 'weibo_app_key',
                'type'       => 'text',
                'title'      => '微博 App Key',
                'attributes' => array('style'=> 'width: 100%;'),
                'dependency' => array( 'weibo_login', '==', true ),
            ),
            array(
                'id'         => 'weibo_app_id',
                'type'       => 'text',
                'title'      => '微博 App Secret',
                'attributes' => array('style'=> 'width: 100%;'),
                'dependency' => array( 'weibo_login', '==', true ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_login',
        'title'  => '手机登录',
        'fields' => array(

            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '阿里云短信注册登录功能配置',
            ),
            array(
                'id'    => 'sms_login',
                'type'  => 'switcher',
                'title' => '手机短信注册登录',
                'default' => false,
            ),
            array(
                'id'    => 'sms_app_key',
                'type'  => 'text',
                'title' => 'AccessKey ID',
                'dependency'   => array( 'sms_login', '==', true ),
            ),
            array(
                'id'    => 'sms_app_secret',
                'type'  => 'text',
                'title' => 'AccessKey Secret',
                'dependency'   => array( 'sms_login', '==', true ),
            ),
            array(
                'id'    => 'sms_app_sign',
                'type'  => 'text',
                'title' => '签名',
                'dependency'   => array( 'sms_login', '==', true ),
            ),
            array(
                'id'    => 'sms_app_template',
                'type'  => 'text',
                'title' => '短信模板',
                'dependency'   => array( 'sms_login', '==', true ),
            ),
            array(
                'id'         => 'sms_reg_prefix',
                'type'       => 'text',
                'title'      => 'ID默认前缀',
                'desc'       => '留空则默认：CEO',
                'attributes' => array('style' => 'width: 100%;'),
                'dependency' => array('sms_login', '==', true),
            ),
            array(
                'id'         => 'sms_reg_suffix',
                'type'       => 'text',
                'title'      => '邮箱默认后缀',
                'desc'       => '留空则默认：@ceo.com',
                'attributes' => array('style' => 'width: 100%;'),
                'dependency' => array('sms_login', '==', true),
            ),
            array(
                'id'      => 'sms_send_verify',
                'type'    => 'switcher',
                'title'   => '发送短信人机验证',
                'default' => false,
                'desc'    => '开启或关闭发送短信人机验证功能（开启则需要进行人机验证才能发送短信，关闭则无需）注意：开启后需要先配置人机验证功能',
            ),
            array(
                'id' => 'sms_send_verify_type',
                'type' => 'radio',
                'title' => '选择人机验证方式',
                'inline' => true,
                'options' => array(
                    '1' => '腾讯云验证码',
                    '2' => 'vaptcha验证',
                ),
                'default' => '1',
                'dependency' => array('sms_send_verify', '==', true),
            ),
        )
    ));

    /*
     * ------------------------------------------------------------------------------
     * 用户中心
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id'    => 'ceotheme_user',
        'icon'  => 'fa fa-user',
        'title' => '用户中心',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_user',
        'title'  => '基础设置 ',
        'fields' => array(
            array(
                'id'      => 'ceo_user_btn',
                'type'    => 'switcher',
                'title'   => '用户模块快捷按钮',
                'desc'    => '开启或关闭商城快捷按钮（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'         => 'ceo_user_btn_set',
                'type'       => 'fieldset',
                'title'      => '商城快捷按钮设置',
                'dependency' => array('ceo_user_btn', '==', true),
                'fields'     => array(
                    array(
                        'id'      => 'title1',
                        'type'    => 'text',
                        'title'   => '按钮1标题',
                        'default' => '创作中心',
                    ),
                    array(
                        'id'      => 'icon1',
                        'type'    => 'text',
                        'title'   => '按钮1图标',
                        'default' => 'ceoicon-edit-box-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'link1',
                        'type'    => 'text',
                        'title'   => '按钮1链接',
                        'default' => '/tougao',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                    array(
                        'id'      => 'title2',
                        'type'    => 'text',
                        'title'   => '按钮2标题',
                        'default' => '账户设置',
                    ),
                    array(
                        'id'      => 'icon2',
                        'type'    => 'text',
                        'title'   => '按钮2图标',
                        'default' => 'ceoicon-user-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'link2',
                        'type'    => 'text',
                        'title'   => '按钮2链接',
                        'default' => '/member/user-settings/',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线（用户中心菜单设置）',
            ),
            array(
                'id'      => 'ceo_user_nav_center',
                'type'    => 'switcher',
                'title'   => '商城中心',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_user_nav_center_icon',
                'dependency' => array('ceo_user_nav_center', '==', true),
                'type'    => 'text',
                'title'   => '菜单图标',
                'default' => '',
                'desc'    => '留空则不显示，按需设置<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
            ),
            array(
                'id'      => 'ceo_user_nav_property',
                'type'    => 'switcher',
                'title'   => '我的资产',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_user_nav_property_icon',
                'dependency' => array('ceo_user_nav_property', '==', true),
                'type'    => 'text',
                'title'   => '菜单图标',
                'default' => '',
                'desc'    => '留空则不显示，按需设置<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
            ),
            array(
                'id'      => 'ceo_user_nav_order',
                'type'    => 'switcher',
                'title'   => '我的订单',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_user_nav_order_icon',
                'dependency' => array('ceo_user_nav_order', '==', true),
                'type'    => 'text',
                'title'   => '菜单图标',
                'default' => '',
                'desc'    => '留空则不显示，按需设置<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
            ),
            array(
                'id'      => 'ceo_user_nav_download',
                'type'    => 'switcher',
                'title'   => '我的下载',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_user_nav_download_icon',
                'dependency' => array('ceo_user_nav_download', '==', true),
                'type'    => 'text',
                'title'   => '菜单图标',
                'default' => '',
                'desc'    => '留空则不显示，按需设置<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
            ),
            array(
                'id'      => 'ceo_user_nav_card',
                'type'    => 'switcher',
                'title'   => '我的卡券',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_user_nav_card_icon',
                'dependency' => array('ceo_user_nav_card', '==', true),
                'type'    => 'text',
                'title'   => '菜单图标',
                'default' => '',
                'desc'    => '留空则不显示，按需设置<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
            ),
            array(
                'id'      => 'ceo_user_nav_reward',
                'type'    => 'switcher',
                'title'   => '我的推广',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_user_nav_reward_icon',
                'dependency' => array('ceo_user_nav_reward', '==', true),
                'type'    => 'text',
                'title'   => '菜单图标',
                'default' => '',
                'desc'    => '留空则不显示，按需设置<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
            ),
            array(
                'id'      => 'ceo_user_nav_income',
                'type'    => 'switcher',
                'title'   => '我的收益',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_user_nav_income_icon',
                'dependency' => array('ceo_user_nav_income', '==', true),
                'type'    => 'text',
                'title'   => '菜单图标',
                'default' => '',
                'desc'    => '留空则不显示，按需设置<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
            ),
            array(
                'id'      => 'ceo_user_nav_authentication',
                'type'    => 'switcher',
                'title'   => '我的认证',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_user_nav_authentication_icon',
                'dependency' => array('ceo_user_nav_authentication', '==', true),
                'type'    => 'text',
                'title'   => '菜单图标',
                'default' => '',
                'desc'    => '留空则不显示，按需设置<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
            ),
            array(
                'id'      => 'ceo_user_nav_post',
                'type'    => 'switcher',
                'title'   => '我的发布',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_user_nav_post_icon',
                'dependency' => array('ceo_user_nav_post', '==', true),
                'type'    => 'text',
                'title'   => '菜单图标',
                'default' => '',
                'desc'    => '留空则不显示，按需设置<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
            ),
            array(
                'id'      => 'ceo_user_nav_collection',
                'type'    => 'switcher',
                'title'   => '我的收藏',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_user_nav_collection_icon',
                'dependency' => array('ceo_user_nav_collection', '==', true),
                'type'    => 'text',
                'title'   => '菜单图标',
                'default' => '',
                'desc'    => '留空则不显示，按需设置<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
            ),
            array(
                'id'      => 'ceo_user_nav_users_icon',
                'type'    => 'text',
                'title'   => '个人中心菜单图标',
                'default' => '',
                'desc'    => '留空则不显示，按需设置<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
            ),
            array(
                'id'      => 'ceo_user_nav_logout_icon',
                'type'    => 'text',
                'title'   => '退出登录菜单图标',
                'default' => '',
                'desc'    => '留空则不显示，按需设置<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_user',
        'title'  => '实名认证',
        'fields' => array(
            array(
                'id'         => 'ceo_user_auth_page_title',
                'type'       => 'fieldset',
                'title'      => '页面基础设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '页面标题',
                        'default' => '实名认证'
                    ),
                    array(
                        'id'      => 'subtitle',
                        'type'    => 'text',
                        'title'   => '页面副标题',
                        'default' => '实名认证用户可拥有更多会员权利'
                    ),
                    array(
                        'id'      => 'prompt',
                        'type'    => 'text',
                        'title'   => '认证提示语',
                        'default' => '信息仅用于身份认证，我们将严格保护您的数据和隐私安全'
                    ),
                ),
            ),
            array(
                'id'         => 'ceo_user_auth_app_code',
                'type'       => 'text',
                'title'      => '实名认证APPCODE',
                'desc'       => '实名认证接口申请：<a href="https://market.aliyun.com/products/57000002/cmapi026109.html?#sku=yuncode20109000025" target="_blank">点击去申请</a>',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '预留占位分割线',
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_user',
        'title'  => '创作中心',
        'fields' => array(
            array(
                'id'         => 'tougao_down_url_upload',
                'type'       => 'switcher',
                'title'      => '创作中心上传资源',
                'default'    => false,
                'desc'       => '开启或关闭创作中心上传资源（开启则允许直接上传资源，关闭则不允许）',
            ),
            array(
                'id'          => 'tougao_cat_ids',
                'type'        => 'select',
                'title'       => '创作中心允许投稿的分类',
                'placeholder' => '',
                'desc'        => '如果不选择，则默认显示允许投稿全部分类',
                'chosen'      => true,
                'multiple'    => true,
                'options'     => 'categories',
            ),
        )
    ));
    
    require __DIR__ .'/../../ceoshop/inc/options/ceotheme-admin.php';
    
    /*
     * ------------------------------------------------------------------------------
     * 首页设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id'    => 'ceotheme_home',
        'icon'  => 'fa fa-home',
        'title' => '首页设置',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '首页布局',
        'fields' => array(
            array(
                'id'           => 'layout',
                'type'         => 'sorter',
                'title'        => '首页模块布局拖拽设置',
                'default'      => array(
                    'enabled'  => array(
                        'slide'       => '幻灯模块',
                        'special'     => '专题模块',
                        'infinite'    => '无限分类',
                        'cooperate'   => '合作伙伴',
                        'link'        => '友链模块',
                    ),
                    'disabled' => array(
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent'  => 'ceotheme_home',
        'title'   => '幻灯模块设置',
        'fields'  => array(
            array(
                'id'      => 'slide_type',
                'type'    => 'image_select',
                'title'   => '幻灯片样式',
                'options' => array(
                    '1' => get_template_directory_uri() . '/static/admin-img/ceo-home-slide-1.jpg',
                    '2' => get_template_directory_uri() . '/static/admin-img/ceo-home-slide-2.jpg',
                ),
                'default' => '1'
            ),
            //幻灯1
            array(
                'id'         => 'ceo_home_slide_1_bg',
                'type'       => 'upload',
                'dependency' => array('slide_type', '==', '1'),
                'title'      => '背景图',
                'default'    => get_template_directory_uri() . '/static/images/ceo-slide-1.png',
            ),
            array(
                'id'         => 'ceo_home_slide_1_title',
                'type'       => 'fieldset',
                'dependency' => array('slide_type', '==', '1'),
                'title'      => '轮播标题',
                'fields'     => array(
                    array(
                        'id'      => 'title1',
                        'type'    => 'text',
                        'title'   => '模块轮播标题【1】',
                        'desc'    => '搜索框上方轮播标题',
                        'default' => '总裁主题，原创主题设计'
                    ),
                    array(
                        'id'      => 'title2',
                        'type'    => 'text',
                        'title'   => '模块轮播标题【2】',
                        'desc'    => '搜索框上方轮播标题',
                        'default' => '总裁主题，高端WordPress主题开发'
                    ),
                    array(
                        'id'      => 'title3',
                        'type'    => 'text',
                        'title'   => '模块轮播标题【3】',
                        'desc'    => '搜索框上方轮播标题',
                        'default' => '海量优质PPT模板，免费下载'
                    ),
                ),
            ),
            array(
                'id'         => 'ceo_home_slide_1_desc',
                'type'       => 'text',
                'dependency' => array('slide_type', '==', '1'),
                'title'      => '副标题',
                'desc'       => '轮播标题下副标题',
                'default'    => '专业办公资源平台助你高效办公'
            ),
            array(
                'id'         => 'ceo_home_slide_1_right_btn',
                'type'       => 'fieldset',
                'dependency' => array('slide_type', '==', '1'),
                'title'      => '搜索框设置',
                'fields'     => array(
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => '搜索框默认语',
                        'default' => '海量精选模板素材供你挑选，立即输入关键字搜索'
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '右侧按钮标题',
                        'default' => '上传作品'
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '右侧按钮链接',
                        'default' => '/tougao'
                    ),
                ),
            ),
            array(
                'id'         => 'ceo_home_slide_1_cms',
                'type'       => 'group',
                'max'        => '5',
                'title'      => 'CMS模块设置',
                'desc'       => '最少/最多添加5个模块',
                'accordion_title_prefix' => '模块',
                'accordion_title_number' => true,
                'dependency' => array('slide_type', '==', '1'),
                'fields'     => array(
                    array(
                        'id'      => 'slide_1_cms_style',
                        'type'    => 'image_select',
                        'title'   => 'CMS模块样式',
                        'options' => array(
                            'cms1'  => get_template_directory_uri() . '/static/admin-img/ceo-home-slide-1-cms1.jpg',
                            'cms2'  => get_template_directory_uri() . '/static/admin-img/ceo-home-slide-1-cms2.jpg',
                            'cms3'  => get_template_directory_uri() . '/static/admin-img/ceo-home-slide-1-cms3.jpg',
                        ),
                        'default' => 'cms1'
                    ),
                    array(
                        'id'         => 'cms1',
                        'dependency' => array('slide_1_cms_style', '==', 'cms1'),
                        'type'       => 'repeater',
                        'max'        => '4',
                        'title'      => '四格样式',
                        'desc'       => '最少/最多添加4个模块',
                        'fields'     => array(
                            array(
                                'id'    => 'title',
                                'type'  => 'text',
                                'title' => '标题'
                            ),
                            array(
                                'id'    => 'link',
                                'type'  => 'text',
                                'title' => '链接'
                            ),
                            array(
                                'id'           => 'img',
                                'type'         => 'upload',
                                'title'        => '图片链接',
                                'desc'         => '图片尺寸32x32（等比例）',
                                'library'      => 'image',
                                'placeholder'  => 'http://',
                                'button_title' => '上传',
                                'remove_title' => '删除',
                            ),

                        ),
                    ),
                    array(
                        'id'         => 'cms2',
                        'type'       => 'repeater',
                        'dependency' => array('slide_1_cms_style', '==', 'cms2'),
                        'max'        => '6',
                        'title'      => '文本样式',
                        'desc'       => '最少/最多添加6个模块',
                        'fields'     => array(
                            array(
                                'id'    => 'title',
                                'type'  => 'text',
                                'title' => '标题'
                            ),
                            array(
                                'id'    => 'link',
                                'type'  => 'text',
                                'title' => '链接'
                            ),
                        ),
                    ),
                    array(
                        'id'         => 'cms3',
                        'dependency' => array('slide_1_cms_style', '==', 'cms3'),
                        'type'       => 'repeater',
                        'max'        => '3',
                        'title'      => '三格样式',
                        'desc'       => '最少/最多添加3个模块',
                        'fields'     => array(
                            array(
                                'id'    => 'title',
                                'type'  => 'text',
                                'title' => '标题'
                            ),
                            array(
                                'id'    => 'link',
                                'type'  => 'text',
                                'title' => '链接'
                            ),
                            array(
                                'id'           => 'img',
                                'type'         => 'upload',
                                'title'        => '图片',
                                'desc'         => '图片尺寸48x48（等比例）',
                                'library'      => 'image',
                                'placeholder'  => 'http://',
                                'button_title' => '上传',
                                'remove_title' => '删除',
                            ),

                        ),
                    ),
                ),
            ),
            //幻灯2
            array(
                'id'         => 'ceo_home_slide_2_bg',
                'type'       => 'upload',
                'title'      => '背景图',
                'default'    => get_template_directory_uri() . '/static/images/ceo-footer-banner.jpg',
                'dependency' => array('slide_type', '==', '2'),
            ),
            array(
                'id'         => 'ceo_home_slide_2_title',
                'type'       => 'fieldset',
                'dependency' => array('slide_type', '==', '2'),
                'title'      => '幻灯设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '主标题',
                        'default' => '海量网站模板、网页特效 下载平台'
                    ),
                    array(
                        'id'      => 'subtitle',
                        'type'    => 'text',
                        'title'   => '副标题',
                        'default' => '让前端开发工作更轻松、高效、便捷'
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => '搜索框默认语',
                        'default' => '海量精选模板素材供你挑选，立即输入关键字搜索'
                    ),
                ),
            ),
            array(
                'id'     => 'ceo_home_slide_2_cms',
                'type'   => 'group',
                'max'    => '4',
                'title'  => 'CMS模块设置',
                'desc'   => '最少/最多添加4个模块',
                'dependency' => array('slide_type', '==', '2'),
                'fields' => array(
                    array(
                        'id'    => 'mktitle',
                        'type'  => 'text',
                        'title' => '模块标题',
                    ),
                    array(
                        'id'    => 'img',
                        'type'  => 'upload',
                        'title' => '模块图标',
                    ),
                    array(
                        'id'    => 'links',
                        'type'  => 'text',
                        'title' => '模块链接',
                    ),
                    array(
                        'id'         => 'tags',
                        'type'       => 'repeater',
                        'title'      => '按钮设置',
                        'fields'     => array(
                            array(
                                'id'    => 'title',
                                'type'  => 'text',
                                'title' => '标题'
                            ),
                            array(
                                'id'    => 'link',
                                'type'  => 'text',
                                'title' => '链接'
                            ),
                        ),
                    ),
                ),
            ),
            array(
                'id'      => 'ceo_home_slide_2_cms_roll',
                'type'    => 'switcher',
                'dependency' => array('slide_type', '==', '2'),
                'title'   => 'CMS滚动模块',
                'desc'    => '开启或关闭CMS滚动模块',
                'default' => true,
            ),
            array(
                'id'     => 'ceo_home_slide_2_cms_roll_set',
                'type'   => 'group',
                'title'  => 'CMS滚动模块设置',
                'desc'   => '最少添加8个模块',
                'dependency' => array('slide_type', '==', '2'),
                'fields' => array(
                    array(
                        'id'    => 'title',
                        'type'  => 'text',
                        'title' => '标题',
                    ),
                    array(
                        'id'    => 'desc',
                        'type'  => 'text',
                        'title' => '描述',
                    ),
                    array(
                        'id'    => 'link',
                        'type'  => 'text',
                        'title' => '链接',
                    ),
                    array(
                        'id'    => 'img',
                        'type'  => 'upload',
                        'title' => '图标',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '专题模块设置',
        'fields' => array(
            array(
                'id'      => 'ceo_home_special_title',
                'type'    => 'text',
                'title'   => '模块标题',
                'default' => '热门专题'
            ),
            array(
                'id'      => 'ceo_home_special_url',
                'type'    => 'text',
                'title'   => '查看更多链接',
                'default' => '/special'
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '模块内容以创建的专题展示 <a href="/wp-admin/edit-tags.php?taxonomy=special" style="color: #0a8eff;">前往创建专题</a>',
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '无限分类设置',
        'fields' => array(
            array(
                'id'     => 'infinite',
                'type'   => 'repeater',
                'button_title'=> '添加模块',
                'title'  => '无限分类模块设置',
                'fields' => array(
                    array(
                        'id'          => 'index_card_style',
                        'type'        => 'image_select',
                        'title'       => '模块样式',
                        'options'     => array(
                            '1'    => get_template_directory_uri() . '/static/admin-img/ceo-category-1.jpg',
                            '2'    => get_template_directory_uri() . '/static/admin-img/ceo-category-2.jpg',
                            '3'    => get_template_directory_uri() . '/static/admin-img/ceo-category-3.jpg',
                            '4'    => get_template_directory_uri() . '/static/admin-img/ceo-category-4.jpg',
                            '5'    => get_template_directory_uri() . '/static/admin-img/ceo-category-5.jpg',
                            '6'    => get_template_directory_uri() . '/static/admin-img/ceo-category-6.jpg',
                        ),
                        'default'     => '1',
                        'desc'        => '[样式1：卡片布局1]  [样式2：卡片布局2]  [样式3：卡片布局3]  [样式4：视频布局]  [样式5：音频布局]  [样式6：软件布局]'
                    ),
                    array(
                        'id'          => 'id',
                        'type'        => 'select',
                        'title'       => '选择分类栏目',
                        'placeholder' => '选择分类栏目',
                        'options'     => 'categories',
                    ),
                    array(
                        'id'          => 'title',
                        'type'        => 'text',
                        'title'       => '自定义模块标题（选填）',
                    ),
                    array(
                        'id'          => 'list',
                        'type'        => 'image_select',
                        'title'       => '选择列表显示排数',
                        'desc'        => '[样式1：五个一排]  [样式2：四个一排]',
                        'options'     => array(
                            '1'  => get_template_directory_uri() . '/static/admin-img/ceo-list-1.jpg',
                            '2'  => get_template_directory_uri() . '/static/admin-img/ceo-list-2.jpg',
                        ),
                        'default'     => '1',
                    ),
                    array(
                        'id'          => 'licat',
                        'type'        => 'select',
                        'title'       => '分类切换',
                        'desc'        => '选择右侧分类切换模块要展示的分类',
                        'chosen'      => true,
                        'multiple'    => true,
                        'options'     => 'categories',
                    ),
                    array(
                        'id'          => 'num',
                        'type'        => 'text',
                        'title'       => '显示数量',
                        'default'     => '10',
                    ),
                    array(
                        'id'          => 'img_switch',
                        'type'        => 'switcher',
                        'title'       => '图片组',
                        'desc'        => '开启或关闭图片组',
                        'default'     => true
                    ),
                    array(
                        'id'          => 'img_radio',
                        'type'        => 'radio',
                        'inline'      => true,
                        'dependency'  => array('img_switch', '==', true),
                        'title'       => '图片组显示排数',
                        'options'     => array(
                            '1' => '一排2个',
                            '2' => '一排3个',
                            '3' => '一排4个',
                        ),
                        'default'     => '2'
                    ),
                    array(
                        'id'          => 'img_set',
                        'type'        => 'group',
                        'dependency'  => array('img_switch', '==', true),
                        'title'       => '图片组设置',
                        'desc'        => '适用于广告、宣传图等',
                        'fields'      => array(
                            array(
                              'id'         => 'img_title',
                              'type'       => 'text',
                              'title'      => '图片标题',
                            ),
                            array(
                              'id'         => 'img_url',
                              'type'       => 'text',
                              'title'      => '图片链接',
                            ),
                            array(
                                'id'       => 'img_images',
                                'type'     => 'upload',
                                'title'    => '上传图片',
                                'desc'     => '一排2个尺寸，一排3个尺寸，一排4个尺寸',
                                'default'  => get_template_directory_uri() . '/static/images/ceotheme-logo.png',
                            ),
                        ),
                    ),
                    array(
                        'type'        => 'notice',
                        'style'       => 'warning',
                        'content'     => '分割线',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '合作伙伴设置',
        'fields' => array(
            array(
                'id'      => 'ceo_home_cooperate_title',
                'type'    => 'text',
                'title'   => '模块标题',
                'default' => '合作伙伴'
            ),
            array(
                'id'     => 'ceo_home_cooperate_box',
                'type'   => 'group',
                'title'  => '模块内容设置',
                'fields' => array(
                    array(
                        'id'       => 'title',
                        'type'     => 'text',
                        'title'    => '标题',
                        'default'  => ''
                    ),
                    array(
                        'id'       => 'url',
                        'type'     => 'text',
                        'title'    => '链接',
                        'default'  => ''
                    ),
                    array(
                        'id'       => 'img',
                        'type'     => 'upload',
                        'title'    => '图片',
                        'default'  => get_template_directory_uri() . '/static/images/ceotheme-logo.png',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '友链模块设置',
        'fields' => array(
            array(
                'id'        => 'ceo_home_link_url',
                'type'      => 'text',
                'title'     => '友链申请地址',
                'desc'      => '<a href="/wp-admin/link-manager.php" style="color: #0a8eff;">前往添加友链</a>',
                'default'   => '/links'
            ),
            array(
                'id'        => 'ceo_home_new',
                'type'      => 'switcher',
                'title'     => '最新发布',
                'desc'      => '开启或关闭最新发布',
                'default'   => true
            ),
            array(
                'id'        => 'ceo_home_new_num',
                'type'      => 'text',
                'title'     => '最新发布显示数量',
                'dependency'   => array('ceo_home_new', '==', true),
                'default'   => '30'
            ),
            array(
                'id'        => 'ceo_home_tag',
                'type'      => 'switcher',
                'title'     => '热门标签',
                'desc'      => '开启或关闭热门标签',
                'default'   => true
            ),
        )
    ));
 /*
 * ------------------------------------------------------------------------------
 * 分类页设置
 * ------------------------------------------------------------------------------
 */
    CSF::createSection($ceotheme, array(
        'id'    => 'ceotheme_cat',
        'icon'  => 'fa fa-folder-open',
        'title' => '分类设置',
    ));
    CSF::createSection($ceotheme, array(
        'parent'  => 'ceotheme_cat',
        'title'   => '分类基础设置',
        'fields'  => array(
            array(
                'id'          => 'target_blank',
                'type'        => 'switcher',
                'title'       => '新窗口打开文章',
                'desc'        => '点击列表文章跳转新窗口（开启则跳转新窗口，关闭则当前窗口跳转）',
                'label'       => '',
                'default'     => false,
            ),
            array(
                'id'          => 'default_thumb',
                'type'        => 'switcher',
                'title'       => '默认缩略图',
                'desc'        => '开启或关闭显示默认缩略图，已设置的文章缩略图依旧显示！',
                'default'     =>  true
            ),
            array(
                'id'           => 'default_thum',
                'type'         => 'upload',
                'dependency'   => array('default_thumb', '==', true),
                'title'        => '设置文章默认缩略图',
                'desc'         => '文章没有设置独立特色图时则调用该图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceotheme_no.jpg',
            ),
            array(
                'id'           => 'category_default_bg',
                'type'         => 'upload',
                'title'        => '分类默认背景图片',
                'desc'         => '也可以在后台分类目录中独立设置分类背景图片~未独立设置则自动调用该设置中默认背景图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_cat',
        'title'  => '资源分类设置',
        'fields' => array(
            array(
                'id'      => 'ceo_cat_top',
                'type'    => 'switcher',
                'title'   => '分类菜单顶部模块总开关',
                'desc'    => '开启或关闭分类菜单顶部统计模块（关闭后将隐藏以下相关内容）',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_top_whole',
                'type'    => 'switcher',
                'title'   => '分类作品全部数量统计',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_top_today',
                'type'    => 'switcher',
                'title'   => '分类作品今日数量统计',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_search',
                'type'    => 'switcher',
                'title'   => '分类搜索框',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_btn',
                'type'    => 'switcher',
                'title'   => '分类自定义按钮',
                'default' => true,
            ),
            array(
                'id'     => 'ceo_cat_btn_set',
                'type'   => 'group',
                'dependency'  => array('ceo_cat_btn', '==', true),
                'title'  => '分类自定义按钮设置',
                'fields' => array(
                    array(
                        'id'    => 'title',
                        'type'  => 'text',
                        'title' => '按钮标题',
                    ),
                    array(
                        'id'    => 'link',
                        'type'  => 'text',
                        'title' => '按钮链接',
                    ),
                    array(
                        'id'    => 'icon',
                        'type'  => 'text',
                        'title' => '按钮图标',
                        'desc'  => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                ),
                'default' => array(
                    array(
                        'title' => '升级会员',
                        'link'  => '/vip',
                        'icon'  => 'ceoicon-vip-crown-2-line',
                    ),
                    array(
                        'title' => '上传作品',
                        'link'  => '/tougao',
                        'icon'  => 'ceoicon-upload-cloud-2-line',
                    ),
                ),
                
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线',
            ),
            array(
                'id'          => 'ceo_cat_nav',
                'type'        => 'switcher',
                'title'       => '一级分类导航',
                'desc'        => '开启或关闭一级分类导航',
                'default'     => true,
            ),
            array(
                'id'          => 'ceo_cat_nav_1',
                'type'        => 'select',
                'dependency'  => array('ceo_cat_nav', '==', true),
                'title'       => '一级主分类菜单配置',
                'desc'        => '排序规则以设置的顺序为准',
                'placeholder' => '选择分类',
                'inline'      => true,
                'chosen'      => true,
                'multiple'    => true,
                'options'     => 'categories',
                'query_args'  => array(
                    'orderby' => 'count',
                    'order'   => 'DESC',
                    'parent'  => 0,
                ),
            ),
            array(
                'id'      => 'ceo_cat_nav_title1',
                'type'    => 'text',
                'title'   => '自定义一级分类标题',
                'default' => '分类',
            ),
            array(
                'id'      => 'ceo_cat_nav_title2',
                'type'    => 'text',
                'title'   => '自定义二级分类标题',
                'default' => '场景',
            ),
            array(
                'id'      => 'ceo_cat_nav_title3',
                'type'    => 'text',
                'title'   => '自定义三级分类标题',
                'default' => '更多',
            ),
            array(
                'id'      => 'ceo_cat_wss',
                'type'    => 'switcher',
                'title'   => '排序筛选',
                'desc'    => '开启或关闭分类排序筛选',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_ss',
                'type'    => 'switcher',
                'title'   => '价格筛选',
                'desc'    => '开启或关闭分类价格筛选',
                'default' => true,
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线',
            ),
            array(
                'id'      => 'ceo_cat_vip',
                'type'    => 'switcher',
                'title'   => '列表资源VIP图标',
                'desc'    => '开启或关闭列表资源VIP图标',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_collection',
                'type'    => 'switcher',
                'title'   => '列表资源收藏按钮',
                'desc'    => '开启或关闭列表资源收藏按钮',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_down_title',
                'type'    => 'text',
                'title'   => '下载按钮标题',
                'default' => '立即下载',
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_cat',
        'title'  => '文章分类设置',
        'fields' => array(
            array(
                'id'         => 'news_slide',
                'type'       => 'group',
                'title'      => '分类幻灯片设置',
                'desc'       => '幻灯片尺寸523px*280px',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'url',
                        'type'    => 'text',
                        'title'   => '图片链接',
                        'default' =>'/',
                    ),
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '幻灯片图片',
                    ),
                ),
            ),
            array(
                'id'         => 'news_slide_right1',
                'type'       => 'fieldset',
                'title'      => '右侧图片（上）',
                'fields'     => array(
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '上传图片',
                        'desc'    => '图片尺寸252x130',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '链接',
                    ),
                ),
            ),
            array(
                'id'         => 'news_slide_right2',
                'type'       => 'fieldset',
                'title'      => '右侧图片（下）',
                'fields'     => array(
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '上传图片',
                        'desc'    => '图片尺寸252x130',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '链接',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '列表文章设置（以下功能开启则显示，关闭则隐藏）',
            ),
            array(
                'id'      => 'ceo_cat_fl',
                'type'    => 'switcher',
                'title'   => '文章所属分类',
                'desc'    => '隐藏/显示列表文章所属分类',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_tx',
                'type'    => 'switcher',
                'title'   => '作者头像',
                'desc'    => '隐藏/显示列表文章作者头像',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_mc',
                'type'    => 'switcher',
                'title'   => '作者名称',
                'desc'    => '隐藏/显示列表文章作者名称',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_rq',
                'type'    => 'switcher',
                'title'   => '发布日期',
                'desc'    => '隐藏/显示列表发布日期',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_dz',
                'type'    => 'switcher',
                'title'   => '文章点赞量',
                'desc'    => '隐藏/显示列表文章点赞量',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_ll',
                'type'    => 'switcher',
                'title'   => '文章浏览量',
                'desc'    => '隐藏/显示列表文章浏览量',
                'default' => true,
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_cat',
        'title'  => '高级分类筛选',
        'fields' => array(
            array(
                'id'      => 'ceo_choice',
                'type'    => 'switcher',
                'title'   => '高级自定义筛选',
                'desc'    => '高级自定义筛选功能主要为资源进行详细属性分类筛选<b><font color="red">需要注意每个筛选名称，必须有两个或两个属性选项，否则无法使用且会报错</font></b>',
                'default' => false,
            ),
            array(
                'id'         => 'ceo_choice_sz',
                'type'       => 'group',
                'title'      => '自定义筛选设置',
                'max'        => '50',
                'fields'     => array(
                    array(
                        'id'      => 'meta_name',
                        'type'    => 'text',
                        'title'   => '主筛选标题',
                        'default' => '颜色',
                        'desc'    => '例如：颜色、格式、型号等主筛选标题<b><font color="red">注意：任何筛选主标题必须唯一，不可重复，只要不一样就行！！！</font></b>'
                    ),
                    array(
                        'id'      => 'meta_ua',
                        'type'    => 'text',
                        'title'   => '标题英文标识',
                        'default' => 'ceo_meta_1',
                        'desc'    => '例如：ceo_meta_1、abc_1等英文标识<b><font color="red">注意：任何筛选英文标识必须唯一，不可重复，只要不一样就行！！！建议英文+数字序号排序</font></b>'
                    ),
                    array(
                        'id'          => 'meta_category',
                        'type'        => 'select',
                        'title'       => '只在该分类下显示高级筛选属性',
                        'placeholder' => '全部显示',
                        'chosen'      => true,
                        'multiple'    => true,
                        'options'     => 'categories',
                        'desc'        => '默认为全部显示，需要在某个分类才显示时请选择该分类'
                    ),
                    array(
                        'id'     => 'meta_opt',
                        'type'   => 'group',
                        'title'  => '属性选项',
                        'fields' => array(
                            array(
                                'id'      => 'opt_name',
                                'type'    => 'text',
                                'title'   => '属性选项名称',
                                'default' => '黄色',
                                'desc'    => '例如：黄色、PSD、型号1等属性选项名称<b><font color="red">注意：任何属性选项名称必须唯一，不可重复，只要不一样就行！！！</font></b>'
                            ),
                            array(
                                'id'      => 'opt_ua',
                                'type'    => 'text',
                                'title'   => '选项英文标识',
                                'default' => 'ceo_opt_1',
                                'desc'    => '例如：ceo_opt_1、def_1等英文标识<b><font color="red">注意：任何属性选项英文标识必须唯一，不可重复，只要不一样就行！！！建议英文+数字序号排序</font></b>'
                            ),
                        ),
                    ),

                ),
                'dependency' => array('ceo_choice', '==', 'true'),
            ),

        ),
    ));
    /*
 * ------------------------------------------------------------------------------
 * 侧边栏设置
 * ------------------------------------------------------------------------------
 */
    CSF::createSection($ceotheme, array(
        'id'    => 'ceotheme_side',
        'icon'  => 'fa fa-th-list',
        'title' => '右侧边栏',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_side',
        'title'  => '侧边栏布局',
        'fields' => array(
            array(
                'id'           => 'sidebar_layout',
                'type'         => 'sorter',
                'title'        => '侧边栏布局拖拽设置',
                'default'      => array(
                    'enabled'      => array(
                        'author'   => '作者模块',
                        'focus'    => '社交模块',
                        'imgtext'  => '图文展示',
                        'ad'       => '广告模块',
                        'text'     => '热门文章',
                    ),
                    'disabled'     => array(
                        
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_side',
        'title'  => '社交模块',
        'fields' => array(
            array(
                'id'           => 'side_focus_img',
                'type'         => 'upload',
                'title'        => '社交模块背景图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo-focus-bg.jpg',
            ),
            array(
                'id'           => 'side_focus_ma',
                'type'         => 'upload',
                'title'        => '模块二维码',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo-ma.png',
            ),
            array(
                'id'      => 'side_focus_title',
                'type'    => 'text',
                'title'   => '模块标题',
                'default' => '扫一扫关注公众号'
            ),
            array(
                'id'      => 'side_focus_subtitle',
                'type'    => 'text',
                'title'   => '副标题',
                'default' => '掌握最新图集尽在总裁主题'
            ),
            array(
                'id'     => 'side_focus_btn',
                'type'   => 'group',
                'title'  => '按钮设置',
                'fields' => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '按钮标题',
                        'default' => '加入QQ群'
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '按钮链接',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_side',
        'title'  => '图文展示',
        'fields' => array(
            array(
                'id'      => 'imgtext_title',
                'type'    => 'text',
                'title'   => '标题',
                'default' => '图文展示'
            ),
            array(
                'id'      => 'imgtext_url',
                'type'    => 'text',
                'title'   => '右侧链接',
                'default' => '/'
            ),
            array(
                'id'          => 'imgtext_cat',
                'type'        => 'select',
                'title'       => '选择展示分类',
                'placeholder' => '请选择分类',
                'chosen'      => true,
                'multiple'    => true,
                'options'     => 'categories',
            ),
            array(
                'id'      => 'imgtext_orderby',
                'type'    => 'radio',
                'title'   => '排序',
                'inline'  => true,
                'options' => array(
                    'date'          => esc_html__('日期'),
                    'rand'          => esc_html__('随机'),
                    'comment_count' => esc_html__('评论数量'),
                    'id'            => esc_html__('文章ID'),
                ),
                'default' => 'date',
            ),
            array(
                'id'      => 'imgtext_number',
                'type'    => 'text',
                'title'   => '显示数量',
                'default' => '6'
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_side',
        'title'  => '热门文章',
        'fields' => array(
            array(
                'id'      => 'text_title',
                'type'    => 'text',
                'title'   => '标题',
                'default' => '热门文章'
            ),
            array(
                'id'      => 'text_url',
                'type'    => 'text',
                'title'   => '右侧链接',
                'default' => '/'
            ),
            array(
                'id'          => 'text_cat',
                'type'        => 'select',
                'title'       => '选择展示分类',
                'placeholder' => '请选择分类',
                'options'     => 'categories',
            ),
            array(
                'id'      => 'text_num',
                'type'    => 'text',
                'title'   => '显示数量',
                'default' => '10'
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_side',
        'title'  => '广告模块',
        'fields' => array(
            array(
                'id'     => 'side_ad',
                'type'   => 'group',
                'title'  => '广告模块设置',
                'fields' => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '广告标题',
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '广告连接',
                    ),
                    array(
                        'id'           => 'img',
                        'type'         => 'upload',
                        'title'        => '广告图片',
                        'library'      => 'image',
                        'placeholder'  => 'http://',
                        'button_title' => '上传',
                        'remove_title' => '删除',
                    ),
                ),
            ),
        )
    ));
    /*
 * ------------------------------------------------------------------------------
 * 文章页设置
 * ------------------------------------------------------------------------------
 */
    CSF::createSection($ceotheme, array(
        'id'    => 'ceotheme_single',
        'icon'  => 'fa fa-window-maximize',
        'title' => '内页设置',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_single',
        'title'  => '资源内页设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线',
            ),
            array(
                'id'      => 'ceo_single_shop_btn',
                'type'    => 'fieldset',
                'title'   => '下载模块按钮设置',
                'fields'  => array(
                    array(
                        'id'      => 'down',
                        'type'    => 'text',
                        'title'   => '购买按钮',
                        'default' => '立即购买',
                    ),
                    array(
                        'id'      => 'cdown',
                        'type'    => 'text',
                        'title'   => '已购买按钮标题',
                        'default' => '立即下载',
                    ),
                    array(
                        'id'      => 'demo',
                        'type'    => 'text',
                        'title'   => '演示按钮',
                        'default' => '查看演示',
                    ),
                    array(
                        'id'         => 'hide_text_l',
                        'type'       => 'text',
                        'title'      => '隐藏信息自定义1',
                        'default'    => '隐藏信息',
                    ),
                    array(
                        'id'         => 'hide_text_2',
                        'type'       => 'text',
                        'title'      => '隐藏信息自定义2',
                        'default'    => '隐藏信息',
                    ),
                ),
            ),
            array(
                'id'      => 'ceo_single_shop_login',
                'type'    => 'switcher',
                'title'   => '登录后显示完整内容',
                'desc'    => '开启则模糊隐藏内容，提示登录后查看完整内容',
                'default' => false,
            ),
            array(
                'id'      => 'ceo_single_shop_login_title',
                'type'    => 'text',
                'dependency'  => array('ceo_single_shop_login', '==', true),
                'title'   => '提示语',
                'default' => '1秒登录查看完整内容',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线',
            ),
            array(
                'id'      => 'ceo_single_shop_price',
                'type'    => 'switcher',
                'title'   => '作品售价',
                'desc'    => '开启则显示，关闭则隐藏',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_single_shop_price_title',
                'type'    => 'text',
                'dependency'  => array('ceo_single_shop_price', '==', true),
                'title'   => '自定义标题',
                'default' => '作品售价',
            ),
            array(
                'id'      => 'ceo_single_shop_vip',
                'type'    => 'switcher',
                'title'   => '会员权益',
                'desc'    => '开启则显示，关闭则隐藏',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_single_shop_vip_title',
                'type'    => 'text',
                'dependency'  => array('ceo_single_shop_vip', '==', true),
                'title'   => '自定义标题',
                'default' => '会员权益',
            ),
            array(
                'id'      => 'ceo_single_shop_id',
                'type'    => 'switcher',
                'title'   => '作品ID',
                'desc'    => '开启则显示，关闭则隐藏',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_single_shop_id_title',
                'type'    => 'text',
                'dependency'  => array('ceo_single_shop_id', '==', true),
                'title'   => '自定义标题',
                'default' => '作品ID',
            ),
            array(
                'id'      => 'ceo_single_shop_author',
                'type'    => 'switcher',
                'title'   => '发布作者',
                'desc'    => '开启则显示，关闭则隐藏',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_single_shop_author_title',
                'type'    => 'text',
                'dependency'  => array('ceo_single_shop_author', '==', true),
                'title'   => '自定义标题',
                'default' => '发布作者',
            ),
            array(
                'id'      => 'ceo_single_shop_cat',
                'type'    => 'switcher',
                'title'   => '作品类型',
                'desc'    => '开启则显示，关闭则隐藏',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_single_shop_cat_title',
                'type'    => 'text',
                'dependency'  => array('ceo_single_shop_cat', '==', true),
                'title'   => '自定义标题',
                'default' => '作品类型',
            ),
            array(
                'id'      => 'ceo_single_shop_time',
                'type'    => 'switcher',
                'title'   => '发布时间',
                'desc'    => '开启则显示，关闭则隐藏',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_single_shop_time_title',
                'type'    => 'text',
                'dependency'  => array('ceo_single_shop_time', '==', true),
                'title'   => '自定义标题',
                'default' => '发布时间',
            ),
            array(
                'id'      => 'ceo_single_shop_share',
                'type'    => 'switcher',
                'title'   => '分享作品',
                'desc'    => '开启则显示，关闭则隐藏',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_single_shop_share_title',
                'type'    => 'text',
                'dependency'  => array('ceo_single_shop_share', '==', true),
                'title'   => '自定义标题',
                'default' => '分享作品',
            ),
            array(
                'id'      => 'ceo_single_shop_views',
                'type'    => 'switcher',
                'title'   => '浏览量',
                'desc'    => '开启则显示，关闭则隐藏',
                'default' => true,
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线',
            ),
            array(
                'id'      => 'ceo_single_shop_complaint',
                'type'    => 'switcher',
                'title'   => '投诉按钮',
                'desc'    => '开启则显示，关闭则隐藏',
                'default' => true,
            ),
            array(
                'id'     => 'ceo_single_shop_complaint_set',
                'type'   => 'fieldset',
                'dependency'  => array('ceo_single_shop_complaint', '==', true),
                'title'  => '投诉按钮设置',
                'fields' => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '按钮标题',
                        'default' => '投诉举报',
                    ),
                    array(
                        'id'         => 'link',
                        'type'       => 'text',
                        'title'      => '按钮链接',
                        'desc'       => '默认为QQ客服链接，使用默认链接则将88888888修改为你的QQ号',
                        'default'    => 'tencent://Message/?Uin=88888888&amp;websiteName=#=&amp;Menu=yes'
                    ),
                ),
            ),
            array(
                'id'      => 'ceo_single_shop_copyright',
                'type'    => 'switcher',
                'title'   => '版权声明',
                'desc'    => '开启则显示，关闭则隐藏',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_single_shop_copyright_set',
                'type'    => 'fieldset',
                'dependency'  => array('ceo_single_shop_copyright', '==', true),
                'title'   => '版权声明设置',
                'fields'  => array(
                    array(
                        'id'         => 'title',
                        'type'       => 'text',
                        'title'      => '标题',
                        'default'    => '版权声明',
                    ),
                    array(
                        'id'         => 'desc',
                        'type'       => 'textarea',
                        'title'      => '内容',
                        'default'    => '任何单位或个人认为本网页内容可能涉嫌侵犯其合法权益，请及时和客服联系。本站将会第一时间移除相关涉嫌侵权的内容。本站关于用户或其发布的相关内容均由用户自行提供，用户依法应对其提供的任何信息承担全部责任，本站不对此承担任何法律责任。'
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线',
            ),
            array(
                'id'      => 'ceo_single_shop_collection',
                'type'    => 'switcher',
                'title'   => '收藏按钮',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_single_shop_tag',
                'type'    => 'switcher',
                'title'   => '作品标签',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_single_shop_tag_title',
                'type'    => 'text',
                'dependency'  => array('ceo_single_shop_tag', '==', true),
                'title'   => '作品标签自定义标题',
                'default' => '作品标签',
            ),
            array(
                'id'      => 'ceo_single_shop_relevant',
                'type'    => 'switcher',
                'title'   => '相关资源推荐模块',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_single_shop_relevant_title',
                'type'    => 'text',
                'dependency'  => array('ceo_single_shop_relevant', '==', true),
                'title'   => '模块自定义标题',
                'default' => '相关主题作品推荐',
            ),
            array(
                'id'      => 'ceo_single_shop_relevant_num',
                'type'    => 'text',
                'dependency'  => array('ceo_single_shop_relevant', '==', true),
                'title'   => '模块数量',
                'default' => '20',
            ),
            array(
                'id'      => 'ceo_single_shop_relevant_tag',
                'type'    => 'switcher',
                'title'   => '相关标签推荐模块',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_single_shop_relevant_tag_title',
                'type'    => 'text',
                'dependency'  => array('ceo_single_shop_relevant_tag', '==', true),
                'title'   => '模块自定义标题',
                'default' => '可能感兴趣的作品',
            ),
            array(
                'id'      => 'ceo_single_shop_other',
                'type'    => 'switcher',
                'title'   => '作者作品模块',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_single_shop_other_title',
                'type'    => 'text',
                'dependency'  => array('ceo_single_shop_other', '==', true),
                'title'   => '模块自定义标题',
                'default' => '作者其他作品',
            ),
            array(
                'id'      => 'ceo_single_shop_ad',
                'type'    => 'switcher',
                'title'   => '按钮广告模块',
                'desc'    => '开启则显示，关闭则隐藏',
                'default' => true,
            ),
            array(
                'id'     => 'ceo_single_shop_ad_set',
                'type'   => 'fieldset',
                'dependency'  => array('ceo_single_shop_ad', '==', true),
                'title'  => '模块设置',
                'fields' => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                        'default' => '上传作品，提升收入',
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '链接',
                        'default' => '/tougao',
                    ),
                    array(
                        'id'      => 'icon',
                        'type'    => 'text',
                        'title'   => '图标',
                        'default' => 'ceoicon-funds-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_single',
        'title'  => '文章内容设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （内页信息设置，以下开关开启则显示功能，关闭则隐藏功能）',
            ),
            array(
                'id'      => 'single_info_tx',
                'type'    => 'switcher',
                'title'   => '文章作者头像',
                'default' => true,
            ),
            array(
                'id'      => 'single_info_mc',
                'type'    => 'switcher',
                'title'   => '文章作者名称',
                'default' => true,
            ),
            array(
                'id'      => 'single_info_fl',
                'type'    => 'switcher',
                'title'   => '文章所属分类',
                'default' => true,
            ),
            array(
                'id'      => 'single_info_rq',
                'type'    => 'switcher',
                'title'   => '文章发布日期',
                'default' => true,
            ),
            array(
                'id'      => 'single_info_ll',
                'type'    => 'switcher',
                'title'   => '文章浏览数量',
                'default' => true,
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （以下开关开启则显示功能，关闭则隐藏功能）',
            ),
            array(
                'id'      => 'single_foo_sc',
                'type'    => 'switcher',
                'title'   => '文章收藏按钮',
                'default' => true,
            ),
            array(
                'id'      => 'single_foo_dz',
                'type'    => 'switcher',
                'title'   => '文章点赞按钮',
                'default' => true,
            ),
            array(
                'id'      => 'single_foo_bq',
                'type'    => 'switcher',
                'title'   => '文章底部版权',
                'default' => true,
            ),
            array(
                'id'         => 'single_foo_bq_text',
                'dependency' => array('single_foo_bq', '==', 'true'),
                'type'       => 'textarea',
                'title'      => '版权文字',
            ),
            array(
                'id'      => 'single_foo_tag',
                'type'    => 'switcher',
                'title'   => '文章底部标签',
                'default' => true,
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （以下开关开启则显示功能，关闭则隐藏功能）',
            ),
            array(
                'id'      => 'single_foo_fy',
                'type'    => 'switcher',
                'title'   => '底部文章分页',
                'default' => true,
            ),
            //发表评论模块
            array(
                'id'      => 'comments_close',
                'type'    => 'switcher',
                'title'   => '整站评论',
                'desc'    =>'开启或关闭整站评论功能，不需要评论可以关闭（按钮开启既关闭整站评论）',
                'default' => false
            ),
            array(
                'id'         => 'comments_title',
                'type'       => 'text',
                'title'      => '发表评论标题',
                'dependency' => array('comments_close', '==', 'false'),
                'default'    => '发表评论'
            ),
            //相关文章模块
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （相关文章模块设置）',
            ),
            array(
                'id'      => 'xg_show',
                'type'    => 'switcher',
                'title'   => '底部相关文章',
                'default' => true,
            ),
            array(
                'id'         => 'xg_title',
                'type'       => 'text',
                'title'      => '相关文章标题',
                'dependency' => array('xg_show', '==', 'true'),
                'default'    => '相关推荐'
            ),
            array(
                'id'         => 'xg_num',
                'type'       => 'text',
                'title'      => '相关文章数量',
                'dependency' => array('xg_show', '==', 'true'),
                'default'    => '6'
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_single',
        'title'  => '内页优化设置',
        'fields' => array(
            array(
                'id'      => 'auto_add_tags',
                'type'    => 'switcher',
                'title'   => '自动添加已有关键词 ',
                'default' => false,
            ),
            array(
                'id'      => 'single_tag_link',
                'type'    => 'switcher',
                'title'   => 'Tag标签自动内链 ',
                'default' => false,
            ),
            array(
                'id'      => 'single_nofollow',
                'type'    => 'switcher',
                'title'   => '文章外链自动添加nofollow',
                'default' => true,
                'subtitle'=> '防止导出权重',
            ),
            array(
                'id'      => 'single_img_alt',
                'type'    => 'switcher',
                'title'   => '图片自动添加alt',
                'default' => true,
            ),
            array(
                'id'      => 'single_upload_filter',
                'type'    => 'switcher',
                'title'   => '上传文件重命名',
                'default' => true,
            ),
            array(
                'id'      => 'single_delete_post_and_img',
                'type'    => 'switcher',
                'title'   => '删除文章时删除图片附件',
                'default' => true,
            ),

        )
    ));
    CSF::createSection($ceotheme, array(
        'id'    => 'ceotheme_page',
        'title' => '单页设置',
        'icon'  => 'fa fa-window-restore',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_page',
        'title'  => '单页基础设置',
        'fields' => array(
            array(
                'id'      => 'ceo_page_top',
                'type'    => 'switcher',
                'title'   => '单页顶部快捷菜单模块',
                'default' => true,
            ),
            array(
                'id'     => 'ceo_page_top_set',
                'type'   => 'group',
                'dependency'  => array('ceo_page_top', '==', true),
                'title'  => '模块设置',
                'desc'   => '最少添加5个模块',
                'fields' => array(
                    array(
                        'id'    => 'title',
                        'type'  => 'text',
                        'title' => '标题',
                    ),
                    array(
                        'id'    => 'subtitle',
                        'type'  => 'text',
                        'title' => '副标题',
                    ),
                    array(
                        'id'    => 'link',
                        'type'  => 'text',
                        'title' => '链接',
                    ),
                    array(
                        'id'    => 'img',
                        'type'  => 'upload',
                        'title' => '图标',
                        'desc'  => '图标尺寸60x60（等比例）',
                    ),
                ),
                
            ),
            //默认页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '默认页设置',
            ),
            array(
                'id'      => 'page-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'page-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            //作者主页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '作者主页设置',
            ),
            array(
                'id'      => 'author-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-page-customized-bg.jpg',
            ),
            //网址导航页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '网址导航页设置',
            ),
            array(
                'id'      => 'site-title',
                'type'    => 'text',
                'title'   => '页面标题',
                'default' => '网址导航',
            ),
            array(
                'id'      => 'site-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            
            array(
                'id'      => 'site-btn',
                'type'    => 'switcher',
                'title'   => '申请收录按钮',
                'default' => true,
            ),
            array(
                'id'       => 'site-btn-desc',
                'type'     => 'textarea',
                'dependency' => array('site-btn', '==', true),
                'title'    => '申请收录提示信息',
                'desc'     => '请务必按照以上格式修改或添加',
                'default'  => '<p>欢迎优质网站提交收录，本站免费收录，提交后需后台审核，请勿重复提交。</p>
<p>申请网站收录前请先加上本站链接；</p>
<p>本站不收录违法违规站点；</p>
<p>禁止一切产品营销、广告联盟类型的站点，优先通过原创、内容相近的网站；</p>',
            ),
            //搜索页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '搜索页设置',
            ),
            array(
                'id'      => 'search-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            //标签页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '标签页设置',
            ),
            array(
                'id'      => 'tag-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'tag-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            //快捷键页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '快捷键页设置',
            ),
            array(
                'id'      => 'quick-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'quick-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            //颜色大全页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '颜色大全页设置',
            ),
            array(
                'id'      => 'color-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'color-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            //投稿页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '投稿页设置',
            ),
            array(
                'id'      => 'togao-title',
                'type'    => 'text',
                'title'   => '主标题',
                'default' => '创作中心',
            ),
            array(
                'id'      => 'togao-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'togao-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_page',
        'title'  => '会员页面设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '会员页面顶部设置',
            ),
            
            array(
                'id'          => 'vip_page_bg_type',
                'type'        => 'radio',
                'title'       => '顶部模块背景样式',
                'inline'      => true,
                'options'     => array(
                    '1' => '样式一【背景颜色】',
                    '2' => '样式二【背景图片】',
                ),
                'default'     => '1',
            ),
            array(
                'id'           => 'vip_page_bg_color',
                'type'         => 'color',
                'dependency'  => array('vip_page_bg_type', '==', '1'),
                'title'        => '背景颜色',
                'default'      => '#215dff',
            ),
            array(
                'id'          => 'vip_page_bg_img',
                'type'        => 'upload',
                'dependency'  => array('vip_page_bg_type', '==', '2'),
                'title'       => '背景图片',
            ),
            array(
                'id'      => 'vip-subtitle',
                'type'    => 'text',
                'title'   => '顶部标题',
                'default' => '开通超级VIP会员 畅享随心下载',
            ),
            array(
                'id'         => 'vip_desc_sz',
                'type'       => 'repeater',
                'title'      => '顶部介绍设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '会员特权模块设置',
            ),
            array(
                'id'      => 'vip_tq_title',
                'type'    => 'text',
                'title'   => '特权模块标题',
                'default' => '会员特权',
            ),
            array(
                'id'      => 'vip_tq_subtitle',
                'type'    => 'text',
                'title'   => '特权模块副标题',
                'default' => '加入VIP，尊享海量丰富作品和功能体验',
            ),
            array(
                'id'         => 'vip_tq_sz',
                'type'       => 'group',
                'title'      => '会员特权内容设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'textarea',
                        'title'   => '介绍',
                    ),
                    array(
                        'id'      => 'icon',
                        'type'    => 'text',
                        'title'   => '图标',
                        'default' => 'ceoicon-vip-crown-2-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '合作企业模块设置',
            ),
            array(
                'id'         => 'vip_enterprise',
                'type'       => 'fieldset',
                'title'      => '合作企业模块设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '模块标题',
                        'default' => '全球创新企业的信任之选',
                    ),
                    array(
                        'id'      => 'subtitle',
                        'type'    => 'text',
                        'title'   => '模块副标题',
                        'default' => '累计服务企业500万+',
                    ),
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '模块图片',
                        'default' => get_template_directory_uri() . '/static/images/ceo-page-customized-enterprise.png',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '常见问题设置',
            ),
            array(
                'id'      => 'vip_qa_title',
                'type'    => 'text',
                'title'   => '常见问题标题',
                'default' => '常见问题',
            ),
            array(
                'id'      => 'vip_qa_subtitle',
                'type'    => 'text',
                'title'   => '常见问题副标题',
                'default' => '为您解决烦忧，总裁主题势在必行！',
            ),
            array(
                'id'         => 'vip_qa_sz',
                'type'       => 'group',
                'title'      => '常见问题内容设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'content',
                        'type'    => 'textarea',
                        'title'   => '内容',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_page',
        'title'  => '邀请页面设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '邀请页面顶部设置',
            ),
            array(
                'id'         => 'invited_top',
                'type'       => 'fieldset',
                'title'      => '邀请页面顶部设置',
                'fields'     => array(
                    array(
                        'id'      => 'bg',
                        'type'    => 'upload',
                        'title'   => '背景',
                        'default' => get_template_directory_uri() . '/static/images/ceo-page-invited-bg.jpg',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                        'default' => '邀请好友来总裁主题一起领好礼',
                    ),
                    array(
                        'id'      => 'subtitle',
                        'type'    => 'text',
                        'title'   => '副标题',
                        'default' => '奖励上不封顶，心动不如行动',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '邀请页面攻略模块设置',
            ),
            array(
                'id'      => 'invited_module2_title',
                'type'    => 'text',
                'title'   => '邀请页面攻略模块标题',
                'default' => '邀请好友攻略',
            ),
            array(
                'id'         => 'invited_module2',
                'type'       => 'group',
                'max'        => '4',
                'title'      => '邀请页面攻略模块设置',
                'desc'       => '最少/最多添加4个模块',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'icon',
                        'type'    => 'text',
                        'title'   => '图标',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                ),
                'default' => array(
                    array(
                        'title'     => '复制推广链接发送给好友',
                        'icon'      => 'ceoicon-file-copy-line',
                    ),
                    array(
                        'title'     => '好友通过链接注册',
                        'icon'      => 'ceoicon-link-unlink',
                    ),
                    array(
                        'title'     => '奖励立即自动到账',
                        'icon'      => 'ceoicon-gift-line',
                    ),
                    array(
                        'title'     => '每次邀请都有奖励',
                        'icon'      => 'ceoicon-red-packet-line',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '邀请页面介绍模块设置',
            ),
            array(
                'id'      => 'invited_module4_title',
                'type'    => 'text',
                'title'   => '邀请页面介绍模块标题',
                'default' => '去哪里邀请和分享',
            ),
            array(
                'id'         => 'invited_module4',
                'type'       => 'group',
                'title'      => '邀请页面介绍模块设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'content',
                        'type'    => 'text',
                        'title'   => '内容',
                    ),
                    array(
                        'id'      => 'icon',
                        'type'    => 'text',
                        'title'   => '图标',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                ),
                'default' => array(
                    array(
                        'title'     => '分享给需要素材的人',
                        'content'   => '需要PPT、Word、Excel等素材，他们可能是你身边的同事、朋友，只要是有素材需要的人。',
                        'icon'      => 'ceoicon-emotion-line',
                    ),
                    array(
                        'title'     => '分享到你的社交圈中',
                        'content'   => '创作人社区、交流学习社群、朋友圈、作品交流平台，邀请更多人来浏览和购买素材，坐等返现收钱。',
                        'icon'      => 'ceoicon-team-line',
                    ),
                    array(
                        'title'     => '社交平台中邀请',
                        'content'   => '在短视频或评论中加入你的邀请链接，在拍摄剪辑或视频制作教程中加入你的专属链接。',
                        'icon'      => 'ceoicon-smartphone-line',
                    ),
                    array(
                        'title'     => '邀请你的客户来购买',
                        'content'   => '如果你的客户需要素材，邀请他们来购买，分享链接给他们，帮助他们找到合适的素材。',
                        'icon'      => 'ceoicon-group-line',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '邀请页面推广模块设置',
            ),
            array(
                'id'         => 'invited_module5',
                'type'       => 'fieldset',
                'title'      => '邀请页面推广模块设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                        'default' => '准备好躺着赚钱了吗？',
                    ),
                    array(
                        'id'      => 'content',
                        'type'    => 'text',
                        'title'   => '内容',
                        'default' => '邀请的人越多，获得的奖励数量越多，多劳多得，快来试试吧！',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '常见问题模块设置',
            ),
            array(
                'id'      => 'invited_module6_title',
                'type'    => 'text',
                'title'   => '常见问题模块标题',
                'default' => '常见问题',
            ),
            array(
                'id'         => 'invited_module6',
                'type'       => 'group',
                'title'      => '常见问题内容',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'content',
                        'type'    => 'textarea',
                        'title'   => '内容',
                    ),
                ),
                'default' => array(
                    array(
                        'title'   => '1、如何邀请新用户？',
                        'content' => '点击立即邀请生成专属推广链接，分享给新用户，新用户通过专属链接在平台注册后，您将立即获得奖励。',
                    ),
                    array(
                        'title'   => '2、如何获得消费佣金奖励？',
                        'content' => '通过你的专属链接在平台购买了素材，你将获得消费额%的佣金奖励，可在推广佣金记录中查看。每个用户每次消费都可以获得奖励。',
                    ),
                    array(
                        'title'   => '3、邀请奖励如何发放？',
                        'content' => '好友通过你的专属链接注册后的奖励会立即到账，每个用户通过你的专属链接注册后都会立即赠送奖励',
                    ),
                    array(
                        'title'   => '4、推广佣金奖励如何发放？',
                        'content' => '好友通过你的专属链接注册后的消费都会记录佣金收益余额',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_page',
        'title'  => '专题页面设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '专题页面顶部设置',
            ),
            array(
                'id'      => 'special-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'id'      => 'special-subtitle',
                'type'    => 'text',
                'title'   => '副标题',
                'default' => '每一次设计,都可能此生不再遇到',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线',
            ),
            array(
                'id'      => 'special-bg-db',
                'type'    => 'upload',
                'title'   => '专题内页顶部背景图',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
                'desc'    => '也可以在后台专题目录中独立设置专题内页顶部背景图~未独立设置则自动调用该设置中默认专题内页顶部背景图'
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_page',
        'title'  => '定制页面设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '定制页面顶部设置',
            ),
            array(
                'id'         => 'customized_top',
                'type'       => 'fieldset',
                'title'      => '定制页面顶部设置',
                'fields'     => array(
                    array(
                        'id'      => 'bg',
                        'type'    => 'upload',
                        'title'   => '背景',
                        'default' => get_template_directory_uri() . '/static/images/ceo-page-customized-bg.jpg',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                        'default' => '专业人士为您提供 高品质的定制服务',
                    ),
                    array(
                        'id'      => 'subtitle',
                        'type'    => 'text',
                        'title'   => '副标题',
                        'default' => '设计师一对一服务，为您提供一站式私人定制服务，迅速提升个人/企业形象',
                    ),
                    array(
                        'id'      => 'ctntitle',
                        'type'    => 'text',
                        'title'   => '按钮标题',
                        'default' => '立即定制',
                    ),
                    array(
                        'id'      => 'btnlink',
                        'type'    => 'text',
                        'title'   => '按钮链接',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '定制页面顶部模块设置',
            ),
            array(
                'id'         => 'customized_cms',
                'type'       => 'group',
                'title'      => '定制页面顶部模块设置',
                'desc'       => '最少/最多添加4个模块',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'subtitle',
                        'type'    => 'text',
                        'title'   => '副标题',
                    ),
                    array(
                        'id'      => 'icon',
                        'type'    => 'text',
                        'title'   => '图标',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                ),
                'default' => array(
                    array(
                        'title'     => '高品质',
                        'subtitle'  => '设计师标准：设计好、服务好、态度正、质量好',
                        'icon'      => 'ceoicon-shield-star-line',
                    ),
                    array(
                        'title'     => '高效率',
                        'subtitle'  => '专业设计师，提供高效率的设计服务，及时解决您的问题',
                        'icon'      => 'ceoicon-shield-flash-line',
                    ),
                    array(
                        'title'     => '超省心',
                        'subtitle'  => '规定时间交稿，积极、快速改稿、快速回复',
                        'icon'      => 'ceoicon-shield-check-line',
                    ),
                    array(
                        'title'     => '超安全',
                        'subtitle'  => '稿件不用担心泄密，统一加密处理，第三人无法查看',
                        'icon'      => 'ceoicon-shield-cross-line',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '服务内容模块设置',
            ),
            array(
                'id'         => 'customized_service',
                'type'       => 'fieldset',
                'title'      => '服务内容模块设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                        'default' => '服务内容',
                    ),
                    array(
                        'id'      => 'subtitle',
                        'type'    => 'text',
                        'title'   => '副标题',
                        'default' => '累计为上万企事业单位和个人提供PPT设计服务，深得客户的信赖，凸显核心价值！',
                    ),
                ),
            ),
            array(
                'id'         => 'customized_service_set',
                'type'       => 'group',
                'title'      => '服务内容',
                'desc'       => '最少添加4个模块',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '服务标题',
                    ),
                    array(
                        'id'      => 'bg',
                        'type'    => 'upload',
                        'title'   => '服务背景',
                    ),
                    array(
                        'id'      => 'textarea',
                        'type'    => 'textarea',
                        'title'   => '服务内容',
                        'default' => '<p>    </p>',
                        'desc'    => '使用<code>p</code>标签包裹',
                    ),
                    array(
                        'id'      => 'price',
                        'type'    => 'text',
                        'title'   => '服务价格',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '服务流程模块设置',
            ),
            array(
                'id'         => 'customized_process',
                'type'       => 'fieldset',
                'title'      => '服务流程模块设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '模块标题',
                        'default' => '服务流程',
                    ),
                    array(
                        'id'      => 'subtitle',
                        'type'    => 'text',
                        'title'   => '模块副标题',
                        'default' => '拥有国内专业职业规划师及HR资源确保服务的专业性及可靠性',
                    ),
                    array(
                        'id'      => 'bg',
                        'type'    => 'upload',
                        'title'   => '模块背景',
                        'default' => get_template_directory_uri() . '/static/images/ceo-page-customized-process.jpg',
                    ),
                ),
            ),
            array(
                'id'         => 'customized_process_set',
                'type'       => 'group',
                'max'        => '6',
                'accordion_title_number' => true,
                'title'      => '服务流程内容',
                'desc'       => '最少/最多添加6个模块',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '流程标题',
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => '流程内容',
                    ),
                ),
                'default' => array(
                    array(
                        'title' => '选择服务',
                        'desc'  => '填写选择所在行业及工作年限，保证为您提供最有针对性的服务',
                    ),
                    array(
                        'title' => '填写信息',
                        'desc'  => '填写选择所在行业及工作年限，保证为您提供最有针对性的服务',
                    ),
                    array(
                        'title' => '支付成功',
                        'desc'  => '根据所选服务项目完成支付，仅支持微信支付与支付宝付款',
                    ),
                    array(
                        'title' => '导师匹配',
                        'desc'  => '通过行业与简历专业分析，2小时内匹配最合适的导师',
                    ),
                    array(
                        'title' => '进行创作',
                        'desc'  => '简历订制优化3-5个工作日内完成，多伦服务将进行多次修改反馈',
                    ),
                    array(
                        'title' => '交付成果',
                        'desc'  => '购买服务10天内可通过在线客服反馈，我们将为您解答任何问题',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '合作企业模块设置',
            ),
            array(
                'id'         => 'customized_enterprise',
                'type'       => 'fieldset',
                'title'      => '合作企业模块设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '模块标题',
                        'default' => '全球创新企业的信任之选',
                    ),
                    array(
                        'id'      => 'subtitle',
                        'type'    => 'text',
                        'title'   => '模块副标题',
                        'default' => '累计服务企业500万+',
                    ),
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '模块图片',
                        'default' => get_template_directory_uri() . '/static/images/ceo-page-customized-enterprise.png',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '常见问题模块设置',
            ),
            array(
                'id'      => 'customized_question',
                'type'    => 'text',
                'title'   => '常见问题模块标题',
                'default' => '常见问题',
            ),
            array(
                'id'         => 'customized_question_set',
                'type'       => 'group',
                'title'      => '常见问题内容',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'content',
                        'type'    => 'textarea',
                        'title'   => '内容',
                    ),
                ),
                'default' => array(
                    array(
                        'title'   => '1、我该如何定制？',
                        'content' => '提交需求上传原始材料→联系定制客服QQ，沟通确认详细需求及价格等信息→ 一次性付清全款→客服安排设计师按照约定时间内容制作交稿。',
                    ),
                    array(
                        'title'   => '2、我什么时候拿到源文件？',
                        'content' => '在确认终稿之前，作品版权归设计师所有，您只能拿到带有设计师水印的PPT图片版本；在确认终稿之后，作品版权归您所有，您将拿到作品的源文件。',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_page',
        'title'  => '申请入驻设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '入驻页面顶部设置',
            ),
            array(
                'id'         => 'apply_top',
                'type'       => 'fieldset',
                'title'      => '入驻页面顶部设置',
                'fields'     => array(
                    array(
                        'id'      => 'bg',
                        'type'    => 'upload',
                        'title'   => '背景',
                        'default' => get_template_directory_uri() . '/static/images/ceo-page-customized-bg.jpg',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                        'default' => '总裁设计师火热集结招募中',
                    ),
                    array(
                        'id'      => 'subtitle',
                        'type'    => 'text',
                        'title'   => '副标题',
                        'default' => '加入总裁设计师，做自己喜欢的事情赚钱',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '入驻页面顶部模块设置',
            ),
            array(
                'id'         => 'apply_cms',
                'type'       => 'group',
                'title'      => '入驻页面顶部模块设置',
                'desc'       => '最少/最多添加4个模块',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'subtitle',
                        'type'    => 'text',
                        'title'   => '副标题',
                    ),
                    array(
                        'id'      => 'icon',
                        'type'    => 'text',
                        'title'   => '图标',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                ),
                'default' => array(
                    array(
                        'title'     => '自由时间',
                        'subtitle'  => '可兼职可全职，时间地点不限，全由你自行安排',
                        'icon'      => 'ceoicon-macbook-line',
                    ),
                    array(
                        'title'     => '多劳多得',
                        'subtitle'  => '每月收益及作品质量及数量挂钩，还有额外奖励发放',
                        'icon'      => 'ceoicon-hand-coin-line',
                    ),
                    array(
                        'title'     => '增加收入',
                        'subtitle'  => '平台为你推荐作品，你发布的作品每次销售都可获得收益',
                        'icon'      => 'ceoicon-funds-line',
                    ),
                    array(
                        'title'     => '提升价值',
                        'subtitle'  => '你的作品将获得更多人的关注与使用，让你的创作产生更多价值',
                        'icon'      => 'ceoicon-trophy-line',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '招募条件模块设置',
            ),
            array(
                'id'         => 'apply_center',
                'type'       => 'fieldset',
                'title'      => '招募条件模块设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '模块标题',
                        'default' => '我们需要这样的你',
                    ),
                    array(
                        'id'      => 'subtitle',
                        'type'    => 'text',
                        'title'   => '模块副标题',
                        'default' => '寻找“能分辨美丑，有一技在手”的你',
                    ),
                ),
            ),
            array(
                'id'         => 'apply_center_set',
                'type'       => 'group',
                'accordion_title_number' => true,
                'title'      => '招募条件内容',
                'fields'     => array(
                    array(
                        'id'      => 'center',
                        'type'    => 'text',
                        'title'   => '内容',
                    ),
                    array(
                        'id'      => 'icon',
                        'type'    => 'text',
                        'title'   => '图标',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                ),
                'default' => array(
                    array(
                        'center' => '个人设计师、在校学生、设计爱好者、宝妈主妇、设计工作室等都是我们招募的对象',
                        'icon'   => 'ceoicon-star-smile-line',
                    ),
                    array(
                        'center' => '平面类设计师需要有一定的排版设计能力，能熟练使用PS、AI、CDR等设计软件',
                        'icon'   => 'ceoicon-star-smile-line',
                    ),
                    array(
                        'center' => '原创绘画类设计师需要有一定的手绘基础、能熟练使用PS、AI、C4D、SAI等设计软件',
                        'icon'   => 'ceoicon-star-smile-line',
                    ),
                    array(
                        'center' => '办公文档类设计师需要熟练使用Excel、Word、PPT等办公软件',
                        'icon'   => 'ceoicon-star-smile-line',
                    ),
                    array(
                        'center' => 'UI类设计师需要有一定的互联网产品设计逻辑，能熟练使用PS、AI、Sketch等设计软件',
                        'icon'   => 'ceoicon-star-smile-line',
                    ),
                    array(
                        'center' => '视频类设计师需要熟练使用AE、PR、会声会影、Eduis等视频软件',
                        'icon'   => 'ceoicon-star-smile-line',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '常见问题模块设置',
            ),
            array(
                'id'      => 'apply_question',
                'type'    => 'text',
                'title'   => '常见问题模块标题',
                'default' => '常见问题',
            ),
            array(
                'id'         => 'apply_question_set',
                'type'       => 'group',
                'title'      => '常见问题内容',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'content',
                        'type'    => 'textarea',
                        'title'   => '内容',
                    ),
                ),
                'default' => array(
                    array(
                        'title'   => '1、签约成功后每月有上传数量要求吗？',
                        'content' => '每月上传数量没有硬性要求（除个别版块）。但是如果长时间不传作品，会被关闭上传权限，具体规则各版块不同，有疑问可联系对应的管理人员咨询。',
                    ),
                    array(
                        'title'   => '2、上传的作品必须是自己原创吗？',
                        'content' => '上传的作品必须保证是自己原创。若因设计师作品出现非原创、抄袭、盗版等造成的版权纠纷和法律责任，由设计师个人自行承担相关侵权责任。',
                    ),
                    array(
                        'title'   => '3、作品上传后，多久进行审核？',
                        'content' => '一般会在1-3个工作日内完成审核并反馈结果（如遇节假日将顺延）；如对审核进度或结果有疑问，请咨询平台客服。',
                    ),
                    array(
                        'title'   => '4、作品所以怎么结算？',
                        'content' => '收益月结。每月第一周统计、核对上月薪资情况，每月10日--15日（如遇节假日将顺延）进行提现打款，收益直接汇入设计师指定支付宝账户。',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '申请入驻资料设置',
            ),
            array(
                'id'      => 'apply_sz_real_auth',
                'type'    => 'switcher',
                'title'   => '实名认证',
                'desc'    => '是否需要实名认证（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            array(
                'id'      => 'apply_sz_username',
                'type'    => 'switcher',
                'title'   => '账号名称',
                'desc'    => '是否需要填写账号名称（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            // array(
            //     'id'      => 'apply_sz_bankno',
            //     'type'    => 'switcher',
            //     'title'   => '真实姓名',
            //     'desc'    => '是否需要填写真实姓名（开启则显示，关闭则隐藏）',
            //     'default' => true
            // ),
            // array(
            //     'id'      => 'apply_sz_score',
            //     'type'    => 'switcher',
            //     'title'   => '身份证号',
            //     'desc'    => '是否需要填写身份证号（开启则显示，关闭则隐藏）',
            //     'default' => true
            // ),
            array(
                'id'      => 'apply_sz_hyid',
                'type'    => 'switcher',
                'title'   => '会员ID',
                'desc'    => '是否需要填写会员ID（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            // array(
            //     'id'      => 'apply_sz_sfz',
            //     'type'    => 'switcher',
            //     'title'   => '身份证照',
            //     'desc'    => '是否需要上传身份证照（开启则显示，关闭则隐藏）',
            //     'default' => true
            // ),
            array(
                'id'      => 'apply_sz_phone',
                'type'    => 'switcher',
                'title'   => '手机号码',
                'desc'    => '是否需要填写手机号码（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            array(
                'id'      => 'apply_sz_price',
                'type'    => 'switcher',
                'title'   => '微信号码',
                'desc'    => '是否需要填写微信号码（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            array(
                'id'      => 'apply_sz_yzmcode',
                'type'    => 'switcher',
                'title'   => '备注信息',
                'desc'    => '是否需要填写备注信息（开启则显示，关闭则隐藏）',
                'default' => true
            ),

        )
    ));
    /*
     * ------------------------------------------------------------------------------
     * 底部设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id'     => 'ceotheme_boo',
        'icon'   => 'fa fa-gears',
        'title'  => '底部设置',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_boo',
        'title'  => '底部Banner模块',
        'fields' => array(
            array(
                'id'      => 'ceo_foo_banner',
                'type'    => 'switcher',
                'title'   => '底部Banner模块',
                'desc'    =>'隐藏/显示底部Banner模块（开启则显示，关闭则隐藏，<b style="color: red;"></i>此按钮关闭后将关闭以下全部功能</b>）',
                'default' => true
            ),
            array(
                'id'          => 'ceo_foo_banner_display',
                'type'        => 'select',
                'title'       => '底部Banner模块显示设置',
                'options'     => array(
                    'all'   => '全站显示',
                    'index' => '首页显示',
                ),
                'default'     => 'all'
            ),
            array(
                'id'          => 'ceo_foo_banner_set',
                'type'        => 'fieldset',
                'title'       => '底部Banner模块设置',
                'fields'      => array(
                    array(
                        'id'      => 'bg',
                        'type'    => 'upload',
                        'title'   => '模块背景图',
                        'desc'    => '背景图尺寸1920x360',
                        'default' => get_template_directory_uri() . '/static/images/ceo-footer-banner.jpg'
                    ),
                    array(
                        'id'         => 'title',
                        'type'       => 'text',
                        'title'      => '模块标题',
                        'default'    => '一个会员，全站十大品类精品内容任意下载',
                    ),
                    array(
                        'id'         => 'desc',
                        'type'       => 'text',
                        'title'      => '模块描述',
                        'default'    => '秉承“地球不爆炸我们不放假”的信念，数年如一日的整合资源，从未间断。',
                    ),
                    array(
                        'id'     => 'btn',
                        'type'   => 'repeater',
                        'title'  => '模块按钮',
                        'fields' => array(
                            array(
                                'id'    => 'title',
                                'type'  => 'text',
                                'title' => '按钮标题',
                            ),
                            array(
                                'id'    => 'link',
                                'type'  => 'text',
                                'title' => '按钮链接',
                            ),
                        ),
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_boo',
        'title'  => '底部基础设置',
        'fields' => array(
            array(
                'id'     => 'foot_menu',
                'type'   => 'group',
                'title'  => '底部快捷导航',
                'fields' => array(
                    array(
                        'id'    => 'title',
                        'type'  => 'text',
                        'title' => '标题',
                    ),
                    array(
                        'id'    => 'link',
                        'type'  => 'text',
                        'title' => '链接',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （底部信息设置）',
            ),
            array(
                'id'      => 'cop_text',
                'type'    => 'textarea',
                'title'   => '网站底部版权文字',
                'desc'    => '可以使用html编辑',
                'default' => '© 2023 总裁主题 - CEOTHEME.COM & WordPress Theme. All rights reserved'
            ),
            array(
                'id'      => 'foot_xml_set',
                'type'    => 'switcher',
                'title'   => '网站地图',
                'label'   => '开启或关闭底部网站地图',
                'default' => true,
            ),
            array(
                'id'         => 'foot_xml',
                'type'       => 'text',
                'title'      => '地图地址',
                'desc'       => '<p>网站地图链接地址<h5 class="csf-text-desc" style="color: #0a8eff;">（推荐使用：Google XML Sitemaps 插件）</h5>后台-插件-搜索Google XML Sitemaps-安装谷歌 XML 站点地图-启用',
                'default'    => '/sitemap.xml',
                'dependency' => array('foot_xml_set', '==', 'true'),
            ),
            array(
                'id'      => 'show_beian',
                'type'    => 'switcher',
                'title'   => '网站底部备案号',
                'desc'    =>'开启或关闭网站备案号',
                'default' => true
            ),
            array(
                'id'         => 'beian',
                'type'       => 'text',
                'dependency' => array('show_beian', '==', true),
                'title'      => '网站备案号',
                'default'    => '闽ICP备888888888号'
            ),
            array(
                'id'      => 'foot_gongan',
                'type'    => 'switcher',
                'title'   => '是否显示公安备案',
                'desc'    => '隐藏/显示底部公安备案号（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'         => 'foot_gongan_beianhao',
                'dependency' => array('foot_gongan', '==', 'true'),
                'type'       => 'text',
                'title'      => '公安备案号',
                'default'    => '闽公安网备888888888号'
            ),
            array(
                'id'      => 'theme_cop',
                'type'    => 'switcher',
                'title'   => '隐藏/显示主题版权',
                'default' => true
            ),
            array(
                'id'     => 'foot_img',
                'type'   => 'group',
                'title'  => '底部右侧图标',
                'fields' => array(
                    array(
                        'id'    => 'title',
                        'type'  => 'text',
                        'title' => '标题',
                    ),
                    array(
                        'id'    => 'link',
                        'type'  => 'text',
                        'title' => '链接',
                    ),
                    array(
                        'id'           => 'img',
                        'type'         => 'upload',
                        'title'        => '图片',
                        'desc'         => '高36px宽自定',
                        'placeholder'  => 'http://',
                        'button_title' => '上传',
                        'remove_title' => '删除',
                    ),
                ),
                
            ),
        )
    ));
    /*
     * ------------------------------------------------------------------------------
     * 手机设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id'     => 'ceotheme_app',
        'icon'   => 'fa fa-tablet',
        'title'  => '手机设置',
        'fields' => array(
            array(
                'id'      => 'ceo_app_foo',
                'type'    => 'switcher',
                'title'   => '手机底部菜单',
                'desc'    => '开启或关闭手机底部菜单（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'         => 'ceo_app_foo_set',
                'type'       => 'fieldset',
                'title'      => '手机底部菜单设置',
                'dependency' => array('ceo_app_foo', '==', true),
                'fields'     => array(
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线 （手机底部左侧菜单设置）',
                    ),
                    array(
                        'id'      => 'title1',
                        'type'    => 'text',
                        'title'   => '左侧菜单1标题',
                        'default' => '首页',
                    ),
                    array(
                        'id'      => 'link1',
                        'type'    => 'text',
                        'title'   => '左侧菜单1链接',
                        'default' => '/',
                    ),
                    array(
                        'id'      => 'ico1',
                        'type'    => 'text',
                        'title'   => '左侧菜单1图标',
                        'default' => 'ceoicon-home-3-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'title2',
                        'type'    => 'text',
                        'title'   => '左侧菜单2标题',
                        'default' => '活动',
                    ),
                    array(
                        'id'      => 'link2',
                        'type'    => 'text',
                        'title'   => '左侧菜单2链接',
                        'default' => '/invited',
                    ),
                    array(
                        'id'      => 'ico2',
                        'type'    => 'text',
                        'title'   => '左侧菜单2图标',
                        'default' => 'ceoicon-gift-2-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线 （手机底部中部菜单设置）',
                    ),
                    array(
                        'id'      => 'middletitle',
                        'type'    => 'text',
                        'title'   => '中部按钮动态标题',
                        'default' => '会员优惠',
                    ),
                    array(
                        'id'      => 'middlelink',
                        'type'    => 'text',
                        'title'   => '中部按钮链接',
                        'default' => '/vip',
                    ),
                    array(
                        'id'      => 'middleicon',
                        'type'    => 'text',
                        'title'   => '中部按钮图标',
                        'default' => 'ceoicon-vip-crown-2-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线 （手机底部右侧菜单设置）',
                    ),
                    array(
                        'id'      => 'titley1',
                        'type'    => 'text',
                        'title'   => '右侧菜单1标题',
                        'default' => '专题',
                    ),
                    array(
                        'id'      => 'linky1',
                        'type'    => 'text',
                        'title'   => '右侧菜单1链接',
                        'default' => '/special',
                    ),
                    array(
                        'id'      => 'icoy1',
                        'type'    => 'text',
                        'title'   => '右侧菜单1图标',
                        'default' => 'ceoicon-folder-open-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'titley2',
                        'type'    => 'text',
                        'title'   => '右侧菜单2标题',
                        'default' => '我的',
                    ),
                    array(
                        'id'      => 'linky2',
                        'type'    => 'text',
                        'title'   => '右侧菜单2链接',
                        'default' => '/member/center/',
                    ),
                    array(
                        'id'      => 'icoy2',
                        'type'    => 'text',
                        'title'   => '右侧菜单2图标',
                        'default' => 'ceoicon-user-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                ),
            ),
        )
    ));
    //扩展功能设置
    CSF::createSection($ceotheme, array(
        'id'    => 'ceotheme_function',
        'icon'  => 'fa fa-laptop',
        'title' => '扩展功能',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_function',
        'title'  => '扩展功能设置',
        'fields' => array(
            array(
                'id'      => 'yinyue_unlogin_allow_play',
                'type'    => 'switcher',
                'title'   => '音乐列表与音乐详情页是否登录播放',
                'default' => true,
                'desc'    => '按钮开启则无需登录也能播放，按钮关闭则需要登录后才能播放',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （文章随机阅读量）',
            ),
            array(
                'id'      => 'is_rand_views',
                'type'    => 'switcher',
                'title'   => '文章随机阅读量',
                'desc'    => '开启或关闭自动文章阅读量功能（开启则发布文章自动生成，关闭则无）',
                'default' => true,
            ),
            array(
                'id'         => 'is_rand_views_sz_q',
                'dependency' => array('is_rand_views', '==', true),
                'type'       => 'number',
                'title'      => '自定义随机阅读量（起）',
                'default'    => 100,
            ),
            array(
                'id'         => 'is_rand_views_sz_z',
                'dependency' => array('is_rand_views', '==', true),
                'type'       => 'number',
                'title'      => '自定义随机阅读量（止）',
                'default'    => 1000,
            ),
            array(
                'type'    => 'submessage',
                'style'   => 'info',
                'content' => '自定义随机阅读量（起）与自定义随机阅读量（止）表示如：从100起1000止，100-1000内数值随机，可以自定义自由设置随机值',
            ),
            array(
                'id'         => 'ceo_be_only_admin',
                'type'       => 'switcher',
                'title'      => '后台管理权限',
                'desc'       => '开启则仅允许【管理员】进后台，关闭则同时允许【管理员】和【内部】进后台',
                'default'    => true
            ),
        ),
    ));
    CSF::createSection($ceotheme, array(
        'parent'   => 'ceotheme_function',
        'title'    => '邮箱功能设置',
        'fields'   => array(
            array(
                'type'     => 'notice',
                'style'    => 'warning',
                'content'  => '总裁主题推荐使用163邮箱发信，更稳定、更高效~',
            ),
            array(
                'id'       => 'mail_smtps',
                'type'     => 'switcher',
                'title'    => 'SMTP邮箱功能',
                'desc'     => '开启或关闭SMTP邮箱功能（注意：开启时请关闭相关功能插件）',
                'default'  => false,
            ),
            array(
                'id'       => 'mail_name',
                'type'     => 'text',
                'title'    => '发信邮箱',
                'desc'     => '请填写发信人邮箱帐号',
                'default'  => '88888888@163.com',
                'validate' => 'csf_validate_email',
            ),
            array(
                'id'       => 'mail_nicname',
                'type'     => 'text',
                'title'    => '发信人昵称',
                'desc'     => '请填写发信人昵称',
                'default'  => 'CeoDocs主题',
            ),
            array(
                'id'       => 'mail_host',
                'type'     => 'text',
                'title'    => '邮箱服务器',
                'desc'     => '请填写SMTP邮箱服务器地址',
                'default'  => 'smtp.163.com',
            ),
            array(
                'id'       => 'mail_port',
                'type'     => 'text',
                'title'    => '服务器端口',
                'desc'     => '请填写SMTP邮箱服务器端口',
                'default'  => '465',
            ),
            array(
                'id'         => 'mail_passwd',
                'type'       => 'text',
                'title'      => '邮箱独立密码',
                'desc'       => '请填写SMTP服务器邮箱独立密码（注意：非账号密码）',
                'default'    => '88888888',
                'attributes' => array(
                    'type'         => 'password',
                    'autocomplete' => 'off',
                ),
            ),
            array(
                'id'       => 'mail_smtpauth',
                'type'     => 'switcher',
                'title'    => '启用SMTPAuth服务',
                'desc'     => '是否启用SMTPAuth服务',
                'default'  => true,
            ),
            array(
                'id'       => 'mail_smtpsecure',
                'type'     => 'text',
                'title'    => 'SMTPSecure设置',
                'desc'     => '若启用SMTPAuth服务则填写ssl，若不启用则留空',
                'default'  => 'ssl',
            ),

        ),
    ));
    CSF::createSection($ceotheme, array(
        'parent'  => 'ceotheme_function',
        'title'   => '验证系统设置',
        'fields'  => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => 'VAPTCHA验证设置',
            ),
            array(
                'id'      => 'vaptcha_enable',
                'type'    => 'switcher',
                'title'   => 'VAPTCHA验证',
                'default' => false,
            ),
            array(
                'type'       => 'content',
                'content'    => 'vaptcha验证码申请：<a href="https://www.vaptcha.com/" target="_blank">点击去申请</a>',
                'dependency' => array('vaptcha_enable', '==', true),
            ),
            array(
                'id'         => 'vaptcha_vid',
                'type'       => 'text',
                'title'      => 'vaptcha vid',
                'dependency' => array( 'vaptcha_enable', '==', true ),
            ),
            array(
                'id'         => 'vaptcha_key',
                'type'       => 'text',
                'title'      => 'vaptcha key',
                'dependency' => array( 'vaptcha_enable', '==', true ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '腾讯云验证码设置',
            ),
            array(
                'id'      => 'tcaptcha_enable',
                'type'    => 'switcher',
                'title'   => '腾讯云 T-Sec 天御验证码',
                'default' => false,
            ),
            array(
                'type'       => 'content',
                'content'    => '腾讯云 T-Sec 天御验证码申请：<a href="https://cloud.tencent.com/product/captcha" target="_blank">点击去申请</a>',
                'dependency' => array('tcaptcha_enable', '==', true),
            ),
            array(
                'id'         => 'tcaptcha_app_secret_id',
                'type'       => 'text',
                'title'      => '腾讯云 SecretId',
                'dependency' => array( 'tcaptcha_enable', '==', true ),
            ),
            array(
                'id'         => 'tcaptcha_app_secret_key',
                'type'       => 'text',
                'title'      => '腾讯云 SecretKey',
                'dependency' => array( 'tcaptcha_enable', '==', true ),
            ),
            array(
                'id'         => 'tcaptcha_captcha_app_id',
                'type'       => 'text',
                'title'      => '验证码 CaptchaAppId',
                'dependency' => array( 'tcaptcha_enable', '==', true ),
            ),
            array(
                'id'         => 'tcaptcha_captcha_app_secret_key',
                'type'       => 'text',
                'title'      => '验证码 AppSecretKey',
                'dependency' => array( 'tcaptcha_enable', '==', true ),
            ),
        ),
    ));
    
    CSF::createSection($ceotheme, array(
        'parent'  => 'ceotheme_function',
        'title'   => 'Sitemap设置',
        'fields'  => array(
            array(
                'id'      => 'sitemap_enable',
                'type'    => 'switcher',
                'title'   => 'Sitemap网站地图生成',
                'default' => false,
            ),
            array(
                'id'      => 'sitemap_group',
                'type'    => 'sorter',
                'title'   => '数据源填充',
                'dependency' => array( 'sitemap_enable', '==', true ),
                'default' => array(
                    'enabled'  => array(
                        'home' => '首页',
                        'post' => '最新文章',
                        'tag'  => '最新标签',
                        'page' => '最新页面',
                        'cat'  => '分类页面',
                    ),
                    'disabled' => array(
                    ),
                ),
            ),
            array(
                'id'         => 'sitemap_data_home',
                'type'       => 'fieldset',
                'title'      => '首页选项',
                'dependency' => array('sitemap_enable', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'changefreq',
                        'type'       => 'select',
                        'title'      => '更新频率（changefreq）',
                        'options' => [
                            'always'=>'总是',
                            'hourly'=>'每小时',
                            'daily'=>'每日',
                            'weekly'=>'每周',
                            'monthly'=>'每月',
                            'yearly'=>'每年',
                            'never'=>'从不',
                        ],
                        'default' => 'always'
                    ),
                    array(
                        'id'         => 'priority',
                        'type'       => 'select',
                        'title'      => '权重（priority）',
                        'options' => [
                            '1'=>'0.1',
                            '2'=>'0.2',
                            '3'=>'0.3',
                            '4'=>'0.4',
                            '5'=>'0.5',
                            '6'=>'0.6',
                            '7'=>'0.7',
                            '8'=>'0.8',
                            '9'=>'0.9',
                            '10'=>'1.0',
                        ],
                        'default' => '10',
                    ),
                ),
            ),
            array(
                'id'         => 'sitemap_data_post',
                'type'       => 'fieldset',
                'title'      => '最新文章选项',
                'dependency' => array('sitemap_enable', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'changefreq',
                        'type'       => 'select',
                        'title'      => '更新频率（changefreq）',
                        'options' => [
                            'always'=>'总是',
                            'hourly'=>'每小时',
                            'daily'=>'每日',
                            'weekly'=>'每周',
                            'monthly'=>'每月',
                            'yearly'=>'每年',
                            'never'=>'从不',
                        ],
                        'default' => 'hourly',
                    ),
                    array(
                        'id'         => 'priority',
                        'type'       => 'select',
                        'title'      => '权重（priority）',
                        'options' => [
                            '1'=>'0.1',
                            '2'=>'0.2',
                            '3'=>'0.3',
                            '4'=>'0.4',
                            '5'=>'0.5',
                            '6'=>'0.6',
                            '7'=>'0.7',
                            '8'=>'0.8',
                            '9'=>'0.9',
                            '10'=>'1.0',
                        ],
                        'default' => '6',
                    ),
                    array(
                        'id'      => 'max',
                        'type'    => 'number',
                        'title'   => '最新文章链接数量',
                        'default' => 100,
                    ),
                ),
            ),
            array(
                'id'         => 'sitemap_data_tag',
                'type'       => 'fieldset',
                'title'      => '最新标签选项',
                'dependency' => array('sitemap_enable', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'changefreq',
                        'type'       => 'select',
                        'title'      => '更新频率（changefreq）',
                        'options' => [
                            'always'=>'总是',
                            'hourly'=>'每小时',
                            'daily'=>'每日',
                            'weekly'=>'每周',
                            'monthly'=>'每月',
                            'yearly'=>'每年',
                            'never'=>'从不',
                        ],
                        'default' => 'hourly',
                    ),
                    array(
                        'id'         => 'priority',
                        'type'       => 'select',
                        'title'      => '权重（priority）',
                        'options' => [
                            '1'=>'0.1',
                            '2'=>'0.2',
                            '3'=>'0.3',
                            '4'=>'0.4',
                            '5'=>'0.5',
                            '6'=>'0.6',
                            '7'=>'0.7',
                            '8'=>'0.8',
                            '9'=>'0.9',
                            '10'=>'1.0',
                        ],
                        'default' => '6',
                    ),
                    array(
                        'id'      => 'max',
                        'type'    => 'number',
                        'title'   => '最新文章链接数量',
                        'default' => 100,
                    ),
                ),
            ),
            array(
                'id'         => 'sitemap_data_page',
                'type'       => 'fieldset',
                'title'      => '最新页面选项',
                'dependency' => array('sitemap_enable', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'changefreq',
                        'type'       => 'select',
                        'title'      => '更新频率（changefreq）',
                        'options' => [
                            'always'=>'总是',
                            'hourly'=>'每小时',
                            'daily'=>'每日',
                            'weekly'=>'每周',
                            'monthly'=>'每月',
                            'yearly'=>'每年',
                            'never'=>'从不',
                        ],
                        'default' => 'hourly',
                    ),
                    array(
                        'id'         => 'priority',
                        'type'       => 'select',
                        'title'      => '权重（priority）',
                        'options' => [
                            '1'=>'0.1',
                            '2'=>'0.2',
                            '3'=>'0.3',
                            '4'=>'0.4',
                            '5'=>'0.5',
                            '6'=>'0.6',
                            '7'=>'0.7',
                            '8'=>'0.8',
                            '9'=>'0.9',
                            '10'=>'1.0',
                        ],
                        'default' => '6',
                    ),
                ),
            ),
            array(
                'id'         => 'sitemap_data_cat',
                'type'       => 'fieldset',
                'title'      => '分类页面选项',
                'dependency' => array('sitemap_enable', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'changefreq',
                        'type'       => 'select',
                        'title'      => '更新频率（changefreq）',
                        'options' => [
                            'always'=>'总是',
                            'hourly'=>'每小时',
                            'daily'=>'每日',
                            'weekly'=>'每周',
                            'monthly'=>'每月',
                            'yearly'=>'每年',
                            'never'=>'从不',
                        ],
                        'default' => 'hourly',
                    ),
                    array(
                        'id'         => 'priority',
                        'type'       => 'select',
                        'title'      => '权重（priority）',
                        'options' => [
                            '1'=>'0.1',
                            '2'=>'0.2',
                            '3'=>'0.3',
                            '4'=>'0.4',
                            '5'=>'0.5',
                            '6'=>'0.6',
                            '7'=>'0.7',
                            '8'=>'0.8',
                            '9'=>'0.9',
                            '10'=>'1.0',
                        ],
                        'default' => '6',
                    ),
                ),
            ),
        ),
    ));
    CSF::createSection($ceotheme, array(
        'parent'  => 'ceotheme_function',
        'title'   => '百度推送设置',
        'fields'  => array(
            array(
                'id'         => 'baidu_push_enable',
                'type'       => 'switcher',
                'title'      => '开启百度推送',
                'default'    => false,
            ),
            array(
                'id'         => 'baidu_push_site',
                'type'       => 'text',
                'title'      => '站点',
                'dependency' => array('baidu_push_enable', '==', true),
                'desc'       => '在搜索资源平台验证的站点，如www.ceotheme.com',
            ),
            array(
                'id'         => 'baidu_push_token',
                'type'       => 'text',
                'title'      => '秘钥',
                'dependency' => array('baidu_push_enable', '==', true),
                'desc'       => '在搜索资源平台申请的推送用的准入密钥，请输入token值',
            ),
        ),
    ));
    
    
    /*
     * ------------------------------------------------------------------------------
     * 美化设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id'     => 'ceotheme_qita',
        'icon'   => 'fa fa-plus-square',
        'title'  => '美化设置',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_qita',
        'title'  => '缩略图美化设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '美化特色图裁剪设置',
            ),
            array(
                'id'      => 'cut_type',
                'type'    => 'radio',
                'title'   => '美化特色图片裁剪',
                'options' => array(
                    '2' => '居上裁剪',
                    '0' => '居中裁剪',
                    '1' => '强制缩放',
                ),
                'default' => '2',
            ),
            array(
                'id'      => 'cut_type_dx',
                'type'    => 'dimensions',
                'title'   => '自定义美化缩略图大小（框内图大小）',
                'default' => array(
                    'width'  => '210',
                    'height' => '325',
                    'unit'   => 'px',
                ),
                'desc'    =>'自定义缩略图背景框时进行修改调整，默认无需修改，默认尺寸210x325'
            ),
            array(
                'id'      => 'cut_type_kg',
                'type'    => 'dimensions',
                'title'   => '自定义美化缩略图宽高（框内图距离）',
                'default' => array(
                    'width'  => '31',
                    'height' => '44',
                    'unit'   => 'px',
                ),
                'desc'    =>'自定义缩略图背景框时进行修改调整，默认无需修改，默认尺寸31x44'
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_qita',
        'title'  => '右侧跟随设置',
        'fields' => array(
            array(
                'id'      => 'ceo_follow',
                'type'    => 'switcher',
                'title'   => '网站右下角跟随总开关',
                'desc'    => '此按钮关闭后将隐藏以下所有内容',
                'default' => true
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （活动按钮设置）',
            ),
            array(
                'id'         => 'ceo_follow_activity',
                'type'       => 'switcher',
                'title'      => '活动按钮',
                'desc'       => '开启或关闭活动图标按钮',
                'default'    => true
            ),
            array(
                'id'         => 'ceo_follow_activity_set',
                'type'       => 'fieldset',
                'title'      => '活动按钮设置',
                'dependency' => array('ceo_follow_activity', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'bg',
                        'type'       => 'upload',
                        'title'      => '活动背景图',
                        'desc'       => '图片尺寸54x128',
                        'default'    => get_template_directory_uri() . '/static/images/ceo-follow-activity-1.png',
                    ),
                    array(
                        'id'         => 'img',
                        'type'       => 'upload',
                        'title'      => '活动动图',
                        'desc'       => '图片尺寸33x43',
                        'default'    => get_template_directory_uri() . '/static/images/ceo-follow-activity-2.png',
                    ),
                    array(
                        'id'         => 'upimg',
                        'type'       => 'upload',
                        'title'      => '活动弹窗图',
                        'desc'       => '图片尺寸251x128',
                        'default'    => get_template_directory_uri() . '/static/images/ceo-follow-activity-3.png',
                    ),
                    array(
                        'id'         => 'link',
                        'type'       => 'text',
                        'title'      => '活动链接',
                        'default'    => '/invited',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （会员按钮设置）',
            ),
            array(
                'id'         => 'ceo_follow_vip',
                'type'       => 'switcher',
                'title'      => '会员按钮',
                'desc'       => '开启或关闭会员按钮',
                'default'    => true
            ),
            array(
                'id'         => 'ceo_follow_vip_set',
                'type'       => 'fieldset',
                'title'      => '会员按钮设置',
                'dependency' => array('ceo_follow_vip', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'img',
                        'type'       => 'upload',
                        'title'      => '按钮图标',
                        'desc'       => '图片尺寸24x24',
                        'default'    => get_template_directory_uri() . '/static/images/ceo-follow-vip.svg',
                    ),
                    array(
                        'id'         => 'title',
                        'type'       => 'text',
                        'title'      => '按钮标题',
                        'default'    => '会员',
                    ),
                    array(
                        'id'         => 'link',
                        'type'       => 'text',
                        'title'      => '按钮链接',
                        'default'    => '/vip',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （签到按钮设置）',
            ),
            array(
                'id'         => 'ceo_follow_sign',
                'type'       => 'switcher',
                'title'      => '签到按钮',
                'desc'       => '开启或关闭签到按钮',
                'default'    => true
            ),
            array(
                'id'         => 'ceo_follow_sign_set',
                'type'       => 'fieldset',
                'title'      => '签到按钮设置',
                'dependency' => array('ceo_follow_sign', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'img',
                        'type'       => 'upload',
                        'title'      => '按钮图标',
                        'desc'       => '图片尺寸24x24',
                        'default'    => get_template_directory_uri() . '/static/images/ceo-follow-sign.gif',
                    ),
                    array(
                        'id'         => 'title',
                        'type'       => 'text',
                        'title'      => '按钮标题',
                        'default'    => '签到',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （抽奖按钮设置）',
            ),
            array(
                'id'         => 'ceo_follow_lottery',
                'type'       => 'switcher',
                'title'      => '抽奖按钮',
                'desc'       => '开启或关闭抽奖按钮',
                'default'    => true
            ),
            array(
                'id'         => 'ceo_follow_lottery_set',
                'type'       => 'fieldset',
                'title'      => '抽奖按钮设置',
                'dependency' => array('ceo_follow_lottery', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'icon',
                        'type'       => 'text',
                        'title'      => '按钮图标',
                        'default'    => 'ceoicon-signal-tower-line',
                        'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'         => 'title',
                        'type'       => 'text',
                        'title'      => '按钮标题',
                        'default'    => '抽奖',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （客服按钮设置）',
            ),
            array(
                'id'         => 'ceo_follow_service',
                'type'       => 'switcher',
                'title'      => '客服按钮',
                'desc'       => '开启或关闭客服按钮',
                'default'    => true
            ),
            array(
                'id'         => 'ceo_follow_service_set',
                'type'       => 'fieldset',
                'title'      => '客服按钮设置',
                'dependency' => array('ceo_follow_service', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'icon',
                        'type'       => 'text',
                        'title'      => '按钮图标',
                        'default'    => 'ceoicon-customer-service-2-line',
                        'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'         => 'title',
                        'type'       => 'text',
                        'title'      => '按钮标题',
                        'default'    => '客服',
                    ),
                ),
            ),
            array(
                'id'         => 'ceo_follow_service_up',
                'type'       => 'fieldset',
                'title'      => '客服弹窗设置',
                'dependency' => array('ceo_follow_service', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'img',
                        'type'       => 'upload',
                        'title'      => '客服图片',
                        'desc'       => '图片尺寸24x24',
                        'default'    => get_template_directory_uri() . '/static/images/ceo-follow-service-qq.png',
                    ),
                    array(
                        'id'         => 'qqtitle',
                        'type'       => 'text',
                        'title'      => '客服按钮标题',
                        'default'    => '点击联系客服',
                    ),
                    array(
                        'id'         => 'qq',
                        'type'       => 'text',
                        'title'      => '客服按钮链接',
                        'desc'       => '默认为QQ客服链接，使用默认链接则将88888888修改为你的QQ号',
                        'default'    => 'tencent://Message/?Uin=88888888&amp;websiteName=#=&amp;Menu=yes'
                    ),
                    array(
                        'id'         => 'time',
                        'type'       => 'text',
                        'title'      => '工作时间',
                        'default'    => '在线时间：09:00-18:00',
                    ),
                    array(
                        'id'         => 'wetitle',
                        'type'       => 'text',
                        'title'      => '微信客服标题',
                        'default'    => '关注微信公众号',
                    ),
                    array(
                        'id'         => 'weimg',
                        'type'       => 'upload',
                        'title'      => '微信客服二维码',
                        'default'    => get_template_directory_uri() . '/static/images/ceo-ma.png',
                    ),
                    array(
                        'id'         => 'phonetitle',
                        'type'       => 'text',
                        'title'      => '客服电话标题',
                        'default'    => '客服电话',
                    ),
                    array(
                        'id'         => 'phone',
                        'type'       => 'text',
                        'title'      => '客服电话号码',
                        'default'    => '400-888-8888',
                    ),
                    array(
                        'id'         => 'mailtitle',
                        'type'       => 'text',
                        'title'      => '客服邮箱标题',
                        'default'    => '客服邮箱',
                    ),
                    array(
                        'id'         => 'mail',
                        'type'       => 'text',
                        'title'      => '客服邮箱账号',
                        'default'    => 'ceotheme@ceo.com',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （手机按钮设置）',
            ),
            array(
                'id'         => 'ceo_follow_phone',
                'type'       => 'switcher',
                'title'      => '手机按钮',
                'desc'       => '开启或关闭手机按钮',
                'default'    => true
            ),
            array(
                'id'         => 'ceo_follow_phone_set',
                'type'       => 'fieldset',
                'title'      => '手机按钮设置',
                'dependency' => array('ceo_follow_phone', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'icon',
                        'type'       => 'text',
                        'title'      => '按钮图标',
                        'default'    => 'ceoicon-smartphone-line',
                        'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'         => 'btntitle',
                        'type'       => 'text',
                        'title'      => '按钮标题',
                        'default'    => '手机',
                    ),
                    array(
                        'id'         => 'title',
                        'type'       => 'text',
                        'title'      => '弹窗标题',
                        'default'    => '扫描二维码',
                    ),
                    array(
                        'id'         => 'subtitle',
                        'type'       => 'text',
                        'title'      => '弹窗副标题',
                        'default'    => '手机访问本站',
                    ),
                    array(
                        'id'         => 'img',
                        'type'       => 'upload',
                        'title'      => '弹窗二维码',
                        'desc'       => '图片尺寸150x150',
                        'default'    => get_template_directory_uri() . '/static/images/ceo-ma.png',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_qita',
        'title'  => '主题美化设置',
        'fields' => array(
            array(
                'id'         => 'ceo_float',
                'type'       => 'switcher',
                'title'      => '左下角活动',
                'desc'       => '开启或关闭左下角活动',
                'default'    => true
            ),
            array(
                'id'         => 'ceo_float_set',
                'type'       => 'fieldset',
                'title'      => '左下角活动设置',
                'dependency' => array('ceo_float', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'title',
                        'type'       => 'text',
                        'title'      => '标题',
                        'default'    => '活动',
                    ),
                    array(
                        'id'         => 'link',
                        'type'       => 'text',
                        'title'      => '链接',
                    ),
                    array(
                        'id'         => 'img',
                        'type'       => 'upload',
                        'title'      => '图片',
                        'desc'       => '图片尺寸150px',
                        'default'    => get_template_directory_uri() . '/static/images/ceo-float.gif',
                    ),
                ),
            ),
            array(
                'id'       => 'diy_js',
                'type'     => 'textarea',
                'title'    => '网站底部自定义JS代码',
                'desc'     => '可用于添加第三方网站流量数据统计代码，如：百度统计或美化效果',
                'sanitize' => false,
                'default'  => '',
            ),
            array(
                'id'        => 'diy_css',
                'type'      => 'code_editor',
                'title'     => '自定义css样式',
                'desc'      => '少量css可以直接写在这里,注意：不需要添加《style》《/style》',
                'settings'  => array(
                    'theme' => 'mbo',
                    'mode'  => 'css',
                ),
            ),
        )
    ));

    /*
     * ------------------------------------------------------------------------------
     * 优化设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id'     => 'ceotheme_optimization',
        'icon'   => 'fa fa-rocket',
        'title'  => '优化设置',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_optimization',
        'title'  => '优化加速',
        'fields' => array(
            array(
                'id'       => 'gtb_editor',
                'type'     => 'switcher',
                'title'    => '禁用古腾堡编辑器',
                'default'  => true,
                'subtitle' => '古腾堡用不习惯吗？那就关闭吧！(默认关闭)',
            ),
            array(
                'id'       => 'googleapis',
                'type'     => 'switcher',
                'title'    => '后台禁止加载谷歌字体',
                'default'  => true,
                'subtitle' => '后台禁止加载谷歌字体，加快后台访问速度',
            ),
            array(
                'id'       => 'emoji',
                'type'     => 'switcher',
                'title'    => '禁用emoji表情',
                'default'  => true,
                'subtitle' => '禁用WordPress的Emoji功能和禁止head区域Emoji css加载',
            ),
            array(
                'id'       => 'article_revision',
                'type'     => 'switcher',
                'title'    => '屏蔽文章修订功能',
                'default'  => true,
                'subtitle' => '文章多，修订次数的用户建议关闭此功能',
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_optimization',
        'title'  => '精简头部',
        'fields' => array(
            array(
                'id'       => 'toolbar',
                'type'     => 'switcher',
                'title'    => '移除顶部工具条',
                'default'  => true,
                'subtitle' => '这个大家应该都懂',
            ),
            array(
                'id'       => 'rest_api',
                'type'     => 'switcher',
                'title'    => '禁用REST API',
                'default'  => false,
                'subtitle' => '不准备打通WordPress小程序的用户建议关闭',
            ),
            array(
                'id'       => 'wpjson',
                'type'     => 'switcher',
                'title'    => '移除wp-json链接代码',
                'default'  => true,
                'subtitle' => '移除头部区域wp-json链接代码，精简头部区域代码',
            ),
            array(
                'id'       => 'emoji_script',
                'type'     => 'switcher',
                'title'    => '移除头部多余Emoji JavaScript代码',
                'default'  => true,
                'subtitle' => '移除头部多余Emoji JavaScript代码，精简头部区域代码',
            ),
            array(
                'id'       => 'wp_generator',
                'type'     => 'switcher',
                'title'    => '移除头部WordPress版本',
                'default'  => true,
                'subtitle' => '移除头部WordPress版本，精简头部区域代码',
            ),
            array(
                'id'       => 'wp_headcssjs',
                'type'     => 'switcher',
                'title'    => '移除头部JS和CSS链接中的Wordpress版本号',
                'default'  => true,
                'subtitle' => '移除头部JS和CSS链接中的Wordpress版本号，精简头部区域代码',
            ),
            array(
                'id'       => 'rsd_link',
                'type'     => 'switcher',
                'title'    => '移除离线编辑器开放接口',
                'default'  => true,
                'subtitle' => '移除WordPress自动添加两行离线编辑器的开放接口，精简头部区域代码',
            ),
            array(
                'id'       => 'index_rel_link',
                'type'     => 'switcher',
                'title'    => '清除前后文、第一篇文章、主页meta信息',
                'default'  => true,
                'subtitle' => 'WordPress把前后文、第一篇文章和主页链接全放在meta中。我认为于SEO帮助不大，反使得头部信息巨大，建议移出。',
            ),
            array(
                'id'       => 'feed',
                'type'     => 'switcher',
                'title'    => '移除文章、分类和评论feed',
                'default'  => true,
                'subtitle' => '移除文章、分类和评论feed，精简头部区域代码。',
            ),
            array(
                'id'       => 'dns_prefetch',
                'type'     => 'switcher',
                'title'    => '移除头部加载DNS预获取',
                'default'  => true,
                'subtitle' => '移出head区域dns-prefetch代码，精简头部区域代码。',
            ),

        )
    ));
    CSF::createSection($ceotheme, array(
        'id'    => 'ceotheme_admin',
        'icon'  => 'fa fa-desktop',
        'title' => '后台设置',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_admin',
        'title'  => '文章发布默认选项',
        'fields' => array(
            array(
              'type'    => 'submessage',
              'style'   => 'danger',
              'content' => '以下功能对应发布文章时的默认选项或默认内容，主要用途为提高创作效率【非必填，按需设置】<br /><br />
              例如：当你在这里选择【缩略图背景样式】为【样式1】那么每次发布新文章默认就会选择【推荐】',
            ),
            array(
                'id'      => 'cut_thumb_style_admin',
                'type'    => 'radio',
                'inline'  => true,
                'title'   => '缩略图背景样式',
                'options' => array(
                    '0' => '不启用',
                    '1' => '样式1',
                    '2' => '样式2',
                ),
                'default' => '0',
                'desc'    =>'样式1：主题目录下static/ceo-img-1文件夹里面的随机图片边框<br> 样式2：主题目录下static/ceo-img-2文件夹里面的随机图片边框'
            ),
            array(
                'id'          => 'down_info_admin',
                'type'        => 'repeater',
                'button_title'=> '添加',
                'title'       => '信息属性',
                'desc'        => '付费资源内页显示资源信息属性（如：大小、格式、版本等）',
                'fields'      => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                        'default' => '',
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => '内容',
                        'default' => '',
                    ),
                ),
            ),
            array(
                'id'          => 'down_btn_admin',
                'type'        => 'repeater',
                'button_title'=> '添加',
                'title'       => '自定义按钮',
                'desc'        => '付费资源内页显示自定义按钮',
                'fields'      => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '按钮标题',
                        'default' => '',
                    ),
                    array(
                        'id'      => 'url',
                        'type'    => 'text',
                        'title'   => '按钮链接',
                        'desc'    => '填写完整的链接地址，如https://www.ceotheme.com',
                        'default' => '',
                    ),
                ),
            ),
            array(
                'id'      => 'down_demourl_admin',
                'type'    => 'text',
                'title'   => '演示地址',
                'desc'    => '请以http://或https://开头',
            ),
            array(
                'id'      => 'ceo_tese_tag_admin',
                'type'    => 'text',
                'title'   => '资源标签',
                'desc'    => '标题前显示资源标签（例：热门、原创、商用等）',
            ),

        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_admin',
        'title'  => '创建分类默认选项',
        'fields' => array(
            array(
              'type'    => 'submessage',
              'style'   => 'danger',
              'content' => '以下功能对应创建分类时的默认选项或默认内容，主要用途为提高工作效率【非必填，按需设置】<br /><br />
              例如：当你在这里选择【分类列表样式默认选项】为【样式1：双栏列表】那么每次创建新分类默认就会选择【样式1：双栏列表】',
            ),
            array(
                'id'           => 'ceo_category_layout_admin',
                'type'         => 'image_select',
                'title'        => '选择分类布局样式',
                'desc'         => '[样式1：卡片布局1]  [样式2：卡片布局2]  [样式3：卡片布局3]  [样式4：视频布局]  [样式5：音频布局]  [样式6：软件布局]  [样式7：文章布局]',
                'options'      => array(
                    '1'    => get_template_directory_uri() . '/static/admin-img/ceo-category-1.jpg',
                    '2'    => get_template_directory_uri() . '/static/admin-img/ceo-category-2.jpg',
                    '3'    => get_template_directory_uri() . '/static/admin-img/ceo-category-3.jpg',
                    '4'    => get_template_directory_uri() . '/static/admin-img/ceo-category-4.jpg',
                    '5'    => get_template_directory_uri() . '/static/admin-img/ceo-category-5.jpg',
                    '6'    => get_template_directory_uri() . '/static/admin-img/ceo-category-6.jpg',
                    '7'    => get_template_directory_uri() . '/static/admin-img/ceo-category-7.jpg',
                ),
                'default'      => '1'
            ),
            array(
                'id'           => 'ceo_category_list_admin',
                'type'         => 'image_select',
                'title'        => '选择列表显示排数',
                'desc'         => '[样式1：五个一排]  [样式2：四个一排]',
                'options'      => array(
                    '1'    => get_template_directory_uri() . '/static/admin-img/ceo-list-1.jpg',
                    '2'    => get_template_directory_uri() . '/static/admin-img/ceo-list-2.jpg',
                ),
                'default'      => '1'
            ),
            array(
                'id'           => 'ceo_category_height_admin',
                'type'         => 'dimensions',
                'title'        => '填写列表图片高度',
                'desc'         => '总裁主题友情提示：<br/>1：填写100，则是等比例正方形，填写小于100或大于100则是高度的长短之差<br/>2：若选择列表样式5（音频列表）时无需填写，音频列表为固定模块尺寸<br/>3：若选择列表样式6（软件列表）时无需填写，软件列表为固定模块尺寸<br/>4：若选择列表样式7（文章列表）时无需填写，文章列表为固定模块尺寸',
                'units'        => ['%'],
                'width'        => false,
                'default'      => array(
                    'height' => '150',
                    'unit'   => '%',
                ),
            ),
            array(
                'id'           => 'ceo_category_single_admin',
                'type'         => 'image_select',
                'title'        => '选择分类内页样式',
                'options'      => array(
                    '1'    => get_template_directory_uri() . '/static/admin-img/ceo-single-1.jpg',
                    '2'    => get_template_directory_uri() . '/static/admin-img/ceo-single-2.jpg',
                ),
                'default'      => '1'
            ),
        )
    ));
}
