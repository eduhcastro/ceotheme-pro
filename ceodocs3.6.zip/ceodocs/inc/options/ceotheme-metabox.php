<?php if ( ! defined( 'ABSPATH' )  ) { die; }

if( class_exists( 'CSF' ) ) {
	$prefix_info = 'ceo_post_info';
	CSF::createMetabox( $prefix_info, array(
		'title'     => '<span class="ceotheme_com"><i class="fa fa-laptop"></i> CeoDocs主题 - 资源信息配置</span>',
		'nav'       => 'inline',
		'post_type' => 'post',
		'data_type' => 'unserialize',
		'context'   => 'normal',

	) );
	CSF::createSection( $prefix_info, array(
	    'title'  => '资源信息',
        'fields' => array(
            array(
                'id'      => 'cut_thumb_style',
                'type'    => 'radio',
                'inline'  => true,
                'title'   => '缩略图背景样式',
                'options' => array(
                    '0' => '不启用',
                    '1' => '样式1',
                    '2' => '样式2',
                ),
                'default' => _ceo('cut_thumb_style_admin'),
                'desc'    =>'样式1：主题目录下static/ceo-img-1文件夹里面的随机图片边框<br> 样式2：主题目录下static/ceo-img-2文件夹里面的随机图片边框'
            ),
            array(
                'id'          => 'down_info',
                'type'        => 'repeater',
                'button_title'=> '添加',
                'title'       => '信息属性',
                'desc'        => '付费资源内页显示资源信息属性（如：大小、格式、版本等）',
                'fields'      => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                        'default' => '',
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => '内容',
                        'default' => '',
                    ),
                ),
                'default' => _ceo('down_info_admin'),
            ),
            array(
                'id'          => 'down_btn',
                'type'        => 'repeater',
                'button_title'=> '添加',
                'title'       => '自定义按钮',
                'desc'        => '付费资源内页显示自定义按钮',
                'fields'      => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '按钮标题',
                        'default' => '',
                    ),
                    array(
                        'id'      => 'url',
                        'type'    => 'text',
                        'title'   => '按钮链接',
                        'desc'    => '填写完整的链接地址，如https://www.ceotheme.com',
                        'default' => '',
                    ),
                ),
                'default' => _ceo('down_btn_admin'),
            ),
            array(
                'id'      => 'down_demourl',
                'type'    => 'text',
                'title'   => '演示地址',
                'desc'    => '请以http://或https://开头',
                'default' => _ceo('down_demourl_admin'),
            ),
            array(
                'id'      => 'ceo-tese-tag',
                'type'    => 'text',
                'title'   => '资源标签',
                'desc'    => '标题前显示资源标签（例：热门、原创、商用等）',
                'default' => _ceo('ceo_tese_tag_admin'),
            ),
            array(
                'id'      => 'enable_audio',
                'type'    => 'switcher',
                'title'   => '音频模块',
            ),
            array(
                'id'      => 'audio_url',
                'type'    => 'upload',
                'title'   => '音频播放地址',
                'desc'    => '音频播放地址，资源为音频资源时使用',
                'dependency'=> array('enable_audio', '==', true),
            ),
            array(
                'id'           => 'list_video_url',
                'type'         => 'upload',
                'title'        => '视频播放地址',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => '',
            ),
        )

	) );

    CSF::createSection( $prefix_info, array(
	    'title'  => '自定义SEO',
        'fields' => array(
            array(
                'id'      => 'ceo-seo-title',
                'type'    => 'text',
                'title'   => '自定义SEO标题',
                'desc'    => '填写自定义SEO标题，未填写则调用默认文章标题',
            ),
            array(
                'id'      => 'ceo-seo-keywords',
                'type'    => 'text',
                'title'   => '自定义SEO关键词',
                'desc'    => '填写自定义SEO关键词，未填写则调用默认文章标签',
            ),
            array(
                'id'      => 'ceo-seo-description',
                'type'    => 'textarea',
                'title'   => '自定义SEO描述',
                'desc'    => '填写自定义SEO描述，未填写则调用默认文章内容前段',
            ),
        )
    
    ) );
}

//文章绑定专题
if (class_exists('CSF')) {
    $prefix = 'my_post_special';
    CSF::createMetabox($prefix, array(
        'title'     => '专题',
        'post_type' => 'post',
        'context'   => 'side',
    ));
    CSF::createSection($prefix, [
        'fields' => array(
            [
                'id'          => 'special_select',
                'type'        => 'select',
                'title'       => '',
                'placeholder' => '选择专题',
                'options'     => 'categories',
                'query_args'  => array(
                'taxonomy'    => 'special',
                ),
            ]

        )
    ]);
    
    $prefix = 'my_post_custom_url_image';
    CSF::createMetabox($prefix, array(
        'title'     => '自定义外链特色图片',
        'post_type' => 'post',
        'context'   => 'side',
        'priority'  => 'low',
        'data_type' => 'unserialize',
        'class'     => 'my_post_custom_url_image',
    ));
    CSF::createSection($prefix, [
        'fields' => array(
            [
                'id'          => 'custom_url_image',
                'type'        => 'text',
                'title'       => '',
                'placeholder' => '自定义外链',
                'desc'        => '自定义外链填写了就优先调用',
            ]

        )
    ]);
}

// 百度推送
if( class_exists( 'CSF' ) && _ceo('baidu_push_enable') ) {
    $prefix = 'baidu_push_option';
    CSF::createMetabox($prefix, array(
      'title'     => '百度推送',
      'post_type' => 'post',
      'context'   => 'side',
    ));
    CSF::createSection($prefix, array(
      'fields' => array(
        array(
            'id'      => 'baidu_push_1',
            'type'    => 'checkbox',
            'label'   => '普通收录',
            'help'    => '勾选后文章发布状态变更为发布时时候进行普通推送',
            'after' => CeoBaiduPush::getPushTip(1),
            'default' => true
        ),
        array(
            'id'      => 'baidu_push_2',
            'type'    => 'checkbox',
            'label'   => '快速收录',
            'help'    => '勾选后文章发布状态变更为发布时时候进行快速推送',
            'after' => CeoBaiduPush::getPushTip(2),
            'default' => false
        ),
      )
    ));
}