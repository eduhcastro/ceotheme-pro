<?php if (! defined('ABSPATH')) {
    die;
}
if (class_exists('CSF')) {
    $prefix = 'my_taxonomy_options';
    CSF::createTaxonomyOptions($prefix, array(
        'taxonomy'  => 'category',
        'data_type' => 'unserialize ',
    ));

    CSF::createSection($prefix, array(
        'fields' => array(
            array(
                'id'           => 'ceo_category_bg',
                'type'         => 'media',
                'title'        => '分类列表背景图片',
                'desc'         => '自定义分类列表背景图片~未独立设置则自动调用主题设置-分类设置中默认背景图片',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => '',
            ),
            array(
                'id'           => 'ceo_category_layout',
                'type'         => 'image_select',
                'title'        => '选择分类布局样式',
                'desc'         => '[样式1：卡片布局1]  [样式2：卡片布局2]  [样式3：卡片布局3]  [样式4：视频布局]  [样式5：音频布局]  [样式6：软件布局]  [样式7：文章布局]',
                'options'      => array(
                    '1'    => get_template_directory_uri() . '/static/admin-img/ceo-category-1.jpg',
                    '2'    => get_template_directory_uri() . '/static/admin-img/ceo-category-2.jpg',
                    '3'    => get_template_directory_uri() . '/static/admin-img/ceo-category-3.jpg',
                    '4'    => get_template_directory_uri() . '/static/admin-img/ceo-category-4.jpg',
                    '5'    => get_template_directory_uri() . '/static/admin-img/ceo-category-5.jpg',
                    '6'    => get_template_directory_uri() . '/static/admin-img/ceo-category-6.jpg',
                    '7'    => get_template_directory_uri() . '/static/admin-img/ceo-category-7.jpg',
                ),
                'default' => _ceo('ceo_category_layout_admin'),
            ),
            array(
                'id'           => 'ceo_category_list',
                'type'         => 'image_select',
                'title'        => '选择列表显示排数',
                'desc'         => '[样式1：五个一排]  [样式2：四个一排]',
                'options'      => array(
                    '1'    => get_template_directory_uri() . '/static/admin-img/ceo-list-1.jpg',
                    '2'    => get_template_directory_uri() . '/static/admin-img/ceo-list-2.jpg',
                ),
                'default' => _ceo('ceo_category_list_admin'),
            ),
            array(
                'id'           => 'ceo_category_height',
                'type'         => 'dimensions',
                'title'        => '填写列表图片高度',
                'desc'         => '总裁主题友情提示：<br/>1：填写100，则是等比例正方形，填写小于100或大于100则是高度的长短之差<br/>2：若选择列表样式5（音频列表）时无需填写，音频列表为固定模块尺寸<br/>3：若选择列表样式6（软件列表）时无需填写，软件列表为固定模块尺寸<br/>4：若选择列表样式7（文章列表）时无需填写，文章列表为固定模块尺寸',
                'units'        => ['%'],
                'width'        => false,
                'default' => _ceo('ceo_category_height_admin'),
            ),
            array(
                'id'           => 'ceo_category_single',
                'type'         => 'image_select',
                'title'        => '选择分类内页样式',
                'options'      => array(
                    '1'    => get_template_directory_uri() . '/static/admin-img/ceo-single-1.jpg',
                    '2'    => get_template_directory_uri() . '/static/admin-img/ceo-single-2.jpg',
                ),
                'default' => _ceo('ceo_category_single_admin'),
            ),
        )
    ));

    //自定义SEO标题
    if (true) {
        $fields_arr = [
            array(
                'id'    => 'seo-title',
                'type'  => 'text',
                'title' => '自定义SEO标题',
                'help'  => '不设置则遵循WP标题规则',
            ),
            array(
                'id'    => 'seo-keywords',
                'type'  => 'textarea',
                'title' => '自定义SEO关键词',
                'help'  => '自定义SEO关键词,用英文逗号隔开',
            ),
            array(
                'id'    => 'seo-description',
                'type'  => 'textarea',
                'title' => '自定义SEO描述',
                'help'  => '自定义SEO描述',
            )
        ];
    }
    CSF::createSection($prefix, array(
        'fields' => $fields_arr
    ));
}

//专题
if (class_exists('CSF')) {
    $prefix = 'special_taxonomy_options';
    CSF::createTaxonomyOptions($prefix, array(
        'taxonomy'  => 'special',
        'data_type' => 'unserialize ',
    ));

    CSF::createSection($prefix, array(
        'fields' => array(
            array(
                'id'           => 'catf_background_img',
                'type'         => 'media',
                'title'        => '专题内页顶部背景图片',
                'desc'         => '自定义专题内页顶部背景图片~未独立设置则自动调用主题设置-单页设置-专题页面设置中默认专题内页顶部背景图片',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => '',
            ),
            array(
                'id'           => 'cate_background_img',
                'type'         => 'media',
                'title'        => '专题模块图片',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => '',
            ),
        )
    ));
    if (true) {
        $fields_arr = [
            array(
                'id'    => 'seo-title',
                'type'  => 'text',
                'title' => '自定义SEO标题',
                'help'  => '不设置则遵循WP标题规则',
            ),
            array(
                'id'    => 'seo-keywords',
                'type'  => 'textarea',
                'title' => '自定义SEO关键词',
                'help'  => '自定义SEO关键词,用英文逗号隔开',
            ),
            array(
                'id'    => 'seo-description',
                'type'  => 'textarea',
                'title' => '自定义SEO描述',
                'help'  => '自定义SEO描述',
            )
        ];
    }
    CSF::createSection($prefix, array(
        'fields' => $fields_arr
    ));
}