<?php
$btn_set = _ceo('ceo_user_btn_set');
$action = get_query_var('action') ?: 'center';

get_header();

$action_file = get_template_directory() . '/member/action/' . $action . '.php';

$args = array(
	'post_author' => $user_id
);
$author_comments = get_comments($args);

$userId = get_current_user_id();
$isVip = CeoShopCoreUser::getVipGradeId($userId) != -1;

?>
<section class="member-main">
	<div class="ceo-container1200">
		<div class="ceo-grid-ceosmls" ceo-grid>
			<div class="ceo-width-1-1 ceo-width-1-4@s sidebar">
				<div class="theiaStickySidebar">
					<div class="member-module b-b ceo-background-default">
						<?php if (_ceo('ceo_shop_sign_in')) : ?>
							<a href="javascript:void(0)" class="btn-ceo-sign ceo-sign member-sign" data-style="slide-down">签到</a>
						<?php endif; ?>
						<div class="ceo-text-center member-img">
							<div class="img">
								<?php echo get_avatar($user_id, 100); ?>
								<?php if (user_can($user_id, 'author') || user_can($user_id, 'editor') || user_can($user_id, 'administrator')) { ?>
									<i ceo-tooltip="认证作者"></i>
								<?php } ?>
							</div>
						</div>
						<div class="member-text ceo-text-center">
							<p class="member-name"><a href="<?php echo get_author_posts_url($user_id, get_userdata($user_id)->user_nicename); ?>"><?php echo $current_user->display_name; ?></a></p>
							<?php if (!$isVip) : ?>
								<p class="member-desc-n"><i class="ceofont ceoicon-vip-crown-2-line"></i>您还不是VIP会员<a href="javascript:void(0)" class="btn-ceo-svip">升级</a></p>
							<?php else : ?>
								<p class="member-desc-v" ceo-tooltip="有效期至：<?php echo substr(CeoShopCoreUser::getVipTerm($userId), 0, 10) ?>"><i class="ceofont ceoicon-vip-crown-2-line"></i>您目前是<?php echo CeoShopCoreUser::getVipGrade($userId) ?></p>
							<?php endif; ?>
							<?php if (_ceo('ceo_user_btn') == true) : ?>
								<div class="ceo-grid-small" ceo-grid>
									<div class="ceo-width-1-2">
										<a href="<?php echo $btn_set['link1'] ?>" class="member-btn1">
											<i class="ceofont <?php echo $btn_set['icon1'] ?>"></i> <?php echo $btn_set['title1'] ?>
										</a>
									</div>
									<div class="ceo-width-1-2">
									    <a href="<?php echo $btn_set['link2'] ?>" class="member-btn2">
											<i class="ceofont <?php echo $btn_set['icon2'] ?>"></i> <?php echo $btn_set['title2'] ?>
										</a>
									</div>
								</div>
							<?php endif; ?>
						</div>
					</div>
					<div class="member-data ceo-background-default">
						<ul class="member-nav">
						    <?php if (_ceo('ceo_user_nav_center') == true) : ?>
							<li class="<?php if ($action == 'center') echo 'active'; ?>">
								<a href="<?php echo home_url(user_trailingslashit('/member/center')); ?>">
								    <i class="ceofont <?php echo _ceo('ceo_user_nav_center_icon'); ?>"></i>
									商城中心
								</a>
							</li>
							<?php endif; ?>
						    <?php if (_ceo('ceo_user_nav_property') == true) : ?>
							<li class="<?php if ($action == 'property' || $action == 'integral' || $action == 'task') echo 'active'; ?>">
								<a href="<?php echo home_url(user_trailingslashit('/member/property')); ?>">
								    <i class="ceofont <?php echo _ceo('ceo_user_nav_property_icon'); ?>"></i>
									我的资产
								</a>
							</li>
							<?php endif; ?>
						    <?php if (_ceo('ceo_user_nav_order') == true) : ?>
							<li class="<?php if ($action == 'order' || $action == 'viporder') echo 'active'; ?>">
								<a href="<?php echo home_url(user_trailingslashit('/member/order')); ?>">
								    <i class="ceofont <?php echo _ceo('ceo_user_nav_order_icon'); ?>"></i>
									我的订单
								</a>
							</li>
							<?php endif; ?>
						    <?php if (_ceo('ceo_user_nav_download') == true) : ?>
							<li class="<?php if ($action == 'download') echo 'active'; ?>">
								<a href="<?php echo home_url(user_trailingslashit('/member/download')); ?>">
								    <i class="ceofont <?php echo _ceo('ceo_user_nav_download_icon'); ?>"></i>
									我的下载
								</a>
							</li>
							<?php endif; ?>
						    <?php if (_ceo('ceo_user_nav_card') == true) : ?>
							<li class="<?php if ($action == 'card' || $action == 'vipcard') echo 'active'; ?>">
								<a href="<?php echo home_url(user_trailingslashit('/member/card')); ?>">
								    <i class="ceofont <?php echo _ceo('ceo_user_nav_card_icon'); ?>"></i>
									我的卡券
								</a>
							</li>
							<?php endif; ?>
						    <?php if (_ceo('ceo_user_nav_reward') == true) : ?>
							<li class="<?php if ($action == 'reward' || $action == 'promotion' || $action == 'commission') echo 'active'; ?>">
								<a href="<?php echo home_url(user_trailingslashit('/member/reward')); ?>">
								    <i class="ceofont <?php echo _ceo('ceo_user_nav_reward_icon'); ?>"></i>
									我的推广
								</a>
							</li>
							<?php endif; ?>
						    <?php if (_ceo('ceo_user_nav_income') == true) : ?>
							<li class="<?php if ($action == 'income' || $action == 'withdrawal') echo 'active'; ?>">
								<a href="<?php echo home_url(user_trailingslashit('/member/income')); ?>">
								    <i class="ceofont <?php echo _ceo('ceo_user_nav_income_icon'); ?>"></i>
									我的收益
								</a>
							</li>
							<?php endif; ?>
							<?php if (_ceo('ceo_user_nav_authentication') == true) : ?>
							<li class="<?php if ($action == 'authentication') echo 'active'; ?>">
								<a href="<?php echo home_url(user_trailingslashit('/member/authentication')); ?>">
								    <i class="ceofont <?php echo _ceo('ceo_user_nav_authentication_icon'); ?>"></i>
									我的认证
								</a>
							</li>
							<?php endif; ?>
						    <?php if (_ceo('ceo_user_nav_post') == true) : ?>
                        	<li class="<?php if($action == 'user-post') echo 'active';?>">
                				<a href="<?php echo home_url(user_trailingslashit('/member/user-post')); ?>">
								    <i class="ceofont <?php echo _ceo('ceo_user_nav_post_icon'); ?>"></i>
                		            我的发布
                				</a>
            				</li>
							<?php endif; ?>
						    <?php if (_ceo('ceo_user_nav_collection') == true) : ?>
            				<li class="<?php if($action == 'user-collection') echo 'active';?>">
                				<a href="<?php echo home_url(user_trailingslashit('/member/user-collection')); ?>">
								    <i class="ceofont <?php echo _ceo('ceo_user_nav_collection_icon'); ?>"></i>
                		            我的收藏
                				</a>
            				</li>
							<?php endif; ?>
                            <li class="<?php if ($action == 'user-follows' || $action == 'user-message' || $action == 'user-settings' || $action == 'user-security') echo 'active'; ?>">
                				<a href="<?php echo home_url(user_trailingslashit('/member/user-follows')); ?>">
								    <i class="ceofont <?php echo _ceo('ceo_user_nav_users_icon'); ?>"></i>
                		            个人中心
                				</a>
            				</li>
							<li>
								<a href="<?php echo wp_logout_url(home_url()); ?>" class="ceo-display-inline-block"><i class="ceofont <?php echo _ceo('ceo_user_nav_logout_icon'); ?>"></i>退出登录</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="ceo-width-1-1 ceo-width-3-4@s">
				<div class="member-content">
					<?php
					if (!is_file($action_file)) {
						include(get_template_directory() . '/member/action/center.php'); //用户中心默认页面
					} else {
						include($action_file);
					}
					?>
				</div>
			</div>
		</div>
	</div>
</section>
<?php get_footer(); ?>