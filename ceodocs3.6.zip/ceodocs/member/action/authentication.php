<?php
    $title = _ceo('ceo_user_auth_page_title');
    $realName = get_user_meta($userId, 'ceo_user_real_name', true);
    $sfz = get_user_meta($userId, 'ceo_user_sfz', true);
?>
<div class="member-authentication ceo-background-default">
    <div class="bg ceo-background-cover ceo-background-muted ceo-panel ">
        <div class="ceo-container">
            <div class="title ceo-text-center">
                <h1><?php echo $title['title'] ?></h1>
                <p><?php echo $title['subtitle'] ?></p>
            </div>
        </div>
    </div>
    <div class="module ceo-background-default">
        <?php if (empty($sfz)): ?>
        <div class="ceo-grid-ceosmls" ceo-grid>
            <div class="ceo-width-1-1 ceo-width-1-2@s">
                <div class="front">
                    
                </div>
            </div>
            <div class="ceo-width-1-1 ceo-width-1-2@s">
                <div class="behind">
                </div>
            </div>
        </div>
        <div class="box">
            <form action="" id="" method="" class="ceo-form">
    		    <div class="ceo-grid-ceosmls" ceo-grid>
        		    <div class="ceo-width-1-1 ceo-width-1-2@s">
        				<label>真实姓名</label>
        				<input id="real_name" type="text" name="" value="" lay-verify="required" placeholder="* 请输入真实姓名" class="b-r-4 ceo-input ceo-margin-small-top">
        			</div>
        		    <div class="ceo-width-1-1 ceo-width-1-2@s">
        				<label>身份证号码</label>
        				<input id="sfz" type="text" name="" value="" lay-verify="required" placeholder="* 请输入身份证号码" class="b-r-4 ceo-input ceo-margin-small-top">
        			</div>
    			</div>
			</form>
			<div class="btn">
			    <a id="submit-ceo-auth" href="javascript:void(0)">提交认证</a>
			    <p><?php echo $title['prompt'] ?></p>
		    </div>
        </div>
        <?php else: ?>
        <?php 
            $realName = mb_substr($realName, 0, 1) . str_repeat('*', mb_strlen($realName) - 1);
            $sfz = mb_substr($sfz, 0, 6) . str_repeat('*', mb_strlen($sfz) - 10) . mb_substr($sfz, -4);
        
        ?>
        <ul>
            <li>
                <span>真实姓名：</span>
                <p><?php echo $realName ?></p>
            </li>
            <li>
                <span>身份证号码：</span>
                <p><?php echo $sfz ?></p>
            </li>
            <em>恭喜您已完成实名认证！</em>
        </ul>
        <?php endif; ?>
    </div>
</div>

<script>
    $(function() {
        $('#submit-ceo-auth').click(function() {
            let btnLoading = Ladda.create(this);
            btnLoading.start()
            $.ajax({
                url: ceotheme.ajaxurl + '?action=ceo_shop_member_user_auth',
                method: 'POST',
                data: {real_name: $('#real_name').val(), sfz: $('#sfz').val()},
                success: function(res) {
                    btnLoading.stop()
                    btnLoading.remove()
                    if (res.success) {
                        UIkit.notification(res.data, { status: 'success' })
                        window.setTimeout(function () {
                            window.location.reload()
                        }, 1500)
                    } else {
                        UIkit.notification(res.data, { status: 'warning' })
                    }
                }
            })
        })
    })
</script>