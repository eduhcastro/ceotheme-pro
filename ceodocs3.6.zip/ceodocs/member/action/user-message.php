<?php
$subpage='messages';
$current_tab['slug']='messages';
?>
<div class="user-page ceo-background-default ceo-margin-bottom">
    <div class="titles">个人中心</div>
    <div class="nav">
        <a href="/member/user-follows/">我的关注</a>
        <a href="/member/user-message/" class="current">我的私信</a>
        <a href="/member/user-settings/">我的资料</a>
        <a href="/member/user-security/">账号安全</a>
    </div>
    <div class="middle">
        <?php if( isset($GLOBALS['validation']) && empty( $GLOBALS['validation']['error'] ) ) { ?>
            <div class="alert alert-success" role="alert">
                <div class="close" data-dismiss="alert"><?php CEO::icon('close');?></div>
                <?php _e( 'Updated successfully.', 'ceo' ); ?>
            </div>
        <?php } ?>
        <?php do_action( 'ceo_account_tabs_' . $subpage ); ?>
    </div>
</div>

<?php add_action('get_footer', function () { wp_enqueue_script('js2021', get_template_directory_uri() . '/static/js/js21.js', ['jquery']); }); ?>