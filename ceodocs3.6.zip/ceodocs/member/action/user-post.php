<?php

global $wpdb;
$user_id        = get_current_user_id();
$paged = ! empty($_GET["pg"]) ? (int)$_GET["pg"] : 1;
$args = array(
    'post_type'           => 'post',
    'author'             => $user_id,
    'ignore_sticky_posts' => 1,
    'posts_per_page'      => 20,
    'paged'                => $paged
);
global $wp_query;
$wp_query = new WP_Query($args);
?>
<div class="user-page ceo-background-default ceo-margin-bottom">
    <div class="titles">我的发布</div>
    <div class="middle">
        <?php if( $wp_query && $wp_query->have_posts() ){ ?>
        <div class="waterfall">
	        <ul class="ceo-child-width-1-2 ceo-child-width-1-4@s" ceo-grid="masonry: true">
                <?php
            		while( $wp_query->have_posts() ) : $wp_query->the_post();
            	?>
            	<li>
            	    <?php get_template_part( 'template-parts/loop/loop', 'user' ); ?>
        	    </li>
            	<?php endwhile; ?>
            </ul>
        </div>
    
    	<?php }else{ ?>
        <div class="empty">
            <i></i>
            <p>您目前没有发布任何文章～</p>
        </div>
    	<?php } ?>
    </div>
    
    <div class="ceo-fanye">
        <?php
        $args = array(
            'prev_next'          => 0,
            'format'       => '?pg=%#%',
            'before_page_number' => '',
            'mid_size'           => 2,
            'current' => max( 1, $paged ),
            'prev_next'    => True,
            'prev_text'    => __('上一页'),
            'next_text'    => __('下一页'),
        );
        $page_arr=paginate_links($args);
        if ($page_arr) {
            echo $page_arr;
        }else{
    
        } ?>
    </div>
</div>