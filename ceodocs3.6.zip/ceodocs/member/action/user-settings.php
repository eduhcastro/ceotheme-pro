<div class="user-page ceo-background-default ceo-margin-bottom">
    <div class="titles">个人中心</div>
    <div class="nav">
        <a href="/member/user-follows/">我的关注</a>
        <a href="/member/user-message/">我的私信</a>
        <a href="/member/user-settings/" class="current">我的资料</a>
        <a href="/member/user-security/">账号安全</a>
    </div>
    <div class="middle">
        <div class="settings">
        	<div class="head">
        		<div class="ceo-grid-small" ceo-grid>
        			<div class="ceo-width-auto">
        				<div class="avatar ceo-text-center ceo-border-circle ceo-overflow-hidden">
        					<?php echo get_avatar( $user_id ,60 );?>
        				</div>
        			</div>
        			<div class="ceo-width-expand">
        				<span class="name ceo-display-block ceo-text-bolder"><?php echo $current_user->display_name; ?></span>
        				<span class="desc ceo-text-small ceo-text-muted">建议尺寸: 100×100px，支持: .jpg、.gif、.png格式的图片，图片大小请不要超过1M</span>
        			</div>
        			<div class="ceo-width-auto">
        				<form action="<?php echo get_bloginfo('template_url');?>/member/action/user-avatar.php" method="post" role="form" name="AvatarForm" class="b-r-4 upload-form" id="AvatarForm" enctype="multipart/form-data">
        				    <span class="ceo-position-center">上传头像</span>
        					<input type="file" name="addPic" id="addPic" ng-multiple="false" accept=".jpg, .gif, .png" resetonclick="true" class="upload-avatar">
        				</form>
        			</div>
        		</div>
        	</div>
        	<div class="ceo-margin-top">
        		<form action="" id="updata_accounts" method="post" class="ceo-form">
        		    <div class="ceo-grid-small" ceo-grid>
            		    <div class="ceo-width-1-1 ceo-width-1-2@s">
            				<label class="rl-label ceo-text-muted">会员ID</label>
            				<input type="text" value="<?php echo esc_attr( $current_user->user_login ); ?>" disabled="disabled" class="form-control b-r-4 ceo-input ceo-margin-small-top">
            			</div>
            		    <div class="ceo-width-1-1 ceo-width-1-2@s">
            				<label class="rl-label ceo-text-muted">注册时间</label>
            				<input type="text" value="<?php echo get_date_from_gmt( $current_user->user_registered ) ?>" disabled="disabled" class="form-control b-r-4 ceo-input ceo-margin-small-top">
            			</div>
        			</div>
        		    <div class="ceo-grid-small" ceo-grid>
            			<div class="ceo-width-1-1 ceo-width-1-2@s">
            				<label for="nickname" class="rl-label ceo-text-muted">账户昵称</label>
            				<input type="text" id="nickname" name="nickname" value="<?php echo $current_user->display_name; ?>" placeholder="请输入您的昵称..." class="b-r-4 ceo-input ceo-margin-small-top">
            			</div>
        			    <div class="ceo-width-1-1 ceo-width-1-2@s">
            				<label for="email" class="rl-label ceo-text-muted">邮箱账号</label>
            				<input type="email" id="email" name="email" value="<?php echo get_userdata(get_current_user_id())->user_email; ?>" placeholder="请输入您的邮箱账号..." class="b-r-4 ceo-input ceo-margin-small-top">
        			    </div>
        			</div>
        			<div class="ceo-grid-small" ceo-grid>
            			<div class="ceo-width-1-1 ceo-width-1-2@s">
            				<label for="qq" class="rl-label ceo-text-muted">QQ号码</label>
            				<input type="text" id="qq" name="qq" value="<?php echo get_the_author_meta('qq',$user_id); ?>" placeholder="请输入您的QQ号码..." class="b-r-4 ceo-input ceo-margin-small-top">
            			</div>
            			<div class="ceo-width-1-1 ceo-width-1-2@s">
            				<label for="weixin" class="rl-label ceo-text-muted">微信号码</label>
            				<input type="text" id="weixin" name="weixin" value="<?php echo get_user_meta( $user_id , 'weixin' , true ); ?>" placeholder="请输入您的微信号码..." class="b-r-4 ceo-input ceo-margin-small-top">
            			</div>
        			</div>
        			<div class="ceo-width-1-1 ceo-margin">
        				<label for="description" class="rl-label ceo-text-muted">个性签名</label>
        				<input type="text" id="description" name="description" value="<?php echo get_the_author_meta('description',$user_id); ?>" placeholder="请输入您的个性签名..." class="b-r-4 ceo-input ceo-margin-small-top">
        			</div>
        			<input type="hidden" name="nonce" value="<?php echo wp_create_nonce( 'upload_data' ); ?>">
        			<input type="hidden" name="action" value="updata_accounts">
        			<button class="ceo-button" type="submit">保存设置</button>
        		</form>
        	</div>
    	</div>
	</div>
</div>
<!--头像上传-->
<script src="<?php echo get_bloginfo('template_url');?>/static/js/jquery.form.js"></script>
<script>
	jQuery(function($){
		$("#addPic").change(function(){
			$("#AvatarForm").ajaxSubmit({
				dataType:  'json',
				beforeSend: function() {
					//return tips('上传中...');
				},
				uploadProgress: function(event, position, total, percentComplete) {

				},
				success: function(data) {
					if (data == "1") {
						//tips('头像修改成功');
						location.reload();
					}else if(data == "2"){
						alert('图片大小请不要超过1M');
					}else if(data == "3"){
						alert('图片格式只支持.jpg .png .gif');
					}else{
						alert('上传失败');
					}
				},
				error:function(xhr){
					alert('上传失败.');
				}
			});

		});
	});
</script>