<?php
// 登录页面背景图片
add_filter('body_class',function ($classes) {
	$classes[]	= 'joy-login';
	return $classes;
});
get_header();
?>
<section class="ceo-container">
    <div class="page-login ceo-animation-slide-bottom-small">
        <?php include get_template_directory().'/member/login/'.$action.'.php'; ?>
    </div>
</section>
<?php get_footer(); ?>