<?php
    $login = _ceo('login_set');
?>
<div class="login-main">
    <div class="ceo-grid-collapse" ceo-grid>
        <div class="ceo-width-1-1 ceo-width-1-2@s ceo-visible@m">
            <div class="left" style="background-image: url(<?php echo _ceo('login_page_img'); ?>)"></div>
        </div>
        <div class="ceo-width-1-1 ceo-width-1-2@s">
            <div class="right ceo-background-default">
                <form action="" method="POST" id="register-form" class="login-weixin">
                    <div class="title">账号注册</div>
        		    <div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
        		        <span class="ceo-form-icon"><i class="ceofont ceoicon-mail-line"></i></span>
            			<input type="email" id="email_address2" class="b-r-4 ceo-input" name="email_address2" placeholder="请输入邮箱" required="required">
        			</div>
        			<div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
        		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-user-line"></i></span>
        			    <input type="text" id="username2" class="b-r-4 ceo-input" name="username2" placeholder="请输入账号(英文/数字)" required="required">
        			</div>
        			<div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
        		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-keyhole-line"></i></span>
        			    <input type="password" id="password2" class="b-r-4 ceo-input" name="password2" placeholder="请输入密码" required="required">
        			</div>
        			<div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
        		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-keyhole-line"></i></span>
        			    <input type="password" id="repeat_password2" class="b-r-4 ceo-input" name="repeat_password2" placeholder="请再次输入密码" required="required">
                    </div>
            		<div class="agreen ceo-margin-bottom">
                        <input id="agreement" name="agreen" type="checkbox" required>
                        <label for="agreen"></label>
                        我已阅读并同意<a href="<?php echo $login['link'] ?>" target="_blank"><?php echo $login['title'] ?></a>
                    </div>
        
                    <div class="ceotheme-tips ceo-margin ceo-text-danger"></div>
        			<input type="hidden" name="action" value="zongcai_register">
        			<input type="hidden" name="ref" value="<?php echo $_GET['ref'] ?>">
        			<button class="login-button ceo-button b-r-4 ceo-width-1-1 button mid dark">立即注册</button>
        		</form>
        		<?php if(_ceo('qq_login') || _ceo('is_oauth_mpweixin') || _ceo('weixin_login') || _ceo('weibo_login')){?>
        		<div class="socialize">
    		        <div class="title">
    		            <em></em>
    		            <span>其他登录方式</span>
    		            <em></em>
    	            </div>
    	            <div class="type">
                        <?php if(_ceo('qq_login')){?>
                    	<a href="javascript:;" class="button mid qq half qq_login_button ceo_qq_login" ceo-tooltip="QQ登录"><i class="ceofont ceoicon-qq-fill"></i></a>
                    	<?php }?>
                    	<?php if(_ceo('is_oauth_mpweixin')){?>
                    	<a href="<?php echo esc_url(home_url('/oauth/mpweixin')); ?>" class="mpweixin_login_button btn change-color social-login button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="关注微信公众号登录"><i class="ceofont ceoicon-wechat-fill"></i></a>
                        <?php }elseif(_ceo('weixin_login')){?>
                    	<a href="<?php echo esc_url(home_url('/oauth/'.'weixin'.'?rurl='.home_url(add_query_arg(array())))); ?>" class="btn change-color social-login button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="微信登录"><i class="ceofont ceoicon-wechat-fill"></i></a>
                        <?php }?>
                    	<?php if(_ceo('weibo_login')){?>
                    	<a href="<?php echo weibo_oauth_url();?>" class="ceo_weibo_login" ceo-tooltip="微博登录"><i class="ceofont ceoicon-weibo-fill"></i></a>
                    	<?php }?>
                	</div>
                </div>
            	<?php }?>
            </div>
            <div class="bottom">
    		    <div class="ceo-flex">
    		    注册即同意<a href="<?php echo $login['link'] ?>" target="_blank" class="ceo-flex-1"><?php echo $login['title'] ?></a>已有账号？ <a href="/member/login">立即登录</a>
    		    </div>
    		</div>
        </div>
    </div>
</div>