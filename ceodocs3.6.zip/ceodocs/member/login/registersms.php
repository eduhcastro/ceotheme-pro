<?php
    $login = _ceo('login_set');
?>
<div class="login-main">
    <div class="ceo-grid-collapse" ceo-grid>
        <div class="ceo-width-1-1 ceo-width-1-2@s ceo-visible@m">
            <div class="left" style="background-image: url(<?php echo _ceo('login_page_img'); ?>)"></div>
        </div>
        <div class="ceo-width-1-1 ceo-width-1-2@s">
            <div class="right ceo-background-default">
                <form action="" method="POST" id="login-form" class="login-weixin">
                    <div class="title">手机登录/注册</div>
                    <div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
                        <span class="ceo-form-icon"><i class="ceofont ceoicon-smartphone-line"></i></span>
                        <input type="number" name="user_mobile" id="user_mobile" class="b-r-4 ceo-input" placeholder="请输入手机号" required="required">
                    </div>
                    <div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
                        <div class="ceo-grid-small" ceo-grid>
                            <div class="ceo-width-3-5">
                                <span class="ceo-form-icon"><i class="ceofont ceoicon-newspaper-line"></i></span>
                                <input type="text" name="captcha" id="captcha" placeholder="请输入验证码" class="b-r-4 ceo-input" value="">
                            </div>
                            <div class="ceo-width-2-5">
                                <span class="input-group-btn">
                                    <script>var is_sms_login=true</script>
                                    <button class="go-captcha_mobile b-r-4 button mid dark ceo-button ceo-button-default ceo-width-1-1" type="button"
                                                    data-smstype="login" data-nonce="<?php echo wp_create_nonce('captcha_mobile'); ?>">发送验证码</button>
                                </span>
                            </div>
                        </div>
                    </div>
        			<div class="desc ceo-flex ceo-margin-bottom">
                		<p class="ceo-flex-1"><a class="forget" href="/wp-login.php?action=lostpassword">忘记密码？</a></p>
                		<p><a href="/member/login">账号密码登录</a></p>
            		</div>
        
                    <div class="ceotheme-tips ceo-margin ceo-text-danger"></div>
        			<input type="hidden" name="action" value="zongcai_login_sms">
        			<button class="login-button ceo-button b-r-4 ceo-width-1-1 button mid dark ceo-display-block">立即登录</button>
        		</form>
        		<?php if(_ceo('qq_login') || _ceo('is_oauth_mpweixin') || _ceo('weixin_login') || _ceo('weibo_login')){?>
        		<div class="socialize">
    		        <div class="title">
    		            <em></em>
    		            <span>其他登录方式</span>
    		            <em></em>
    	            </div>
    	            <div class="type">
                        <?php if(_ceo('qq_login')){?>
                    	<a href="javascript:;" class="button mid qq half qq_login_button ceo_qq_login" ceo-tooltip="QQ登录"><i class="ceofont ceoicon-qq-fill"></i></a>
                    	<?php }?>
                    	<?php if(_ceo('is_oauth_mpweixin')){?>
                    	<a href="<?php echo esc_url(home_url('/oauth/mpweixin')); ?>" class="mpweixin_login_button btn change-color social-login button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="关注微信公众号登录"><i class="ceofont ceoicon-wechat-fill"></i></a>
                        <?php }elseif(_ceo('weixin_login')){?>
                    	<a href="<?php echo esc_url(home_url('/oauth/'.'weixin'.'?rurl='.home_url(add_query_arg(array())))); ?>" class="btn change-color social-login button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="微信登录"><i class="ceofont ceoicon-wechat-fill"></i></a>
                        <?php }?>
                    	<?php if(_ceo('weibo_login')){?>
                    	<a href="<?php echo weibo_oauth_url();?>" class="ceo_weibo_login" ceo-tooltip="微博登录"><i class="ceofont ceoicon-weibo-fill"></i></a>
                    	<?php }?>
                	</div>
                </div>
                <?php }?>
            </div>
            <div class="bottom">
    		    <div class="ceo-flex">
    		    登录即同意<a href="<?php echo $login['link'] ?>" target="_blank" class="ceo-flex-1"><?php echo $login['title'] ?></a>没有账号？ <a href="/member/register/">立即注册</a>
    		    </div>
    		</div>
        </div>
    </div>
</div>