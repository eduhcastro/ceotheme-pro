<?php
/* Template Name: 默认 */
get_header(); 
$text = _ceo('page-text');
$bg = _ceo('page-bg');
?>
<div class="ceo-default-bg ceo-background-cover ceo-background-muted ceo-panel ceo-flex ceo-flex-center ceo-flex-middle" style="background-image: url(<?php echo $bg; ?>)">
    <div class="ceo-container1280">
        <div class="title ceo-position-center ceo-text-center">
            <h1><?php the_title(); ?></h1>
            <p><?php echo $text; ?></p>
        </div>
    </div>
</div>
<section class="ceo-container1280">
	<div class="ceo-background-default single-content ceo-margin-medium-bottom">
		<?php while(have_posts()) : the_post(); ?>
		<?php the_content(); ?>
		<?php endwhile; ?>
	</div>	
	<?php if(_ceo('comments_close') == false ): ?>	
	<?php if ( comments_open() || get_comments_number() ) : ?>
	<?php comments_template( '', true ); ?>
	<?php endif; ?>
	<?php endif; ?>
</section>
<?php get_footer(); ?>