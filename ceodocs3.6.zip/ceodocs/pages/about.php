<?php 
/* Template Name: 单页合集 */ 
get_header();
?>
<div class="ceo-page-about">
    <div class="ceo-container1280">
        <div class="position">
    	    <?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
        </div>
        <div class="ceo-grid-ceosmls" ceo-grid>
            <div class="sidebar ceo-width-1-1 ceo-width-1-6@s">
            	<div class="theiaStickySidebar">
            	    <ul class="about-menu ceo-background-default b-r-4">
            		    <?php ceo_menu('page-nav'); ?>
            		</ul>
            	</div>
            </div>
            <div class="ceo-width-1-1 ceo-width-5-6@s">
            	<div class="about-main b-r-4 ceo-background-default">
        	        <h1 class="title"><?php the_title(); ?></h1>
            		<div class="about-content single-content">
            			<?php while(have_posts()) : the_post(); ?>
            			<?php the_content(); ?>
            			<?php endwhile; ?>
            		</div>
            		<?php if(_ceo('comments_close') == false ): ?>	
            		<?php if ( comments_open() || get_comments_number() ) : ?>
            		<?php comments_template( '', true ); ?>
            		<?php endif; ?>
            		<?php endif; ?>
            	</div>
        	</div>
    	</div>
    </div>
</div>
<?php get_footer(); ?>