<?php
/*
Template Name: 申请入驻
*/
get_header(); 
$top = _ceo('apply_top');
$cms = _ceo('apply_cms');
$apply_center = _ceo('apply_center');
$apply_center_set = _ceo('apply_center_set');
$apply_question_set = _ceo('apply_question_set');
?>
<div class="ceo-apply-bg">
    <div class="bg ceo-inline ceo-background-muted ceo-panel ceo-flex ceo-flex-center ceo-flex-middle" style="background-image: url(<?php echo $top['bg'] ?>)">
        <div class="ceo-container1280">
            <div class="title ceo-position-center ceo-text-center">
                <h1><?php echo $top['title'] ?></h1>
                <p><?php echo $top['subtitle'] ?></p>
                <?php if( is_user_logged_in() ){?>
                <a ceo-toggle="target: #form">立即入驻</a>
                <?php }else{ ?>
                <a ceo-toggle="target: #navbar-login">立即入驻</a>
                <?php } ?>
            </div>
        </div>
    </div>
    <div class="ceo-container1280">
        <div class="bgmodule ceo-background-default">
            <ul class="ceo-child-width-1-2 ceo-child-width-1-4@s ceo-grid-large" ceo-grid>
                <?php
		            if ($cms) {
					foreach ( $cms as $key => $value) {
				?>
                <li>
                    <i class="ceofont <?php echo $value['icon'] ?>"></i>
                    <span><?php echo $value['title'] ?></span>
                    <p><?php echo $value['subtitle'] ?></p>
                </li>
                <?php } } ?>
            </ul>
        </div>
    </div>
</div>
<div class="ceo-page-apply">
    <div class="ceo-container1280">
        <div class="center">
            <div class="title">
                <span><?php echo $apply_center['title'] ?></span>
                <p><?php echo $apply_center['subtitle'] ?></p>
            </div>
            <ul class="ceo-child-width-1-2 ceo-child-width-1-3@s ceo-grid-medium" ceo-grid>
                <?php
		            if ($apply_center_set) {
					foreach ( $apply_center_set as $key => $value) {
				?>
                <li>
                    <span><i class="ceofont <?php echo $value['icon'] ?>"></i><?php echo $value['center'] ?></span>
                </li>
                <?php } } ?>
            </ul>
        </div>
    </div>
    <div class="question">
        <div class="ceo-container1280">
            <div class="box">
                <div class="title"><?php echo _ceo('apply_question'); ?></div>
                <ul class="ceo-child-width-1-1 ceo-child-width-1-2@s ceo-grid-large" ceo-grid>
                    <?php
    		            if ($apply_question_set) {
    					foreach ( $apply_question_set as $key => $value) {
    				?>
                    <li>
                        <div class="content">
                            <span><em>Q</em><?php echo $value['title'] ?></span>
                            <p><em>A</em><?php echo $value['content'] ?></p>
                        </div>
                    </li>
                <?php } } ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<div id="form" class="apply-box" ceo-modal>
    <div class="ceo-modal-dialog ceo-modal-body ceo-margin-auto-vertical">
        <div class="applytitle">
            <span>填写资料</span>
            <p>我们珍惜每一位有梦想的设计师入驻</p>
        </div>
        <form class="loginForm" id="custom_loginForm">
            <div class="ceo-grid-ceosmls" ceo-grid>
                <?php if(_ceo('apply_sz_username') == true ): ?>
                <div class="ceo-apply-txt ceo-width-1-2">
                    账号昵称：<input type="text" name="username" lay-verify="required|userName" value="<?php echo $current_user->display_name; ?>" disabled="disabled" class="form-control ceo-input"/></input>
                </div>
                <?php endif; ?>
                <?php if(_ceo('apply_sz_hyid') == true ): ?>
                <div class="ceo-apply-txt ceo-width-1-2">
                    用户ID：<input type="text" name="hyid" value="<?php echo esc_attr( $current_user->user_login ); ?>" disabled="disabled" class="form-control ceo-input"/>
                </div>
                <?php endif; ?>
            </div>
            <?php if(_ceo('apply_sz_real_auth') == true ): ?>
                <?php
                    $realName = get_user_meta(get_current_user_id(), 'ceo_user_real_name', true);
                    $sfz = get_user_meta(get_current_user_id(), 'ceo_user_sfz', true);
                ?>
                <?php if (!empty($sfz)): ?>
                    <div class="ceo-grid-ceosmls ceo-margin-bottom" ceo-grid>
                        <div class="ceo-apply-txt ceo-width-1-2">
                            真实姓名：<input type="text" name="bankno" value="<?php echo $realName ?>" disabled="" placeholder="* 请填写真实姓名" lay-verify="required" class="ceo-input"/>
                        </div>
                        <div class="ceo-apply-txt ceo-width-1-2">
                            身份证号：<input type="text" name="score" value="<?php echo $sfz ?>" disabled="" placeholder="* 请填写身份证号" lay-verify="required" class="ceo-input"/>
                        </div>
                    </div>
                <?php else: ?>
                    <p style="margin: 15px; font-size: 16px; font-weight: bold;">请先 <a href="/member/authentication/" target="__blank" style="color: var(--primary-color);">实名认证</a> 后提交申请</p>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(_ceo('apply_sz_sfz') == true ): ?>
            <!--<div class="ceo_apple_is ceo-margin-bottom">-->
            <!--    <div class="ceo-apply-txt">-->
            <!--        身份证照：-->
            <!--    </div>-->
            <!--    <div class="ceo-apply-sfz" ceo-grid>-->
            <!--        <div class="ceo-apply-sfzimg ceo-width-1-2">-->
            <!--            <input type="text" name="yfz1" id="yfz1" placeholder="* 身份证正面" lay-verify="required" class="ceo-input"/>-->
            <!--            <input type="button" class="applybat codeBtn filebtn" data-id="fileyfz1" value="上传" />-->
            <!--            <img style="display: none;margin-bottom: 30px;border-radius: 4px;" class="previewyfz1">-->
            <!--            <input type="file" class="fileyfz" data-id="yfz1" id="fileyfz1" name="fileyfz1" placeholder="图片" />-->
            <!--        </div>-->
            <!--        <div class="ceo-apply-sfzimg ceo-width-1-2">-->
            <!--            <input type="text" name="yfz2" id="yfz2" placeholder="* 身份证反面" lay-verify="required" class="ceo-input"/>-->
            <!--            <input type="button" class="applybat codeBtn filebtn" data-id="fileyfz2" value="上传" />-->
            <!--            <img style="display: none;margin-bottom: 30px;border-radius: 4px;" class="previewyfz2">-->
            <!--            <input type="file" class="fileyfz" data-id="yfz2" id="fileyfz2" name="fileyfz2" placeholder="图片" />-->
            <!--        </div>-->
            <!--    </div>-->
            <!--</div>-->
            <?php endif; ?>
            <div class="ceo-grid-ceosmls ceo-margin-bottom" ceo-grid>
                <?php if(_ceo('apply_sz_phone') == true ): ?>
                <div class="ceo-apply-txt ceo-width-1-2">
                    手机号码：<input type="text" name="phone" class="userLogo ceo-input" placeholder="* 请填写手机号码" lay-verify="phone"/>
                </div>
                <?php endif; ?>
                <?php if(_ceo('apply_sz_price') == true ): ?>
                <div class="ceo-apply-txt ceo-width-1-2">
                    微信号码：<input type="text" name="price" placeholder="* 请填写微信号码" lay-verify="required" class="ceo-input"/>
                </div>
                <?php endif; ?>
            </div>
            <?php if(_ceo('apply_sz_yzmcode') == true ): ?>
            <div class="ceo-apply-txt ceo-margin-bottom">
                备注信息：<input type="text" name="yzmcode" placeholder="请填写备注信息" class="ceo-input"/>
            </div>
            <?php endif; ?>
            <div class="abtn">
                <input type="button" value="提交申请" id="regBtn" class="ceo-input"/>
            </div>
            <div class="extra-info">信息仅用于身份认证，我们将严格保护您的数据和隐私安全</div>
        </form>
    </div>
</div>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri().'/static';?>/js/base.js"></script>
<?php get_footer(); ?>