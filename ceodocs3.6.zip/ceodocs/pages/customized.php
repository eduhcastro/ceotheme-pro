<?php
/*
Template Name: 定制模板
*/
get_header(); 
$top = _ceo('customized_top');
$cms = _ceo('customized_cms');
$service = _ceo('customized_service');
$service_set = _ceo('customized_service_set');
$process = _ceo('customized_process');
$process_set = _ceo('customized_process_set');
$enterprise = _ceo('customized_enterprise');
$question_set = _ceo('customized_question_set');

?>
<div class="ceo-page-customized">
    <div class="bg ceo-inline ceo-background-muted ceo-panel ceo-flex ceo-flex-center ceo-flex-middle" style="background-image: url(<?php echo $top['bg'] ?>)">
        <div class="ceo-container1280">
            <div class="title ceo-position-center ceo-text-center">
                <h1><?php echo $top['title'] ?></h1>
                <p><?php echo $top['subtitle'] ?></p>
                <a href="<?php echo $top['btnlink'] ?>" target="_blank" rel="noreferrer nofollow"><?php echo $top['ctntitle'] ?></a>
            </div>
        </div>
    </div>
    <div class="ceo-container1280">
        <div class="bgmodule ceo-background-default">
            <ul class="ceo-child-width-1-2 ceo-child-width-1-4@s ceo-grid-large" ceo-grid>
                <?php
		            if ($cms) {
					foreach ( $cms as $key => $value) {
				?>
                <li>
                    <i class="ceofont <?php echo $value['icon'] ?>"></i>
                    <span><?php echo $value['title'] ?></span>
                    <p><?php echo $value['subtitle'] ?></p>
                </li>
                <?php } } ?>
            </ul>
        </div>
    </div>
    <div class="ceo-container1280">
        <div class="service">
            <div class="title">
                <span><?php echo $service['title'] ?></span>
                <p><?php echo $service['subtitle'] ?></p>
            </div>
            <ul class="ceo-child-width-1-2 ceo-child-width-1-4@s ceo-grid-medium" ceo-grid>
                <?php
		            if ($service_set) {
					foreach ( $service_set as $key => $value) {
				?>
                <li>
                    <div class="box ceo-background-default ceo-dongtai">
        	            <div class="bg ceo-background-cover" style="background-image: url(<?php echo $value['bg'] ?>);">
                            <span><?php echo $value['title'] ?></span>
                        </div>
        	            <div class="ner">
        	                <?php echo $value['textarea'] ?>
                        </div>
                        <div class="bot">
                            <span><em>￥</em> <?php echo $value['price'] ?> <em>起</em></span>
                            <a href="<?php echo $top['btnlink'] ?>" target="_blank" rel="noreferrer nofollow"><?php echo $top['ctntitle'] ?></a>
                        </div>
        	        </div>
                </li>
                <?php } } ?>
            </ul>
        </div>
    </div>
    <div class="process ceo-background-cover ceo-background-muted ceo-panel ceo-flex ceo-flex-center ceo-flex-middle" style="background-image: url(<?php echo $process['bg'] ?>)">
        <div class="ceo-container1280">
            <div class="title">
                <span><?php echo $process['title'] ?></span>
                <p><?php echo $process['subtitle'] ?></p>
            </div>
            <ul class="ceo-child-width-1-2 ceo-child-width-1-6@s ceo-grid-ceosmls" ceo-grid>
                <?php
		            if ($process_set) {
					foreach ( $process_set as $key => $value) {
				?>
                <li>
                    <div class="box">
                        <span><?php echo $value['title'] ?></span>
                        <p><?php echo $value['desc'] ?></p>
        	        </div>
                </li>
                <?php } } ?>
            </ul>
        </div>
    </div>
    <div class="enterprise">
        <div class="ceo-container1280">
            <div class="title">
                <span><?php echo $enterprise['title'] ?></span>
                <p><?php echo $enterprise['subtitle'] ?>+</p>
            </div>
    	    <div class="box">
    	        <img src="<?php echo $enterprise['img'] ?>" alt="<?php echo $enterprise['title'] ?>">
            </div>
        </div>
    </div>
    <div class="question">
        <div class="ceo-container1280">
            <div class="box">
                <div class="title"><?php echo _ceo('customized_question'); ?></div>
                <ul class="ceo-child-width-1-1 ceo-child-width-1-2@s ceo-grid-large" ceo-grid>
                    <?php
    		            if ($question_set) {
    					foreach ( $question_set as $key => $value) {
    				?>
                    <li>
                        <div class="content">
                            <span><?php echo $value['title'] ?></span>
                            <p><?php echo $value['content'] ?></p>
                        </div>
                    </li>
                    <?php } } ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>