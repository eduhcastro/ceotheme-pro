<?php
/* Template Name: 邀请活动 */
get_header();
$top = _ceo('invited_top');
$module2 = _ceo('invited_module2');
$module4 = _ceo('invited_module4');
$module5 = _ceo('invited_module5');
$module6 = _ceo('invited_module6');
?>
<div class="ceo-page-invited">
    <div class="bg ceo-inline ceo-background-muted ceo-panel ceo-flex ceo-flex-center ceo-flex-middle" style="background-image: url(<?php echo $top['bg'] ?>)">
        <div class="ceo-container1280">
            <div class="title ceo-position-center ceo-text-center">
                <h1><?php echo $top['title'] ?></h1>
                <p><?php echo $top['subtitle'] ?></p>
                <?php if( is_user_logged_in() ){?>
                <a href="/member/reward/" target="_blank">立即邀请</a>
                <?php }else{ ?>
                <a ceo-toggle="target: #navbar-login">立即邀请</a>
                <?php } ?>
            </div>
        </div>
    </div>
    <div class="ceo-container1280">
        <div class="module2">
            <div class="title"><?php echo _ceo('invited_module2_title'); ?></div>
            <ul class="ceo-child-width-1-2 ceo-child-width-1-4@s ceo-grid-medium" ceo-grid>
                <?php
		            if ($module2) {
					foreach ( $module2 as $key => $value) {
				?>
                <li>
                    <div class="box">
                        <p><i class="ceofont <?php echo $value['icon'] ?>"></i></p>
                        <span><?php echo $value['title'] ?></span>
                    </div>
                </li>
                <?php } } ?>
            </ul>
        </div>
        <div class="module3">
            <div class="title">邀请奖励说明</div>
            <div class="reward">
                <div class="header">
                    <div class="header-1">赠送奖品</div>
                    <div class="header-2">赠送条件</div>
                    <div class="header-3">获取次数</div>
                </div>
                <ul class="list">
                    <?php 
                        $registerConfigArr = _ceo('ceo_shop_recommend_register_set');
                        $vipNameArr = CeoShopCoreUser::getVipGradeList(2, false);
                        $currencyName = ceo_shop_get_balance_name();
                    ?>
                     <?php if ($registerConfigArr['recommend_integral'] > 0) : ?>
                        <li>
                            <div class="list-1"><?php echo $registerConfigArr['recommend_integral'] ?>积分</div>
                            <div class="list-2">每次</div>
                            <div class="list-3"><?php echo CeoShopMemberPromotion::getRewardCount(get_current_user_id(), 1) ?>次</div>
                        </li>
                    <?php endif; ?>
                    <?php if ($registerConfigArr['recommend_currency'] > 0) : ?>
                        <li>
                            <div class="list-1"><?php echo $registerConfigArr['recommend_currency'] . $currencyName ?></div>
                            <div class="list-2">每次</div>
                            <div class="list-3"><?php echo CeoShopMemberPromotion::getRewardCount(get_current_user_id(), 2) ?>次</div>
                        </li>
                    <?php endif; ?>
                    <?php if (!empty($registerConfigArr['recommend_coupon'])) : ?>
                        <?php $discountInfo = CeoShopCoreCoupon::getDiscountByCode($registerConfigArr['recommend_coupon']) ?>
                        <?php if (!empty($discountInfo)) : ?>
                            <li>
                                <div class="list-1" data-code="<?php echo $registerConfigArr['recommend_coupon'] ?>">代金券 - <?php echo $discountInfo->money . $currencyName ?></div>
                                <div class="list-2">每次</div>
                                <div class="list-3"><?php echo CeoShopMemberPromotion::getRewardCount(get_current_user_id(), 3) ?>次</div>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if (!empty($registerConfigArr['recommend_vip'])) : ?>
                        <?php $vipCodeInfo = CeoShopCoreCoupon::getVipCodeByCode($registerConfigArr['recommend_vip']) ?>
                        <?php if (!empty($vipCodeInfo)) : ?>
                            <li>
                                <div class="list-1" data-code="<?php echo $registerConfigArr['recommend_vip'] ?>">VIP优惠券 - <?php echo $vipCodeInfo->money . $currencyName ?></div>
                                <div class="list-2">每次</div>
                                <div class="list-3"><?php echo CeoShopMemberPromotion::getRewardCount(get_current_user_id(), 4) ?>次</div>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if ($registerConfigArr['recommend_vipday']['people'] > 0 && isset($vipNameArr[$registerConfigArr['recommend_vipday']['vip_grade']])) : ?>
                        <li>
                            <div class="list-1">VIP会员 - <?php echo $vipNameArr[$registerConfigArr['recommend_vipday']['vip_grade']] ?></div>
                            <div class="list-2"><?php if ($registerConfigArr['recommend_vipday']['accumulating']) {
                                                    echo '每';
                                                } ?>邀请<?php echo $registerConfigArr['recommend_vipday']['people'] ?>人</div>
                            <div class="list-3"><?php echo CeoShopMemberPromotion::getRewardCount(get_current_user_id(), 5) ?>次</div>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <div class="module4">
            <div class="title"><?php echo _ceo('invited_module4_title'); ?></div>
            <ul class="ceo-child-width-1-2 ceo-child-width-1-4@s ceo-grid-medium" ceo-grid>
                <?php
		            if ($module4) {
					foreach ( $module4 as $key => $value) {
				?>
                <li>
                    <div class="box">
                        <i class="ceofont <?php echo $value['icon'] ?>"></i>
                        <span><?php echo $value['title'] ?></span>
                        <p><?php echo $value['content'] ?></p>
                    </div>
                </li>
                <?php } } ?>
            </ul>
        </div>
    </div>
    <div class="module5">
        <div class="ceo-container1280">
            <div class="box">
                <span><?php echo $module5['title'] ?></span>
                <p><?php echo $module5['content'] ?></p>
                <a href="/member/reward/" target="_blank">立即邀请</a>
                <a href="/member/reward/" target="_blank">我的推广</a>
            </div>
        </div>
    </div>
    <div class="module6">
        <div class="ceo-container1280">
            <div class="box">
                <div class="title"><?php echo _ceo('invited_module6_title'); ?></div>
                <ul class="ceo-child-width-1-1 ceo-child-width-1-2@s ceo-grid-large" ceo-grid>
                    <?php
    		            if ($module6) {
    					foreach ( $module6 as $key => $value) {
    				?>
                    <li>
                        <div class="content">
                            <span><em>Q</em><?php echo $value['title'] ?></span>
                            <p><em>A</em><?php echo $value['content'] ?></p>
                        </div>
                    </li>
                    <?php } } ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php get_footer();?>