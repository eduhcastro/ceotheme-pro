<?php
/* Template Name: 友情链接 */
get_header();
?>
<div class="ceo-page-about">
    <div class="ceo-container1280">
        <div class="position">
    	    <?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
        </div>
        <div class="ceo-grid-ceosmls" ceo-grid>
            <div class="sidebar ceo-width-1-1 ceo-width-1-6@s">
            	<div class="theiaStickySidebar">
            	    <ul class="about-menu ceo-background-default b-r-4">
            		    <?php ceo_menu('page-nav'); ?>
            		</ul>
            	</div>
            </div>
            <div class="ceo-width-1-1 ceo-width-5-6@s">
            	<div class="about-main">
            	    <div class="page-link ceo-background-default b-r-4">
                    <?php
                	wp_list_bookmarks(array(
                	    'show_description' => true,
                	    'show_name'        => true,
                	    'orderby'          => 'rating',
                	    'title_before'     => '<h1>',
                	    'title_after'      => '</h1>',
                	    'order'            => 'DESC',
                	    'show_description' => '0',
                	));
                	?>
                	</div>
            		<div class="about-content single-content b-r-4 ceo-background-default">
            			<?php while(have_posts()) : the_post(); ?>
            			<?php the_content(); ?>
            			<?php endwhile; ?>
            		</div>
            		<?php if(_ceo('comments_close') == false ): ?>	
            		<?php if ( comments_open() || get_comments_number() ) : ?>
            		<?php comments_template( '', true ); ?>
            		<?php endif; ?>
            		<?php endif; ?>
            	</div>
        	</div>
    	</div>
    </div>
</div>
<?php get_footer();?>