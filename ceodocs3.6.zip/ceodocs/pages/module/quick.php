<?php $page_top = _ceo('ceo_page_top_set') ?>
<div class="ceo-container1280">
    <div class="ceo-default-quick ceo-background-default">
        <div ceo-slider>
            <div class="ceo-position-relative">
                <div class="box ceo-slider-container ceo-light">
                    <ul class="ceo-slider-items ceo-child-width-1-2 ceo-child-width-1-5@s ceo-grid-ceosmls ceo-grid">
                        <?php
						    if ($page_top) {
							foreach ( $page_top as $key => $value) {
					    ?>
                        <li>
                            <a href="<?php echo $value['link'] ?>" target="_blank">
                		        <div class="ceo-grid-small" ceo-grid>
                		            <div class="ceo-width-auto">
                    				    <img src="<?php echo $value['img'] ?>" alt="<?php echo $value['title'] ?>">
                    				</div>
                    				<div class="ceo-width-expand">
                    					<span><?php echo $value['title'] ?></span>
                    					<p><?php echo $value['subtitle'] ?></p>
                    				</div>
                				</div>
                			</a>
                        </li>
                        <?php } } ?>
                    </ul>
                </div>
                <div class="ceo-hidden@s ceo-light">
                    <a class="ceo-position-center-left ceo-position-small" href="#" ceo-slider-item="previous"><i class="ceofont ceoicon-arrow-left-s-line"></i></a>
                    <a class="ceo-position-center-right ceo-position-small" href="#" ceo-slider-item="next"><i class="ceofont ceoicon-arrow-right-s-line"></i></a>
                </div>
                <div class="ceo-visible@s">
                    <a class="ceo-position-center-left-out ceo-position-small" href="#" ceo-slider-item="previous"><i class="ceofont ceoicon-arrow-left-s-line"></i></a>
                    <a class="ceo-position-center-right-out ceo-position-small" href="#" ceo-slider-item="next"><i class="ceofont ceoicon-arrow-right-s-line"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>