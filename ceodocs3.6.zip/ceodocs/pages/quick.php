<?php
/* Template Name: PPT快捷键 */
get_header();
$text = _ceo('quick-text');
$bg = _ceo('quick-bg');
?>
<div class="ceo-quick-bg ceo-default-bg ceo-background-cover ceo-background-muted ceo-panel ceo-flex ceo-flex-center ceo-flex-middle" style="background-image: url(<?php echo $bg; ?>)">
    <div class="ceo-container1280">
        <div class="title ceo-position-center ceo-text-center">
            <h1><?php the_title(); ?></h1>
            <p><?php echo $text; ?></p>
        </div>
    </div>
</div>
<section class="ceo-pages-quick">
    <div class="quick-module ceo-background-default">
        <ul class="cat-switcher quick-title ceo-padding-remove-left ceo-background-default" ceo-switcher>
    		<li class="ceo-display-inline-block ceo-position-relative ceo-margin-right ceo-active" aria-expanded="true">
    			<h3 class="ceo-margin-remove-bottom"><a class="ceo-text-bolder"><i class="ceofont ceoicon-windows-line"></i>Windows快捷键</a></h3>
    		</li>
    		<li class="ceo-display-inline-block ceo-position-relative" aria-expanded="false">
    			<h3 class="ceo-margin-remove-bottom"><a class="ceo-text-bolder"><i class="ceofont ceoicon-mac-line"></i>Mac快捷键</a></h3>
    		</li>
    	</ul>
        
        <ul class="ceo-switcher ceo-margin">
            <!--Windows快捷键-->
            <li>
                <div class="ceo-container1280">
                    <div class="ceo-grid-collapse" ceo-grid>
                        <div class="ceo-width-1-1 ceo-width-1-4@s">
                            <div class="box1">
                                <div class="title">对象编辑</div>
                                <ul>
                                    <li>
                                    <div class="ceo-grid-collapse" ceo-grid>
                                        <div class="ceo-width-1-2">
                                            <span>Ctrl + D</span>
                                        </div>
                                        <div class="ceo-width-1-2">
                                            <span>复制选中的对象</span>
                                        </div>
                                    </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + Z</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>撤销操作</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + Y</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>重复最后一次操作</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + X</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>剪切</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + G</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>组合对象</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + Shift + G</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>解除组合</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + Shift + 拖动</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>快速复制</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Shift + 鼠标</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>等比例缩放</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + Shift + 鼠标</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>中心点缩放</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="ceo-width-1-1 ceo-width-1-4@s">
                            <div class="box2">
                                <div class="title">文字编辑</div>
                                <ul>
                                    <li>
                                    <div class="ceo-grid-collapse" ceo-grid>
                                        <div class="ceo-width-1-2">
                                            <span>Ctrl + Shift + C</span>
                                        </div>
                                        <div class="ceo-width-1-2">
                                            <span>复制文本格式</span>
                                        </div>
                                    </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + Shift + V</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>粘贴文本格式</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Alt + Ctrl + V</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>选择性粘贴</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + T</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>打开“字体”对话框</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + L</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>使段落左对齐</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + R</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>使段落右对齐</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + J</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>使段落两端对齐</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + E</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>文本居中对齐</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Shift + F3</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>更改字母大小写</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + F</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>打开“查找”对话框</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + H</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>打开“替换”对话框</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl+Shift+><</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>字号放大缩小</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + "="</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>将文本更改为下标</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + B</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>应用粗体格式</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + 空格键</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>删除手动字符格式</span>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="ceo-width-1-1 ceo-width-1-4@s">
                            <div class="box3">
                                <div class="title">视图窗口</div>
                                <ul>
                                    <li>
                                    <div class="ceo-grid-collapse" ceo-grid>
                                        <div class="ceo-width-1-2">
                                            <span>Ctrl + 鼠标滚轮</span>
                                        </div>
                                        <div class="ceo-width-1-2">
                                            <span>缩放当前页面大小</span>
                                        </div>
                                    </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Shift + F9</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>显示或隐藏网格</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Alt + F9</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>显示或隐藏参考线</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Alt + F10</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>打开选择窗格</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + K</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>加入超链接</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Alt + K</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>切换动画</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="ceo-width-1-1 ceo-width-1-4@s">
                            <div class="box4">
                                <div class="title">全屏播放</div>
                                <ul>
                                    <li>
                                    <div class="ceo-grid-collapse" ceo-grid>
                                        <div class="ceo-width-1-2">
                                            <span>F5</span>
                                        </div>
                                        <div class="ceo-width-1-2">
                                            <span>从头播放幻灯片</span>
                                        </div>
                                    </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Shift + F5</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>从当前页播放幻灯片</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>←↑→↓</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>上一页或下一页</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Page UP</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>上一页</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Page Down</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>下一页</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Tab</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>转至下一个超级链接</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Shift + Tab</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>转至上一个超级链接</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>H</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>到下一张隐藏幻灯片</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>B</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>黑屏</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>W</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>白屏</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>S</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>暂停，再次点击继续</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Esc</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>退出幻灯片放映</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Shift + F10</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>显示右键快捷菜单</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + P</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>激活绘图笔</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Alt + F5</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>进入演讲者视图</span>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
            <!--Mac快捷键-->
            <li>
                <div class="ceo-container1280">
                    <div class="ceo-grid-collapse" ceo-grid>
                        <div class="ceo-width-1-1 ceo-width-1-4@s">
                            <div class="box1">
                                <div class="title">对象编辑</div>
                                <ul>
                                    <li>
                                    <div class="ceo-grid-collapse" ceo-grid>
                                        <div class="ceo-width-1-2">
                                            <span>Command + D</span>
                                        </div>
                                        <div class="ceo-width-1-2">
                                            <span>复制选中的对象</span>
                                        </div>
                                    </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + Z</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>撤销操作</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + Y</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>重复最后一次操作</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + X</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>剪切</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + G</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>组合对象</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + Shift + G</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>解除组合</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + Shift + 拖动</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>快速复制</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + 鼠标</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>等比例缩放</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + Shift + 鼠标</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>中心点缩放</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="ceo-width-1-1 ceo-width-1-4@s">
                            <div class="box2">
                                <div class="title">文字编辑</div>
                                <ul>
                                    <li>
                                    <div class="ceo-grid-collapse" ceo-grid>
                                        <div class="ceo-width-1-2">
                                            <span>Command + Shift + C</span>
                                        </div>
                                        <div class="ceo-width-1-2">
                                            <span>复制文本格式</span>
                                        </div>
                                    </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + Shift + V</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>粘贴文本格式</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + Ctrl + V</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>选择性粘贴</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + T</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>打开“字体”对话框</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + L</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>使段落左对齐</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + R</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>使段落右对齐</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + J</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>使段落两端对齐</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + E</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>文本居中对齐</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + F3</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>更改字母大小写</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + F</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>打开“查找”对话框</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + H</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>打开“替换”对话框</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command+Shift+><</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>字号放大缩小</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + "="</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>将文本更改为下标</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + B</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>应用粗体格式</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + 空格键</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>删除手动字符格式</span>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="ceo-width-1-1 ceo-width-1-4@s">
                            <div class="box3">
                                <div class="title">视图窗口</div>
                                <ul>
                                    <li>
                                    <div class="ceo-grid-collapse" ceo-grid>
                                        <div class="ceo-width-1-2">
                                            <span>Command + 鼠标滚轮</span>
                                        </div>
                                        <div class="ceo-width-1-2">
                                            <span>缩放当前页面大小</span>
                                        </div>
                                    </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Shift + F9</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>显示或隐藏网格</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + F9</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>显示或隐藏参考线</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + F10</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>打开选择窗格</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + K</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>加入超链接</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + K</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>切换动画</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span></span>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="ceo-width-1-1 ceo-width-1-4@s">
                            <div class="box4">
                                <div class="title">全屏播放</div>
                                <ul>
                                    <li>
                                    <div class="ceo-grid-collapse" ceo-grid>
                                        <div class="ceo-width-1-2">
                                            <span>F5</span>
                                        </div>
                                        <div class="ceo-width-1-2">
                                            <span>从头播放幻灯片</span>
                                        </div>
                                    </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Shift + F5</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>从当前页播放幻灯片</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>←↑→↓</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>上一页或下一页</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Page UP</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>上一页</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Page Down</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>下一页</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Tab</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>转至下一个超级链接</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Shift + Tab</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>转至上一个超级链接</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>H</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>到下一张隐藏幻灯片</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>B</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>黑屏</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>W</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>白屏</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>S</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>暂停，再次点击继续</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Esc</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>退出幻灯片放映</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Shift + F10</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>显示右键快捷菜单</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Command + P</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>激活绘图笔</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ceo-grid-collapse" ceo-grid>
                                            <div class="ceo-width-1-2">
                                                <span>Ctrl + F5</span>
                                            </div>
                                            <div class="ceo-width-1-2">
                                                <span>进入演讲者视图</span>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</section>
<?php get_footer(); ?>