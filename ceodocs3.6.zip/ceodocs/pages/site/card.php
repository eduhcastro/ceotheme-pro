<a href="<?php the_permalink(); ?>" target="_blank" class="site-item b-r-4 ceo-dongtai">
	<div class="ceo-grid-ceosmls" ceo-grid>
	    <div class="ceo-width-auto">
    	    <div class="item-img ceo-display-block">
    			<img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>"/>
    		</div>
		</div>
		<div class="ceo-width-expand">
    		<div class="item-info">
    			<span class="ceo-text-truncate"><?php the_title(); ?></span>
    			<p class="ceo-text-truncate">
    				<?php 
    				if (has_excerpt()) {
    					echo $description = get_the_excerpt();
    				}else {
    					echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 50,"…");
    				} 
    				?>
    			</p>
    		</div>
		</div>
	</div>
</a>