<div class="sitenav">
    <div class="sitenavbox ceo-background-default" ceo-sticky="animation: ceo-animation-slide-top;offset: 100">
		<span>直达导航</span>
    	<ul>
    		<?php
    		$args=array(
    		'taxonomy' => 'sitecat',
    		'hide_empty'=>'0',
    		'hierarchical'=>1,
    		'parent'=>'0',
    		);
    		$categories=get_categories($args);
    		foreach($categories as $category){
    		$cat_id = $category->term_id;
    		?>
    		<li><a href="#site<?php echo $category->term_id;?>" class="ceo-display-block" ceo-scroll><?php echo $category->name;?></a></li>
    		<?php }?>	
    	</ul>
    	<?php if(_ceo('site-btn') == true): ?>
    	<div class="site-navbtn">
		    <a href="#ceo-site-apply" ceo-toggle>申请收录</a>
		</div>
		<?php endif; ?>
    </div>
</div>

<?php if(_ceo('site-btn') == true): ?>
<?php
$bloginfo = get_bloginfo('url');
if( isset($_POST['tougao_form']) && $_POST['tougao_form'] == 'send') {
global $wpdb;

$current_url = $bloginfo.'/site';

$last_post = $wpdb->get_var("SELECT `post_date` FROM `$wpdb->posts` ORDER BY `post_date` DESC LIMIT 1");
$title =  isset( $_POST['tougao_title'] ) ? trim(htmlspecialchars($_POST['tougao_title'], ENT_QUOTES)) : '';
$url = isset( $_POST['tougao_url'] ) ? $_POST['tougao_url'] : '';
$description =  isset( $_POST['tougao_description'] ) ? trim(htmlspecialchars($_POST['tougao_description'], ENT_QUOTES)) : '';
$liebie =  isset( $_POST['tougao_leibie'] ) ? trim(htmlspecialchars($_POST['tougao_leibie'], ENT_QUOTES)) : '';
$icon = isset( $_POST['tougao_icon'] ) ? $_POST['tougao_icon'] : '';

?>

<?php if ( empty($title) || mb_strlen($title) < 1 ) { ?>

<script>alert("网站名称不能为空！");</script>
<meta http-equiv="refresh" content="0;url=<?php $bloginfo ?>">

<?php die; } ?>

<?php if ( empty($url) || mb_strlen($url) < 1 ) { ?>

<script>alert("网址不能为空！");</script>
<meta http-equiv="refresh" content="0;url=<?php $bloginfo ?>">

<?php die; } ?>

<?php
if ( empty($liebie) ) {
?>

<script>alert("网站类别不能为空！");</script>
<meta http-equiv="refresh" content="0;url=<?php $bloginfo ?>">

<?php die; } ?>

<?php if ( empty($description) || mb_strlen($description) < 5 ) { ?>

<script>alert("网站描述不能为空，且不得少于5个字！");</script>
<meta http-equiv="refresh" content="0;url=<?php $bloginfo ?>">

<?php die; } ?>

<?php if ( empty($icon) || mb_strlen($icon) < 1 ) { ?>

<script>alert("网站LOGO不能为空！");</script>
<meta http-equiv="refresh" content="0;url=<?php $bloginfo ?>">

<?php die; } ?>


<?php

$post_content = '网站名称: '.$title.'<br />网站地址: '.$url.'<br />网站类别: '.$liebie.'<br />网站描述: '.$description.'<br />网站图标:'.$icon;
$tougao = array(
	'post_title' => $title,
	'post_content' => $post_content,
	'post_status' => 'pending',
	'post_type' => 'site'
);

// 将文章插入数据库
$status = wp_insert_post( $tougao );

if ($status != 0) { ?>
<script>alert("申请成功！");</script>
<meta http-equiv="refresh" content="0;url=<?php $bloginfo ?>">
<?php } else { ?>
<script>alert("申请失败，请重新填写！");</script>
<meta http-equiv="refresh" content="0;url=<?php $bloginfo ?>">
<?php } } ?>


<!--申请收录-->
<div id="ceo-site-apply" class="ceo-site-apply ceo-flex-top" ceo-modal>
    <div class="ceo-modal-dialog ceo-modal-body ceo-margin-auto-vertical">
        <div class="moduletitle">
            <span>申请收录</span>
            <button class="ceo-modal-close-default" type="button" ceo-close></button>
        </div>
        <form class="ceo-form" method="post" id="sitesubmit-form" action="<?php echo $_SERVER["REQUEST_URI"]; $current_user = wp_get_current_user(); ?>">
		    <div class="ceo-margin-bottom ceo-grid-ceossss" ceo-grid>
                <div class="ceo-width-1-2">
		            <label for="nickname" class="rl-label">网站名称</label>
        			<input type="text" id="tougao_title" value="" name="tougao_title" placeholder="网站名称" class="b-r-4 ceo-input"/>
    			</div>
    			<div class="ceo-width-1-2">
    			    <label for="nickname" class="rl-label">网站地址</label>
        			<input type="text" id="tougao_url" value="" name="tougao_url" placeholder="网站地址" class="b-r-4 ceo-input"/>
    			</div>
			</div>
			<div class="ceo-margin-bottom ceo-grid-ceossss" ceo-grid>
    			<div class="ceo-width-1-2">
        			<label for="nickname" class="rl-label">网站类别</label>
        			<input type="text" id="tougao_leibie" value="" name="tougao_leibie" placeholder="网站类别" class="b-r-4 ceo-input"/>
    			</div>
    			<div class="ceo-width-1-2">
        			<label for="nickname" class="rl-label">网站描述</label>
        			<input type="text" id="tougao_description" name="tougao_description" placeholder="网站描述" class="b-r-4 ceo-input">
    			</div>
			</div>
			<div class="ceo-margin-bottom">
    			<label for="nickname" class="rl-label user-text-small ceo-text-muted">网站LOGO</label>
    			<input type="text" id="tougao_icon" value="" name="tougao_icon" placeholder="网站LOGO" class="b-r-4 ceo-input"/>
			</div>
			<div class="ceo-margin-bottom">
				<input type="hidden" value="send" name="tougao_form" />
				<div class="ceo-grid-ceossss" ceo-grid>
				    <div class="ceo-width-1-2">
    				    <button class="b-r-4 button ceo-button" type="reset" value="重填">清空</button>
    				</div>
    				<div class="ceo-width-1-2">
    				    <button class="submit b-r-4 button ceo-button" type="submit" id="sitesubmit-tj" value="提交">提交申请</button>
    				</div>
				</div>
			</div>
		</form>
		<div class="desc">
		    <?php echo _ceo('site-btn-desc'); ?>
	    </div>
    </div>
</div>

<script>
    $(function () {
        $("#sitesubmit-tj").on("click",function () {
            if(true){
                var tougao_url = $("#tougao_url").val()

                var han = /^[\u4e00-\u9fa5]+$/;
                if (tougao_url == '') {
                    alert("请输入网站地址");
                    return false;
                };
                if (han.test(tougao_url)) {
                    alert("网站地址不能包含中文")
                    return false;
                };
            }

            $("#sitesubmit-form").submit()
        })
    })
</script>
<?php endif; ?>