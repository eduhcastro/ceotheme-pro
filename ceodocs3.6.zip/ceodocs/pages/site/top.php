<div class="site-switcher ceo-container">
	<ul ceo-switcher class="ceo-list site-switcher-menu ceo-text-center ceo-text-nowrap">
		<li><span>百度</span></li>
		<li><span>谷歌</span></li>
		<li><span>必应</span></li>
		<li><span>360</span></li>
		<li><span>搜狗</span></li>
	</ul>
	<div class="site-switcher-main ceo-switcher" class="ceo-list">
	    <!-- 百度 -->
		<div class="b-r-4 b-a ceo-background-default">
			<div class="site-search">
				<div class="site-form" style="display: block;">
					<form class="ceo-position-relative" action="https://www.baidu.com/baidu" target="_blank">
						<input type="text" name=word placeholder="百度 搜一搜">
						<button type="submit" value=""><i class="ceofont ceoicon-search-2-line"></i></button>
					</form>
				</div>
			</div>
		</div>
		<!-- 谷歌 -->
		<div class="b-r-4 b-a ceo-background-default">
			<div class="site-search">
				<div class="site-form" style="display: block;">
					<form class="ceo-position-relative" method="GET" action="https://www.google.com/search" target="_blank">  
						<input type="text" name="q" maxlength="255" placeholder="谷歌 搜一搜"> 
						<button type="submit" name="btnG" value=""><i class="ceofont ceoicon-search-2-line"></i></button>
					</form> 
				</div>
			</div>
		</div>
		<!-- 必应 -->
		<div class="b-r-4 b-a ceo-background-default">
			<div class="site-search">
				<div class="site-form" style="display: block;">
					<form class="ceo-position-relative" action="https://cn.bing.com/search" target="_blank">
						<input type="text" id="search_input" name="q" placeholder="必应 搜一搜">
						<button type="submit" name="btnG" value=""><i class="ceofont ceoicon-search-2-line"></i></button>
					</form>
				</div>
			</div>
		</div>
		<!-- 360 -->
		<div class="b-r-4 b-a ceo-background-default">
			<div class="site-search">
				<div class="site-form" style="display: block;">
					<form class="ceo-position-relative" action=" https://www.so.com/s" target="_blacnk">
						<input name="q" type="text" id="input"  autocomplete="off" x-webkit-speech placeholder="360 搜一搜">
						<button type="submit" name="btnG" value=""><i class="ceofont ceoicon-search-2-line"></i></button>
					</form>
				</div>
			</div>
		</div>
		<!-- 搜狗 -->
		<div class="b-r-4 b-a ceo-background-default">
			<div class="site-search">
				<div class="site-form" style="display: block;">
					<form class="ceo-position-relative" action="https://www.sogou.com/web" target="_blank">
						<input type="text" name=query placeholder="搜狗 搜一搜">
						<button type="submit" value=""><i class="ceofont ceoicon-search-2-line"></i></button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>