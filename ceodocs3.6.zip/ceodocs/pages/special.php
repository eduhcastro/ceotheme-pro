<?php
/*
Template Name: 专题页面
*/
get_header();
$bg       = _ceo('special-bg');
$subtitle = _ceo('special-subtitle');
?>
<div class="ceo-default-bg ceo-background-cover ceo-background-muted ceo-panel ceo-flex ceo-flex-center ceo-flex-middle" style="background-image: url(<?php echo $bg; ?>)">
    <div class="ceo-container1280">
        <div class="title ceo-position-center ceo-text-center">
            <h1><?php the_title(); ?></h1>
            <p><?php echo $subtitle; ?></p>
        </div>
    </div>
</div>
<?php if(_ceo('ceo_page_top') == true ): ?>
<?php get_template_part( 'pages/module/quick' ); ?>
<?php endif; ?>
<section class="ceo-special-home ceo-margin-medium-bottom">
    <div class="ceo-container1280">
        <ul class="ceo-grid-ceosmls" ceo-grid>
            <?php
        		$args=array(
        			'taxonomy' => 'special',
        			'hide_empty'=>'0',
        			'hierarchical'=>1,
        			'parent'=>'0',
        			'orderby'=>'date',
        			'order'=>'desc',
        		);
        		$categories=get_categories($args);
        		foreach($categories as $category){
        			$cat_id = $category->term_id;

                    $backgroud_img = '';
                    $cate_background_img_arrs = get_term_meta($cat_id, 'cate_background_img', 1);
                    if ($cate_background_img_arrs && ! empty($cate_background_img_arrs['url'])) {
                        $backgroud_img = $cate_background_img_arrs['url'];
                    }
        	?>
            
            <li class="ceo-width-1-2 ceo-width-1-4@s">
                <a href="<?php echo get_category_link( $category->term_id )?>" target="_blank" class="url">
                    <img src="<?php echo $backgroud_img; ?>" alt="<?php echo $category->name;?>">
                </a>
            </li>
            <?php }?>
        </ul>
    </div>
</section>
<?php get_footer(); ?>