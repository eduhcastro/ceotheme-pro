<?php 
/* Template Name: 热门标签 */ 
get_header(); 
$text = _ceo('tag-text');
$bg = _ceo('tag-bg');
?>
<div class="ceo-default-bg ceo-background-cover ceo-background-muted ceo-panel ceo-flex ceo-flex-center ceo-flex-middle" style="background-image: url(<?php echo $bg; ?>)">
    <div class="ceo-container1280">
        <div class="title ceo-position-center ceo-text-center">
            <h1><?php the_title(); ?></h1>
            <p><?php echo $text; ?></p>
        </div>
    </div>
</div>
<?php if(_ceo('ceo_page_top') == true ): ?>
<?php get_template_part( 'pages/module/quick' ); ?>
<?php endif; ?>
<section class="ceo-container1280">
    <div class="ceo-page-tags ceo-background-default ceo-margin-medium-bottom">
    	<ul class="ceo-child-width-1-2 ceo-child-width-1-5@s ceo-grid-ceosmls" ceo-grid>
    		<?php
    		$tags_list = get_tags('orderby=count&order=DESC&number=100');
    		if($tags_list) {
    			foreach($tags_list as $tag) {
    				echo '<li>
    				          <a class="item ceo-flex" href="'.get_tag_link($tag).'">
        				          <h2 class="ceo-text-truncate ceo-flex-1" ceo-tooltip="共 '. $tag->count .' 个相关作品" title="'. $tag->name .'"><span>#</span>'. $tag->name .'</h2>
        				          <p></p>
    				          ';
    				echo '</a></li>';
    			}
    		}
    		?>
    	</ul>
	</div>
</section>
<?php get_footer(); ?>