<?php
/*
Template Name: VIP模板
*/
get_header(); 
$bg_color = _ceo('vip_page_bg_color');
$bg_img = _ceo('vip_page_bg_img');
$subtitle = _ceo('vip-subtitle');
$bg = _ceo('vip-bg');
$vd = _ceo('vip_desc_sz');
$vip_tq_sz= _ceo('vip_tq_sz');
$vip_enterprise= _ceo('vip_enterprise');
$vip_qa_sz= _ceo('vip_qa_sz');

$vip = _ceo('ceo_shop_vip_info');
?>

<div class="ceo-page-vip">
    <?php if(_ceo('vip_page_bg_type')=='1'){ ?>
    <div class="vip-header" style="background-color: <?php echo $bg_color ?>;">
    <?php }else { ?>
    <div class="vip-header" style="background-image: url(<?php echo $bg_img ?>);">
    <?php }?>
        <div class="ceo-container">
            <div class="top-title">
                <h1><?php echo $subtitle; ?></h1>
                <ul class="ceo-visible@s">
                    <?php
            		if ($vd) {
            			foreach ( $vd as $key => $value) {
            		?>
                    <li><?php echo $vd[$key]['title']; ?></li>
                    <?php } } ?>
                </ul>
            </div>
        </div>
        <div class="vip-left-bg"></div>
        <div class="vip-right-bg"></div>
    </div>
    <div class="vip-tocmk">
        <div class="ceo-container1280">
            <ul class="ceo-grid-ceosmls" ceo-grid>
                <?php
        		if ($vip) {
        			foreach ( $vip as $key => $value) {
        		?>
                <li class="ceo-width-1-1 ceo-width-1-4@s">
            	    <div class="box">
                	    <div class="top">
                	        <?php if ($vip[$key]['tags']): ?>
                	        <div class="tag"><?php echo $vip[$key]['tags']; ?></div>
                	        <?php endif; ?>
                	        <h1><?php echo $vip[$key]['name']; ?></h1>
        	                <p class="tp">会员有效期<?php echo $vip[$key]['validity']; ?>天</p>
        	                <p class="pi">每天可下载<?php echo $vip[$key]['number']; ?>个VIP资源</p>
        	                <div class="dj">
            	                <span>¥</span><strong><?php echo $vip[$key]['price']; ?></strong><em><?php echo _ceo('ceo_shop_currency_name'); ?></em>
                	        </div>
                	        <?php if( is_user_logged_in() ){ ?>
                            <a href="javascript:void(0)" class="btn-ceo-svip" data-vip-id="<?php echo $vip[$key]['id'] ?>" data-style="slide-down">立即开通</a>
                            <?php }else{ ?>
                            <a href="#navbar-login" ceo-toggle>立即开通</a>
                            <?php } ?>
                	    </div>
                	    <div class="bottom">
                	        <div class="title">会员权益：</div>
            	            <p><?php echo $vip[$key]['desc']; ?></p>
                	    </div>
            	    </div>
                </li>
                <?php } } ?>
            </ul>
        </div>
    </div>
    <div class="vip-problem">
        <div class="ceo-container1280">
            <div class="problem-title">
                <span><?php echo _ceo('vip_tq_title'); ?></span>
                <p><?php echo _ceo('vip_tq_subtitle'); ?></p>
            </div>
            <ul class="ceo-grid-ceosmls" ceo-grid>
                <?php
    			if ($vip_tq_sz) {
    				foreach ( $vip_tq_sz as $key => $value) {
    			?>
                <li class="ceo-width-1-2 ceo-width-1-4@s">
            	    <div class="mk">
            	        <i class="ceofont <?php echo $vip_tq_sz[$key]['icon']; ?>"></i>
            	        <span><?php echo $vip_tq_sz[$key]['title']; ?></span>
            	        <p><?php echo $vip_tq_sz[$key]['desc']; ?></p>
                	</div>
        	    </li>
        	    <?php } } ?>
            </ul>
        </div>
    </div>
    <div class="vip-enterprise">
        <div class="ceo-container1280">
            <div class="enterprise-title">
                <span><?php echo $vip_enterprise['title'] ?></span>
                <p><?php echo $vip_enterprise['subtitle'] ?></p>
            </div>
    	    <div class="enterprise-mk">
    	        <img src="<?php echo $vip_enterprise['img'] ?>" alt="<?php echo $vip_enterprise['title'] ?>">
            </div>
        </div>
    </div>
    <div class="vip-qa">
        <div class="ceo-container1280">
            <div class="qa-title">
                <span><?php echo _ceo('vip_qa_title'); ?></span>
                <p><?php echo _ceo('vip_qa_subtitle'); ?></p>
            </div>
            
            <ul class="ceo-grid-large" ceo-grid>
                <?php
    			if ($vip_qa_sz) {
    				foreach ( $vip_qa_sz as $key => $value) {
    			?>
                <li class="ceo-width-1-1 ceo-width-1-2@s">
                    <div class="mk">
                        <span><em>Q</em><?php echo $vip_qa_sz[$key]['title']; ?></span>
                        <p><em>A</em><?php echo $vip_qa_sz[$key]['content']; ?></p>
                    </div>
                </li>
                <?php } } ?>
            </ul>
        </div>
    </div>
</div>
<?php get_footer(); ?>