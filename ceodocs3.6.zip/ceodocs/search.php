<?php
get_header();
$bg = _ceo('search-bg');

$tabType = $_GET['type'] ?? 1;

?>
<div class="ceo-tag-bg ceo-default-bg ceo-background-cover ceo-background-muted ceo-panel" style="background-image: url(<?php echo $bg; ?>)">
    <div class="ceo-container">
        <div class="top ceo-flex">
            <div class="title ceo-flex-1">
                <?php
				$allsearch = new WP_Query(
				      array(
                        'post_type'      => 'post',
                        'posts_per_page' => get_option( 'posts_per_page' ),
                        'post_status'    => 'publish',
                        's' => $_GET['s'],
                        'paged' => $page,
                        'meta_query' => array(
                            array(
                                'key' => 'ceo_shop_type',
                                'value' => 'close',
                                'compare' => $tabType == 1 ? '!=' : '=',
                            ),
                        ),
                    )
			    );
				$key = get_search_query(1);
				if(empty($key)){
				    $key = get_query_var( 'p' );
                }
				$count = $allsearch->post_count;
				echo '<h1>'. $key .'</h1>';
				
				// if(is_search()){
    //                 global $wp_query;
    //                 $count = $wp_query->found_posts;
    //             }
				echo '<p class="ceo-display-block ceo-margin-remove">共搜索到<strong class="ceo-text-warning ceo-text-bold"> ' . $count .' </strong>个「' . $key .'」的相关作品</p>' ;
				wp_reset_query(); 
				?>
            </div>
            <a href="/tags">热门作品标签<i class="ceofont ceoicon-arrow-right-s-line"></i></a>
        </div>
    </div>
</div>
<section class="ceo-default-list">
    <div class="ceo-container ceo-margin-medium-bottom">
	    <div class="default-box">
    	    <ul class="nav">
                <li <?php if ($tabType == 1) echo 'class="ceo-active"' ?>><a href="<?php echo home_url(add_query_arg(['type' => 1])) ?>">作品</a></li>
                <li <?php if ($tabType == 2) echo 'class="ceo-active"' ?>><a href="<?php echo home_url(add_query_arg(['type' => 2])) ?>">文章</a></li>
            </ul>
            
            <?php if ($tabType == 1): ?>
            <?php get_template_part( 'template-parts/default/search', 'works' ); ?>
             <?php elseif ($tabType == 2): ?>
            <?php get_template_part( 'template-parts/default/search', 'article' ); ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php get_footer(); ?>