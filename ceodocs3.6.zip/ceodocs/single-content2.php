<?php
get_header();
$post_id =  get_the_ID();
?>

<section class="ceo-single-content">
    <div class="ceo-container1200">
        <div class="ceo-shouji-pass">
        	<?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
        </div>
        <div class="ceo-grid-ceosmls" ceo-grid>
            <div class="ceo-width-1-1 ceo-width-7-0@s">
                <div class="ceo-background-default ceo-margin-bottom b-r-4">
            		<?php while ( have_posts() ) : the_post(); ?>
                    <div class="content-box">
            			<article class="single-content">
            			    <?php
                            if(get_post_meta(get_the_ID(),"enable_audio",1)){
                                get_template_part( 'template-parts/single/single', 'music' );
                            }
                            ?>
            				<?php the_content(); ?>
            				
            				<?php if (_ceo('ceo_single_shop_login') == true ): ?>
            				<?php if( is_user_logged_in() == false ){ ?>
            				<div class="mask"></div>
            				<div class="single-login">
            				    <div class="login-box">
            				        <a href="<?php bloginfo('url'); ?>" class="logo">
                                        <img src="<?php echo _ceo('head_logo'); ?>" alt="<?php bloginfo('name'); ?>">
                                    </a>
            				        <p class="desc">— <?php echo _ceo('ceo_single_shop_login_title'); ?> —</p>
            				        <div class="type">
            				            <div class="tab">
                				            <?php if(_ceo('qq_login')){?>
                                        	<a href="javascript:;" class="button mid qq half qq_login_button ceo_qq_login" ceo-tooltip="QQ登录"><i class="ceofont ceoicon-qq-fill"></i>QQ登录</a>
                                        	<?php }?>
                                        </div>
                                        <div class="tab">
                                        	<?php if(_ceo('is_oauth_mpweixin')){?>
                                        	<a href="<?php echo esc_url(home_url('/oauth/mpweixin')); ?>" class="mpweixin_login_button btn change-color social-login button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="关注微信公众号登录"><i class="ceofont ceoicon-wechat-fill"></i>微信登录</a>
                                            <?php }elseif(_ceo('weixin_login')){?>
                                        	<a href="<?php echo esc_url(home_url('/oauth/'.'weixin'.'?rurl='.home_url(add_query_arg(array())))); ?>" class="btn change-color social-login button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="微信登录"><i class="ceofont ceoicon-wechat-fill"></i>微信登录</a>
                                            <?php }?>
                                        </div>
        				                <div class="tab">
        				                    <a class="form" href="#navbar-login" ceo-tooltip="账号登录" ceo-toggle><i class="ceofont ceoicon-computer-line"></i>账号登录</a>
        				                </div>
    				                </div>
				                </div>
			                </div>
			                <?php } ?>
			                <?php endif ?>
            			</article>
            			
            			<?php if (_ceo('ceo_single_shop_tag') == true ): ?>
        				<div class="ceo-single-tagmk">
        				    <div class="title"><?php echo _ceo('ceo_single_shop_tag_title'); ?></div>
        				    <div class="box">
        					<?php the_tags('', '') ?>
        					</div>
        				</div>
        				<?php endif ?>
        				
            		</div>
            		<?php endwhile; ?>
                </div>
            </div>
            <?php get_template_part( 'template-parts/sidebar/sidebar', 'content2' ); ?>
        </div>
        <?php if (_ceo('ceo_single_shop_relevant') == true ): ?>
        <div class="relevant">
            <div class="title"><?php echo _ceo('ceo_single_shop_relevant_title'); ?></div>
            <?php get_template_part( 'template-parts/single/single', 'relevant' ); ?>
        </div>
        <?php endif ?>
        <?php if (_ceo('ceo_single_shop_relevant_tag') == true ): ?>
        <div class="relevant-tag">
            <div class="title"><?php echo _ceo('ceo_single_shop_relevant_tag_title'); ?></div>
            <ul class="ceo-grid-ceosmls" ceo-grid>
               <?php 
                    $tags = get_tags();
                    $tagKey = count($tags) > 0 ? array_rand($tags, count($tags) >=30 ? 30 : count($tags)) : [];
                    foreach ($tagKey as $tagK):
                ?>
                <li class="ceo-width-1-3 ceo-width-1-10@s">
                    <a href="<?php echo get_term_link($tags[$tagK]) ?>" class="ceo-text-truncate" ceo-tooltip="<?php echo $tags[$tagK]->name ?>"><?php echo $tags[$tagK]->name ?></a>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php endif ?>
    </div>
</section>

<!--必备-->
<?php add_action('get_footer', function () { wp_enqueue_script('js2021', get_template_directory_uri() . '/static/js/js21.js', ['jquery']); }); ?>
<?php get_footer(); ?>