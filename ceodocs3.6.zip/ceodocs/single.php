<?php
get_header();
$post_id =  get_the_ID();
?>

<section class="ceo-single-content">
    <div class="ceo-container1200">
        <section class="ceo-shouji-pass">
        	<?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
        </section>
    	<div class="ceo-grid-ceosmls" ceo-grid>
    		<div class="ceo-width-1-1 ceo-width-7-0@s">
    			<?php while ( have_posts() ) : the_post(); ?>
                <div class="ceo-single ceo-background-default ceo-margin-bottom b-r-4">
        			<header class="header b-b">
        			    <div class="title">
            			    <?php if(get_post_meta( get_the_ID(), 'ceo-tese-tag', true )){?>
            			    <div class="tag">
        				        <?php echo get_post_meta( get_the_ID(), 'ceo-tese-tag', true );?>
        				    </div>
        				    <?php }?>
        					<h1><?php the_title(); ?></h1>
    					</div>
    					<?php get_template_part( 'template-parts/single/single', 'info' ); ?>
    				</header>
					<article class="single-content">
						<?php the_content(); ?>
					</article>
    				<!--文章按钮-->
    				<div class="ceo-single-szcan">
    				    <?php if(_ceo('single_foo_sc') == true ): ?>
    				    <div class="ceo-single-szcan-sc">
                	        <?php echo ceotheme_post_collection_button( get_the_ID() );?>
                	    </div>
                	    <?php endif ?>
                	    <?php if(_ceo('single_foo_dz') == true ): ?>
                	    <div class="ceo-single-szcan-dz">
                            <?php echo ceotheme_post_like_button();?>
                        </div>
                        <?php endif ?>
                    </div>

    				<?php if (_ceo('single_foo_bq') == true ): ?>
    				<!--文章版权-->
    				<div class="ceo-single-copyright">
    					<p><i class="ceofont ceoicon-information-line"></i> 版权：<?php echo _ceo('single_foo_bq_text'); ?> 转载请注明出处：<?php the_permalink(); ?></p>
    				</div>
    				<?php endif ?>

    				<?php if (_ceo('single_foo_tag') == true ): ?>
    				<!--文章标签-->
    				<div class="ceo-single-tag">
    					<?php the_tags('', '') ?>
    				</div>
    				<?php endif ?>

    				<!--文章作者-->
    				<div class="ceo-position-z-index" ceo-sticky="position: bottom; end: !.ceo-single">
        				<div class="ceo-single-share b-t ceo-flex">
        				    <div class="ceo-single-author ceo-flex-1">
            					<?php echo get_avatar(get_the_author_meta( 'ID' ), 20); ?>
            					<span class="ceo-text-small ceo-margin-small-left ceo-visible@s"><?php the_author_posts_link(); ?></span>
        					</div>
    
                    		<div class="share">
                                <a class="share-post meta-item mobile j-mobile-share" href="javascript:;" data-id="<?php echo get_the_ID(); ?>"
                                   data-qrcode="<?php echo get_the_permalink(); ?>">
                                    <i class="ceofont ceoicon-image-line"></i> 生成海报
                                </a>
                                <?php
        							$qrcode = ''.get_bloginfo('template_directory').'/inc/qrcode?data='.get_the_permalink().'';
        							$post_url = esc_url(get_permalink());
        							$post_title = esc_attr(get_the_title());
        							$post_desc = wp_trim_words( get_the_content(), 30 );
        						?>
        						<p class="ceo-display-inline-block">分享</p>
        						<a class="weixin-share ceo-display-inline-block" href="<?php echo $qrcode; ?>" ceo-tooltip="分享到微信" data-image="<?php echo esc_attr($post_image); ?>" target="_blank"><i class="ceofont ceoicon-wechat-fill"></i>
        						</a>
        						<a class="ceo-display-inline-block" href="http://connect.qq.com/widget/shareqq/index.html?url=<?php echo $post_url; ?>&sharesource=qzone&title=<?php echo $post_title; ?>&pics=<?php echo post_thumbnail_src(); ?>&summary=<?php echo $post_desc; ?>"  ceo-tooltip="分享到QQ好友/QQ空间" target="_blank" rel="noreferrer nofollow"><i class="ceofont ceoicon-qq-fill"></i>
        						</a>
        						<a class="ceo-display-inline-block" href="http://service.weibo.com/share/mobile.php?url=<?php echo $post_url; ?>&title=<?php echo $post_title ?> - <?php bloginfo('name'); ?>&appkey=3313789115" ceo-tooltip="分享到微博" target="_blank" rel="noreferrer nofollow"><i class="ceofont ceoicon-weibo-fill"></i>
        						</a>
                    		</div>
        				</div>
    				</div>
				</div>

    			<?php get_template_part( 'template-parts/single/single', 'page' ); ?>
    			<?php endwhile; ?>

                <?php if(_ceo('xg_show') == true ): ?>
    			<?php get_template_part( 'template-parts/single/single', 'bottom' ); ?>
    			<?php endif ?>

    			<?php if(_ceo('comments_close') == false ): ?>
    			<?php if ( comments_open() || get_comments_number() ) : ?>
    			<?php comments_template( '', true ); ?>
    			<?php endif; ?>
    			<?php endif; ?>
    		</div>
    		<?php get_sidebar(); ?>
    	</div>
    </div>
</section>

<!--必备-->
<?php add_action('get_footer', function () { wp_enqueue_script('js2021', get_template_directory_uri() . '/static/js/js21.js', ['jquery']); }); ?>
<?php get_footer(); ?>