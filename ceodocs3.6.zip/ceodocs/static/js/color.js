const colorData = {
  colorComplete: [{id: 1, name: '鸨色', color: '#f7acbc'}, {id: 2, name: '赤白橡', color: '#deab8a'}, {
    id: 3,
    name: '油色',
    color: '#817936'
  }, {id: 4, name: '绀桔梗', color: '#444693'}, {id: 5, name: '踯躅色', color: '#ef5b9c'}, {
    id: 6,
    name: '肌色',
    color: '#fedcbd'
  }, {id: 7, name: '伽罗色', color: '#7f7522'}, {id: 8, name: '花色', color: '#2b4490'}, {
    id: 9,
    name: '桜色',
    color: '#feeeed'
  }, {id: 10, name: '橙色', color: '#f47920'}, {id: 11, name: '青丹', color: '#80752c'}, {
    id: 12,
    name: '瑠璃色',
    color: '#2a5caa'
  }, {id: 13, name: '蔷薇色', color: '#f05b72'}, {id: 14, name: '灰茶', color: '#905a3d'}, {
    id: 15,
    name: '莺色',
    color: '#87843b'
  }, {id: 16, name: '琉璃绀', color: '#224b8f'}, {id: 17, name: '韩红', color: '#f15b6c'}, {
    id: 18,
    name: '茶色',
    color: '#8f4b2e'
  }, {id: 19, name: '利久色', color: '#726930'}, {id: 20, name: '绀色', color: '#003a6c'}, {
    id: 21,
    name: '珊瑚色',
    color: '#f8aba6'
  }, {id: 22, name: '桦茶色', color: '#87481f'}, {id: 23, name: '媚茶', color: '#454926'}, {
    id: 24,
    name: '青蓝',
    color: '#102b6a'
  }, {id: 25, name: '红梅色', color: '#f69c9f'}, {id: 26, name: '枯茶', color: '#5f3c23'}, {
    id: 27,
    name: '蓝海松茶',
    color: '#2e3a1f'
  }, {id: 28, name: '杜若色', color: '#426ab3'}, {id: 29, name: '桃色', color: '#f58f98'}, {
    id: 30,
    name: '焦茶',
    color: '#6b473c'
  }, {id: 31, name: '青钝', color: '#4d4f36'}, {id: 32, name: '胜色', color: '#46485f'}, {
    id: 33,
    name: '薄柿',
    color: '#ca8687'
  }, {id: 34, name: '柑子色', color: '#faa755'}, {id: 35, name: '抹茶色', color: '#b7ba6b'}, {
    id: 36,
    name: '群青色',
    color: '#4e72b8'
  }, {id: 37, name: '薄红梅', color: '#f391a9'}, {id: 38, name: '杏色', color: '#fab27b'}, {
    id: 39,
    name: '黄緑',
    color: '#b2d235'
  }, {id: 40, name: '铁绀', color: '#181d4b'}, {id: 41, name: '曙色', color: '#bd6758'}, {
    id: 42,
    name: '蜜柑色',
    color: '#f58220'
  }, {id: 43, name: '苔色', color: '#5c7a29'}, {id: 44, name: '蓝铁', color: '#1a2933'}, {
    id: 45,
    name: '红色',
    color: '#d71345'
  }, {id: 46, name: '褐色', color: '#843900'}, {id: 47, name: '若草色', color: '#bed742'}, {
    id: 48,
    name: '青褐',
    color: '#121a2a'
  }, {id: 49, name: '赤丹', color: '#d64f44'}, {id: 50, name: '路考茶', color: '#905d1d'}, {
    id: 51,
    name: '若緑',
    color: '#7fb80e'
  }, {id: 52, name: '褐返', color: '#0c212b'}, {id: 53, name: '红赤', color: '#d93a49'}, {
    id: 54,
    name: '饴色',
    color: '#8a5d19'
  }, {id: 55, name: '萌黄', color: '#a3cf62'}, {id: 56, name: '藤纳戸', color: '#6a6da9'}, {
    id: 57,
    name: '臙脂色',
    color: '#b3424a'
  }, {id: 58, name: '丁子色', color: '#8c531b'}, {id: 59, name: '苗色', color: '#769149'}, {
    id: 60,
    name: '桔梗色',
    color: '#585eaa'
  }, {id: 61, name: '真赭', color: '#c76968'}, {id: 62, name: '丁子茶', color: '#826858'}, {
    id: 63,
    name: '草色',
    color: '#6d8346'
  }, {id: 64, name: '绀蓝', color: '#494e8f'}, {id: 65, name: '今様色', color: '#bb505d'}, {
    id: 66,
    name: '黄栌',
    color: '#64492b'
  }, {id: 67, name: '柳色', color: '#78a355'}, {id: 68, name: '藤色', color: '#afb4db'}, {
    id: 69,
    name: '梅染',
    color: '#987165'
  }, {id: 70, name: '土器色', color: '#ae6642'}, {id: 71, name: '若草色', color: '#abc88b'}, {
    id: 72,
    name: '藤紫',
    color: '#9b95c9'
  }, {id: 73, name: '退红色', color: '#ac6767'}, {id: 74, name: '黄枯茶', color: '#56452d'}, {
    id: 75,
    name: '松叶色',
    color: '#74905d'
  }, {id: 76, name: '青紫', color: '#6950a1'}, {id: 77, name: '苏芳', color: '#973c3f'}, {
    id: 78,
    name: '狐色',
    color: '#96582a'
  }, {id: 79, name: '白緑', color: '#cde6c7'}, {id: 80, name: '菫色', color: '#6f60aa'}, {
    id: 81,
    name: '茜色',
    color: '#b22c46'
  }, {id: 82, name: '黄橡', color: '#705628'}, {id: 83, name: '薄緑', color: '#1d953f'}, {
    id: 84,
    name: '鸠羽色',
    color: '#867892'
  }, {id: 85, name: '红', color: '#a7324a'}, {id: 86, name: '银煤竹', color: '#4a3113'}, {
    id: 87,
    name: '千草色',
    color: '#77ac98'
  }, {id: 88, name: '薄色', color: '#918597'}, {id: 89, name: '银朱', color: '#aa363d'}, {
    id: 90,
    name: '涅色',
    color: '#412f1f'
  }, {id: 91, name: '青緑', color: '#007d65'}, {id: 92, name: '薄鼠', color: '#6f6d85'}, {
    id: 93,
    name: '赤',
    color: '#ed1941'
  }, {id: 94, name: '胡桃色', color: '#845538'}, {id: 95, name: '浅緑', color: '#84bf96'}, {
    id: 96,
    name: '鸠羽鼠',
    color: '#594c6d'
  }, {id: 97, name: '朱色', color: '#f26522'}, {id: 98, name: '香色', color: '#8e7437'}, {
    id: 99,
    name: '緑',
    color: '#45b97c'
  }, {id: 100, name: '菖蒲色', color: '#694d9f'}, {id: 101, name: '洗朱', color: '#d2553d'}, {
    id: 102,
    name: '国防色',
    color: '#69541b'
  }, {id: 103, name: '草色', color: '#225a1f'}, {id: 104, name: '江戸紫', color: '#6f599c'}, {
    id: 105,
    name: '红桦色',
    color: '#b4534b'
  }, {id: 106, name: '练色', color: '#d5c59f'}, {id: 107, name: '木贼色', color: '#367459'}, {
    id: 108,
    name: '紫',
    color: '#8552a1'
  }, {id: 109, name: '红绯', color: '#ef4136'}, {id: 110, name: '肉色', color: '#cd9a5b'}, {
    id: 111,
    name: '常盘色',
    color: '#007947'
  }, {id: 112, name: '灭紫', color: '#543044'}, {id: 113, name: '桦色', color: '#c63c26'}, {
    id: 114,
    name: '人色',
    color: '#cd9a5b'
  }, {id: 115, name: '緑青色', color: '#40835e'}, {id: 116, name: '葡萄鼠', color: '#63434f'}, {
    id: 117,
    name: '铅丹色',
    color: '#f3715c'
  }, {id: 118, name: '土色', color: '#b36d41'}, {id: 119, name: '千歳緑', color: '#2b6447'}, {
    id: 120,
    name: '古代紫',
    color: '#7d5886'
  }, {id: 121, name: '赭', color: '#a7573b'}, {id: 122, name: '小麦色', color: '#df9464'}, {
    id: 123,
    name: '深緑',
    color: '#005831'
  }, {id: 124, name: '暗红', color: '#401c44'}, {id: 125, name: '绯色', color: '#aa2116'}, {
    id: 126,
    name: '琥珀色',
    color: '#b76f40'
  }, {id: 127, name: '萌葱色', color: '#006c54'}, {id: 128, name: '葡萄', color: '#472d56'}, {
    id: 129,
    name: '丹',
    color: '#b64533'
  }, {id: 130, name: '木兰色', color: '#ad8b3d'}, {id: 131, name: '青白橡', color: '#375830'}, {
    id: 132,
    name: '茄子绀',
    color: '#45224a'
  }, {id: 133, name: '土', color: '#b54334'}, {id: 134, name: '栀子色', color: '#dea32c'}, {
    id: 135,
    name: '革色',
    color: '#274d3d'
  }, {id: 136, name: '紫绀', color: '#411445'}, {id: 137, name: '焦香', color: '#853f04'}, {
    id: 138,
    name: '朽叶',
    color: '#d1923f'
  }, {id: 139, name: '麹尘', color: '#375830'}, {id: 140, name: '浓色', color: '#4b2f3d'}, {
    id: 141,
    name: '真红',
    color: '#840228'
  }, {id: 142, name: '萱草色', color: '#c88400'}, {id: 143, name: '仙斎茶', color: '#27342b'}, {
    id: 144,
    name: '二蓝',
    color: '#402e4c'
  }, {id: 145, name: '绯', color: '#7a1723'}, {id: 146, name: '黄金', color: '#c37e00'}, {
    id: 147,
    name: '若竹色',
    color: '#65c294'
  }, {id: 148, name: '菖蒲色', color: '#c77eb5'}, {id: 149, name: '红海老茶', color: '#a03939'}, {
    id: 150,
    name: '金色',
    color: '#c37e00'
  }, {id: 151, name: '青磁色', color: '#73b9a2'}, {id: 152, name: '牡丹色', color: '#ea66a6'}, {
    id: 153,
    name: '浅苏芳',
    color: '#8a2e3b'
  }, {id: 154, name: '金茶', color: '#e0861a'}, {id: 155, name: '青竹色', color: '#72baa7'}, {
    id: 156,
    name: '赤紫',
    color: '#f173ac'
  }, {id: 157, name: '鸢色', color: '#8e453f'}, {id: 158, name: '卵色', color: '#ffce7b'}, {
    id: 159,
    name: '铁色',
    color: '#005344'
  }, {id: 160, name: '白', color: '#fffffb'}, {id: 161, name: '小豆色', color: '#8f4b4a'}, {
    id: 162,
    name: '山吹色',
    color: '#fcaf17'
  }, {id: 163, name: '锖鼠', color: '#122e29'}, {id: 164, name: '胡粉色', color: '#fffef9'}, {
    id: 165,
    name: '弁柄色',
    color: '#892f1b'
  }, {id: 166, name: '黄土色', color: '#ba8448'}, {id: 167, name: '铁御纳戸', color: '#293047'}, {
    id: 168,
    name: '生成色',
    color: '#f6f5ec'
  }, {id: 169, name: '栗梅', color: '#6b2c25'}, {id: 170, name: '朽叶色', color: '#896a45'}, {
    id: 171,
    name: '青緑',
    color: '#00ae9d'
  }, {id: 172, name: '灰白', color: '#d9d6c3'}, {id: 173, name: '海老茶', color: '#733a31'}, {
    id: 174,
    name: '空五倍子色',
    color: '#76624c'
  }, {id: 175, name: '锖浅葱', color: '#508a88'}, {id: 176, name: '石竹色', color: '#d1c7b7'}, {
    id: 177,
    name: '深绯',
    color: '#54211d'
  }, {id: 178, name: '莺茶', color: '#6d5826'}, {id: 179, name: '水浅葱', color: '#70a19f'}, {
    id: 180,
    name: '象牙色',
    color: '#f2eada'
  }, {id: 181, name: '赤铜色', color: '#78331e'}, {id: 182, name: '向日葵色', color: '#ffc20e'}, {
    id: 183,
    name: '新桥色',
    color: '#50b7c1'
  }, {id: 184, name: '乳白色', color: '#d3d7d4'}, {id: 185, name: '赤褐色', color: '#53261f'}, {
    id: 186,
    name: '郁金色',
    color: '#fdb933'
  }, {id: 187, name: '浅葱色', color: '#00a6ac'}, {id: 188, name: '薄钝', color: '#999d9c'}, {
    id: 189,
    name: '金赤',
    color: '#f15a22'
  }, {id: 190, name: '砂色', color: '#d3c6a6'}, {id: 191, name: '白群', color: '#78cdd1'}, {
    id: 192,
    name: '银鼠',
    color: '#a1a3a6'
  }, {id: 193, name: '赤茶', color: '#b4533c'}, {id: 194, name: '芥子色', color: '#c7a252'}, {
    id: 195,
    name: '御纳戸色',
    color: '#008792'
  }, {id: 196, name: '茶鼠', color: '#9d9087'}, {id: 197, name: '赤锖色', color: '#84331f'}, {
    id: 198,
    name: '淡黄',
    color: '#dec674'
  }, {id: 199, name: '瓮覗', color: '#94d6da'}, {id: 200, name: '鼠色', color: '#8a8c8e'}, {
    id: 201,
    name: '黄丹',
    color: '#f47a55'
  }, {id: 202, name: '亜麻色', color: '#b69968'}, {id: 203, name: '水色', color: '#afdfe4'}, {
    id: 204,
    name: '薄墨色',
    color: '#74787c'
  }, {id: 205, name: '赤橙', color: '#f15a22'}, {id: 206, name: '枯色', color: '#c1a173'}, {
    id: 207,
    name: '蓝鼠',
    color: '#5e7c85'
  }, {id: 208, name: '利休鼠', color: '#7c8577'}, {id: 209, name: '柿色', color: '#f3704b'}, {
    id: 210,
    name: '鸟子色',
    color: '#dbce8f'
  }, {id: 211, name: '秘色', color: '#76becc'}, {id: 212, name: '铅色', color: '#72777b'}, {
    id: 213,
    name: '肉桂色',
    color: '#da765b'
  }, {id: 214, name: '黄色', color: '#ffd400'}, {id: 215, name: '空色', color: '#90d7ec'}, {
    id: 216,
    name: '灰色',
    color: '#77787b'
  }, {id: 217, name: '桦色', color: '#c85d44'}, {id: 218, name: '蒲公英色', color: '#ffd400'}, {
    id: 219,
    name: '青',
    color: '#009ad6'
  }, {id: 220, name: '钝色', color: '#4f5555'}, {id: 221, name: '炼瓦色', color: '#ae5039'}, {
    id: 222,
    name: '中黄',
    color: '#ffe600'
  }, {id: 223, name: '蓝色', color: '#145b7d'}, {id: 224, name: '煤竹色', color: '#6c4c49'}, {
    id: 225,
    name: '锖色',
    color: '#6a3427'
  }, {id: 226, name: '刈安色', color: '#f0dc70'}, {id: 227, name: '浓蓝', color: '#11264f'}, {
    id: 228,
    name: '黒茶',
    color: '#563624'
  }, {id: 229, name: '桧皮色', color: '#8f4b38'}, {id: 230, name: '黄檗色', color: '#fcf16e'}, {
    id: 231,
    name: '勿忘草色',
    color: '#7bbfea'
  }, {id: 232, name: '黒橡', color: '#3e4145'}, {id: 233, name: '栗色', color: '#8e3e1f'}, {
    id: 234,
    name: '緑黄色',
    color: '#decb00'
  }, {id: 235, name: '露草色', color: '#33a3dc'}, {id: 236, name: '浓鼠', color: '#3c3645'}, {
    id: 237,
    name: '黄赤',
    color: '#f36c21'
  }, {id: 238, name: '鶸色', color: '#cbc547'}, {id: 239, name: '缥色', color: '#228fbd'}, {
    id: 240,
    name: '墨',
    color: '#464547'
  }, {id: 241, name: '代赭', color: '#b4532a'}, {id: 242, name: '海松色', color: '#6e6b41'}, {
    id: 243,
    name: '浅缥',
    color: '#2468a2'
  }, {id: 244, name: '黒', color: '#130c0e'}, {id: 245, name: '骆驼色', color: '#b7704f'}, {
    id: 246,
    name: '鶸茶',
    color: '#596032'
  }, {id: 247, name: '薄缥', color: '#2570a1'}, {id: 248, name: '黒铁', color: '#281f1d'}, {
    id: 249,
    name: '黄茶',
    color: '#de773f'
  }, {id: 250, name: '山鸠色', color: '#525f42'}, {id: 251, name: '薄花色', color: '#2585a6'}, {
    id: 252,
    name: '蝋色',
    color: '#2f271d'
  }, {id: 253, name: '洗柿', color: '#c99979'}, {id: 254, name: '生壁色', color: '#5f5d46'}, {
    id: 255,
    name: '绀青',
    color: '#1b315e'
  }, {id: 256, name: '紫黒', color: '#1d1626'}]
}
if(!colorNameMap){
  var colorNameMap = {}
}
const renderColorComplete = () => {
  const $completeList = $('.cce-complete-list-wrapper .complete-list')
  const dom = Object.keys(colorNameMap).reduce((result, item) =>
    result + '<li class="ceo-width-1-2 ceo-width-1-5@s"><div class="complete-item">\n' +
    '        <span>' + colorNameMap[item] + '</span>\n' +
    '        <span class="magnifier-icon"></span>\n' +
    '        <span class="copy-icon copy-button"></span>\n' +
    '        <input readonly value="' + item.toUpperCase() + '" />\n' +
    '        <div class="color-show" target="_blank" style="background-color:' + item.toUpperCase() + '" data-color="' + item + '"></div>\n' +
    '      </div></li>'
    , '')
  $completeList.append(dom)
}
const bindColorClickEvent = () => {
  const selectorList = ['.cce-complete-list-wrapper .complete-list']
  const pageJump = (color) => {
    // window.open('','_blank')
  }
  selectorList.forEach(item => {
    $(item).on('click', function (e) {
      const color = $(e.target).data().color
      if (!color) return
      pageJump(color)
    })
  })
}
const bindColorMagnifierClickEvent = () => {
  const r = 1500
  const $cceColorFullScreen = $('.cce-color-full-screen')
  const $magnifierIcon = $('.cce-complete-list-wrapper .magnifier-icon')
  let pendingFlag = false
  $magnifierIcon.on('click', function (e) {

    const color = $(this).siblings('.color-show').data().color
    $cceColorFullScreen.css({
      background: color,
      left: e.clientX - r + 'px',
      top: e.clientY - r + 'px'
    }).addClass('state-pending')
    pendingFlag = true
    $('body').addClass('state-fixed')
    setTimeout(() => {
      pendingFlag = false
      $cceColorFullScreen.addClass('state-fulfilled')
    }, 700)
  })
  $cceColorFullScreen.on('click', function () {
    if (pendingFlag) return
    $('body').removeClass('state-fixed')
    $(this).removeClass('state-pending').removeClass('state-fulfilled')
  })
}

const bindColorCopyClickEvent = () => {
  const $copyButton = $('.cce-complete-list-wrapper .copy-button')
  const domColorCopy =  document.querySelector('#color-copy')
  let $colorCopy = domColorCopy ? $(domColorCopy) : ''
  if(!domColorCopy){
    $('body').append('<input id="color-copy" type="text" value="" style="position: absolute;bottom:0;right:0;opacity: 0;cursor: default">')
    $colorCopy = $('#color-copy')
  }
  $copyButton.on('click', function (e) {
    const $input = $(this).siblings('input')
    $colorCopy.val($input.val()).select()
    document.execCommand('copy')
    window.alert($input.val() + ' 复制成功!')
  })
}
renderColorComplete()
bindColorClickEvent()
bindColorMagnifierClickEvent()
bindColorCopyClickEvent()