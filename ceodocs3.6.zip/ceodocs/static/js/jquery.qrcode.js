"use strict";
var i;
(i = jQuery).fn.qrcode = function (e) {
    var t;

    function a(e) {
        this.mode = t, this.data = e
    }

    function s(e, t) {
        this.typeNumber = e, this.errorCorrectLevel = t, this.modules = null, this.moduleCount = 0, this.dataCache = null, this.dataList = []
    }

    function o(e, t) {
        if (null == e.length) throw Error(e.length + "/" + t);
        for (var a = 0; a < e.length && 0 == e[a];) a++;
        this.num = Array(e.length - a + t);
        for (var i = 0; i < e.length - a; i++) this.num[i] = e[i + a]
    }

    function r(e, t) {
        this.totalCount = e, this.dataCount = t
    }

    function n() {
        this.buffer = [], this.length = 0
    }

    a.prototype = {
        getLength: function () {
            return this.data.length
        }, write: function (e) {
            for (var t = 0; t < this.data.length; t++) e.put(this.data.charCodeAt(t), 8)
        }
    }, s.prototype = {
        addData: function (e) {
            this.dataList.push(new a(e)), this.dataCache = null
        }, isDark: function (e, t) {
            if (0 > e || this.moduleCount <= e || 0 > t || this.moduleCount <= t) throw Error(e + "," + t);
            return this.modules[e][t]
        }, getModuleCount: function () {
            return this.moduleCount
        }, make: function () {
            if (1 > this.typeNumber) {
                var e = 1;
                for (e = 1; 40 > e; e++) {
                    for (var t = r.getRSBlocks(e, this.errorCorrectLevel), a = new n, i = 0, s = 0; s < t.length; s++) i += t[s].dataCount;
                    for (s = 0; s < this.dataList.length; s++) t = this.dataList[s], a.put(t.mode, 4), a.put(t.getLength(), l.getLengthInBits(t.mode, e)), t.write(a);
                    if (a.getLengthInBits() <= 8 * i) break
                }
                this.typeNumber = e
            }
            this.makeImpl(!1, this.getBestMaskPattern())
        }, makeImpl: function (e, t) {
            this.moduleCount = 4 * this.typeNumber + 17, this.modules = Array(this.moduleCount);
            for (var a = 0; a < this.moduleCount; a++) {
                this.modules[a] = Array(this.moduleCount);
                for (var i = 0; i < this.moduleCount; i++) this.modules[a][i] = null
            }
            this.setupPositionProbePattern(0, 0), this.setupPositionProbePattern(this.moduleCount - 7, 0), this.setupPositionProbePattern(0, this.moduleCount - 7), this.setupPositionAdjustPattern(), this.setupTimingPattern(), this.setupTypeInfo(e, t), 7 <= this.typeNumber && this.setupTypeNumber(e), null == this.dataCache && (this.dataCache = s.createData(this.typeNumber, this.errorCorrectLevel, this.dataList)), this.mapData(this.dataCache, t)
        }, setupPositionProbePattern: function (e, t) {
            for (var a = -1; 7 >= a; a++) if (!(-1 >= e + a || this.moduleCount <= e + a)) for (var i = -1; 7 >= i; i++) -1 >= t + i || this.moduleCount <= t + i || (this.modules[e + a][t + i] = 0 <= a && 6 >= a && (0 == i || 6 == i) || 0 <= i && 6 >= i && (0 == a || 6 == a) || 2 <= a && 4 >= a && 2 <= i && 4 >= i)
        }, getBestMaskPattern: function () {
            for (var e = 0, t = 0, a = 0; 8 > a; a++) {
                this.makeImpl(!0, a);
                var i = l.getLostPoint(this);
                (0 == a || e > i) && (e = i, t = a)
            }
            return t
        }, createMovieClip: function (e, t, a) {
            for (e = e.createEmptyMovieClip(t, a), this.make(), t = 0; t < this.modules.length; t++) {
                a = 1 * t;
                for (var i = 0; i < this.modules[t].length; i++) {
                    var s = 1 * i;
                    this.modules[t][i] && (e.beginFill(0, 100), e.moveTo(s, a), e.lineTo(s + 1, a), e.lineTo(s + 1, a + 1), e.lineTo(s, a + 1), e.endFill())
                }
            }
            return e
        }, setupTimingPattern: function () {
            for (var e = 8; e < this.moduleCount - 8; e++) null == this.modules[e][6] && (this.modules[e][6] = 0 == e % 2);
            for (e = 8; e < this.moduleCount - 8; e++) null == this.modules[6][e] && (this.modules[6][e] = 0 == e % 2)
        }, setupPositionAdjustPattern: function () {
            for (var e = l.getPatternPosition(this.typeNumber), t = 0; t < e.length; t++) for (var a = 0; a < e.length; a++) {
                var i = e[t], s = e[a];
                if (null == this.modules[i][s]) for (var o = -2; 2 >= o; o++) for (var r = -2; 2 >= r; r++) this.modules[i + o][s + r] = -2 == o || 2 == o || -2 == r || 2 == r || 0 == o && 0 == r
            }
        }, setupTypeNumber: function (e) {
            for (var t = l.getBCHTypeNumber(this.typeNumber), a = 0; 18 > a; a++) {
                var i = !e && 1 == (t >> a & 1);
                this.modules[Math.floor(a / 3)][a % 3 + this.moduleCount - 8 - 3] = i
            }
            for (a = 0; 18 > a; a++) i = !e && 1 == (t >> a & 1), this.modules[a % 3 + this.moduleCount - 8 - 3][Math.floor(a / 3)] = i
        }, setupTypeInfo: function (e, t) {
            for (var a = l.getBCHTypeInfo(this.errorCorrectLevel << 3 | t), i = 0; 15 > i; i++) {
                var s = !e && 1 == (a >> i & 1);
                6 > i ? this.modules[i][8] = s : 8 > i ? this.modules[i + 1][8] = s : this.modules[this.moduleCount - 15 + i][8] = s
            }
            for (i = 0; 15 > i; i++) s = !e && 1 == (a >> i & 1), 8 > i ? this.modules[8][this.moduleCount - i - 1] = s : 9 > i ? this.modules[8][15 - i - 1 + 1] = s : this.modules[8][15 - i - 1] = s;
            this.modules[this.moduleCount - 8][8] = !e
        }, mapData: function (e, t) {
            for (var a = -1, i = this.moduleCount - 1, s = 7, o = 0, r = this.moduleCount - 1; 0 < r; r -= 2) for (6 == r && r--; ;) {
                for (var n = 0; 2 > n; n++) if (null == this.modules[i][r - n]) {
                    var d = !1;
                    o < e.length && (d = 1 == (e[o] >>> s & 1)), l.getMask(t, i, r - n) && (d = !d), this.modules[i][r - n] = d, -1 == --s && (o++, s = 7)
                }
                if (0 > (i += a) || this.moduleCount <= i) {
                    i -= a, a = -a;
                    break
                }
            }
        }
    }, s.PAD0 = 236, s.PAD1 = 17, s.createData = function (e, t, a) {
        t = r.getRSBlocks(e, t);
        for (var i = new n, o = 0; o < a.length; o++) {
            var d = a[o];
            i.put(d.mode, 4), i.put(d.getLength(), l.getLengthInBits(d.mode, e)), d.write(i)
        }
        for (o = e = 0; o < t.length; o++) e += t[o].dataCount;
        if (i.getLengthInBits() > 8 * e) throw Error("code length overflow. (" + i.getLengthInBits() + ">" + 8 * e + ")");
        for (i.getLengthInBits() + 4 <= 8 * e && i.put(0, 4); 0 != i.getLengthInBits() % 8;) i.putBit(!1);
        for (; !(i.getLengthInBits() >= 8 * e || (i.put(s.PAD0, 8), i.getLengthInBits() >= 8 * e));) i.put(s.PAD1, 8);
        return s.createBytes(i, t)
    }, s.createBytes = function (e, t) {
        for (var a = 0, i = 0, s = 0, r = Array(t.length), n = Array(t.length), d = 0; d < t.length; d++) {
            var c = t[d].dataCount, p = t[d].totalCount - c;
            i = Math.max(i, c), s = Math.max(s, p), r[d] = Array(c);
            for (var u = 0; u < r[d].length; u++) r[d][u] = 255 & e.buffer[u + a];
            for (a += c, u = l.getErrorCorrectPolynomial(p), c = new o(r[d], u.getLength() - 1).mod(u), n[d] = Array(u.getLength() - 1), u = 0; u < n[d].length; u++) p = u + c.getLength() - n[d].length, n[d][u] = 0 <= p ? c.get(p) : 0
        }
        for (u = d = 0; u < t.length; u++) d += t[u].totalCount;
        for (a = Array(d), u = c = 0; u < i; u++) for (d = 0; d < t.length; d++) u < r[d].length && (a[c++] = r[d][u]);
        for (u = 0; u < s; u++) for (d = 0; d < t.length; d++) u < n[d].length && (a[c++] = n[d][u]);
        return a
    }, t = 4;
    for (var l = {
        PATTERN_POSITION_TABLE: [[], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50], [6, 30, 54], [6, 32, 58], [6, 34, 62], [6, 26, 46, 66], [6, 26, 48, 70], [6, 26, 50, 74], [6, 30, 54, 78], [6, 30, 56, 82], [6, 30, 58, 86], [6, 34, 62, 90], [6, 28, 50, 72, 94], [6, 26, 50, 74, 98], [6, 30, 54, 78, 102], [6, 28, 54, 80, 106], [6, 32, 58, 84, 110], [6, 30, 58, 86, 114], [6, 34, 62, 90, 118], [6, 26, 50, 74, 98, 122], [6, 30, 54, 78, 102, 126], [6, 26, 52, 78, 104, 130], [6, 30, 56, 82, 108, 134], [6, 34, 60, 86, 112, 138], [6, 30, 58, 86, 114, 142], [6, 34, 62, 90, 118, 146], [6, 30, 54, 78, 102, 126, 150], [6, 24, 50, 76, 102, 128, 154], [6, 28, 54, 80, 106, 132, 158], [6, 32, 58, 84, 110, 136, 162], [6, 26, 54, 82, 110, 138, 166], [6, 30, 58, 86, 114, 142, 170]],
        G15: 1335,
        G18: 7973,
        G15_MASK: 21522,
        getBCHTypeInfo: function (e) {
            for (var t = e << 10; 0 <= l.getBCHDigit(t) - l.getBCHDigit(l.G15);) t ^= l.G15 << l.getBCHDigit(t) - l.getBCHDigit(l.G15);
            return (e << 10 | t) ^ l.G15_MASK
        },
        getBCHTypeNumber: function (e) {
            for (var t = e << 12; 0 <= l.getBCHDigit(t) - l.getBCHDigit(l.G18);) t ^= l.G18 << l.getBCHDigit(t) - l.getBCHDigit(l.G18);
            return e << 12 | t
        },
        getBCHDigit: function (e) {
            for (var t = 0; 0 != e;) t++, e >>>= 1;
            return t
        },
        getPatternPosition: function (e) {
            return l.PATTERN_POSITION_TABLE[e - 1]
        },
        getMask: function (e, t, a) {
            switch (e) {
                case 0:
                    return 0 == (t + a) % 2;
                case 1:
                    return 0 == t % 2;
                case 2:
                    return 0 == a % 3;
                case 3:
                    return 0 == (t + a) % 3;
                case 4:
                    return 0 == (Math.floor(t / 2) + Math.floor(a / 3)) % 2;
                case 5:
                    return 0 == t * a % 2 + t * a % 3;
                case 6:
                    return 0 == (t * a % 2 + t * a % 3) % 2;
                case 7:
                    return 0 == (t * a % 3 + (t + a) % 2) % 2;
                default:
                    throw Error("bad maskPattern:" + e)
            }
        },
        getErrorCorrectPolynomial: function (e) {
            for (var t = new o([1], 0), a = 0; a < e; a++) t = t.multiply(new o([1, d.gexp(a)], 0));
            return t
        },
        getLengthInBits: function (e, a) {
            if (1 <= a && 10 > a) switch (e) {
                case 1:
                    return 10;
                case 2:
                    return 9;
                case t:
                case 8:
                    return 8;
                default:
                    throw Error("mode:" + e)
            } else if (27 > a) switch (e) {
                case 1:
                    return 12;
                case 2:
                    return 11;
                case t:
                    return 16;
                case 8:
                    return 10;
                default:
                    throw Error("mode:" + e)
            } else {
                if (!(41 > a)) throw Error("type:" + a);
                switch (e) {
                    case 1:
                        return 14;
                    case 2:
                        return 13;
                    case t:
                        return 16;
                    case 8:
                        return 12;
                    default:
                        throw Error("mode:" + e)
                }
            }
        },
        getLostPoint: function (e) {
            for (var t = e.getModuleCount(), a = 0, i = 0; i < t; i++) for (var s = 0; s < t; s++) {
                for (var o = 0, r = e.isDark(i, s), n = -1; 1 >= n; n++) if (!(0 > i + n || t <= i + n)) for (var l = -1; 1 >= l; l++) 0 > s + l || t <= s + l || 0 == n && 0 == l || r == e.isDark(i + n, s + l) && o++;
                5 < o && (a += 3 + o - 5)
            }
            for (i = 0; i < t - 1; i++) for (s = 0; s < t - 1; s++) o = 0, e.isDark(i, s) && o++, e.isDark(i + 1, s) && o++, e.isDark(i, s + 1) && o++, e.isDark(i + 1, s + 1) && o++, (0 == o || 4 == o) && (a += 3);
            for (i = 0; i < t; i++) for (s = 0; s < t - 6; s++) e.isDark(i, s) && !e.isDark(i, s + 1) && e.isDark(i, s + 2) && e.isDark(i, s + 3) && e.isDark(i, s + 4) && !e.isDark(i, s + 5) && e.isDark(i, s + 6) && (a += 40);
            for (s = 0; s < t; s++) for (i = 0; i < t - 6; i++) e.isDark(i, s) && !e.isDark(i + 1, s) && e.isDark(i + 2, s) && e.isDark(i + 3, s) && e.isDark(i + 4, s) && !e.isDark(i + 5, s) && e.isDark(i + 6, s) && (a += 40);
            for (s = o = 0; s < t; s++) for (i = 0; i < t; i++) e.isDark(i, s) && o++;
            return a + 10 * (e = Math.abs(100 * o / t / t - 50) / 5)
        }
    }, d = {
        glog: function (e) {
            if (1 > e) throw Error("glog(" + e + ")");
            return d.LOG_TABLE[e]
        }, gexp: function (e) {
            for (; 0 > e;) e += 255;
            for (; 256 <= e;) e -= 255;
            return d.EXP_TABLE[e]
        }, EXP_TABLE: Array(256), LOG_TABLE: Array(256)
    }, c = 0; 8 > c; c++) d.EXP_TABLE[c] = 1 << c;
    for (c = 8; 256 > c; c++) d.EXP_TABLE[c] = d.EXP_TABLE[c - 4] ^ d.EXP_TABLE[c - 5] ^ d.EXP_TABLE[c - 6] ^ d.EXP_TABLE[c - 8];
    for (c = 0; 255 > c; c++) d.LOG_TABLE[d.EXP_TABLE[c]] = c;
    return o.prototype = {
        get: function (e) {
            return this.num[e]
        }, getLength: function () {
            return this.num.length
        }, multiply: function (e) {
            for (var t = Array(this.getLength() + e.getLength() - 1), a = 0; a < this.getLength(); a++) for (var i = 0; i < e.getLength(); i++) t[a + i] ^= d.gexp(d.glog(this.get(a)) + d.glog(e.get(i)));
            return new o(t, 0)
        }, mod: function (e) {
            if (0 > this.getLength() - e.getLength()) return this;
            for (var t = d.glog(this.get(0)) - d.glog(e.get(0)), a = Array(this.getLength()), i = 0; i < this.getLength(); i++) a[i] = this.get(i);
            for (i = 0; i < e.getLength(); i++) a[i] ^= d.gexp(d.glog(e.get(i)) + t);
            return new o(a, 0).mod(e)
        }
    }, r.RS_BLOCK_TABLE = [[1, 26, 19], [1, 26, 16], [1, 26, 13], [1, 26, 9], [1, 44, 34], [1, 44, 28], [1, 44, 22], [1, 44, 16], [1, 70, 55], [1, 70, 44], [2, 35, 17], [2, 35, 13], [1, 100, 80], [2, 50, 32], [2, 50, 24], [4, 25, 9], [1, 134, 108], [2, 67, 43], [2, 33, 15, 2, 34, 16], [2, 33, 11, 2, 34, 12], [2, 86, 68], [4, 43, 27], [4, 43, 19], [4, 43, 15], [2, 98, 78], [4, 49, 31], [2, 32, 14, 4, 33, 15], [4, 39, 13, 1, 40, 14], [2, 121, 97], [2, 60, 38, 2, 61, 39], [4, 40, 18, 2, 41, 19], [4, 40, 14, 2, 41, 15], [2, 146, 116], [3, 58, 36, 2, 59, 37], [4, 36, 16, 4, 37, 17], [4, 36, 12, 4, 37, 13], [2, 86, 68, 2, 87, 69], [4, 69, 43, 1, 70, 44], [6, 43, 19, 2, 44, 20], [6, 43, 15, 2, 44, 16], [4, 101, 81], [1, 80, 50, 4, 81, 51], [4, 50, 22, 4, 51, 23], [3, 36, 12, 8, 37, 13], [2, 116, 92, 2, 117, 93], [6, 58, 36, 2, 59, 37], [4, 46, 20, 6, 47, 21], [7, 42, 14, 4, 43, 15], [4, 133, 107], [8, 59, 37, 1, 60, 38], [8, 44, 20, 4, 45, 21], [12, 33, 11, 4, 34, 12], [3, 145, 115, 1, 146, 116], [4, 64, 40, 5, 65, 41], [11, 36, 16, 5, 37, 17], [11, 36, 12, 5, 37, 13], [5, 109, 87, 1, 110, 88], [5, 65, 41, 5, 66, 42], [5, 54, 24, 7, 55, 25], [11, 36, 12], [5, 122, 98, 1, 123, 99], [7, 73, 45, 3, 74, 46], [15, 43, 19, 2, 44, 20], [3, 45, 15, 13, 46, 16], [1, 135, 107, 5, 136, 108], [10, 74, 46, 1, 75, 47], [1, 50, 22, 15, 51, 23], [2, 42, 14, 17, 43, 15], [5, 150, 120, 1, 151, 121], [9, 69, 43, 4, 70, 44], [17, 50, 22, 1, 51, 23], [2, 42, 14, 19, 43, 15], [3, 141, 113, 4, 142, 114], [3, 70, 44, 11, 71, 45], [17, 47, 21, 4, 48, 22], [9, 39, 13, 16, 40, 14], [3, 135, 107, 5, 136, 108], [3, 67, 41, 13, 68, 42], [15, 54, 24, 5, 55, 25], [15, 43, 15, 10, 44, 16], [4, 144, 116, 4, 145, 117], [17, 68, 42], [17, 50, 22, 6, 51, 23], [19, 46, 16, 6, 47, 17], [2, 139, 111, 7, 140, 112], [17, 74, 46], [7, 54, 24, 16, 55, 25], [34, 37, 13], [4, 151, 121, 5, 152, 122], [4, 75, 47, 14, 76, 48], [11, 54, 24, 14, 55, 25], [16, 45, 15, 14, 46, 16], [6, 147, 117, 4, 148, 118], [6, 73, 45, 14, 74, 46], [11, 54, 24, 16, 55, 25], [30, 46, 16, 2, 47, 17], [8, 132, 106, 4, 133, 107], [8, 75, 47, 13, 76, 48], [7, 54, 24, 22, 55, 25], [22, 45, 15, 13, 46, 16], [10, 142, 114, 2, 143, 115], [19, 74, 46, 4, 75, 47], [28, 50, 22, 6, 51, 23], [33, 46, 16, 4, 47, 17], [8, 152, 122, 4, 153, 123], [22, 73, 45, 3, 74, 46], [8, 53, 23, 26, 54, 24], [12, 45, 15, 28, 46, 16], [3, 147, 117, 10, 148, 118], [3, 73, 45, 23, 74, 46], [4, 54, 24, 31, 55, 25], [11, 45, 15, 31, 46, 16], [7, 146, 116, 7, 147, 117], [21, 73, 45, 7, 74, 46], [1, 53, 23, 37, 54, 24], [19, 45, 15, 26, 46, 16], [5, 145, 115, 10, 146, 116], [19, 75, 47, 10, 76, 48], [15, 54, 24, 25, 55, 25], [23, 45, 15, 25, 46, 16], [13, 145, 115, 3, 146, 116], [2, 74, 46, 29, 75, 47], [42, 54, 24, 1, 55, 25], [23, 45, 15, 28, 46, 16], [17, 145, 115], [10, 74, 46, 23, 75, 47], [10, 54, 24, 35, 55, 25], [19, 45, 15, 35, 46, 16], [17, 145, 115, 1, 146, 116], [14, 74, 46, 21, 75, 47], [29, 54, 24, 19, 55, 25], [11, 45, 15, 46, 46, 16], [13, 145, 115, 6, 146, 116], [14, 74, 46, 23, 75, 47], [44, 54, 24, 7, 55, 25], [59, 46, 16, 1, 47, 17], [12, 151, 121, 7, 152, 122], [12, 75, 47, 26, 76, 48], [39, 54, 24, 14, 55, 25], [22, 45, 15, 41, 46, 16], [6, 151, 121, 14, 152, 122], [6, 75, 47, 34, 76, 48], [46, 54, 24, 10, 55, 25], [2, 45, 15, 64, 46, 16], [17, 152, 122, 4, 153, 123], [29, 74, 46, 14, 75, 47], [49, 54, 24, 10, 55, 25], [24, 45, 15, 46, 46, 16], [4, 152, 122, 18, 153, 123], [13, 74, 46, 32, 75, 47], [48, 54, 24, 14, 55, 25], [42, 45, 15, 32, 46, 16], [20, 147, 117, 4, 148, 118], [40, 75, 47, 7, 76, 48], [43, 54, 24, 22, 55, 25], [10, 45, 15, 67, 46, 16], [19, 148, 118, 6, 149, 119], [18, 75, 47, 31, 76, 48], [34, 54, 24, 34, 55, 25], [20, 45, 15, 61, 46, 16]], r.getRSBlocks = function (e, t) {
        var a = r.getRsBlockTable(e, t);
        if (null == a) throw Error("bad rs block @ typeNumber:" + e + "/errorCorrectLevel:" + t);
        for (var i = a.length / 3, s = [], o = 0; o < i; o++) for (var n = a[3 * o + 0], l = a[3 * o + 1], d = a[3 * o + 2], c = 0; c < n; c++) s.push(new r(l, d));
        return s
    }, r.getRsBlockTable = function (e, t) {
        switch (t) {
            case 1:
                return r.RS_BLOCK_TABLE[4 * (e - 1) + 0];
            case 0:
                return r.RS_BLOCK_TABLE[4 * (e - 1) + 1];
            case 3:
                return r.RS_BLOCK_TABLE[4 * (e - 1) + 2];
            case 2:
                return r.RS_BLOCK_TABLE[4 * (e - 1) + 3]
        }
    }, n.prototype = {
        get: function (e) {
            return 1 == (this.buffer[Math.floor(e / 8)] >>> 7 - e % 8 & 1)
        }, put: function (e, t) {
            for (var a = 0; a < t; a++) this.putBit(1 == (e >>> t - a - 1 & 1))
        }, getLengthInBits: function () {
            return this.length
        }, putBit: function (e) {
            var t = Math.floor(this.length / 8);
            this.buffer.length <= t && this.buffer.push(0), e && (this.buffer[t] |= 128 >>> this.length % 8), this.length++
        }
    }, "string" == typeof e && (e = {text: e}), e = i.extend({}, {
        render: "canvas",
        width: 256,
        height: 256,
        typeNumber: -1,
        correctLevel: 2,
        background: "#ffffff",
        foreground: "#000000"
    }, e), this.each((function () {
        var t;
        if ("canvas" == e.render) {
            (t = new s(e.typeNumber, e.correctLevel)).addData(e.text), t.make();
            var a = document.createElement("canvas");
            a.width = e.width, a.height = e.height;
            for (var o = a.getContext("2d"), r = e.width / t.getModuleCount(), n = e.height / t.getModuleCount(), l = 0; l < t.getModuleCount(); l++) for (var d = 0; d < t.getModuleCount(); d++) {
                o.fillStyle = t.isDark(l, d) ? e.foreground : e.background;
                var c = Math.ceil((d + 1) * r) - Math.floor(d * r),
                    p = Math.ceil((l + 1) * r) - Math.floor(l * r);
                o.fillRect(Math.round(d * r), Math.round(l * n), c, p)
            }
        } else for ((t = new s(e.typeNumber, e.correctLevel)).addData(e.text), t.make(), a = i("<table></table>").css("width", e.width + "px").css("height", e.height + "px").css("border", "0px").css("border-collapse", "collapse").css("background-color", e.background), o = e.width / t.getModuleCount(), r = e.height / t.getModuleCount(), n = 0; n < t.getModuleCount(); n++) for (l = i("<tr></tr>").css("height", r + "px").appendTo(a), d = 0; d < t.getModuleCount(); d++) i("<td></td>").css("width", o + "px").css("background-color", t.isDark(n, d) ? e.foreground : e.background).appendTo(l);
        t = a, jQuery(t).appendTo(this)
    }))
}
