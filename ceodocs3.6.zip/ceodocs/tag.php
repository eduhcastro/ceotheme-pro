<?php
get_header();
$bg = _ceo('tag-bg');

$tabType = $_GET['type'] ?? 1;

?>
<div class="ceo-tag-bg ceo-default-bg ceo-background-cover ceo-background-muted ceo-panel" style="background-image: url(<?php echo $bg; ?>)">
    <div class="ceo-container">
        <div class="top ceo-flex">
            <div class="title ceo-flex-1">
                <h1>#<?php single_tag_title(); ?></h1>
                <p>标签为 <em class="ceo-text-warning">#<?php single_tag_title(); ?></em> 的相关作品如下：</p>
            </div>
            <a href="/tags">更多热门标签<i class="ceofont ceoicon-arrow-right-s-line"></i></a>
        </div>
    </div>
</div>
<section class="ceo-default-list">
    <div class="ceo-container ceo-margin-medium-bottom">
	    <div class="default-box">
    	    <ul class="nav">
                <li <?php if ($tabType == 1) echo 'class="ceo-active"' ?>><a href="<?php echo home_url(add_query_arg(['type' => 1])) ?>">作品</a></li>
                <li <?php if ($tabType == 2) echo 'class="ceo-active"' ?>><a href="<?php echo home_url(add_query_arg(['type' => 2])) ?>">文章</a></li>
            </ul>
            
            <?php if ($tabType == 1): ?>
            <?php get_template_part( 'template-parts/default/tag', 'works' ); ?>
            <?php elseif ($tabType == 2): ?>
            <?php get_template_part( 'template-parts/default/tag', 'article' ); ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php get_footer(); ?>