<?php
    get_header();
?>
<div class="ceo-special-list">
    <?php
    $backgroud_img = '';
    $cate_background_img_arrs = get_term_meta(get_queried_object_id(), 'catf_background_img', 1);
    if ($cate_background_img_arrs && ! empty($cate_background_img_arrs['url'])) {
        $backgroud_img = $cate_background_img_arrs['url'];
    }
    ?>
    <div class="ceo-default-bg ceo-display-block ceo-cover-container ceo-overflow-hidden ceo-flex ceo-flex-center ceo-flex-middle">
        <img src="<?php echo $backgroud_img; ?>" ceo-cover/>
        <?php if(!$backgroud_img){?>
		<img src="<?php echo _ceo('special-bg-db'); ?>" ceo-cover/>
        <?php }?>
        <div class="ceo-container1280">
            <div class="title ceo-position-center ceo-text-center">
                <?php
                $term_current=get_term(get_queried_object_id());
                if($term_current){
                    echo "<h1>".$term_current->name."</h1>";
                    echo "<p>".$term_current->description."</p>";
                }
                ?>
            </div>
        </div>
    </div>
    <div class="ceo-container ceo-margin-medium-bottom">
    	<div class="waterfall">
    	    <ul class="ceo-child-width-1-2 ceo-child-width-1-5@s" ceo-grid="masonry: true">
        	    <?php
                $category = get_the_category();
                $term_id = get_queried_object_id();
                global $wp_query;
                $current_page = !empty($paged) ? $paged: get_query_var('paged');
        
                $wp_query = new WP_Query(
                    array(
                        'post_type'   => 'post',
                        'post_status' => 'publish',
                        'tax_query'   => array(
                            array(
                                'taxonomy' => 'special',
                                'field'    => 'term_id',
                                'terms'    => $term_id,
                            )
                        ),
                        'paged'=>$current_page
                    )
                );
                if ( have_posts() ) :  while ( have_posts() ) : the_post(); ?>
                <li>
        		<?php get_template_part( 'template-parts/loop/loop', 'works' ); ?>
        		</li>
        		<?php endwhile;endif; ?>
    		</ul>
    	</div>
        <div class="ceo-fanye">
        	<?php
            $args = array(
                'prev_next'          => 0,
                'format'       => '?paged=%#%',
                'before_page_number' => '',
                'mid_size'           => 2,
                'current' => max( 1, $current_page ),
                'prev_next'    => True,
                'prev_text'    => __('上一页'),
                'next_text'    => __('下一页'),
            );
            $page_arr=paginate_links($args);
            if ($page_arr) {
                echo $page_arr;
            }else{
    
            }
            ?>
        </div>
    </div>
</div>
<?php get_footer();?>