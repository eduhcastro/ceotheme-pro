<?php
$class_name = 'ceo-width-1-5@s';
$post_cat_id=get_queried_object_id();
if (get_term_meta($post_cat_id, 'ceo_category_list', 1) == 2) {
    $class_name = 'ceo-width-1-4@s';
}
?>
<?php get_template_part( 'template-parts/category/module/category', 'nav' ); ?>

<section class="ceo-container ceo-margin-medium-bottom">
    <div class="loop-5">
        <ul class="ceo-grid-ceosmls" ceo-grid>
        	<?php if ( have_posts() ) :  while ( have_posts() ) : the_post(); ?>
        	<li class="ceo-width-1-2 <?php echo $class_name; ?>">
        	<?php get_template_part( 'template-parts/loop/loop', '5' ); ?>
        	</li>
        	<?php endwhile;endif; ?>
    	</ul>
    </div>
    <?php ceo_fenye(); ?>
</section>