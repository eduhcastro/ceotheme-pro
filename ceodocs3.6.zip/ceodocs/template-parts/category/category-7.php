<section class="ceo-category-news">
    <div class="ceo-container1200">
        <div class="position ceo-visible@s">
    	    <?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
        </div>
        <div class="ceo-grid-ceosmls" ceo-grid>
        	<div class="ceo-width-1-1 ceo-width-7-0@s">
        	    <div class="module">
        		    <?php get_template_part( 'template-parts/category/module/category', 'slide' ); ?>
        		    <div class="ceo-background-default nav b-r-4">
                		<ul>
                		    <?php 
                                global $wp_query;
                                $cat_obj = $wp_query->get_queried_object();
                                $thisCat = $cat_obj->term_id;
                                $thisCat = get_category($thisCat);
                                $parentCat = get_category($thisCat->parent);
                                
                                $allLink = '';
                                if ($thisCat->parent == 0) {
                                    $allLink = get_category_link($thisCat->term_id);
                                } else {
                                    $allLink = get_category_link($parentCat->term_id);
                                }
                                
                                if ($thisCat->parent == 0):
                		    ?>
                		    <li class="cat-item-all current-cat"><a href="<?php echo $allLink ?>">全部</a></li>
                		    <?php else: ?>
                		    <li class="cat-item-all"><a href="<?php echo $allLink ?>">全部</a></li>
                		    <?php endif; ?>
                		   
                			<?php wp_list_categories('child_of=' . get_category_root_id($cat) . '&depth=1&hide_empty=0&hierarchical=1&optioncount=1&title_li='); ?>
                		</ul>
            		</div>
            		
            		<div class="loop-7">
            		    <ul class="ceo-background-default b-r-4">
                        	<?php if ( have_posts() ) :  while ( have_posts() ) : the_post(); ?>
                        	<?php get_template_part( 'template-parts/loop/loop', '7' ); ?>
                        	<?php endwhile;endif; ?>
                    	</ul>
                    </div>
                    <?php ceo_fenye(); ?>
                </div>
        	</div>
        	<?php get_sidebar(); ?>
        </div>
    </div>
</section>