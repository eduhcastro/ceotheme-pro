<?php
	$term = get_category(get_query_var('cat'));
	$btn_set = _ceo('ceo_cat_btn_set');
?>

<?php
$ceo_category_bg=get_term_meta($term->term_id,'ceo_category_bg',1);
if(!empty($ceo_category_bg['url'])) {
?>
<div class="ceo-category-bg ceo-background-cover" style="background-image: url(<?php echo $ceo_category_bg['url'];?>);">
<?php }elseif(_ceo('category_default_bg')){ ?>
<div class="ceo-category-bg ceo-background-cover" style="background-image: url(<?php echo _ceo('category_default_bg'); ?>);">
<?php }?>
    <div class="ceo-container">
        <div class="ceo-catnav-wz ceo-visible@s">
    	    <?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
        </div>
        <div class="title">
            <h1><?php single_cat_title(); ?></h1>
            <p><?php echo category_description();?></p>
        </div>
    </div>
</div>

<div class="ceo-category-box ceo-container">
    <div class="ceo-category-nav ceo-background-default">
        <?php if(_ceo('ceo_cat_top') == true ): ?>
    	<div class="data b-b">
    	    <div class="ceo-flex">
                <div class="ceo-flex-1">
                    <?php if(_ceo('ceo_cat_top_whole') == true ): ?>
                    <span><i class="ceofont ceoicon-copper-diamond-line"></i><?php single_cat_title(); ?>共 <em><?php echo get_cat_postcount($term->term_id); ?></em> 个作品<i class="ceofont ceoicon-arrow-up-line"></i></span>
                    <?php endif; ?>
                    <?php if(_ceo('ceo_cat_top_today') == true ): ?>
                    <span><i class="ceofont ceoicon-compass-3-line"></i>今日上传
                        <?php
                        $today = getdate();
                        $args = array(
                            'ignore_sticky_posts' => 1,
                            'posts_per_page' => -1,
                            'date_query' => array(
                                array(
                                    'year'  => $today["year"],
                                    'month' => $today["mon"],
                                    'day'   => $today["mday"],
                                ),
                            ),
                            'cat'=>get_queried_object_id()
                        );

                        $today_posts = new WP_Query( $args );
                        $count = $today_posts->post_count;

                        ?>
                        <em><?php echo $count;?></em> 个作品<i class="ceofont ceoicon-arrow-up-line"></i></span>
                    <?php endif; ?>
                </div>
                <div class="search">
                    <?php if(_ceo('ceo_cat_search') == true ): ?>
        			<form method="get" class="ceo-form ceo-position-relative" action="<?php bloginfo('url'); ?>">
        				<input type="search" placeholder="输入关键字搜索【<?php single_cat_title(); ?>】相关素材" autocomplete="off" value="" name="s" required="required" class="b-a ceo-input">
        				<input type="hidden" value="<?php echo get_queried_object_id(); ?>" name="cat" class="b-a ceo-input">
        				<button type="submit" class="ceo-position-center-right"><i class="ceofont ceoicon-search-2-line"></i></button>
        			</form>
        			<?php endif; ?>
        			<?php if(_ceo('ceo_cat_btn') == true ): ?>
        			<?php
						if ($btn_set) {
						foreach ( $btn_set as $key => $value) {
					?>
        			<a href="<?php echo $value['link'] ?>" class="ceo-visible@s"><i class="ceofont <?php echo $value['icon'] ?>"></i><?php echo $value['title'] ?><i class="ceofont ceoicon-arrow-right-line"></i></a>
        			<?php } } ?>
        			<?php endif; ?>
        		</div>
            </div>
        </div>
        <?php endif; ?>
        <?php if(_ceo('ceo_cat_nav') == true ): ?>
        <div class="ceo-grid-ceosmls" ceo-grid>
            <div class="ceo-width-auto">
    		    <strong><?php echo _ceo('ceo_cat_nav_title1'); ?>：</strong>
        	</div>
		    <div class="ceo-width-expand">
            	<ul>
            		<?php
                    $ceo_cat_nav_1_arrs=(array) _ceo('ceo_cat_nav_1');
                    $ceo_cat_nav_1=implode(' ',$ceo_cat_nav_1_arrs);
                    // $current_cat=get_queried_object_id();
                    $current_cat = get_category(get_query_var('cat'));
                    foreach ($ceo_cat_nav_1_arrs as $v) {
                        $term_v = get_term($v, 'category');
        
                        $current_cat_class=' ';
                        if ($current_cat->parent != 0) {
                            if($term_v->term_id == $current_cat->parent){
                                $current_cat_class=' current ';
                            }
                        } else {
                            if($term_v->term_id == $current_cat->term_id){
                                $current_cat_class=' current ';
                            } 
                        }
                        
                        if ($term_v) {
                            echo '<li class="cat-item cat-item-'.$term_v->term_id.' '.$current_cat_class.'"><a href="'.get_category_link($term_v->term_id).'">' . $term_v->name . '</a></li>';
                        }
                    }
            		?>
            	</ul>
    	    </div>
    	</div>
    	<?php endif; ?>
        <?php ceo_category_menu(); ?>
        <?php ceo_category_screen(); ?>
        <div class="ceo-grid-ceosmls ceo-margin-remove-top" ceo-grid>
            <div class="ceo-width-expand">
                <?php if(_ceo('ceo_cat_wss') == true ): ?>
        		<div class="ceo-catnav-ss">
                    <?php
                    $order_var = ! empty($_GET['order']) ? $_GET['order'] : '';
                    ?>
    		        <strong>排序：</strong>
                    <a class="hot n <?php if(empty($order_var)){echo 'current';} ?>" href="<?php echo get_category_link($cat) ?>">最新上传</a>
                    <a class="hot <?php if($order_var=='hot'){echo 'current';} ?>" href="<?php echo get_category_link($cat) ?>?order=hot">热门下载</a>
                    <a class="hot <?php if($order_var=='rand'){echo 'current';} ?>" href="<?php echo get_category_link($cat) ?>?order=rand">随机推荐</a>
        		</div>
        		<?php endif; ?>
        		<?php if(_ceo('ceo_cat_ss') == true ): ?>
        		<div class="ceo-catnav-ss">
        		    <strong>价格：</strong>
        		    <a class="<?php echo empty($_GET['filter_type_1']) && empty($_GET['filter_type_2']) && empty($_GET['filter_type_3']) && empty($_GET['filter_type_4']) ? 'current' : '' ?>" href="<?php echo get_category_link(get_queried_object_id()); ?>">全部</a>
					<a class="<?php echo $_GET['filter_type_1'] == 1 ? 'current' : '' ?>" href="<?php echo get_category_link(get_queried_object_id()); ?>?filter_type_1=1">免费</a>
					<a class="<?php echo $_GET['filter_type_2'] == 1 ? 'current' : '' ?>" href="<?php echo get_category_link(get_queried_object_id()); ?>?filter_type_2=1">收费</a>
					<a class="<?php echo $_GET['filter_type_3'] == 1 ? 'current' : '' ?>" href="<?php echo get_category_link(get_queried_object_id()); ?>?filter_type_3=1">VIP专属</a>
					<a class="<?php echo $_GET['filter_type_4'] == 1 ? 'current' : '' ?>" href="<?php echo get_category_link(get_queried_object_id()); ?>?filter_type_4=1">VIP免费</a>
    		    </div>
        		<?php endif; ?>
    		</div>
        </div>
	</div>
</div>