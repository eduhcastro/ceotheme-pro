<?php 
    $news_slide = _ceo('news_slide');
    $right1     = _ceo('news_slide_right1');
    $right2     = _ceo('news_slide_right2');
?>
<section class="news-slide ceo-background-default b-r-4">
	<div class="ceo-grid-ceosmls" ceo-grid>
		<div class="ceo-width-1-1 ceo-width-2-3@s">
			<div class="left ceo-position-relative ceo-visible-toggle" tabindex="-1" ceo-slideshow="autoplay: true">
			    <ul class="ceo-slideshow-items">
			    	<?php 
						if ($news_slide) { 
						foreach ( $news_slide as $key => $value) {
					?>
			        <li>
			            <a href="<?php echo $value['url']; ?>" target="_blank" class="ceo-height-1-1 ceo-cover-container ceo-display-block b-r-4">
			            	<img src="<?php echo $value['img']; ?>" alt="<?php echo $value['title']; ?>" ceo-cover />
			            </a>
			        </li>
			        <?php } } ?>
			    </ul>
			    <a class="ceo-position-center-left ceo-position-small ceo-hidden-hover" href="#" ceo-slidenav-previous ceo-slideshow-item="previous"></a>
                <a class="ceo-position-center-right ceo-position-small ceo-hidden-hover" href="#" ceo-slidenav-next ceo-slideshow-item="next"></a>
			    <ul class="slide-dotnav ceo-position-bottom-center ceo-slideshow-nav ceo-dotnav"></ul>
			</div>
		</div>
		<div class="ceo-width-1-1 ceo-width-1-3@s">
			<div class="right ceo-grid-ceosmls" ceo-grid>
			    <div class="ceo-width-1-2 ceo-width-1-1@s">
			    	<a href="<?php echo $right1['link'] ?>" target="_blank" class="ceo-display-block ceo-cover-container b-r-4">
			    	    <img src="<?php echo $right1['img'] ?>" alt="<?php echo $right1['title'] ?>" ceo-cover />
			        </a>
		    	</div>
			    <div class="ceo-width-1-2 ceo-width-1-1@s">
			    	<a href="<?php echo $right2['link'] ?>" target="_blank" class="ceo-display-block ceo-cover-container b-r-4">
			    	    <img src="<?php echo $right2['img'] ?>" alt="<?php echo $right2['title'] ?>" ceo-cover />
			        </a>
			    </div>
			</div>
		</div>
	</div>
</section>