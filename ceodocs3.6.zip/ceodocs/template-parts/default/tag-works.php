<?php
if(!empty($author)){
    $user_id=$author;
}
?>
<div class="waterfall">
	<?php
        //我的发布
        global $wp_query;
        $page=!empty(get_query_var('paged')) ?get_query_var('paged') :1;
        $wp_query = new WP_Query(
            array(
                'post_type'      => 'post',
                'posts_per_page' => get_option( 'posts_per_page' ),
                'post_status'    => 'publish',
                'tag' => single_tag_title('', false),
                'paged' => $page,
                'meta_query' => array(
                    array(
                        'key' => 'ceo_shop_type',
                        'value' => 'close',
                        'compare' => '!=',
                    ),
                ),
            )
        );
        if(have_posts()) : ?>
            <ul class="ceo-child-width-1-2 ceo-child-width-1-5@s" ceo-grid="masonry: true">
            <?php while (have_posts()) : the_post(); ?>
            <li><?php get_template_part( 'template-parts/loop/loop', 'works' ); ?></li>
            <?php endwhile; ?>
            </ul>
        <?php else: ?>
        	<div class="ceo-default-nocontent">
        	    <i></i>
        	    <p>没有找到相关内容~</p>
            </div>
        <?php endif; ?>
</div>
<?php ceo_fenye(); ?>