<?php $banner_set = _ceo('ceo_foo_banner_set') ?>
<?php if(_ceo('ceo_foo_banner') == true ): ?>
<?php if (_ceo('ceo_foo_banner_display')!='index' || (is_home() && _ceo('ceo_foo_banner_display')=='index') ) { ?>
<div class="ceo-footer-banner" style="background-image: url(<?php echo $banner_set['bg'] ?>)">
	<div class="ceo-container">
    	<div class="box">
        	<span><?php echo $banner_set['title'] ?></span>
        	<p><?php echo $banner_set['desc'] ?></p>
        	<?php foreach($banner_set['btn'] as $p) : ?>
            <a href="<?php echo $p['link'] ?>" target="_blank"><?php echo $p['title'] ?></a>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php } ?>
<?php endif; ?>

<div class="ceo-footer-ctrl">
	<div class="ceo-container">
	    <div class="ceo-grid-collapse" ceo-grid>
	        <div class="ceo-width-1-1 ceo-width-expand@s">
	            <div class="menu">
                    <?php
					$foot_menu = _ceo('foot_menu');
					if(!$foot_menu){
						echo '<p><i class="ceofont ceoicon-error-warning-fill ceo-margin-small-right"></i>请前往后台<i class="ceofont ceoicon-arrow-right-s-line"></i>主题设置<i class="ceofont ceoicon-arrow-right-s-line"></i>底部设置，设置该模块内容！</p>';
					}else {
						if ($foot_menu) {
							foreach ( $foot_menu as $key => $value) {
					?>
					<li><a href="<?php echo $value['link'] ?>" target="_blank"><?php echo $value['title'] ?></a></li>
					<?php } } } ?>
				</div>
            </div>
            <div class="ceo-width-1-1 ceo-width-auto@s ceo-visible@s">
	            <span>来不及找到心仪的内容？按<em>Ctrl</em>+<em>D</em>收藏本站</span>
            </div>
        </div>
    </div>
</div>