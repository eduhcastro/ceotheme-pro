<?php 
    $activity_set = _ceo('ceo_follow_activity_set');
    $vip_set      = _ceo('ceo_follow_vip_set');
    $sign_set     = _ceo('ceo_follow_sign_set');
    $lottery_set     = _ceo('ceo_follow_lottery_set');
    $service_set  = _ceo('ceo_follow_service_set');
    $service_up   = _ceo('ceo_follow_service_up');
    $phone_set    = _ceo('ceo_follow_phone_set');
    $float_set    = _ceo('ceo_float_set');
?>
<?php if(_ceo('ceo_follow') == true): ?>
<div class="gotop ceo-animation-slide-bottom-small ceo-visible@s">
    <div class="gotop-box ceo-background-default">
        <?php if(_ceo('ceo_follow_activity') == true): ?>
        <div class="gotop-item activity">
            <a href="<?php echo $activity_set['link'] ?>">
                <img src="<?php echo $activity_set['bg'] ?>" alt="activity" class="a1">
                <img src="<?php echo $activity_set['img'] ?>" alt="activity" class="a2">
                <div class="popover" style="background: url(<?php echo $activity_set['upimg'] ?>) no-repeat center/cover;"></div>
            </a>
        </div>
        <?php endif; ?>
        
        <?php if(_ceo('ceo_follow_vip') == true): ?>
        <div class="gotop-item gotop-vip">
            <a href="<?php echo $vip_set['link'] ?>" class="ceo-display-block">
                <img src="<?php echo $vip_set['img'] ?>" alt="<?php echo $vip_set['title'] ?>">
                <p class="text"><?php echo $vip_set['title'] ?></p>
            </a>
        </div>
        <?php endif; ?>
        
        <?php if(_ceo('ceo_follow_sign') == true): ?>
        <div class="gotop-item">
            <?php if( is_user_logged_in() ){ ?>
            <a href="javascript:void(0)" class="btn-ceo-sign ceo-sign member-sign ceo-display-block">
            <?php }else{ ?>
            <a href="#navbar-login" class="ceo-display-block" ceo-toggle>
            <?php } ?>
                <img src="<?php echo $sign_set['img'] ?>" alt="<?php echo $sign_set['title'] ?>">
                <p class="text"><?php echo $sign_set['title'] ?></p>
            </a>
        </div>
        <?php endif; ?>
        
        <?php if(_ceo('ceo_follow_lottery') == true): ?>
        <div class="gotop-item">
            <?php if( is_user_logged_in() ){ ?>
            <a href="javascript:void(0)" class="btn-ceo-lottery ceo-display-block">
            <?php }else{ ?>
            <a href="#navbar-login" class="ceo-display-block" ceo-toggle>
            <?php } ?>
                <i class="ceofont <?php echo $lottery_set['icon'] ?>"></i>
                <p class="text"><?php echo $lottery_set['title'] ?></p>
            </a>
        </div>
        <?php endif; ?>
    
        <?php if(_ceo('ceo_follow_service') == true): ?>
    	<div class="gotop-item gotop-service">
    	    <i class="ceofont <?php echo $service_set['icon'] ?>"></i>
    	    <p class="text"><?php echo $service_set['title'] ?></p>
    	    <div class="gotop-service-box ceo-background-default">
                <div class="tops">
                    <img src="<?php echo $service_up['img'] ?>" alt="<?php echo $service_up['qqtitle'] ?>">
                    <a href="<?php echo $service_up['qq'] ?>" class="topsqq" rel="noreferrer nofollow"><?php echo $service_up['qqtitle'] ?></a>
                    <p><?php echo $service_up['time'] ?></p>
                </div>
                
                <div class="gotop-wx-box">
                    <div class="boxs">
                        <p><?php echo $service_up['wetitle'] ?></p>
                        <img src="<?php echo $service_up['weimg'] ?>" alt="<?php echo $service_up['wetitle'] ?>">
                    </div>
                </div>
                
                <div class="btms">
                    <em><?php echo $service_up['phonetitle'] ?></em>
                    <p><?php echo $service_up['phone'] ?></p>
                    <em><?php echo $service_up['mailtitle'] ?></em>
                    <span><?php echo $service_up['mail'] ?></span>
                </div>
            </div>
        </div>
    	<?php endif; ?>
        
    	<?php if(_ceo('ceo_follow_phone') == true): ?>
    	<div class="gotop-item gotop-ma">
    	    <i class="ceofont <?php echo $phone_set['icon'] ?>"></i>
    	    <p class="text"><?php echo $phone_set['btntitle'] ?></p>
    	    <div class="gotop-ma-box">
    	        <i></i>
                <div class="tops">
                    <p><?php echo $phone_set['title'] ?></p>
                    <p><?php echo $phone_set['subtitle'] ?></p>
                    <img src="<?php echo $phone_set['img'] ?>" alt="<?php echo $phone_set['title'] ?>"/>
                </div>
                <em></em>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="gotop-item gotops" id="gotops">
            <a href="#header" class="ceo-display-block" ceo-scroll>
                <img src="<?php bloginfo('template_url'); ?>/static/images/ceo-follow-gotop.png" alt="TOP">
                <p>TOP</p>
            </a>
        </div>
    </div>
</div>
<?php endif; ?>
<div class="ceo-app-gotop gotops ceo-hidden@s" id="gotops">
    <a href="#header" class="ceo-display-block" ceo-scroll>
        <i class="ceofont ceoicon-arrow-up-s-line"></i>
    </a>
</div>

<?php if(_ceo('ceo_float') == true): ?>
<div class="ceo-float ceo-visible@s">
    <a href="<?php echo $float_set['link'] ?>" target="_blank">
        <img src="<?php echo $float_set['img'] ?>" alt="<?php echo $float_set['title'] ?>">
    </a>
</div>
<?php endif; ?>