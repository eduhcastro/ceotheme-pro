<?php echo _ceo('diy_js'); ?>
<script>
    console.log("\n %c \u603b\u88c1\u4e3b\u9898 V3.6 %c \u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0077\u0077\u0077\u002e\u0063\u0065\u006f\u0074\u0068\u0065\u006d\u0065\u002e\u0063\u006f\u006d \n\n", "color: #fff; background: #3371f5; padding:5px 0;", "background: #3371f5; padding:5px 0;");
</script>

<!--弹窗搜索-->
<div id="mobSearch" class="ceo-search-dialog" ceo-modal>
    <div class="ceo-modal-dialog ceo-modal-body ceo-margin-auto-vertical">
		<button class="ceo-modal-close-default ceo-modal-close" type="button" ceo-close></button>
        <div class="title">搜索</div>
        <div class="search">
			<form method="get" class="ceo-form ceo-flex ceo-overflow-hidden ceo-position-relative" action="<?php bloginfo('url'); ?>">
				<input type="search" placeholder="输入关键字搜索" autocomplete="off" value="" name="s" required="required" class="b-a b-r-4 ceo-input ceo-flex-1">
				<button type="submit" class="ceo-position-center-right"><i class="ceofont ceoicon-search-2-line"></i></button>
			</form>
		</div>
		<div class="item ceo-margin-top">
			<p class="ceo-margin-small-bottom ceo-text-small">热门标签</p>
		    <?php wp_tag_cloud('number=8&orderby=count&order=DESC&smallest=12&largest=12&unit=px'); ?>
		</div>
    </div>
</div>
<!--导航弹窗-->
<div id="mobNav" ceo-offcanvas>
    <div class="ceo-offcanvas-bar ceo-background-default ceo-box-shadow-small ceo-mobNav-box">
        <div class="mobSide">
            <div class="ceo-text-center ceo-margin-small-bottom">
                <a href="<?php bloginfo('url'); ?>" class="logo ceo-display-inline-block ceo-margin-bottom">
                    <img src="<?php echo _ceo('head_logo'); ?>" alt="<?php bloginfo('name'); ?>"/>
                </a>
            </div>
            <div class="mobNav">
    		    <ul class="ceo-margin-remove ceo-padding-remove ceo-text-center">
    		        <?php ceo_menu('main-nav'); ?>
    		    </ul>
    		</div>
        </div>
    </div>
</div>