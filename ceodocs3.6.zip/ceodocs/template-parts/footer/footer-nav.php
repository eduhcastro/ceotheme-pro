<?php $foo_set = _ceo('ceo_app_foo_set') ?>
<div class="ceo-app-footer-fixed ceo-app-footer ceo-hidden@s">
    <a href="<?php echo $foo_set['link1'] ?>">
        <i class="ceofont <?php echo $foo_set['ico1'] ?>"></i>
        <span class="text"><?php echo $foo_set['title1'] ?></span>
    </a>
    <a href="<?php echo $foo_set['link2'] ?>">
        <i class="ceofont <?php echo $foo_set['ico2'] ?>"></i>
        <span class="text"><?php echo $foo_set['title2'] ?></span>
    </a>
    <a  href="<?php echo $foo_set['middlelink'] ?>" class="vip">
        <i class="ceofont <?php echo $foo_set['middleicon'] ?>"></i>
        <em><?php echo $foo_set['middletitle'] ?></em>
    </a>
    <a href="<?php echo $foo_set['linky1'] ?>">
        <i class="ceofont <?php echo $foo_set['icoy1'] ?>"></i>
        <span class="text"><?php echo $foo_set['titley1'] ?></span>
    </a>
    <a href="<?php echo $foo_set['linky2'] ?>">
        <i class="ceofont <?php echo $foo_set['icoy2'] ?>"></i>
        <span class="text"><?php echo $foo_set['titley2'] ?></span>
    </a>
</div>