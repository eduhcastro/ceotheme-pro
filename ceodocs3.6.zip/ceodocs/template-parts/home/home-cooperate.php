<?php
$cooperate_box = _ceo('ceo_home_cooperate_box');
?>
<!--首页合作模块-->
<div class="ceo-home-cooperate ceo-background-default">
    <div class="ceo-container">
        <div class="title">
        	<span><?php echo _ceo('ceo_home_cooperate_title') ?></span>
        </div>
        <div class="box">
            <div ceo-slider="autoplay: true;autoplay-interval: 3000;">
                <div class="ceo-position-relative">
                    <div class="ceo-slider-container ceo-light">
                        <ul class="ceo-slider-items ceo-child-width-1-3 ceo-child-width-1-6@s ceo-grid-zhiershi ceo-grid">
                            <?php
                    		if ($cooperate_box) {
                    			foreach ( $cooperate_box as $key => $value) {
                    		?>
                            <li>
                                <a href="<?php echo $cooperate_box[$key]['url']; ?>" target="_blank" class="ceo-display-block">
                                    <img src="<?php echo $cooperate_box[$key]['img']; ?>" alt="<?php echo $cooperate_box[$key]['title']; ?>">
                                </a>
                            </li>
                            <?php } } ?>
                        </ul>
                    </div>
            
                    <div class="ceo-hidden@s ceo-light">
                        <a class="ceo-position-center-left ceo-position-small" href="#" ceo-slidenav-previous ceo-slider-item="previous"></a>
                        <a class="ceo-position-center-right ceo-position-small" href="#" ceo-slidenav-next ceo-slider-item="next"></a>
                    </div>
            
                    <div class="ceo-visible@s">
                        <a class="ceo-position-center-left-out ceo-position-small" href="#" ceo-slidenav-previous ceo-slider-item="previous"></a>
                        <a class="ceo-position-center-right-out ceo-position-small" href="#" ceo-slidenav-next ceo-slider-item="next"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>