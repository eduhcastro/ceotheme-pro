<?php
	$infinite = _ceo('infinite');
?>
<?php
	if ($infinite) {
		foreach ( $infinite as $key => $value) {
?>
<!--首页无限分类模块-->
<div class="ceo-home-infinite">
    <div class="ceo-container">
        <span class="title">
            <?php
				if(!$value['title']){
					echo get_cat_name( $value['id'] );
				}else {
					echo $value['title'];
				}
			?>
        </span>
        <div class="more">
            <a href="<?php echo get_category_link($value['id']); ?>" target="_blank">查看全部<i class="ceofont ceoicon-arrow-right-s-line"></i></a>
        </div>

        <ul class="ceo-subnav-pill ceo-infinite-title" ceo-switcher="animation: ceo-animation-fade">
		    <li><a href="#">
    		        <?php
        				if(!$value['title']){
        					echo get_cat_name( $value['id'] );
        				}else {
        					echo $value['title'];
        				}
        			?>
		        </a>
	        </li>
            <?php
            $cat_arrs   = $value['licat'];
            if(empty($cat_arrs)){
                $cat_arrs=[];
            }
            foreach ($cat_arrs as $v) {
                $term_v = get_term($v);
                if (is_null($term_v)) {
                    continue;
                }
                ?>
                <li><a href="#"><?php echo $term_v->name; ?></a></li>
            <?php }?>
        </ul>

        <ul class="ceo-switcher ceo-margin">
            <li>
			    <div class="ceo-grid-ceosmls" ceo-grid>
                    <?php query_posts('cat='.$value['id'] .'&showposts='.$value['num'] ); ?>
    			    <?php while (have_posts()) : the_post(); ?>

                    <?php
                        if ($value['list'] == 1) {
                            $class_infinite_num = 'ceo-width-1-5@s';
                        } else {
                            $class_infinite_num = 'ceo-width-1-4@s';
                        }
                    ?>
                	<div class="ceo-width-1-2 <?php echo $class_infinite_num; ?>">
                	    <?php
        				$index_card_style = $value['index_card_style'];
        				if( $index_card_style == '1' ){ ?>
		                <div class="loop-1">
            			<?php get_template_part( 'template-parts/loop/loop', '1' );?>
                        </div>
            			<?php } elseif( $index_card_style == '2' ) { ?>
            			<div class="loop-2">
            			<?php get_template_part( 'template-parts/loop/loop', '2' );?>
            			</div>
            			<?php } elseif( $index_card_style == '3' ) { ?>
            			<div class="loop-3">
            			<?php get_template_part( 'template-parts/loop/loop', '3' );?>
            			</div>
            			<?php } elseif( $index_card_style == '4' ) { ?>
            			<div class="loop-4">
            			<?php get_template_part( 'template-parts/loop/loop', '4' );?>
            			</div>
            			<?php } elseif( $index_card_style == '5' ) { ?>
            			<div class="loop-5">
            			<?php get_template_part( 'template-parts/loop/loop', '5' );?>
            			</div>
            			<?php } elseif( $index_card_style == '6' ) { ?>
            			<div class="loop-6">
            			<?php get_template_part( 'template-parts/loop/loop', '6' );?>
            			</div>
            			<?php } ?>
                	</div>
                	<?php endwhile; wp_reset_query(); ?>
                </div>
            </li>

            <?php
            if(empty($cat_arrs)){
                $cat_arrs=[];
            }
            foreach ($cat_arrs as $v) {
            $term_v = get_term($v);
             if (is_null($term_v)) {
                    continue;
                }
            ?>
            <li>
			    <div class="ceo-grid-ceosmls" ceo-grid>
                    <?php
                    global $wp_query;
                    $wp_query = new WP_Query(
                        array(
                            'cat' => $term_v->term_id,
                            'post_type' => 'post',
                            'post_status' => 'publish',
                            'order' => 'DESC',
                            'orderby' => 'date',
                            'posts_per_page' => $value['num'],
                        )
                    );
                    if ( have_posts() ) :  while ( have_posts() ) : the_post(); ?>
                    <?php
                    if ($value['list'] == 1) {
                        $class_infinite_num = 'ceo-width-1-5@s';
                    } else {
                        $class_infinite_num = 'ceo-width-1-4@s';
                    }
                    ?>
                    <div class="ceo-width-1-2 <?php echo $class_infinite_num; ?>">
                        <?php
        				$index_card_style = $value['index_card_style'];
        				if( $index_card_style == '1' ){ ?>
		                <div class="loop-1">
            			<?php get_template_part( 'template-parts/loop/loop', '1' );?>
                        </div>
            			<?php } elseif( $index_card_style == '2' ) { ?>
            			<div class="loop-2">
            			<?php get_template_part( 'template-parts/loop/loop', '2' );?>
            			</div>
            			<?php } elseif( $index_card_style == '3' ) { ?>
            			<div class="loop-3">
            			<?php get_template_part( 'template-parts/loop/loop', '3' );?>
            			</div>
            			<?php } elseif( $index_card_style == '4' ) { ?>
            			<div class="loop-4">
            			<?php get_template_part( 'template-parts/loop/loop', '4' );?>
            			</div>
            			<?php } elseif( $index_card_style == '5' ) { ?>
            			<div class="loop-5">
            			<?php get_template_part( 'template-parts/loop/loop', '5' );?>
            			</div>
            			<?php } elseif( $index_card_style == '6' ) { ?>
            			<div class="loop-6">
            			<?php get_template_part( 'template-parts/loop/loop', '6' );?>
            			</div>
            			<?php } ?>
                    </div>
                    <?php endwhile;endif; ?>
                </div>
            </li>
            <?php }?>
        </ul>
        <?php if ($value['img_switch']) { ?>
        <div class="img-box">
            <?php
                if ($value['img_radio'] == 1) {
                    $num = 'ceo-child-width-1-2@s';
                } elseif($value['img_radio'] == 2) {
                    $num = 'ceo-child-width-1-3@s';
                } elseif($value['img_radio'] == 3) {
                    $num = 'ceo-child-width-1-4@s';
                }
            ?>
            <div class="ceo-child-width-1-1 <?php echo $num; ?> ceo-grid-ceosmls" ceo-grid>
                <?php 
					 if ( $value['img_set'] ) {
						foreach ( $value['img_set'] as $k => $v) {
				?>
                <div class="img-module">
                    <a href="<?php echo $v['img_url']; ?>" target="_blank" class="ceo-display-block ceo-cover-container">
                        <img src="<?php echo $v['img_images']; ?>" alt="<?php echo $v['img_title']; ?>" ceo-cover>
                    </a>
                </div>
                <?php } } ?>
            </div>
        </div>
        <?php } ?>
    </div>
</div>
<?php } } ?>