<!--首页友链模块-->
<div class="ceo-home-link ceo-background-default">
    <div class="ceo-container">
        <div class="rec">
            <ul class="hd">
                <li class="active">友情链接</li>
                <?php if(_ceo('ceo_home_new') == true): ?>
                <li class="">最新发布</li>
                <?php endif; ?>
                <?php if(_ceo('ceo_home_tag') == true): ?>
                <li class="">热门标签</li>
                <?php endif; ?>
            </ul>
            <div class="bd">
                <div style="display: list-item;">
                    <?php $wp_list_bookmarks=wp_list_bookmarks('title_li=&echo=0');
                    echo preg_replace('#<img src="(.*?)"  alt="(.*?)".*?/>#', "$2", $wp_list_bookmarks);
        			?>
        			<li><a href="<?php echo _ceo('ceo_home_link_url'); ?>" target="_blank" rel="noreferrer nofollow">友链申请+</a></li>
                </div>
                <?php if(_ceo('ceo_home_new') == true): ?>
                <div style="display: none;">
                    <?php
                        $args = array(
                            'post_type' => 'post',
                            'posts_per_page' => _ceo('ceo_home_new_num'),
                            'orderby' => 'date',
                            'order' => 'DESC',
                        );
                        
                        $query = new WP_Query($args);
                        if ($query->have_posts()) {
                            while ($query->have_posts()) {
                                $query->the_post();
                    ?>
                    <li><a href="<?php the_permalink() ?>" target="_blank"><?php the_title() ?></a></li>
                    <?php 
                            }
                        } 
                        wp_reset_postdata();
                    ?>
                </div>
                <?php endif; ?>
                <?php if(_ceo('ceo_home_tag') == true): ?>
                <div style="display: none;">
                    <?php 
                        $tags = wp_tag_cloud('number=50&orderby=count&order=DESC&smallest=12&largest=14&unit=px&echo=0');
                        $tags = preg_replace('/<a(.*?)>(.*?)<\/a>/', '<li><a$1>$2</a></li>', $tags);
                        echo $tags;
                    ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>