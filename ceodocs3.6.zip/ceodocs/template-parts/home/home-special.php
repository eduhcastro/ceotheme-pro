<!--首页专题模块-->
<div class="ceo-home-special">
    <div class="ceo-container">
        <div class="title ceo-flex">
            <span class="ceo-flex-1"><?php echo _ceo('ceo_home_special_title'); ?></span>
            <div class="more">
                <a href="<?php echo _ceo('ceo_home_special_url'); ?>" target="_blank">查看全部<i class="ceofont ceoicon-arrow-right-s-line"></i></a>
            </div>
        </div>
        <div class="box">
            <div ceo-slider>
                <div class="ceo-position-relative">
                    <div class="box ceo-slider-container ceo-light">
                        <ul class="ceo-slider-items ceo-child-width-1-2 ceo-child-width-1-5@s ceo-grid-ceosmls ceo-grid">
                            <?php
                        		$args=array(
                        			'taxonomy' => 'special',
                        			'hide_empty'=>'0',
                        			'hierarchical'=>1,
                        			'parent'=>'0',
                        			'number'=>'10',
                        			'orderby'=>'date',
                        			'order'=>'desc',
                        		);
                        		$categories=get_categories($args);
                        		foreach($categories as $category){
                        			$cat_id = $category->term_id;
            
                                    $backgroud_img = '';
                                    $cate_background_img_arrs = get_term_meta($cat_id, 'cate_background_img', 1);
                                    if ($cate_background_img_arrs && ! empty($cate_background_img_arrs['url'])) {
                                        $backgroud_img = $cate_background_img_arrs['url'];
                                    }
                        	?>
                            <li>
                                <a href="<?php echo get_category_link( $category->term_id )?>" target="_blank" class="url">
                                    <img src="<?php echo $backgroud_img; ?>" alt="<?php echo $category->name;?>">
                                </a>
                            </li>
                            <?php }?>
                        </ul>
                    </div>
                    <div class="ceo-hidden@s ceo-light">
                        <a class="ceo-position-center-left ceo-position-small" href="#" ceo-slider-item="previous"><i class="ceofont ceoicon-arrow-left-s-line"></i></a>
                        <a class="ceo-position-center-right ceo-position-small" href="#" ceo-slider-item="next"><i class="ceofont ceoicon-arrow-right-s-line"></i></a>
                    </div>
                    <div class="ceo-visible@s">
                        <a class="ceo-position-center-left-out ceo-position-small" href="#" ceo-slider-item="previous"><i class="ceofont ceoicon-arrow-left-s-line"></i></a>
                        <a class="ceo-position-center-right-out ceo-position-small" href="#" ceo-slider-item="next"><i class="ceofont ceoicon-arrow-right-s-line"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>