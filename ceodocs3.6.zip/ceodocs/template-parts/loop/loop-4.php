<?php 
	$post_id =  get_the_ID();
	$my_post_video_options=get_post_meta(get_the_ID(),'list_video_url',1);
    $post_has_video = ! empty($my_post_video_options) ? true : false;
	$ceo_category_height = get_term_meta(get_queried_object_id(), 'ceo_category_height', 1);
    if(!empty($ceo_category_height['height'])){
        $cat_height_css='padding-bottom:'.$ceo_category_height['height'].'%';
    }
?>
<div class="loop-4-box ceo-background-default">
    <div class="loop-4-box-img">
        
    	<a href="<?php the_permalink(); ?>" <?php echo _target_blank();?> class="thumb post-video ceo-display-block ceo-overflow-hidden <?php if($post_has_video)echo 'post-has-video ' ?>" style="<?php echo $cat_height_css;?>">
            <?php
                if(!empty($my_post_video_options)){
                    echo '<span></span>';
                    echo '<video autoplay="autoplay" loop="loop" data-src="'.$my_post_video_options.'" src="" style="display: none;" ceo-cover></video>';
                }
            ?>
            <img data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" src="<?php echo get_template_directory_uri().'/static/images/thumb-card.gif'; ?>" class="lazyload show-image" ceo-cover>
    	</a>
	</div>
    <div class="content ceo-position-bottom">
        <h2 class="ceo-text-truncate">
            <?php if (_ceo('ceo_cat_vip') == true && _ceo('ceo_shop_whole') && CeoShopCoreProduct::hasVipFree($post_id)) : ?>
    	    <?php if (get_current_user_id() > 0 || _ceo('ceo_shop_tourist')) : ?>
    	    <span class="vip"></span>
    	    <?php endif; ?>
    	    <?php endif; ?>
            <a href="<?php the_permalink(); ?>" <?php echo _target_blank();?> title="<?php the_title(); ?>"><?php the_title(); ?></a>
        </h2>
    </div>
</div>