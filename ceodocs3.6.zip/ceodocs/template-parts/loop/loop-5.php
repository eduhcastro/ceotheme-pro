<?php 
	$post_id =  get_the_ID();
	$audio_url=get_post_meta(get_the_ID(),'audio_url',1);
    $post_has_video = ! empty($audio_url) ? true : false;
?>
<div class="loop-5-box">
	<div class="loop-5-box-img">
	    <a href="<?php the_permalink(); ?>" post-id="<?php echo get_the_ID();?>" <?php echo _target_blank();?> video-data="<?php echo $audio_url;?>" class="ceo-music-cat post-audio ceo-display-block ceo-overflow-hidden <?php if($post_has_video)echo 'post-has-video ' ?>">
	        <div class="views"><i class="ceofont ceoicon-eye-line"></i><?php post_views('', ''); ?></div>
	        <audio id="player-<?php echo get_the_ID();?>" class="audio-play" autoplay="autoplay" preload="none" src=""></audio>
            <div class="audio-pan ceo-position-center ceo-text-center">
                <img id="audioplayer" class="play-icon" src="<?php echo get_template_directory_uri();?>/static/images/play.png">
                <img class="play-dot" src="<?php echo get_template_directory_uri();?>/static/images/zhen-btn.png">
                <img class="play-zhen" src="<?php echo get_template_directory_uri();?>/static/images/zhen.png">
                <img class="play-pan" src="<?php echo get_template_directory_uri();?>/static/images/pan.png">
            </div>
        </a>
    </div>
    <div class="loop-5-box-btm">
    	<h2 class="ceo-text-truncate">
    	    <?php if (_ceo('ceo_cat_vip') == true && _ceo('ceo_shop_whole') && CeoShopCoreProduct::hasVipFree($post_id)) : ?>
    	    <?php if (get_current_user_id() > 0 || _ceo('ceo_shop_tourist')) : ?>
    	    <span class="vip"></span>
    	    <?php endif; ?>
    	    <?php endif; ?>
    	    <a href="<?php the_permalink() ?>" <?php echo _target_blank();?>><?php the_title(); ?></a>
	    </h2>
    </div>
</div>