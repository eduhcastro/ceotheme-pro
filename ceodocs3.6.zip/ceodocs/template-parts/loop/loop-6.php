<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" <?php echo _target_blank();?> class="loop-6-box ceo-background-default">
	<div class="top">
	    <div class="thumb ceo-display-block ceo-cover-container">
	        <img data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" src="<?php echo get_template_directory_uri().'/static/images/thumb-card.gif'; ?>" class="lazyload" ceo-cover>
        </div>
    </div>
    <div class="bottom">
	    <div class="info"><?php echo soft_score_output(get_post_down_info_by_key('评分')); ?></div>
	    <h2 class="ceo-text-truncate"><?php the_title(); ?></h2>
	    <em><i class="ceofont ceoicon-arrow-right-line"></i></em>
        <div class="ceo-flex">
            <span class="ceo-flex-1"><?php the_time('Y-m-d') ?></span>
            <span><?php echo get_post_down_info_by_key('大小'); ?></span>
        </div>
    </div>
</a>