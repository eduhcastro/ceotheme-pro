<?php 
	$post_id =  get_the_ID();
?>
<li class="loop-7-box">
    <div class="ceo-grid-ceosmls" ceo-grid>
    	<div class="ceo-width-auto left">
    		<a href="<?php the_permalink(); ?>" <?php echo _target_blank();?> class="thumb ceo-display-block ceo-cover-container">
    			<img data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" src="<?php echo get_template_directory_uri().'/static/images/thumb-card.gif'; ?>" class="lazyload" ceo-cover>
    		</a>
    	</div>
    	<div class="ceo-width-expand right">
    		<h2><a href="<?php the_permalink(); ?>" <?php echo _target_blank();?> class="ceo-display-block ceo-text-truncate" title="<?php the_title(); ?>">
    		    <?php if (is_sticky()): //置顶文章 ?>
    		    <div class="tag">顶</div>
                <?php endif; ?>
                <?php if(get_post_meta( get_the_ID(), 'ceo-tese-tag', true )){?>
    		    <div class="tag">
    		        <?php echo get_post_meta( get_the_ID(), 'ceo-tese-tag', true );?>
    		    </div>
    		    <?php }?>
                <?php the_title(); ?>
            </a></h2>
    		<p class="desc"><?php echo wp_trim_words( get_the_content(), 30 ); ?></p>
    		<div class="loop-7-info">
                <div class="ceo-flex">
                    <div class="ceo-flex-1">
                		<?php if(_ceo('ceo_cat_tx') == true ): ?>
                        <div class="avatar">
                		<?php echo get_avatar(get_the_author_meta( 'ID' ), 20); ?>
                		</div>
                		<?php endif; ?>
                		<?php if(_ceo('ceo_cat_mc') == true ): ?>
                		<span class="name"><?php the_author_posts_link(); ?></span>
                		<?php endif; ?>
                    	<?php if(_ceo('ceo_cat_fl') == true ): ?>
                        <?php
                        	$category = get_the_category();
                        	if($category[0]){
                        		echo '<a class="category" target="_blank" href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';
                        	}
                        ?>
                        <?php endif; ?>
                	</div>
                	<div class="y">
                        <?php if(_ceo('ceo_cat_rq') == true ): ?>
                    	<span class="ceo-visible@s"><i class="ceofont ceoicon-time-line"></i><?php the_time('Y-m-d') ?></span>
                    	<?php endif; ?>
                    	<?php if(_ceo('ceo_cat_dz') == true ): ?>
                    	<span class="ceo-visible@s"><i class="ceofont ceoicon-heart-2-line"></i><?php echo ($dot_good=get_post_meta($post->ID, 'like', true)) ? $dot_good : '0'; ?></span>
                    	<?php endif; ?>
                    	<?php if(_ceo('ceo_cat_ll') == true ): ?>
                    	<span><i class="ceofont ceoicon-eye-line"></i><?php post_views('', ''); ?></span>
                    	<?php endif; ?>
                	</div>
                </div>
            </div>
    	</div>
	</div>
</li>