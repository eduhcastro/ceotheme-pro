<?php 
	$post_id =  get_the_ID();
?>
<div class="item ceo-background-default">
	<div class="top">
	    <?php if(get_post_meta( get_the_ID(), 'ceo-tese-tag', true )){?>
	    <div class="tese">
	        <?php echo get_post_meta( get_the_ID(), 'ceo-tese-tag', true );?>
	    </div>
	    <?php }?>
    	<a href="<?php the_permalink() ?>" <?php echo _target_blank();?> class="thumb ceo-display-block ceo-cover-container">
    		<img data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" src="<?php echo get_template_directory_uri().'/static/images/thumb-card.gif'; ?>" class="lazyload" ceo-cover>
        </a>
        <div class="category ceo-position-bottom ceo-flex">
            <?php
            	$category = get_the_category();
            	if($category[0]){
            		echo '<a class="ceo-flex-1" target="_blank" href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';
            	}
            ?>
        	<span><i class="iconfont icon-rili"></i><?php the_time('Y-m-d') ?></span>
    	</div>
    </div>
    <div class="bottom">
    	<h2><a href="<?php the_permalink() ?>" <?php echo _target_blank();?> class="title" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
    	<div class="info ceo-flex">
    	    <div class="ceo-flex-1">
            	<div class="avatarimg"><?php echo get_avatar(get_the_author_meta( 'ID' ), 20); ?></div>
        		<span><?php the_author_posts_link(); ?></span>
    		</div>
            <div class="views"><i class="ceofont ceoicon-eye-line"></i><?php post_views('', ''); ?></span>
        </div>
    </div>
</div>