<?php 
	$post_id =  get_the_ID();
?>
<div class="waterfall-box">
	<div class="waterfall-box-img">
	    <?php if (_ceo('ceo_cat_vip') == true && _ceo('ceo_shop_whole') && CeoShopCoreProduct::hasVipFree($post_id)) : ?>
	    <?php if (get_current_user_id() > 0 || _ceo('ceo_shop_tourist')) : ?>
	    <span class="vip"></span>
	    <?php endif; ?>
	    <?php endif; ?>
	    <div class="btn">
    	    <a href="<?php echo home_url(user_trailingslashit('tougao')); ?>?post=<?php echo get_the_ID(); ?>&amp;action=edit" class="collection edit">编辑</a>
	    </div>
	    <a href="<?php the_permalink() ?>" <?php echo _target_blank();?> class="thumb ceo-display-block">
	        <img data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" src="<?php echo get_template_directory_uri().'/static/images/thumb-card.gif'; ?>" class="lazyload">
        </a>
    </div>
    <div class="content ceo-position-bottom">
	    <h2 class="ceo-text-truncate"><a href="<?php the_permalink(); ?>" <?php echo _target_blank();?> title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
    </div>
</div>