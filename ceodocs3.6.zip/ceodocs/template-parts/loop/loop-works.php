<?php 
	$post_id =  get_the_ID();
?>
<div class="waterfall-box">
	<div class="waterfall-box-img">
	    <?php if (_ceo('ceo_cat_vip') == true && _ceo('ceo_shop_whole') && CeoShopCoreProduct::hasVipFree($post_id)) : ?>
	    <?php if (get_current_user_id() > 0 || _ceo('ceo_shop_tourist')) : ?>
	    <span class="vip"></span>
	    <?php endif; ?>
	    <?php endif; ?>
	    <div class="btn">
    	    <?php if(get_post_meta( get_the_ID(), 'down_demourl', true )){?>
    	    <a href="<?php echo get_post_meta( get_the_ID(), 'down_demourl', true );?>" target="_blank" class="demo" ceo-tooltip="title: 演示; pos: bottom"><i class="ceofont ceoicon-computer-line"></i></a>
    	    <?php }?>
    	    <?php if(_ceo('ceo_cat_collection') == true ): ?>
    	    <a href="javascript:void(0)" class="collection add-collection-front" data-id="<?php echo $post_id ?>" ceo-tooltip="title: 收藏; pos: bottom"><i class="ceofont ceoicon-star-line"></i></a>
    	    <?php endif; ?>
	    </div>
	    <a href="<?php the_permalink() ?>" <?php echo _target_blank();?> class="thumb ceo-display-block">
            <span class="down"><i class="ceofont ceoicon-download-line"></i><?php echo _ceo('ceo_cat_down_title'); ?></span>
	        <img data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" src="<?php echo get_template_directory_uri().'/static/images/thumb-card.gif'; ?>" class="lazyload">
        </a>
    </div>
    <div class="content ceo-position-bottom">
	    <h2 class="ceo-text-truncate"><a href="<?php the_permalink(); ?>" <?php echo _target_blank();?> title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
    </div>
</div>