<?php
$logo_group = _ceo('navbar_logo_group_set');
$whole = _ceo('navbar_whole_set');
$info = _ceo('navbar_info_set');
$vip = _ceo('navbar_vip_set');
$delivery = _ceo('navbar_delivery_set');
?>
<header class="navBar navBar_02 navBar_01 navBar_01_c ceo-visible@s" ceo-sticky>
    <div class="fat"></div>
	<div class="navBar-box ceo-flex ceo-flex-middle">
	    <div class="ceo-logo">
    		<a href="<?php bloginfo('url'); ?>" class="logo ceo-display-block">
    			<img src="<?php echo _ceo('head_logo'); ?>" alt="<?php bloginfo('name'); ?>">
    		</a>
    		<?php if (_ceo('logo_website')) : ?>
    		<i class="website"></i>
    		<?php endif; ?>
		</div>
		<?php if (_ceo('navbar_logo_group')) : ?>
	    <div class="desc">
    		<a href="<?php echo $logo_group['link'] ?>" class="more"><i class="ceofont <?php echo $logo_group['icon'] ?>"></i><?php echo $logo_group['title'] ?></a>
    		<div class="box ceo-animation-slide-bottom-small">
		        <div class="boxmk">
		            <div class="title"><?php echo $logo_group['module'] ?></div>
		            <ul>
		                <?php foreach($logo_group['btn'] as $p) : ?>
                        <li>
        		            <a href="<?php echo $p['link'] ?>">
                                <div class="img"><img src="<?php echo $p['img'] ?>" alt="<?php echo $p['title'] ?>"></div>
                                <p><?php echo $p['title'] ?></p>
                            </a>
                        </li>
                        <?php endforeach; ?>
                   </ul>
                   <div class="descx"><i class="ceofont ceoicon-lightbulb-flash-line"></i><?php echo $logo_group['desc'] ?></div>
	            </div>
	        </div>
		</div>
		<?php endif; ?>
		<?php if (_ceo('navbar_whole')) : ?>
		<div class="whole">
            <span class="title"><i class="iwhole"></i><?php echo _ceo('navbar_whole_title'); ?><i class="hot"></i></span>
	        <div class="drop ceo-animation-slide-bottom-small">
	            <div class="box">
	                <?php 
                        if ($whole) { 
                        foreach ( $whole as $key => $value) {
                    ?>
    	            <div class="drop-item">
    	                <div class="item-left">
    	                    <img src="<?php echo $value['img']; ?>" alt="<?php echo $value['antitle']; ?>">
    	                    <a target="_blank" href="<?php echo $value['anlink']; ?>"><?php echo $value['antitle']; ?></a>
                        </div>
                        <ul>
                            <?php 
    							 if ( $value['group'] ) {
								foreach ( $value['group'] as $k => $v) {
    						?>
                            <li><a href="<?php echo $v['link']; ?>" target="_blank"><?php echo $v['title']; ?></a></li>
                            <?php } } ?>
                        </ul>
                    </div>
                    <?php } } ?>
                </div>
	        </div>
	    </div>
		<?php endif; ?>
		
		<div class="nav ceo-flex-1 ceo-visible@s">
		    <ul class="ceo-navbar-ul ceo-padding-remove">
		        <?php ceo_menu('main-nav'); ?>
		    </ul>
		</div>

		<?php if(_ceo('navbar_search') == true): ?>
		<div class="navBar_search ceo-visible@s">
		    <div class="search ceo-visible@s">
    		    <form method="get" class="ceo-form ceo-flex ceo-overflow-hidden ceo-position-relative" action="<?php bloginfo('url'); ?>">
    				<input type="search" placeholder="输入关键字搜索" autocomplete="off" value="" name="s" required="required" class="ceo-input ceo-flex-1">
    				<button type="submit" class="ceo-position-center-right"><i class="ceofont ceoicon-search-2-line"></i></button>
    			</form>
    		</div>
		</div>
		<?php endif; ?>

	    <?php if (_ceo('navbar_info')) : ?>
	    <div class="navBar_info">
	        <a href="<?php echo $info['link'] ?>" class="huodong"><i></i><?php echo $info['title'] ?></a>
	        <div class="box ceo-animation-slide-bottom-small">
	            <div class="nav-info-temp">
	                <?php foreach($info['btn'] as $p) : ?>
                    <li>
                        <a href="<?php echo $p['link'] ?>"><img src="<?php echo $p['img'] ?>" alt="<?php echo $p['title'] ?>"></a>
                    </li>
                    <?php endforeach; ?>
                </div>
            </div>
	    </div>
		<?php endif; ?>

		<?php if (_ceo('navbar_vip')) : ?>
		<div class="navBar_vip ceo-visible@s">
		    <a href="<?php echo $vip['link'] ?>" class="vip"><i></i><?php echo $vip['title'] ?></a>
		    <div class="box ceo-animation-slide-bottom-small">
	            <div class="nav-vip-temp">
                    <div class="nav-vip-title">
                        <span><?php echo $vip['moduletitle'] ?></span>
                    </div>
                    <p class="nav-vip-subtitle"><?php echo $vip['moduledesc'] ?></p>
                    <ul>
                        <?php foreach($vip['group'] as $p) : ?>
                        <li>
                            <img src="<?php echo $p['img'] ?>" alt="<?php echo $p['title'] ?>">
                            <span><?php echo $p['title'] ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    <div class="nav-vip-btn">
                        <a href="<?php echo $vip['btnlink'] ?>">
                            <i></i>
                            <span><?php echo $vip['btntitle'] ?></span>
                            <em><?php echo $vip['btndesc'] ?></em>
                        </a>
                    </div>
                </div>
            </div>
	    </div>
		<?php endif; ?>

	    <?php if (_ceo('navbar_delivery')) : ?>
	    <div class="navBar_delivery">
	        <a href="<?php echo $delivery['link'] ?>" class="tougao"><i class="ceofont <?php echo $delivery['icon'] ?>"></i><?php echo $delivery['title'] ?></a>
	    </div>
		<?php endif; ?>

		<?php if(_ceo('navbar_user') == true): ?>
		<div class="ceo-visible@s">
		    <?php get_template_part( 'template-parts/navbar/navbar', 'user' ); ?>
		</div>
		<?php endif; ?>
	</div>
</header>
<style>
.ceo-home-slide1 {
    margin-top: -100px;
}
@media screen and (max-width: 900px){
    .ceo-home-slide1 {
        margin-top: -61px;
    }
}
</style>
<?php get_template_part( 'template-parts/navbar/navbar', 'app' ); ?>