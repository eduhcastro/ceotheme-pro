<header class="ceo-app-navbar ceo-background-default ceo-hidden@s" ceo-sticky>
	<div class="module ceo-container ceo-flex ceo-flex-middle">
	    <div class="left">
    	    <a href="<?php bloginfo('url'); ?>" class="logo ceo-display-block">
    			<img src="<?php echo _ceo('head_logo'); ?>" alt="<?php bloginfo('name'); ?>"/>
    		</a>
		</div>
		<div class="right">
            <?php if(_ceo('navbar_search') == true): ?>
    		<div class="search">
    		    <a ceo-toggle="target: #mobSearch"><i class="ceofont ceoicon-search-2-line"></i></a>
    		</div>
    		<?php endif; ?>
    		<div class="cat">
        		<a onclick="showNavClick()">
                    <i class="ceofont ceoicon-menu-line"></i>
                </a>
            </div>
    		<?php if(_ceo('navbar_user') == true): ?>
            <?php get_template_part( 'template-parts/navbar/navbar', 'user' ); ?>
            <?php endif; ?>
        </div>
	</div>
</header>
<script>
    var showNav = false;
    function showNavClick()
    {
        if (!showNav) {
            UIkit.offcanvas('#mobNav').show();
            showNav = true;
        } else {
            UIkit.offcanvas('#mobNav').hide();
            showNav = false;
        }
    }
</script>