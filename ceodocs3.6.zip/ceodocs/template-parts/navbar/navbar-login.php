<?php
    $login = _ceo('login_set');
    $slide = _ceo('login_slide');
?>
<div id="navbar-login" class="ceo-navbar-login ceo-flex-top" ceo-modal>
    <div class="ceo-modal-dialog ceo-modal-body ceo-margin-auto-vertical">
        <button class="ceo-modal-close-default ceo-modal-close" type="button" ceo-close></button>
        <div class="ceo-grid-collapse" ceo-grid>
            <div class="ceo-width-1-1 ceo-width-1-2@s ceo-visible@m">
                <div class="left">
                    <?php 
                        $loginHeight = 389;
                        if (_ceo('qq_login') || _ceo('is_oauth_mpweixin') || _ceo('weixin_login') || _ceo('weibo_login')) {
                            $loginHeight = 509;
                        }
                    ?>
                    <div class="ceo-position-relative ceo-visible-toggle ceo-light" tabindex="-1" ceo-slideshow="min-height: <?php echo $loginHeight ?>; autoplay: true">
                        <ul class="ceo-slideshow-items">
                            <?php 
        						if ($slide) { 
        						foreach ( $slide as $key => $value) {
        					?>
        			        <li>
        			            <a href="<?php echo $value['url']; ?>" target="_blank" class="ceo-display-block" style="background-image: url(<?php echo $value['img']; ?>)">
        			            </a>
        			        </li>
        			        <?php } } ?>
                        </ul>
                        <a class="ceo-position-center-left ceo-position-small ceo-hidden-hover" href="#" ceo-slidenav-previous ceo-slideshow-item="previous"></a>
                        <a class="ceo-position-center-right ceo-position-small ceo-hidden-hover" href="#" ceo-slidenav-next ceo-slideshow-item="next"></a>
                        <ul class="ceo-slideshow-nav ceo-dotnav ceo-flex-center"></ul>
                    </div>
                </div>
            </div>
            <div class="ceo-width-1-1 ceo-width-1-2@s">
                <div class="right ceo-background-default">
                    <form action="" method="POST" id="login-form" class="login-weixin">
                        <div class="title">账号登录</div>
            		    <div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
            		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-user-line"></i></span>
            			    <input type="text" id="username" class="b-r-4 ceo-input" name="username" placeholder="请输入账号/邮箱" required="required">
            			</div>
            			<div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
            			    <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-keyhole-line"></i></span>
            			    <input type="password" id="password" class="b-r-4 ceo-input" name="password" placeholder="请输入密码" required="required">
            			</div>
            			<div class="desc ceo-flex ceo-margin-bottom">
                    		<p class="ceo-flex-1"><a class="forget" href="/wp-login.php?action=lostpassword">忘记密码？</a></p>
                    		<?php if(_ceo('sms_login')):?>
                            <p><a href="#navbar-registersms" class="registersms" ceo-toggle>手机登录/注册</a></p>
                            <?php endif;?>
                		</div>
            
                        <div class="ceotheme-tips ceo-margin ceo-text-danger"></div>
            			<input type="hidden" name="action" value="zongcai_login">
            			<button class="login-button ceo-button b-r-4 ceo-width-1-1 button mid dark ceo-display-block">立即登录</button>
            		</form>
            		<?php if(_ceo('qq_login') || _ceo('is_oauth_mpweixin') || _ceo('weixin_login') || _ceo('weibo_login')){?>
            		<div class="socialize">
        		        <div class="title">
        		            <em></em>
        		            <span>其他登录方式</span>
        		            <em></em>
        	            </div>
        	            <div class="type">
                            <?php if(_ceo('qq_login')){?>
                        	<a href="javascript:;" class="button mid qq half qq_login_button ceo_qq_login" ceo-tooltip="QQ登录"><i class="ceofont ceoicon-qq-fill"></i></a>
                        	<?php }?>
                        	<?php if(_ceo('is_oauth_mpweixin')){?>
                        	<a href="<?php echo esc_url(home_url('/oauth/mpweixin')); ?>" class="mpweixin_login_button btn change-color social-login button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="关注微信公众号登录"><i class="ceofont ceoicon-wechat-fill"></i></a>
                            <?php }elseif(_ceo('weixin_login')){?>
                        	<a href="<?php echo esc_url(home_url('/oauth/'.'weixin'.'?rurl='.home_url(add_query_arg(array())))); ?>" class="btn change-color social-login button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="微信登录"><i class="ceofont ceoicon-wechat-fill"></i></a>
                            <?php }?>
                        	<?php if(_ceo('weibo_login')){?>
                        	<a href="<?php echo weibo_oauth_url();?>" class="ceo_weibo_login" ceo-tooltip="微博登录"><i class="ceofont ceoicon-weibo-fill"></i></a>
                        	<?php }?>
                    	</div>
                    </div>
                    <?php }?>
                </div>
                <div class="bottom">
        		    <div class="ceo-flex">
        		    登录即同意<a href="<?php echo $login['link'] ?>" target="_blank" class="ceo-flex-1"><?php echo $login['title'] ?></a>没有账号？ <a href="#navbar-register" ceo-toggle>立即注册</a>
        		    </div>
        		</div>
            </div>
        </div>
    </div>
</div>

<div id="navbar-register" class="ceo-navbar-login ceo-flex-top" ceo-modal>
    <div class="ceo-modal-dialog ceo-modal-body ceo-margin-auto-vertical">
        <button class="ceo-modal-close-default ceo-modal-close" type="button" ceo-close></button>
        <div class="ceo-grid-collapse" ceo-grid>
            <div class="ceo-width-1-1 ceo-width-1-2@s ceo-visible@m">
                <div class="left">
                    <?php 
                        $registerheight = 519;
                        if (_ceo('qq_login') || _ceo('is_oauth_mpweixin') || _ceo('weixin_login') || _ceo('weibo_login')) {
                            $registerheight = 639;
                        }
                    ?>
                    <div class="ceo-position-relative ceo-visible-toggle ceo-light" tabindex="-1" ceo-slideshow="min-height: <?php echo $registerheight ?>; autoplay: true">
                        <ul class="ceo-slideshow-items">
                            <?php 
        						if ($slide) { 
        						foreach ( $slide as $key => $value) {
        					?>
        			        <li>
        			            <a href="<?php echo $value['url']; ?>" target="_blank" class="ceo-display-block" style="background-image: url(<?php echo $value['img']; ?>)">
        			            </a>
        			        </li>
        			        <?php } } ?>
                        </ul>
                        <a class="ceo-position-center-left ceo-position-small ceo-hidden-hover" href="#" ceo-slidenav-previous ceo-slideshow-item="previous"></a>
                        <a class="ceo-position-center-right ceo-position-small ceo-hidden-hover" href="#" ceo-slidenav-next ceo-slideshow-item="next"></a>
                        <ul class="ceo-slideshow-nav ceo-dotnav ceo-flex-center"></ul>
                    </div>
                </div>
            </div>
            <div class="ceo-width-1-1 ceo-width-1-2@s">
                <div class="right ceo-background-default">
                    <form action="" method="POST" id="register-form" class="login-weixin">
                        <div class="title">账号注册</div>
            		    <div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
            		        <span class="ceo-form-icon"><i class="ceofont ceoicon-mail-line"></i></span>
                			<input type="email" id="email_address2" class="b-r-4 ceo-input" name="email_address2" placeholder="请输入邮箱" required="required">
            			</div>
            			<div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
            		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-user-line"></i></span>
            			    <input type="text" id="username2" class="b-r-4 ceo-input" name="username2" placeholder="请输入账号(英文/数字)" required="required">
            			</div>
            			<div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
            		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-keyhole-line"></i></span>
            			    <input type="password" id="password2" class="b-r-4 ceo-input" name="password2" placeholder="请输入密码" required="required">
            			</div>
            			<div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
            		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-keyhole-line"></i></span>
            			    <input type="password" id="repeat_password2" class="b-r-4 ceo-input" name="repeat_password2" placeholder="请再次输入密码" required="required">
                        </div>
                		<div class="agreen ceo-margin-bottom">
                            <input id="agreement" name="agreen" type="checkbox" required>
                            <label for="agreen"></label>
                            我已阅读并同意<a href="<?php echo $login['link'] ?>" target="_blank"><?php echo $login['title'] ?></a>
                        </div>
            
                        <div class="ceotheme-tips ceo-margin ceo-text-danger"></div>
            			<input type="hidden" name="action" value="zongcai_register">
            			<input type="hidden" name="ref" value="<?php echo $_GET['ref'] ?>">
            			<button class="login-button ceo-button b-r-4 ceo-width-1-1 button mid dark">立即注册</button>
            		</form>
            		<?php if(_ceo('qq_login') || _ceo('is_oauth_mpweixin') || _ceo('weixin_login') || _ceo('weibo_login')){?>
            		<div class="socialize">
        		        <div class="title">
        		            <em></em>
        		            <span>其他登录方式</span>
        		            <em></em>
        	            </div>
        	            <div class="type">
                            <?php if(_ceo('qq_login')){?>
                        	<a href="javascript:;" class="button mid qq half qq_login_button ceo_qq_login" ceo-tooltip="QQ登录"><i class="ceofont ceoicon-qq-fill"></i></a>
                        	<?php }?>
                        	<?php if(_ceo('is_oauth_mpweixin')){?>
                        	<a href="<?php echo esc_url(home_url('/oauth/mpweixin')); ?>" class="mpweixin_login_button btn change-color social-login button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="关注微信公众号登录"><i class="ceofont ceoicon-wechat-fill"></i></a>
                            <?php }elseif(_ceo('weixin_login')){?>
                        	<a href="<?php echo esc_url(home_url('/oauth/'.'weixin'.'?rurl='.home_url(add_query_arg(array())))); ?>" class="btn change-color social-login button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="微信登录"><i class="ceofont ceoicon-wechat-fill"></i></a>
                            <?php }?>
                        	<?php if(_ceo('weibo_login')){?>
                        	<a href="<?php echo weibo_oauth_url();?>" class="ceo_weibo_login" ceo-tooltip="微博登录"><i class="ceofont ceoicon-weibo-fill"></i></a>
                        	<?php }?>
                    	</div>
                    </div>
                	<?php }?>
                </div>
                <div class="bottom">
        		    <div class="ceo-flex">
        		    注册即同意<a href="<?php echo $login['link'] ?>" target="_blank" class="ceo-flex-1"><?php echo $login['title'] ?></a>已有账号？ <a href="#navbar-login" ceo-toggle>立即登录</a>
        		    </div>
        		</div>
            </div>
        </div>
    </div>
</div>

<?php if(_ceo('sms_login')):?>
<div id="navbar-registersms" class="ceo-navbar-login ceo-flex-top" ceo-modal>
    <div class="ceo-modal-dialog ceo-modal-body ceo-margin-auto-vertical">
        <button class="ceo-modal-close-default ceo-modal-close" type="button" ceo-close></button>
        <div class="ceo-grid-collapse" ceo-grid>
            <div class="ceo-width-1-1 ceo-width-1-2@s ceo-visible@m">
                <div class="left">
                    <?php 
                        $registersmsheight = 389;
                        if (_ceo('qq_login') || _ceo('is_oauth_mpweixin') || _ceo('weixin_login') || _ceo('weibo_login')) {
                            $registersmsheight = 509;
                        }
                    ?>
                    <div class="ceo-position-relative ceo-visible-toggle ceo-light" tabindex="-1" ceo-slideshow="min-height: <?php echo $registersmsheight ?>; autoplay: true">
                        <ul class="ceo-slideshow-items">
                            <?php 
        						if ($slide) { 
        						foreach ( $slide as $key => $value) {
        					?>
        			        <li>
        			            <a href="<?php echo $value['url']; ?>" target="_blank" class="ceo-display-block" style="background-image: url(<?php echo $value['img']; ?>)">
        			            </a>
        			        </li>
        			        <?php } } ?>
                        </ul>
                        <a class="ceo-position-center-left ceo-position-small ceo-hidden-hover" href="#" ceo-slidenav-previous ceo-slideshow-item="previous"></a>
                        <a class="ceo-position-center-right ceo-position-small ceo-hidden-hover" href="#" ceo-slidenav-next ceo-slideshow-item="next"></a>
                        <ul class="ceo-slideshow-nav ceo-dotnav ceo-flex-center"></ul>
                    </div>
                </div>
            </div>
            <div class="ceo-width-1-1 ceo-width-1-2@s">
                <div class="right ceo-background-default">
                    <form action="" method="POST" id="login-form" class="login-weixin">
                        <div class="title">手机登录/注册</div>
                        <div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
                            <span class="ceo-form-icon"><i class="ceofont ceoicon-smartphone-line"></i></span>
                            <input type="number" name="user_mobile" id="user_mobile" class="b-r-4 ceo-input" placeholder="请输入手机号" required="required">
                        </div>
                        <div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
                            <div class="ceo-grid-small" ceo-grid>
                                <div class="ceo-width-3-5">
                                    <span class="ceo-form-icon"><i class="ceofont ceoicon-newspaper-line"></i></span>
                                    <input type="text" name="captcha" id="captcha" placeholder="请输入验证码" class="b-r-4 ceo-input" value="">
                                </div>
                                <div class="ceo-width-2-5">
                                    <span class="input-group-btn">
                                        <script>var is_sms_login=true</script>
                                        <button class="go-captcha_mobile b-r-4 button mid dark ceo-button ceo-button-default ceo-width-1-1" type="button"
                                                        data-smstype="login" data-nonce="<?php echo wp_create_nonce('captcha_mobile'); ?>">发送验证码</button>
                                    </span>
                                </div>
                            </div>
                        </div>
            			<div class="desc ceo-flex ceo-margin-bottom">
                    		<p class="ceo-flex-1"><a class="forget" href="/wp-login.php?action=lostpassword">忘记密码？</a></p>
                            <p><a href="#navbar-login" class="registersms" ceo-toggle>账号密码登录</a></p>
                		</div>
            
                        <div class="ceotheme-tips ceo-margin ceo-text-danger"></div>
            			<div class="ceo-flex-middle ceo-margin-top">
                            <input type="hidden" name="action" value="zongcai_login_sms">
                            <button class="login-button ceo-button b-r-4 ceo-width-1-1 button mid dark ceo-display-block">登录/注册</button>
                        </div>
            		</form>
            		<?php if(_ceo('qq_login') || _ceo('is_oauth_mpweixin') || _ceo('weixin_login') || _ceo('weibo_login')){?>
            		<div class="socialize">
        		        <div class="title">
        		            <em></em>
        		            <span>其他登录方式</span>
        		            <em></em>
        	            </div>
        	            <div class="type">
                            <?php if(_ceo('qq_login')){?>
                        	<a href="javascript:;" class="button mid qq half qq_login_button ceo_qq_login" ceo-tooltip="QQ登录"><i class="ceofont ceoicon-qq-fill"></i></a>
                        	<?php }?>
                        	<?php if(_ceo('is_oauth_mpweixin')){?>
                        	<a href="<?php echo esc_url(home_url('/oauth/mpweixin')); ?>" class="mpweixin_login_button btn change-color social-login button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="关注微信公众号登录"><i class="ceofont ceoicon-wechat-fill"></i></a>
                            <?php }elseif(_ceo('weixin_login')){?>
                        	<a href="<?php echo esc_url(home_url('/oauth/'.'weixin'.'?rurl='.home_url(add_query_arg(array())))); ?>" class="btn change-color social-login button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="微信登录"><i class="ceofont ceoicon-wechat-fill"></i></a>
                            <?php }?>
                        	<?php if(_ceo('weibo_login')){?>
                        	<a href="<?php echo weibo_oauth_url();?>" class="ceo_weibo_login" ceo-tooltip="微博登录"><i class="ceofont ceoicon-weibo-fill"></i></a>
                        	<?php }?>
                    	</div>
                    </div>
                    <?php }?>
                </div>
                <div class="bottom">
        		    <div class="ceo-flex">
        		    登录即同意<a href="<?php echo $login['link'] ?>" target="_blank" class="ceo-flex-1"><?php echo $login['title'] ?></a>没有账号？ <a href="#navbar-register" ceo-toggle>立即注册</a>
        		    </div>
        		</div>
            </div>
        </div>
    </div>
</div>
<?php endif;?>

<script>
    function is_in_weixin() {
        return "micromessenger" == navigator.userAgent.toLowerCase().match(/MicroMessenger/i)
    }

    $(".login-form .mpweixin_login_button,.login-form .mpweixin_login_button").on("click", function(e) {
        setTimeout(function (){
            UIkit.modal('#navbar-login').show();
        },500)
    });
    $(document).on("click", ".mpweixin_login_button", function(e) {
        e.preventDefault();
        var t = $(this)
            , a = t.html();
        if (is_in_weixin())
            return window.location.href = t.attr("href"),
                !0;
        $.post(ceotheme.ajaxurl, {
            action: "get_mpweixin_qr"
        }, function(e) {
            if (1 == e.status) {
                $("#navbar-login").find('form').html('<img class="login-weixin-img" src="' + e.ticket_img + '"><p class="login-weixin-p">请使用微信扫码关注登录</p>');
                $("#navbar-register").find('form').html('<img class="login-weixin-img" src="' + e.ticket_img + '"><p class="login-weixin-p">请使用微信扫码关注登录</p>');
                var n = setInterval(function() {
                    $.post(ceotheme.ajaxurl, {
                        action: "check_mpweixin_qr",
                        scene_id: e.scene_id
                    }, function(e) {
                        1 == e.status && (clearInterval(n),
                            UIkit.notification('扫码成功，即将登录', { status: 'success' }),
                            window.location.reload())
                    })
                }, 5e3)
            } else
                alert(e.ticket_img);
            t.html(a)
        })
    });
</script>

<?php
if (_ceo('sms_send_verify') == true) {
    if (_ceo('sms_send_verify_type') == '1') {
        echo tencent_captcha_load();
        echo '<script>var verify_sms_send = 1</script>';
    }
    if (_ceo('sms_send_verify_type') == '2') {
        ?>
        <script src="https://v-cn.vaptcha.com/v3.js"></script>
        <script>
            var vaptchaFirstInit = false;
            window.vaptcha_obj = vaptcha({
                vid: '<?php echo _ceo('vaptcha_vid');?>',
                mode: 'invisible',
                scene: 0,
                area: 'cn',
            }).then(function () {
                vaptchaFirstInit = true
            })
        </script>
        <?php
        echo '<script>var verify_sms_send = 2</script>';
    }
} else {
    echo '<script>var verify_sms_send = 0</script>';
}
?>

<?php
if (_ceo('login_verify') == true) {
    if (_ceo('login_verify_type') == '1') {
        echo tencent_captcha_load();
        echo '<script>var verify_ceo_login = 1</script>';
    }
    if (_ceo('login_verify_type') == '2') {
        ?>
        <script src="https://v-cn.vaptcha.com/v3.js"></script>
        <script>
            if (typeof vaptchaFirstInit === "undefined") {
                var vaptchaFirstInit = true
            }
            window.vaptchaInit = setInterval(function () {
                if (vaptchaFirstInit) {
                    clearInterval(window.vaptchaInit)
                     window.vaptcha_obj = vaptcha({
                        vid: '<?php echo _ceo('vaptcha_vid');?>',
                        mode: 'invisible',
                        scene: 0,
                        area: 'cn',
                    })
                }
            }, 500)
        </script>
        <?php
        echo '<script>var verify_ceo_login = 2</script>';
    }
} else {
    echo '<script>var verify_ceo_login = 0</script>';
}
?>