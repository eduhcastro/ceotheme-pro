<style>
    <?php echo _ceo('diy_css'); ?>
    :root {
    	--primary-color: <?php echo _ceo('ceo_color'); ?>;
    	--shallow-color: <?php echo _ceo('ceo_color_shallow'); ?>;
    }
</style>