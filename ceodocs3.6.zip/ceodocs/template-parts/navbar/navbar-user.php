<?php
    if( is_user_logged_in() ){
        global $current_user;
        $user_id = get_current_user_id();
    	$current_user = wp_get_current_user();
    	$authorID = $current_user->ID;
?>
<div class="navbar-user ceo-position-relative">
	<a href="<?php echo home_url(user_trailingslashit('/member/center')); ?>" class="ceo-display-block ceo-border-circle ceo-overflow-hidden ceo-margin-left">
    	<?php echo get_avatar( $user_id , 38 ); ?>
	</a>
	<div class="dropdown ceo-animation-slide-bottom-small">
	    <div class="boxs">
	        <div class="dropdown-box">
                <div class="user-warp ceo-flex ceo-flex-middle">
                    <div class="ceo-border-circle ceo-overflow-hidden"><?php echo get_avatar( $user_id , 45 ); ?></div>
                    <div class="user-name ceo-text-bold"><?php echo $current_user->display_name; ?></div>
                    <span class="role"><?php echo CeoShopCoreUser::getVipGrade($user_id) ?></span>
                    <div class="ceo-flex-1"></div>
                    <a href="<?php echo wp_logout_url( home_url() ); ?>" ceo-tooltip="退出"><i class="ceofont ceoicon-logout-circle-r-line"></i></a>
                </div>
                <?php if (_ceo('ceo_shop_whole')) : ?>
                <?php if(_ceo('navbar_user_vip') == true ): ?>
                <?php $vip_set = _ceo('navbar_user_vip_set') ?>
                <div class="ceo-scxx">
                    <div class="ceo-scxx-user-vip">
                        <a href="<?php echo $vip_set['link']; ?>"><?php echo $vip_set['title']; ?></a>
                        <span><?php echo CeoShopCoreUser::getVipGrade($user_id) ?></span>
                        <p><?php echo $vip_set['desc']; ?></p>
                    </div>
                </div>
                <?php endif; ?>
                <?php endif; ?>
                <div class="ceo-czgr">
                    <div class="ceo-grid-small" ceo-grid>
                        <?php $n_u_d = _ceo('navbar_user_delivery_set') ?>
                        <div class="ceo-width-1-2">
                            <a href="<?php echo $n_u_d['link']; ?>">
                                <i class="ceofont <?php echo $n_u_d['icon']; ?>"></i><?php echo $n_u_d['title']; ?>
                            </a>  
                        </div>
                        <?php $n_u_s = _ceo('navbar_user_shop_set') ?>
                        <div class="ceo-width-1-2">
                            <a href="<?php echo $n_u_s['link']; ?>">
                        		<i class="ceofont <?php echo $n_u_s['icon']; ?>"></i><?php echo $n_u_s['title']; ?>
                        	</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="userbottom ceo-background-default">
                <div class="user-menu">
                    <ul class="ceo-child-width-1-5 ceo-grid-ceosmls" ceo-grid>
                        <li class="ceo-text-center">
                            <a href="/author/<?php echo the_author_meta( 'user_login',$authorID ); ?>"><i class="ceofont ceoicon-home-3-line"></i>主页</a>
                        </li>
                	    <li class="ceo-text-center">
                			<a href="<?php echo home_url(user_trailingslashit('/member/download')); ?>"><i class="ceofont ceoicon-download-2-line"></i>下载</a>
                		</li>
                        <li class="ceo-text-center">
                			<a href="<?php echo home_url(user_trailingslashit('/member/order')); ?>"><i class="ceofont ceoicon-shopping-bag-2-line"></i>订单</a>
                		</li>
                		<li class="ceo-text-center">
                			<a href="<?php echo home_url(user_trailingslashit('/member/user-collection')); ?>"><i class="ceofont ceoicon-star-line"></i>收藏</a>
                		</li>
                	    <li class="ceo-text-center">
                			<a href="<?php echo home_url(user_trailingslashit('/member/user-settings')); ?>"><i class="ceofont ceoicon-account-box-line"></i>资料</a>
                		</li>
                    </ul>
                </div>
                <?php if(current_user_can('level_4')){ ?>
                <a class="admin" href="<?php echo admin_url(); ?>" target="_blank">
            		<i class="ceofont ceoicon-settings-4-line"></i>后台管理
            	</a>
                <?php } ?>
            </div>
        </div>
	</div>
</div>
<?php }else{ ?>

<div class="ceo-users-lore">
    <?php if(_ceo('navbar_login') == 1 ){ ?>
	<a href="#navbar-login" ceo-toggle>
	    <span>登录/注册</span>
	    <?php if(_ceo('navbar_user_desc') == true): ?><i><?php echo _ceo('navbar_user_desc_set'); ?></i><?php endif; ?>
	</a>
    <?php }else { ?>
    <a href="<?php echo home_url(user_trailingslashit('/member/login')); ?>">
        <span>登录/注册</span>
        <?php if(_ceo('navbar_user_desc') == true): ?><i><?php echo _ceo('navbar_user_desc_set'); ?></i><?php endif; ?>
    </a>
    <?php } ?>
</div>
<?php } ?>