<?php
    $ad = _ceo('side_ad');
?>
<!--广告模块-->
<div class="ceo-sidebar-ad ceo-background-default ceo-margin-bottom b-r-4">
    <?php
    if ($ad) {
    foreach ( $ad as $key => $value) {
    ?>
	<a href="<?php echo $ad[$key]['link']; ?>" target="_blank" class="ceo-display-block">
	    <img src="<?php echo $ad[$key]['img']; ?>" alt="<?php echo $ad[$key]['title']; ?>" />
	</a>
	<?php } } ?>
</div>
