<?php
	$user_id  = get_the_author_ID();
	$author = get_the_author_meta( 'ID' );
	$args = array(
	    'post_author' => $user_id
	);
	$author_comments = get_comments($args);
	if (is_single()):
?>

<!--作者模块-->
<div class="ceo-sidebar-author ceo-background-default ceo-margin-bottom b-r-4">
    <div class="ceo-text-center">
	    <div class="adminimg">
			<?php echo get_avatar( get_the_author_meta( 'ID' ),'100' ); ?>
            <?php if(user_can(get_the_author_meta( 'ID' ),'author') || user_can(get_the_author_meta( 'ID' ),'editor') || user_can(get_the_author_meta( 'ID' ),'administrator')){ ?>
			<i ceo-tooltip="认证作者"></i>
            <?php }?>
		</div>
	    <p class="name"><?php the_author_posts_link(); ?></p>
	    <p class="desc">
	    <?php
	    if(!get_the_author_description()){
	      echo '这家伙很懒，只想把你留下。';
	    	}else {
	    	   the_author_description();
 	    	}
	    ?>
	    </p>
	</div>
	<div class="count b-t">
		<ul class="ceo-grid-collapse" ceo-grid>
			<li class="ceo-text-center ceo-width-1-4">
				<span>文章</span>
				<p><?php echo count_user_posts($user_id); ?></p>
			</li>
			<li class="ceo-text-center ceo-width-1-4">
				<span>收藏</span>
				<p><?php echo count($author_comments); ?></p>
			</li>
			<li class="ceo-text-center ceo-width-1-4">
				<span>人气</span>
				<p><?php echo cx_posts_views($user_id); ?></p>
			</li>
            <li class="ceo-text-center ceo-width-1-4">
				<span>粉丝</span>
				<p><?php echo get_user_meta($user_id, 'wp_followers_count', true); ?></p>
			</li>
		</ul>
	</div>
	<div class="btns">
        <?php do_action('ceo_profile_after_description', $author);?>
        <a href="<?php echo get_author_posts_url( $user_id, get_userdata($user_id)->user_nicename ); ?>" target="_blank" class="ceo-zybtn"><i class="ceofont ceoicon-user-add-line"></i>进主页</a>
    </div>
</div>
<?php endif; ?>