<?php
$post_id =  get_the_ID();
$user_id  = get_the_author_ID();
$btn = _ceo('ceo_single_shop_btn');
$complaint = _ceo('ceo_single_shop_complaint_set');
$copyright = _ceo('ceo_single_shop_copyright_set');
$ad = _ceo('ceo_single_shop_ad_set');
$info=get_post_meta( get_the_ID(), 'down_info', true );
$down_btn=get_post_meta( get_the_ID(), 'down_btn', true );
?>
<div class="sidebar ceo-width-1-1 ceo-width-3-0@s">
	<div class="theiaStickySidebar">
        <div class="ceo-background-default ceo-margin-bottom b-r-4">
            <div class="ceo-sidebar-shop2">
                <div class="header">
                    <div class="title ceo-flex">
    				    <span class="s"></span>
        			    <?php if(get_post_meta( get_the_ID(), 'ceo-tese-tag', true )){?>
        			    <div class="t"><i class="ceofont ceoicon-award-fill"></i><?php echo get_post_meta( get_the_ID(), 'ceo-tese-tag', true );?></div>
    				    <?php }?>
    					<h1 class="ceo-flex-1 ceo-text-truncate" title="<?php the_title(); ?>"><?php the_title(); ?></h1>
					</div>
					<ul class="info">
					    <?php if(_ceo('ceo_single_shop_author') == true ): ?>
                        <li>
                        	<span><i class="ceofont ceoicon-user-line"></i><?php the_author_posts_link(); ?></span>
                    	</li>
                    	<?php endif ?>
                    	<?php if(_ceo('ceo_single_shop_views') == true ): ?>
                        <li>
                        	<span><i class="ceofont ceoicon-eye-line"></i><?php post_views('', ''); ?></span>
                    	</li>
                    	<?php endif ?>
                    	<?php if(_ceo('ceo_single_shop_id') == true ): ?>
                        <li>
                        	<span><i class="ceofont ceoicon-cloud-line"></i>ID<?php echo get_the_ID(); ?></span>
                    	</li>
                    	<?php endif ?>
                    	<li class="edit" ceo-tooltip="编辑作品">
    					    <?php edit_post_link('<i class="ceofont ceoicon-edit-2-line"></i>'); ?>
    					</li>
				    </ul>
                </div>
                <div class="list">
                    <ul>
                        <?php if (_ceo('ceo_shop_whole')) : ?>
					    <?php if (get_current_user_id() > 0 || _ceo('ceo_shop_tourist')) : ?>
                        <?php if(_ceo('ceo_single_shop_price') == true ): ?>
                        <li>
                            <p><?php echo _ceo('ceo_single_shop_price_title'); ?></p>
                            <em><?php echo CeoShopCoreProduct::getPriceFormat($post_id) ?></em>
                        </li>
                        <?php endif ?>
                        <?php if(_ceo('ceo_single_shop_vip') == true ): ?>
    					<li>
                            <p><?php echo _ceo('ceo_single_shop_vip_title'); ?></p>
                            <em><?php echo CeoShopCoreProduct::getVipDiscountInfoFormat($post_id, get_current_user_id()) ?></em>
                        </li>
    					<?php endif; ?>
    					<?php endif; ?>
                        <?php endif ?>
                        <?php
                        if(!empty($info)){
                            foreach ($info as $k=>$v){
                                $number=$k+1;
                                echo '<li><p>'.$v['title'].'</p>'.'<em>'.$v['desc'].'</em></li>';
                            }
                        }
                        ?>
                        <?php if(_ceo('ceo_single_shop_cat') == true ): ?>
                    	<li>
                        	<p><?php echo _ceo('ceo_single_shop_cat_title'); ?></p>
                        	<?php
                	    	$category = get_the_category();
                	    	if($category[0]){
                	    		echo '<em><a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a></em>';
                	    	}
                	    ?>
                    	</li>
                        <?php endif ?>
                        <?php if(_ceo('ceo_single_shop_time') == true ): ?>
                        <li>
                        	<p><?php echo _ceo('ceo_single_shop_time_title'); ?></p>
                        	<em><?php echo the_time('Y-m-d'); ?></em>
                    	</li>
                        <?php endif ?>
                    </ul>
                </div>
                <div class="btns">
                    <?php if (_ceo('ceo_single_shop_collection') == true ): ?>
                    <div class="collection"><?php echo ceotheme_post_collection_button_content2( get_the_ID() );?></div>
                    <?php endif ?>
                    <?php if(_ceo('ceo_single_shop_share') == true ): ?>
                    <div class="share">
                        <span class="title"><i class="ceofont ceoicon-share-line"></i>分享</span>
                        <div class="box">
                            <ul>
                                <li>
                                    <a class="share-post meta-item mobile j-mobile-share" href="javascript:;" data-id="<?php echo get_the_ID(); ?>"
                                   data-qrcode="<?php echo get_the_permalink(); ?>" ceo-tooltip="生成海报分享">
                                        <i class="ceofont ceoicon-image-line"></i>
                                    </a>
                			    </li>
                    			<li>
                                    <?php
                        				$qrcode = ''.get_bloginfo('template_directory').'/inc/qrcode?data='.get_the_permalink().'';
                        				$post_url = esc_url(get_permalink());
                        				$post_title = esc_attr(get_the_title());
                        				$post_desc = wp_trim_words( get_the_content(), 30 );
                        			?>
                        			<a class="weixin-share ceo-display-inline-block" href="<?php echo $qrcode; ?>" ceo-tooltip="分享到微信" data-image="<?php echo esc_attr($post_image); ?>" target="_blank"><i class="ceofont ceoicon-wechat-fill"></i>
                        			</a>
                    			</li>
                    			<li>
                        			<a class="qq-share ceo-display-inline-block" href="http://connect.qq.com/widget/shareqq/index.html?url=<?php echo $post_url; ?>&sharesource=qzone&title=<?php echo $post_title; ?>&pics=<?php echo post_thumbnail_src(); ?>&summary=<?php echo $post_desc; ?>"  ceo-tooltip="分享到QQ好友/QQ空间" target="_blank" rel="noreferrer nofollow"><i class="ceofont ceoicon-qq-fill"></i>
                        			</a>
                    			</li>
                    			<li>
                        			<a class="weibo-share ceo-display-inline-block" href="http://service.weibo.com/share/mobile.php?url=<?php echo $post_url; ?>&title=<?php echo $post_title ?> - <?php bloginfo('name'); ?>&appkey=3313789115" ceo-tooltip="分享到微博" target="_blank" rel="noreferrer nofollow"><i class="ceofont ceoicon-weibo-fill"></i>
                        			</a>
                    			</li>
                			</ul>
                        </div>
                    </div>
                    <?php endif ?>
                    <?php if(_ceo('ceo_single_shop_complaint') == true ): ?>
                    <div class="report"><a href="<?php echo $complaint['link'] ?>" target="_blank" rel="nofollow"><i class="ceofont ceoicon-error-warning-line"></i>举报</a></div>
                    <?php endif ?>
                </div>
                <div class="download-btn">
                    <?php if(get_post_meta( get_the_ID(), 'down_demourl', true )){?>
                    <a href="/demo?id=<?php echo get_the_ID();?>" target="_blank" class="demo"><i class="ceofont ceoicon-mac-line"></i><?php echo $btn['demo'] ?></a>
                    <?php } ?>
                    <?php if (_ceo('ceo_shop_whole')) : ?>
						<?php if (get_current_user_id() > 0 || _ceo('ceo_shop_tourist')) : ?>
							<?php if (get_current_user_id() == 0 && (!_ceo('ceo_shop_tourist_buy') || CeoShopCoreProduct::getTypeId(get_the_ID()) == 2)) : ?>
								<a href="#navbar-login" data-product-id="<?php echo get_the_ID() ?>" class="download" ceo-toggle>
									<i class="ceofont ceoicon-download-line"></i><?php echo CeoShopCoreProduct::getPayButtonText(get_the_ID(), get_current_user_id()) ?>
								</a>
							<?php else : ?>
								<a href="javascript:void(0)" data-product-id="<?php echo get_the_ID() ?>" data-flush="<?php echo CeoShopCoreProduct::getTypeId(get_the_ID()) == 1 ? '1': '0' ?>" class="download btn-ceo-purchase-product" data-style="slide-down">
									<i class="ceofont ceoicon-download-line"></i><?php echo CeoShopCoreProduct::getPayButtonText(get_the_ID(), get_current_user_id()) ?>
								</a>
							<?php endif; ?>
						<?php endif; ?>
					<?php endif; ?>
					<?php
                    if(!empty($down_btn)){
                        foreach ($down_btn as $k=>$v){
                            $number=$k+1;
                            echo '<a href="'.$v['url'].'" target="_blank" class="btn">'.$v['title'].'</a>';
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <div class="ceo-background-default ceo-margin-bottom b-r-4">
            <div class="ceo-sidebar-shop-more">
                <?php if(_ceo('ceo_single_shop_other') == true ): ?>
                <div class="recommend-title ceo-flex">
                    <span class="ceo-flex-1"><?php echo _ceo('ceo_single_shop_other_title'); ?></span>
                    <a href="<?php echo get_author_posts_url( $user_id, get_userdata($user_id)->user_nicename ); ?>">更多<i class="ceofont ceoicon-arrow-right-s-line"></i></a>
                </div>
                <ul class="ceo-child-width-1-3 ceo-grid-ceossss" ceo-grid>
                    <?php
                        $the_query = new WP_Query( 
                			array( 
                				'no_found_rows' => true,
                				'posts_per_page' => 3,
                				'post__not_in' => array_merge(get_option( 'sticky_posts' ), [$post_id]),
                				'author' => $user_id,
                				'meta_query' => array(
                                    array(
                                        'key' => 'ceo_shop_type',
                                        'value' => 'close',
                                        'compare' => '!=',
                                    ),
                                ),
                			)
                		);
                		if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post(); 
                	?>
                	<li>
                    	<a href="<?php the_permalink() ?>" <?php echo _target_blank();?> class="thumb ceo-display-block ceo-cover-container">
                	        <img data-src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" src="<?php echo get_template_directory_uri().'/static/images/thumb-card.gif'; ?>" class="lazyload" ceo-cover>
                        </a>
                	</li>
                    <?php endwhile; endif; wp_reset_postdata(); ?>
                </ul>
                <?php endif ?>
                <?php if(_ceo('ceo_single_shop_ad') == true ): ?>
                <div class="quick ceo-margin-top">
                    <a href="<?php echo $ad['link'] ?>" class="btns">
                        <i class="ceofont <?php echo $ad['icon'] ?>"></i><?php echo $ad['title'] ?><i class="ceofont ceoicon-arrow-right-s-line"></i>
                    </a>
                </div>
                <?php endif ?>
            </div>
        </div>
    </div>
</div>