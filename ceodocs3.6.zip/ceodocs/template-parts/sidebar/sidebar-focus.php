<?php
    $btn = _ceo('side_focus_btn');
?>
<!--社交模块-->
<div class="ceo-sidebar-focus ceo-background-default ceo-margin-bottom b-r-4">
    <div class="bg" style="background:url(<?php echo _ceo('side_focus_img'); ?>) center no-repeat; background-size:cover;"></div>
    <div class="img">
	    <img src="<?php echo _ceo('side_focus_ma'); ?>">
    </div>
    <div class="title">
        <span><?php echo _ceo('side_focus_title'); ?></span>
        <p><?php echo _ceo('side_focus_subtitle'); ?></p>
    </div>
    <div class="link">
        <?php
        if ($btn) {
        foreach ( $btn as $key => $value) {
        ?>
	    <a href="<?php echo $btn[$key]['link']; ?>" target="_blank" rel="nofollow"><?php echo $btn[$key]['title']; ?></a>
	    <?php } } ?>
    </div>
</div>