<?php
    $imgtext_on = 1;
    $args = array(
        'cat'            => _ceo('imgtext_cat'),
        'ignore_sticky_posts' => true,
        'post_status'         => 'publish',
        'posts_per_page'      => _ceo('imgtext_number'),
        'orderby'      => _ceo('imgtext_orderby'),
        'order' => 'DESC',
    );
    $data = new WP_Query($args);
?>
<!--图文模块-->
<div class="ceo-sidebar-imgtext ceo-background-default ceo-margin-bottom b-r-4">
    <?php while ( $data->have_posts() ) : $data->the_post();if($imgtext_on==1){ ?>
    <div class="title ceo-flex">
        <span class="ceo-flex-1">
            <?php echo _ceo('imgtext_title') ?>
        </span>
        <a href="<?php echo _ceo('imgtext_url') ?>" target="_blank"><i class="ceofont ceoicon-more-line"></i></a>
    </div>
    <div class="top">
        <a href="<?php echo get_permalink(); ?>" target="_blank" class="ceo-display-block ceo-cover-container b-r-4">
            <img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" ceo-cover>
            <div class="desc">
                <p class="ceo-text-truncate"><?php echo get_the_title(); ?></p>
            </div>
        </a>
    </div>
    
    <div class="bottom">
        <?php $imgtext_on++;}else{ ?>
        <div class="item">
            <div class="ceo-grid-small" ceo-grid>
                <div class="ceo-width-1-3 img">
                    <a href="<?php echo get_permalink(); ?>" alt="<?php the_title(); ?>" target="_blank" class="ceo-display-block ceo-cover-container b-r-4">
                        <img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" ceo-cover>
                    </a>
                </div>
                <div class="ceo-width-2-3 list">
                    <a href="<?php echo get_permalink(); ?>" alt="<?php the_title(); ?>" target="_blank"><?php echo get_the_title(); ?></a>
                    <div class="ceo-flex">
                        <p class="ceo-flex-1"><?php the_time('Y-m-d') ?></p>
                        <p><?php post_views('', ''); ?> 浏览</p>
                    </div>
                </div>
            </div>
        </div>
        <?php } endwhile; ?>
    </div>
</div>