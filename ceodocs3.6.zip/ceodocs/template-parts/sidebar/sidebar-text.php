<!--热门文章-->
<div class="ceo-sidebar-text ceo-background-default ceo-margin-bottom b-r-4">
    <div class="title ceo-flex">
        <span class="ceo-flex-1">
            <?php echo _ceo('text_title') ?>
        </span>
        <a href="<?php echo _ceo('text_url') ?>" target="_blank"><i class="ceofont ceoicon-more-line"></i></a>
    </div>
    <ul>
        <?php
            $cat_id = _ceo('text_cat');
			$text_num = _ceo('text_num');
			$args=array(
    			'cat'            => $cat_id,
    			'ignore_sticky_posts' => 1,
    			'meta_key' => 'views',
    			'orderby' => 'meta_value_num',
    			'showposts' => $text_num
		    );
		    $category = get_category( $cat_id);
    		query_posts($args);
    		if ( have_posts() ) : 
    		    $i=0;
    		    while ( have_posts() ) : the_post();
    		    $i++;
		?>
        <li class="ceo-flex">
            <em class="num num<?php echo $i;?>"><?php echo $i;?></em>
            <a href="<?php echo get_permalink(); ?>" target="_blank" class="ceo-flex-1 ceo-text-truncate"><?php echo get_the_title(); ?></a>
            <span><i class="ceofont ceoicon-eye-line"></i><?php post_views('', ''); ?></span>
        </li>
        <?php endwhile; endif; wp_reset_query(); ?>
    </ul>
</div>