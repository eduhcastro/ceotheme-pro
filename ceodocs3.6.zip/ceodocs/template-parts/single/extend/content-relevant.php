<?php 
    $post_id =  get_the_ID();
    $xg_num = _ceo('xg_num');
?>
<div class="loop-2">
	<ul class="ceo-grid-ceosmls" ceo-grid>
    	<?php
    		$cat=get_the_category();
            $cat_id=$cat[0]->cat_ID;
    		$the_query = new WP_Query( 
    			array( 
    				'no_found_rows' => true,
    				'cat' => $cat_id,
    				'posts_per_page' => 10,
    				'post__not_in' => get_option( 'sticky_posts' ) 
    			)
    		);
    		if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post(); 
    	?>
    	<li class="ceo-width-1-2 ceo-width-1-5@s">
    	<?php get_template_part( 'template-parts/loop/loop', '2' ); ?>
    	</li>
        <?php endwhile; endif; wp_reset_postdata(); ?>
    </ul>
</div>