<?php 
    $post_id =  get_the_ID();
    $xg_num = _ceo('xg_num');
?>
<div class="related-module ceo-background-default ceo-margin-bottom b-r-4">
	<div class="related-title">
		<span><?php echo _ceo('xg_title'); ?></span>
	</div>
	<div class="loop-7">
	    <ul>
    	<?php
    		$cat=get_the_category();
            $cat_id=$cat[0]->cat_ID;
    		$the_query = new WP_Query( 
    			array( 
    				'no_found_rows' => true,
    				'cat' => $cat_id,
    				'posts_per_page' => $xg_num,
    				'post__not_in' => get_option( 'sticky_posts' ) 
    			)
    		);
    		if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post(); 
    	?>
    	<?php get_template_part( 'template-parts/loop/loop', '7' ); ?>
        <?php endwhile; endif; wp_reset_postdata(); ?>
        </ul>
    </div>
</div>