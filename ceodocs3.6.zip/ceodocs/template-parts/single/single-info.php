<?php 
	$post_id =  get_the_ID();
?>
<div class="info ceo-flex ceo-flex-middle">
    <div class="left ceo-flex-1">
		<?php if(_ceo('single_info_tx') == true ): ?>
        <div class="avatar">
		<?php echo get_avatar(get_the_author_meta( 'ID' ), 20); ?>
		</div>
		<?php endif; ?>
		<?php if(_ceo('single_info_mc') == true ): ?>
		<span class="name"><?php the_author_posts_link(); ?></span>
		<?php endif; ?>
		<?php if(_ceo('single_info_fl') == true ): ?>
	    <span class="cat ceo-visible@s">
	    <?php
	    	$category = get_the_category();
	    	if($category[0]){
	    		echo '<a href="'.get_category_link($category[0]->term_id ).'"><i class="ceofont ceoicon-function-line"></i>'.$category[0]->cat_name.'</a>';
	    	}
	    ?>
	    </span>
	    <?php endif; ?>
        <?php if(_ceo('single_info_rq') == true ): ?>
    	<span><i class="ceofont ceoicon-time-line"></i><?php echo the_time('Y年m月j日'); ?></span>
    	<?php endif; ?>
	</div>
	<div class="right">
    	<span><?php edit_post_link('<i class="ceofont ceoicon-edit-2-line"></i> 编辑'); ?></span>
    	<?php if(_ceo('single_info_ll') == true ): ?>
    	<span><?php post_views('', ''); ?> 浏览</span>
    	<?php endif; ?>
	</div>
</div>