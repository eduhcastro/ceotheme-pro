<?php
	$current_category = get_the_category();//获取当前文章所属分类ID
	$prev_post = get_previous_post($current_category,'');//与当前文章同分类的上一篇文章
	$next_post = get_next_post($current_category,'');//与当前文章同分类的下一篇文章
?>
<?php if(_ceo('single_foo_fy') == true ): ?>
<div class="ceo-grid-ceosmls ceo-margin-bottom" ceo-grid>
	<div class="ceo-width-1-2">
		<?php if (!empty( $prev_post )){ ?>
        <div class="b-r-4 ceo-inline ceo-overflow-hidden ceo-width-1-1 ceo-single-page" style="height:82px">
            <div class="ceo-overlay ceo-sxp ceo-position-bottom ceo-background-default">
            	<span>上一篇：</span>
                <a href="<?php echo get_permalink( $prev_post->ID ); ?>" class="ceo-display-block ceo-text-truncate"><?php echo $prev_post->post_title; ?></a>
            </div>
        </div>
		<?php }else { ?>
		<div class="b-r-4 ceo-inline ceo-overflow-hidden ceo-width-1-1 ceo-single-page" style="height:82px">
            <div class="ceo-overlay ceo-sxp ceo-position-bottom ceo-background-default">
            	<span>上一篇：</span>
            	<p class="ceo-text-truncate">已经没有上一篇了!</p>
            </div>
        </div>
		<?php } ?>
	</div>
	<div class="ceo-width-1-2">
		<?php if (!empty( $next_post )){ ?>
		<div class="b-r-4 ceo-inline ceo-overflow-hidden ceo-width-1-1 ceo-single-page" style="height:82px">
            <div class="ceo-overlay ceo-sxp ceo-position-bottom ceo-background-default">
            	<span>下一篇：</span>
            	<a href="<?php echo get_permalink( $next_post->ID ); ?>" class="ceo-display-block ceo-text-truncate"><?php echo $next_post->post_title; ?></a>
            </div>
        </div>
	    <?php }else { ?>
	    <div class="b-r-4 ceo-inline ceo-overflow-hidden ceo-width-1-1 ceo-single-page" style="height:82px">
            <div class="ceo-overlay ceo-sxp ceo-position-bottom ceo-background-default">
            	<span>下一篇：</span>
            	<p class="ceo-text-truncate">已经没有下一篇了!</p>
            </div>
        </div>
	    <?php } ?>
	</div>
</div>
<?php endif ?>