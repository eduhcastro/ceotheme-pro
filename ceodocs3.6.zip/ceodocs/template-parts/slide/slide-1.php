<?php 
    $slide_1_title = _ceo('ceo_home_slide_1_title');
    $slide_1_right_btn = _ceo('ceo_home_slide_1_right_btn');
    $slide_1_cms = _ceo('ceo_home_slide_1_cms');
?>
<div class="ceo-home-slide1" style="background-image: url(<?php echo _ceo('ceo_home_slide_1_bg'); ?>);">
    <div class="ceo-container ceo-text-center">
        <div class="slide1-title">
            <p class="big_title slide_text"></p>
    		<script type="text/javascript">
                var jump_pram = "eyJyb3V0ZV9pZCI6IjE2MDUyNjA0OTU0MzA5Iiwicm91dGUiOiIzLDEsIiwiYWZ0ZXJfcm91dGUiOiIzLDEiLCJyZWZlcmVyIjoiJTJGJTNGcm91dGVfaWQlM0QxNjA1MjYwNDk1NDMwOSUyNnJvdXRlJTNEMyUyQzElMkMlMjZhZnRlcl9yb3V0ZSUzRDMlMkMxIn0=";
                var isGuest = '1';
                var is_login = "";
                var phoneBind = "";
                var origin = "index_recommend";
                var index_player = "";
                var invite_user = "";
                var invite_uid = "";
                var is_new_user = "";
                var templ_count = "792,291";
                var isClientSide = "";
                var templ_num = "792,291";
                setInterval(function() {
                    if ($('.slide1-title .big_title').text() == "<?php echo $slide_1_title['title1'] ?>") {
                         $('.slide1-title .big_title').text('<?php echo $slide_1_title['title2'] ?>')
                    } else if ($('.slide1-title .big_title').text() == "<?php echo $slide_1_title['title2'] ?>") {
                        $('.slide1-title .big_title').text('<?php echo $slide_1_title['title3'] ?>')
                    } else {
                        $('.slide1-title .big_title').text('<?php echo $slide_1_title['title1'] ?>')
                    }
                }, 2000);
            </script>
        </div>
        <div class="slide1-desc"><?php echo _ceo('ceo_home_slide_1_desc'); ?></div>
        <div class="slidebox ceo-text-center">
    	    <div class="search">
    			<form method="get" class="ceo-form ceo-overflow-hidden ceo-position-relative" action="<?php bloginfo('url'); ?>">
    				<input type="search" placeholder="<?php echo $slide_1_right_btn['desc'] ?>" autocomplete="off" value="" name="s" required="required" class="ceo-input">
    				<button type="submit"><i class="ceofont ceoicon-search-2-line"></i>搜索</button>
    			</form>
    			<div class="sean ceo-visible@m">
    			    <span>或</span>
    				<a href="<?php echo $slide_1_right_btn['link'] ?>"><p class="ceo-text-truncate"><?php echo $slide_1_right_btn['title'] ?></p></a>
    			</div>
    		</div>
    			
    		<ul class="tag ceo-visible@s">
    		    <li class="k1">热门搜索：</li>
    		    <?php wp_tag_cloud('number=9&orderby=count&order=DESC&smallest=12&largest=14&unit=px'); ?>
		    </ul>
    	</div>
	</div>
	
	<div class="ceo-container ceo-visible@m">
	    <div class="slide1-quick ceo-background-default">
    	    <ul class="ceo-grid-large" ceo-grid>
    	        <?php 
    			    if ($slide_1_cms) { 
    				foreach ( $slide_1_cms as $key => $value) {
    			?>
    			<?php 
					$cms_style = $value['slide_1_cms_style'];
					if( $cms_style == 'cms1' ){
				?>
                <li class="ceo-width-1-1 ceo-width-1-5@s">
                    <div class="quick-1box">
                	    <div class="ceo-grid-ceosmls" ceo-grid>
                	        <?php 
							    if ( $value['cms1'] ) {
								foreach ( $value['cms1'] as $k => $v) {
    						?>
                            <div class="ceo-width-1-2">
                                <a href="<?php echo $v['link']; ?>">
                                    <div class="ceo-grid-ceossss" ceo-grid>
            	                        <div class="ceo-width-auto">
            	                            <img src="<?php echo $v['img']; ?>">
                                        </div>
                                        <div class="ceo-width-expand">
                                            <span class="ceo-text-truncate"><?php echo $v['title']; ?></span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <?php } } ?>
                        </div>
                    </div>
                </li>
                <?php } elseif( $cms_style == 'cms2' ) { ?>
                <li class="ceo-width-1-1 ceo-width-1-5@s">
                    <div class="quick-2box">
                	    <div class="ceo-grid-ceosmls" ceo-grid>
                	        <?php 
							    if ( $value['cms2'] ) {
								foreach ( $value['cms2'] as $k => $v) {
    						?>
                            <div class="ceo-width-1-3">
                                <a href="<?php echo $v['link']; ?>" class="ceo-text-truncate" ceo-tooltip="<?php echo $v['title']; ?>"><?php echo $v['title']; ?></a>
                            </div>
                            <?php } } ?>
                        </div>
                    </div>
                </li>
                <?php }else { ?>
                <li class="ceo-width-1-1 ceo-width-1-5@s">
                    <div class="quick-3box">
                	    <div class="ceo-grid-ceosmls" ceo-grid>
                	        <?php 
							    if ( $value['cms3'] ) {
								foreach ( $value['cms3'] as $k => $v) {
    						?>
                            <div class="ceo-width-1-3">
                                <a href="<?php echo $v['link']; ?>" class="ceo-text-truncate">
    	                            <img src="<?php echo $v['img']; ?>">
                                    <span><?php echo $v['title']; ?></span>
                                </a>
                            </div>
                            <?php } } ?>
                        </div>
                    </div>
                </li>
                <?php } ?>
                <?php } } ?>
    		</ul>
		</div>
	</div>
</div>