<?php
    $slide_2_title = _ceo('ceo_home_slide_2_title');
    $slide_2_cms = _ceo('ceo_home_slide_2_cms');
    $slide_2_cms_roll = _ceo('ceo_home_slide_2_cms_roll_set');
?>
<div class="ceo-home-slide2">
    <div class="slide-box" style="background-image: url(<?php echo _ceo('ceo_home_slide_2_bg'); ?>);">
        <div class="ceo-container">
            <div class="banner-box">
                <div class="slide-box-text">
                    <span><?php echo $slide_2_title['title'] ?></span>
                    <p><?php echo $slide_2_title['subtitle'] ?></p>
                </div>
                <div class="search">
        			<form method="get" class="ceo-form ceo-flex ceo-overflow-hidden ceo-position-relative" action="<?php bloginfo('url'); ?>">
        				<input type="search" placeholder="<?php echo $slide_2_title['desc'] ?>" autocomplete="off" value="" name="s" required="required" class="ceo-input">
        				<button type="submit" class="ceo-position-center-right ceo-flex-1"><i class="ceofont ceoicon-search-2-line"></i>立即搜索</button>
        			</form>
        		</div>
            </div>
        </div>
    </div>
    <div class="slide-cms ceo-visible@m">
        <div class="ceo-container">
            <div class="slide-cmsbox ceo-background-default">
                <div class="ceo-grid-medium" ceo-grid>
                    <?php 
            			if ($slide_2_cms) { 
        				foreach ( $slide_2_cms as $key => $value) {
        			?>
                    <div class="mk ceo-width-1-4">
                        <div class="box">
                            <span><a href="<?php echo $value['links']; ?>" target="_blank"><img src="<?php echo $value['img']; ?>"><?php echo $value['mktitle']; ?><i class="ceofont ceoicon-arrow-right-circle-line"></i></a></span>
                            <div class="ceo-grid-ceossss" ceo-grid>
                                <?php 
        							 if ( $value['tags'] ) {
    								foreach ( $value['tags'] as $k => $v) {
        						?>
                                <div class="ceo-width-1-4">
                                    <a href="<?php echo $v['link']; ?>" target="_blank" class="btn ceo-text-truncate"><?php echo $v['title']; ?></a>
                                </div>
                                <?php } } ?>
                            </div>
                        </div>
                    </div>
                    <?php } } ?>
                </div>
                <?php if (_ceo('ceo_home_slide_2_cms_roll')) : ?>
                <div class="home-tool" ceo-slider="sets: true">
                    <div class="ceo-position-relative">
                        <div class="ceo-slider-container ceo-light">
                            <ul class="ceo-slider-items ceo-child-width-1-8 ceo-grid-medium" ceo-grid>
                                <?php 
                        			if ($slide_2_cms_roll) { 
                    				foreach ( $slide_2_cms_roll as $key => $value) {
                    			?>
                                <li>
                                    <a href="<?php echo $slide_2_cms_roll[$key]['link']; ?>" class="tool" target="_blank">
                                        <img src="<?php echo $slide_2_cms_roll[$key]['img']; ?>" alt="<?php echo $slide_2_cms_roll[$key]['title']; ?>">
                                        <span><?php echo $slide_2_cms_roll[$key]['title']; ?></span>
                                        <p><?php echo $slide_2_cms_roll[$key]['desc']; ?></p>
                                    </a>
                                </li>
                                <?php } } ?>
                            </ul>
                        </div>
                    </div>
                    <ul class="ceo-slider-nav ceo-dotnav ceo-flex-center"></ul>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>