<?php
/*
Template Name: 投稿模板
*/
global $current_user;
if ( ! current_user_can('editor') && ! current_user_can('administrator')) {
    wp_redirect('/apply');
    exit;
}
$post_id=$_GET['post'];
if (!empty($post_id)) {
    $post = get_post($post_id, OBJECT);
    if ($post->post_author != get_current_user_id()) {
        wp_die(
            '非法请求访问',
            '非法请求',
            array(
                'response'  => 0,
                'back_link' => true,
            )
        );
    }
}
ceo_tougao_admin();
?>
<?php
wp_enqueue_style('tougaocss',get_template_directory_uri().'/static/css/tougao.css');
get_header();
wp_enqueue_script('tougaojs',get_template_directory_uri().'/static/js/tougao.js');
$title = _ceo('togao-title');
$text = _ceo('togao-text');
$bg = _ceo('togao-bg');
?>
<div class="ceo-default-bg ceo-background-cover ceo-background-muted ceo-panel ceo-flex ceo-flex-center ceo-flex-middle" style="background-image: url(<?php echo $bg; ?>)">
    <div class="ceo-container1280">
        <div class="title ceo-position-center ceo-text-center">
            <h1><?php echo $title; ?></h1>
            <p><?php echo $text; ?></p>
        </div>
    </div>
</div>
<?php
//编辑
if ( ! empty($_GET['post']) && get_post($_GET['post'])) {
    global $post;
    $post_id=$_GET['post'];
    $post = get_post($post_id, OBJECT);
    setup_postdata($post);

    ?>
    <section class="ceo-tougao ceo-container1280">
        <div id='wrap'>
            <div class="wrap">
                <form method='post' class='post-form' id='j-form'>
                    <?php wp_nonce_field('update_post_tougao','update_post_tougao') ?>
                    <input type='hidden' name='ID' value>
                    <div class=post-form-main>
                        <div class="pf-item clearfix">
                            <div class="ceo-display-block title">作品标题</div>
                            <div class="ceo-display-block pf-item-input"><input type='text' class=form-control maxlength=200 id=post-title name='post-title' placeholder=在此输入标题 value="<?php the_title(); ?>" autocomplete=off>
                            </div>
                        </div>
                        <div class="pf-item clearfix">
                            <div class="ceo-display-block title">作品标签</div>
                            <div class="ceo-display-block pf-item-input">
                                <?php
                                $tag_list = wp_get_post_tags($post_id);
                                if(true){
                                    echo '<input id="postTags" type="hidden" value=\''.json_encode(array_column($tag_list,'name')).'\' />';
                                }
                                ?>
                                <ul id=tag-container></ul>
                                <p class=pf-notice>作品关键词，使用回车换行键确定，可选填</p>
                            </div>
                        </div>
                        <div class="ceo-margin-medium-bottom pf-item clearfix">
                            <div class="ceo-display-block title">作品内容</div>
                            <div class="ceo-display-block pf-item-input">
                                <div id=wp-post-content-wrap class="wp-core-ui wp-editor-wrap tmce-active">
                                    <?php
                                    wp_enqueue_media();

                                    wp_editor(get_the_content(),'post-content',array(
                                        'textarea_rows' => 35,
                                    ));
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=post-form-sidebar>
                        <div class=pf-submit-wrap>
                            <button type=submit class="btn btn-primary btn-block btn-lg pf-submit">提交发布</button>
                        </div>
                        <div class=pf-side-item>
                            <div class=pf-side-label><h3>缩略图</h3></div>
                            <div class=pf-side-input>
                                <?php if(get_post_thumbnail_id($post_id)): ?>
                                <div id="j-thumb-wrap" class="thumb-wrap"><?php echo get_the_post_thumbnail($post_id); ?>
                                    <div class="thumb-remove j-thumb-remove">×</div>
                                </div>
                                <?php endif;?>
                                <div id=j-thumb-wrap class=thumb-wrap></div>
                                <a class="thumb-selector j-thumb" href=javascript:;>设置缩略图片</a>
                                <p class=pf-notice>请设置作品缩略图，将会在作品列表展示</p>
                            </div>
                            <input type=hidden name=_thumbnail_id id=_thumbnail_id value="<?php echo get_post_thumbnail_id($post_id);?>">
                        </div>
                        <div class=pf-side-item>
                            <div class=pf-side-label><h3>作品分类</h3></div>
                            <div class=pf-side-input>
                                <select multiple=multiple size=5 id=post-category name=post-category[] class=form-control>
                                    <?php ceo_tougao_cat(); ?>
                                </select>
                                <p class="pf-notice">按住键盘Ctrl键+鼠标左键可多选分类</p>
                            </div>
                        </div>
                        <?php if (_ceo('ceo_shop_submit_divide')) : ?>
                            <div class="pf-side-item ceo-tougao-pay">
                                <?php
                                $productSku = CeoShopCoreProduct::getInfo($post_id, get_current_user_id())[0];
                                $payShowFlag = isset($productSku['price']);
                                ?>
                                <div class="pf-side-label title">
                                    <h3>作品付费</h3>
                                    <?php if ($payShowFlag) : ?>
                                        <a id="ceo-tougao-switch" data-pay="0" class="btns">关闭</a>
                                    <?php else : ?>
                                        <a id="ceo-tougao-switch" data-pay="1" class="btns">开启</a>
                                    <?php endif; ?>
                                </div>
                                <div id="tougao-pay-show" style="<?php echo $payShowFlag ? '' : 'display:none' ?>" class=pf-side-input>
                                    <div id=j-thumb-wrap class=thumb-wrap></div>
                                    <div class="ceo-margin-small-bottom">
                                        <span class="pf-notice">价格</span>
                                        <input class="form-control" name="ceo-pay-price" value="<?php echo $productSku['price'] ?>" type="text" placeholder="请输入价格">
                                    </div>
                                    <div class="ceo-margin-small-bottom ceo-position-relative">
                                        <span class="pf-notice">下载地址</span>
                                        <?php if (_ceo('tougao_down_url_upload')): ?>
                                        <a id="ceo-tougao-upload" href="javascript:void(0)" class="upload">上传</a>
                                        <?php endif; ?>
                                        <input type="file" id="fileInput" style="display: none;">
                                        <input class="form-control" id="ceo-pay-url" name="ceo-pay-url" value="<?php echo $productSku['down'][0]['url'] ?>" type="text" placeholder="请输入下载地址">
                                    </div>
                                    <div class="ceo-margin-small-bottom">
                                        <span class="pf-notice">隐藏信息</span>
                                        <input class="form-control" name="ceo-pay-hide" value="<?php echo $productSku['down'][0]['hide'] ?>" type="text" placeholder="请输入隐藏信息">
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <div class=pf-side-item>
                            <div class=pf-side-label><h3>作品信息</h3></div>
                            <div class=pf-side-input>
                                <div class="ceo-tougao-item pf-item clearfix">
                                    <div class="csf-field csf-field-repeater ceo-tougao-field">
                                        <div class="csf-fieldset ceo-tougao-fieldset">
                                            <div class="csf-repeater-wrapper csf-data-wrapper ui-sortable" data-unique-id="ceo_post_info" data-field-id="[down_info]" data-max="0"  data-min="0">
                                                <?php
                                                $down_info =  get_post_meta($post_id, 'down_info', 1);
                                                if(empty($down_info)){
                                                    $down_info=[];
                                                }
                                                foreach ($down_info as $k=>$v):
                                                ?>
                                                <div class="csf-repeater-item" style="">
                                                    <div class="csf-repeater-content">
                                                        <div class="csf-field csf-field-text">
                                                            <div class="csf-title"><h4>标题</h4></div>
                                                            <div class="csf-fieldset">
                                                                <input class="input-title" type="text" name="ceo_post_info[down_info][<?php echo $k ?>][title]" value="<?php echo $v['title'] ?>" data-depend-id="title">
                                                            </div>
                                                        </div>
                                                        <div class="csf-field csf-field-text">
                                                            <div class="csf-title"><h4>内容</h4></div>
                                                            <div class="csf-fieldset">
                                                                <input class="input-desc" type="text" name="ceo_post_info[down_info][<?php echo $k ?>][desc]" value="<?php echo $v['desc'] ?>" data-depend-id="desc">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="csf-repeater-helper">
                                                        <div class="csf-repeater-helper-inner">
                                                            <i class="csf-repeater-remove csf-confirm fa fa-times" data-confirm="确定要删除此项目吗？"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endforeach;?>
                                            </div>
                                            <a href="javascript:void(0)" class="button button-primary csf-repeater-add">添加作品信息</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <script>var postTags = [];</script>
        </div>
    </section>

<?php wp_reset_postdata();
    //添加
    }else{
?>
    <section class="ceo-tougao ceo-container1280">
        <div id='wrap'>
            <div class="wrap">
                <form method='post' class='post-form' id='j-form'>
                    <?php wp_nonce_field('update_post_tougao','update_post_tougao') ?>
                    <input type='hidden' name='ID' value>
                    <div class=post-form-main>
                        <div class="pf-item clearfix">
                            <div class="ceo-display-block title">作品标题</div>
                            <div class="ceo-display-block pf-item-input"><input type='text' class=form-control maxlength=200 id=post-title name='post-title' placeholder=在此输入标题 value="" autocomplete=off>
                            </div>
                        </div>
                        <div class="pf-item clearfix">
                            <div class="ceo-display-block title">作品标签</div>
                            <div class="ceo-display-block pf-item-input">
                                <?php
                                echo '<input id="postTags" type="hidden" value=\''.'[]'.'\' />';
                                ?>
                                <ul id=tag-container></ul>
                                <p class=pf-notice>作品关键词，使用回车换行键确定，可选填</p>
                            </div>
                        </div>
                        <div class="pf-item clearfix">
                            <div class="ceo-display-block title">作品内容</div>
                            <div class="ceo-display-block pf-item-input">
                                <div id=wp-post-content-wrap class="wp-core-ui wp-editor-wrap tmce-active">
                                    <?php
                                    wp_enqueue_media();

                                    wp_editor('','post-content',array(
                                        'textarea_rows' => 35,
                                    ));
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class=post-form-sidebar>
                        <div class=pf-submit-wrap>
                            <button type=submit class="btn btn-primary btn-block btn-lg pf-submit">提交发布</button>
                        </div>
                        <div class=pf-side-item>
                            <div class=pf-side-label><h3>缩略图</h3></div>
                            <div class=pf-side-input>
                                <div id=j-thumb-wrap class=thumb-wrap></div>
                                <a class="thumb-selector j-thumb" href=javascript:;>设置缩略图片</a>
                                <p class=pf-notice>请设置作品缩略图，将会在作品列表展示</p>
                            </div>
                            <input type=hidden name=_thumbnail_id id=_thumbnail_id value>
                        </div>
                        <div class=pf-side-item>
                            <div class=pf-side-label><h3>作品分类</h3></div>
                            <div class=pf-side-input>
                                <select multiple=multiple size=5 id=post-category name=post-category[] class=form-control>
                                    <?php ceo_tougao_cat(); ?>
                                </select>
                                <p class="pf-notice">按住键盘Ctrl键+鼠标左键可多选分类</p>
                            </div>
                        </div>
                        <?php if (_ceo('ceo_shop_submit_divide')) : ?>
                            <div class="pf-side-item ceo-tougao-pay">
                                <div class="pf-side-label title">
                                    <h3>作品付费</h3>
                                    <a id="ceo-tougao-switch" data-pay="1" class="btns">开启</a>
                                </div>
                                <div id="tougao-pay-show" style="display: none;" class="pf-side-input">
                                    <div id=j-thumb-wrap class=thumb-wrap></div>
                                    <div class="ceo-margin-small-bottom">
                                        <span class="pf-notice">价格</span>
                                        <input class="form-control" name="ceo-pay-price" type="text" placeholder="请输入价格">
                                    </div>
                                    <div class="ceo-margin-small-bottom ceo-position-relative">
                                        <span class="pf-notice">下载地址</span>
                                        <?php if (_ceo('tougao_down_url_upload')): ?>
                                        <a id="ceo-tougao-upload" href="javascript:void(0)" class="upload">上传</a>
                                        <?php endif; ?>
                                        <input type="file" id="fileInput" style="display: none;">
                                        <input class="form-control" id="ceo-pay-url" name="ceo-pay-url" type="text" placeholder="请输入下载地址">
                                    </div>
                                    <div class="ceo-margin-small-bottom">
                                        <span class="pf-notice">隐藏信息</span>
                                        <input class="form-control" name="ceo-pay-hide" type="text" placeholder="请输入隐藏信息">
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <div class=pf-side-item>
                            <div class=pf-side-label><h3>作品信息</h3></div>
                            <div class=pf-side-input>
                                <div class="ceo-tougao-item pf-item clearfix">
                                    <div class="postmeta-class">
                                        <div class="inside">
                                            <div class="csf csf-metabox csf-theme-dark">
                                                <div class="csf-wrapper csf-show-all">
                                                    <div class="csf-content">
                                                        <div class="csf-sections">
                                                            <div id="csf-section-ceo_post_opts_1" class="csf-section csf-onload">
                                                                <div class="csf-field csf-field-repeater ceo-tougao-field">
                                                                    <div class="csf-fieldset ceo-tougao-fieldset">
                                                                        <div class="csf-repeater-wrapper csf-data-wrapper ui-sortable" data-unique-id="ceo_post_info" data-field-id="[down_info]" data-max="0" data-min="0">
                                                                        </div>
                                                                        <a href="javascript:void(0)" class="button button-primary csf-repeater-add">添加作品信息</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <script>var postTags = [];</script>
        </div>
    </section>

<?php } ?>

<div class="clear" style="both:clear"></div>
<style>
    .csf-shortcode-button{
        display: none !important;
    }
    .csf-section{
        display: block !important;
    }
    @media (min-width: 1240px) {
        .container {
            width: auto;
        }
    }
</style>
<?php wp_enqueue_style('csfcss', get_template_directory_uri() . '/inc/codestar-framework/assets/css/style.min.css'); ?>
<script>
    $(function() {
        $('#ceo-tougao-switch').click(function() {
            if (jQuery(this).data('pay') == 0) {
                jQuery(this).text('开启');
                jQuery('#tougao-pay-show').hide()
                jQuery(this).data('pay', 1)
            } else {
               jQuery(this).text('关闭');
                jQuery('#tougao-pay-show').show()
                jQuery(this).data('pay', 0)
            }
        })

        $('#ceo-tougao-upload').click(function(e) {
            e.preventDefault();
            jQuery('#fileInput').click();
        });

        $('#fileInput').change(function() {
            var file = this.files[0];
            var formData = new FormData();
            formData.append('file', file);

            jQuery.ajax({
                url: ceotheme.ajaxurl + '?action=ceo_shop_upload_file',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        jQuery('#ceo-pay-url').val(response.link)
                        UIkit.notification('文件上传成功！', {
                            status: 'success'
                        })
                    } else {
                        UIkit.notification(response.msg, {
                            status: 'warning'
                        })
                    }
                },
                error: function() {
                    UIkit.notification('文件上传失败。', {
                        status: 'warning'
                    })
                }
            });
        });
    });
</script>

<?php
if (false) {
    echo '<script>
    (function($) {
        $.fn.pasteImageReader = function() {

        }
    }(jQuery));
</script>';
}
// General libraries.
require_once ABSPATH .  '/wp-admin/includes/plugin.php';
if (is_plugin_active('imgspider/index.php')) {
    if (defined('WB_CORE_ASSETS_LOAD') && class_exists('WB_Core_Asset_Load')) {
        WB_Core_Asset_Load::load('post-01');
    } else {
        wp_enqueue_style('wbp-admin-style-imgspy', IMGSPY_URI . 'assets/wbp_admin_imgspy.css', array(), IMGSPY_VERSION);
    }

    wp_register_script('wbs-imgspy-inline-js', false, null, false);
    wp_enqueue_script('wbs-imgspy-inline-js');

    $ajax_nonce = wp_create_nonce('wp_ajax_wb_imgspider');
    $imgspider_ver = get_option('wb_imgspider_ver', 0);
    $config_url = admin_url('403.php');

    wp_add_inline_script('wbs-imgspy-inline-js', 'var imgspy_cnf=' . json_encode(WB_IMGSPY_Conf::opt()) . ',wb_ajaxurl=\'' . admin_url('admin-ajax.php') . '\',imgspider_ver=' . $imgspider_ver . ',_wb_imgspider_ajax_nonce=\'' . $ajax_nonce . '\',imgspider_pro_url=\'' . $config_url . '\';', 'before');
}

?>

<?php get_footer(); ?>