<?php 
$title = _ceo('site-title');
$bg = _ceo('site-bg');
get_header();
?>
<div class="ceo-tag-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);">
    <div class="ceo-container ceo-containertag">
        <div class="ceo-tag-bgleft">
            <h3 class="ceo-hs"><?php echo $title; ?></h3>
            <?php include TEMPLATEPATH.'/inc/sitenav/template-parts/top.php'; ?>
        </div>
    </div>
</div>
<?php include TEMPLATEPATH.'/inc/sitenav/template-parts/nav.php'; ?>
<?php include TEMPLATEPATH.'/inc/sitenav/template-parts/hot.php'; ?>
<?php include TEMPLATEPATH.'/inc/sitenav/index.php' ;?>
<style>.ceo-tag-bgleft{margin-top: 80px;} @media (max-width: 768px){.ceo-tag-bgleft{margin-top: 44px;}}</style>
<?php get_footer(); ?>