<?php get_header(); ?>
<main class="site-top-bottom">
	<div class="ceo-container">
		<section class="site-classification-box card">
			<h3 class="ceo-text-bolder section-title"><?php single_cat_title(); ?></h3>
			<div class="ceo-grid-ceosmls" ceo-grid>
				<?php while (have_posts()) : the_post(); ?>
				<div class="ceo-width-1-1@s ceo-width-1-4@m ceo-width-1-4@l ceo-width-1-4@xl">
					<?php include(TEMPLATEPATH . '/inc/sitenav/loop/card.php'); ?>
				</div>
				<?php endwhile; ?> 
			</div>
		</section>
	</div>
</main>
<?php get_footer(); ?>