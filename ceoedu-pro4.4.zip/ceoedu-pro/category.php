<?php
	get_header();
?>

<section class="ceo-container ceo-catnav-wz ceo-visible@s">
	<div class="ceo-text-small ceo-flex ceo-flex-middle">
		<div class="ceo-shouji-pass ceo-flex-1">
		    <div class="ceo-position-absolute"><?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?></div>
	    </div>
    </div>
</section>

<?php
$cate_background_bg=get_term_meta($term->term_id,'cate_background_bg',1);
if(!empty($cate_background_bg['url'])) {
?>
<div class="ceo-tag-bg ceo-background-cover" style="background-image: url(<?php echo $cate_background_bg['url'];?>);">
<?php }elseif(_ceo('category_default_bg')){ ?>
<div class="ceo-tag-bg ceo-background-cover" style="background-image: url(<?php echo _ceo('category_default_bg'); ?>);">
<?php }?>
    <div class="ceo-container ceo-containertag">
        <div class="ceo-tag-bgleft">
            <h3 class="ceo-hs"><?php single_cat_title(); ?></h3>
            <p class="ceo-visible@s"><?php echo category_description();?></p>
        </div>
    </div>
</div>

<?php ceo_category_tpl_part(); ?>

<?php get_footer(); ?>