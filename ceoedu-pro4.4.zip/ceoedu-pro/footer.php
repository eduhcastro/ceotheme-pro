		</main>
		    <!--底部VIP跟随模块-->
		    <?php get_template_part( 'template-parts/footer/footer', 'vip' ); ?>
		    <!--底部banner模块-->
		    <?php get_template_part( 'template-parts/footer/footer', 'banner' ); ?>
			<!--右下角跟随模块-->
			<?php get_template_part( 'template-parts/footer/footer', 'follow' ); ?>
			<!--底部主模块-->
			<footer class="ceo_footer">
                <div class="ceo-footdibu">
                    <div class="ceo-container">
                        <div class="ceo-grid-ceosmls" ceo-grid>
                            <div class="ceo-visible@s ceo-width-1-1 ceo-width-1-4@s">
                                <div class="ceo_footer_lo">
                                	<span><?php if(_ceo('foot_gz'))echo _ceo('foot_gz')['foot_gztitle']; ?></span>
                                    <img src="<?php if(_ceo('foot_gz'))echo _ceo('foot_gz')['foot_gzimg']; ?>">
                                    <p><?php if(_ceo('foot_gz'))echo _ceo('foot_gz')['foot_gzsubtitle']; ?></p>
                                </div>
                            </div>
                            <div class="ceo-visible@s ceo-width-1-1 ceo-width-1-2@s">
                                <div class="ceo_footer_z">
                                    <div class="ceo-grid-ceosmls" ceo-grid>
                                        <?php
        								$foot_menu = _ceo('foot_menu');
        								if(!$foot_menu){
        									echo '<p><i class="ceofont ceoicon-alert-fill ceo-margin-small-right"></i>请前往后台<i class="ceofont ceoicon-arrow-right-s-line"></i>主题设置<i class="ceofont ceoicon-arrow-right-s-line"></i>底部设置，设置该模块内容！</p>';
        								}else {
        									if ($foot_menu) {
        										foreach ( $foot_menu as $key => $value) {
        								?>
        								<div class="ceo-width-1-4">
        									<div class="foot-item">
        										<div class="foot-item-title"><?php echo $value['h4'] ?></div>
        										<ul class="ceo-padding-remove">
        											<?php
        											$foot_menu_item = $value['foot_menu_item'];
        											?>
        											<?php
        											if ( $foot_menu_item ) {
        												foreach ( $foot_menu_item as $k => $v) {
        											?>
        											<li><a href="<?php echo $v['link'] ?>" target="_blank"><?php echo $v['title'] ?></a></li>
        
        											<?php } } ?>
        										</ul>
        									</div>
        								</div>
        								<?php } } } ?>
    								</div>
								</div>
                            </div>
                            <div class="ceo-width-1-1 ceo-width-1-4@s">
                                <div class="ceo_footer_y">
                                	<div class="ceo_footer_yq">
                                	    <a href="<?php if(_ceo('foot_lainx'))echo _ceo('foot_lainx')['foot_lainx_link']; ?>"><i class="ceofont <?php if(_ceo('foot_lainx'))echo _ceo('foot_lainx')['foot_lainx_icon']; ?>"></i><?php if(_ceo('foot_lainx'))echo _ceo('foot_lainx')['foot_lainx_title']; ?></a>
                            	    </div>
                                    <?php if(_ceo('foot_lainx'))echo _ceo('foot_lainx')['foot_lainx_desc']; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php if (is_home()) { ?>
                <?php if(_ceo('link_show') == true ): ?>
                <div class="ceo-container">
                    <div class="foot-link">
                		<div class="link">
                			<ul class="ceo-margin-remove ceo-text-small">
                				<li style="margin-right: 15px;"><i class="ceofont ceoicon-user-star-line"></i> 友情链接：</li><?php $wp_list_bookmarks=wp_list_bookmarks('title_li=&echo=0');
                                echo preg_replace('#<img src="(.*?)"  alt="(.*?)".*?/>#', "$2", $wp_list_bookmarks);
    							?>
    							<li>
    							    <a href="tencent://Message/?Uin=<?php if(_ceo('goTop_service_sz'))echo _ceo('goTop_service_sz')['goTop_qq_qq']; ?>&amp;websiteName=#=&amp;Menu=yes" rel="noreferrer nofollow">
    							        <i class="ceofont ceoicon-qq-fill"></i> 友链申请+
    						        </a>
    					        </li>
                			</ul>
                		</div>
                    </div>
                </div>
                <?php endif; ?>
                <?php } ?>
                
                <div class="foot-cop">
                    <div class="ceo-flex ceo-flex-middle ceo-container">
                        <div class="ceo-flex-1">
                            <span class="ceo-visible@s"><?php echo _ceo('cop_text'); ?></span>
                            <?php if(_ceo('foot_xml-y') == true): ?>
                            <span class="ceo-visible@s"><a href="<?php echo _ceo('foot_xml'); ?>" target="_blank"><i class="ceofont ceoicon-map-pin-fill" aria-hidden="true"></i> 网站地图</a>
                            </span>
                            <?php endif; ?>
                            
                            <?php if(_ceo('foot_gongan') == true): ?>
    						<span class="ceo-margin-small-right ceo-gongan"><a href="http://www.beian.gov.cn/" target="_blank" rel="noreferrer nofollow"><img src="<?php bloginfo('template_url'); ?>/static//images/ceo-110.png" height="6"><?php echo _ceo('foot_gongan_beianhao'); ?></a>
    						</span>
    						<?php endif; ?>
    						
                            <?php if(_ceo('show_beian') == true): ?>
                            <span class="ceo-display-inline-block"><a href="https://beian.miit.gov.cn/" target="_blank" rel="noreferrer nofollow"><?php echo _ceo('beian'); ?></a>
                            </span>
                            <?php endif; ?>
                        </div>
                        <div class="foot-cop-y ceo-margin-remove ceo-padding-remove">
                            <?php if(_ceo('theme_cop') == true): ?>
                            <span>Theme By <a href="https://www.ceotheme.com/" target="_blank" rel="noreferrer nofollow">CeoTheme</a></span>
                            <?php endif; ?>
    			        </div>
                    </div>
                </div>
                <?php if( is_user_logged_in() ){ ?>
                <?php }else{ ?>
	            <?php get_template_part( 'template-parts/navbar/navbar', 'login' ); ?>
		        <?php } ?>
			    <?php wp_footer(); ?>
		    </footer>
		</div>
		<?php get_template_part( 'template-parts/navbar/navbar', 'mob' ); ?>
		<?php get_template_part( 'template-parts/footer/footer', 'js' ); ?>
		<?php if(_ceo('ceo_app_foo') == true): ?>
		<?php get_template_part( 'template-parts/footer/footer', 'nav' ); ?>
		<?php endif; ?>
        <!-- CeoEdu-Pro主题 -->
        <div id="ceoshop-member-box"></div>
</body>
</html>