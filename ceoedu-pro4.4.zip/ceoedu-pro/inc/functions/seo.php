<?php
$website_title = _ceo('website_title');
$website_keywords = _ceo('website_keywords');
$website_description = _ceo('website_description');
?>
<title><?php
	if ( is_home() ) {
		if ($website_title == null) {
			echo '请在后台主题设置填写网站名称 - 总裁主题';
		}else {
			echo $website_title;
		}
	}elseif ( is_category() ) {
        $cat_ID  = get_query_var('cat');
        $seo_str = get_term_meta($cat_ID, 'seo-title', true);
        if($seo_str){
            echo $seo_str;
        }else{
            _e(trim(wp_title('', 0)));
        }
        _e(' - ');
        $paged = get_query_var('paged');
        if ($paged > 1) {
            printf('第%s页 - ', $paged);
        }
        bloginfo('name');
	}elseif ( is_tax('special') ) {
        $cat_ID  = get_queried_object_id();
        $seo_str = get_term_meta($cat_ID, 'seo-title', true);
        if($seo_str){
            echo $seo_str;
        }else{
            _e(trim(wp_title('', 0)));
        }
        _e(' - ');
        $paged = get_query_var('paged');
        if ($paged > 1) {
            printf('第%s页 - ', $paged);
        }
        bloginfo('name');
    }elseif ( get_post_type() == 'site'  ) {
		_e(trim(wp_title('',0)));_e(' - ');bloginfo('name');
	}elseif ( is_single() ){
        $seo_title = get_post_meta(get_the_ID(), 'ceo-seo-title', 1);
        if($seo_title){
            echo $seo_title.(' - ').get_bloginfo('name');
        }else{
            _e(trim(wp_title('',0)));_e(' - ');bloginfo('name');
        }
	}elseif ( is_search() ) {
		_e('搜索 '); $key = wp_specialchars($s, 1); _e($key.' '); _e('的相关内容 - ');$paged = get_query_var('paged'); if ( $paged > 1 ) printf('第%s页 - ',$paged); bloginfo('name');
	}elseif ( is_404() ) {
		_e('抱歉，您访问的页面走丢了 - '); bloginfo('name');
	}elseif ( is_author() ) {
		_e('「');_e(trim(wp_title('',0)));_e('」的个人主页 - ');bloginfo('name');
	}elseif(is_page()){
		_e(trim(wp_title('',0)));_e(' - ');$paged = get_query_var('paged'); if ( $paged > 1 ) printf('第%s页 - ',$paged); bloginfo('name');
	}elseif ( is_month() ) {
		the_time('Y年n月');_e('的文章归档');_e(' - ');$paged = get_query_var('paged'); if ( $paged > 1 ) printf('第%s页 - ',$paged); bloginfo('name');
	}elseif ( is_day() ) {
		the_time('Y年n月j日');_e('的文章归档');_e(' - ');$paged = get_query_var('paged'); if ( $paged > 1 ) printf('第%s页 - ',$paged); bloginfo('name');
	}elseif ( is_tag() ) {
        _e('');single_tag_title("", true);_e(' 相关文章列表');_e(' - ');$paged = get_query_var('paged'); if ( $paged > 1 ) printf('第%s页 - ',$paged); bloginfo('name');
    }else{
        if(!empty(get_queried_object_id())){
	        $term_current=get_term(get_queried_object_id());
	        echo $term_current->name;
        }else if(is_archive() && get_post_type() == 'question'){
            echo '问答社区 - ';bloginfo('name');
        }else if(is_archive() && get_post_type() == 'forum' && $_SERVER['REQUEST_URI'] == '/forum'){
            echo '论坛大厅 - ';bloginfo('name');
        }else{
            echo get_the_title();
        }
    }
	?>
</title>
<?php
$keywords = $website_keywords;
$description = $website_description;
if (is_home()){
	$keywords = $keywords;
	$description = $description;
} elseif ( is_category() ) {
    $description = category_description();
    $keywords = $keywords;


    if ($cate_keywords_custom = get_term_meta($cat, 'cate_keywords_custom', 1)) {
        $keywords = trim($cate_keywords_custom);
    }

    //关键词与描述seo
    $cat_ID              = get_query_var('cat');
    $seo_str_keywords    = get_term_meta($cat_ID, 'seo-keywords', true);
    $seo_str_description = get_term_meta($cat_ID, 'seo-description', true);
    if ($seo_str_keywords) {
        $keywords = $seo_str_keywords;
    }
    if ($seo_str_description) {
        $description = $seo_str_description;
    }
} elseif ( is_tax('sitecat') ) {
        $description=trim(strip_tags(get_term_field( 'description', get_queried_object()->term_id )));
		$keywords = $keywords;
    if ($cate_keywords_custom = get_term_meta(get_queried_object()->term_id, 'cate_keywords_custom', 1)) {
        $keywords = trim($cate_keywords_custom);
    }
} elseif ( is_tax('special') ) {
    $description=get_term_meta(get_queried_object_id(),'seo-description',1);
    $keywords = $keywords;
    if ($cate_keywords_custom = get_term_meta(get_queried_object_id(),'seo-keywords',1)) {
        $keywords = trim($cate_keywords_custom);
    }
} elseif (is_single()){
    $keywords = '';
	$single_cat = get_the_category();
	$single_cat_id = $single_cat[0]->cat_ID;
	if(wp_get_post_tags($post->ID)){
		$tags = wp_get_post_tags($post->ID);
		foreach ($tags as $tag ) {
			$keywords = $tag->name.",".$keywords;
		}
	}else{
		$keywords = $website_keywords;
	}
	if ($post->post_excerpt) {
		$description = $post->post_excerpt;
	}else {
		global $more;
		$more = 1; //1=全文 0=摘要
		$my_content = strip_tags(get_the_excerpt(), $post->post_content); //获得文章
		$my_content = str_replace(array('rn', 'r', 'n', ' ', 't', 'o', 'x0B',''),'',$my_content); //去掉空格
		$my_content = mb_strimwidth( $my_content, 0, 180, '...');
		$description = $my_content;
	}
	    if($keywords){
            $keywords=trim($keywords,',');
        }

    if ( ! empty(get_post_meta(get_the_ID(), 'ceo-seo-keywords', 1))) {
        $keywords = get_post_meta(get_the_ID(), 'ceo-seo-keywords', 1);
    }
    if ( ! empty(get_post_meta(get_the_ID(), 'ceo-seo-description', 1))) {
        $description = trim(get_post_meta(get_the_ID(), 'ceo-seo-description', 1));
    }

} elseif(function_exists('is_tag')){
	if( is_tag() ) {
        $keywords = '';
		$keywords = trim(wp_title('',0));
		$description = trim(wp_title('',0));
	}
}if ( is_search() ) {
	$keywords = $index_keywords;
	$description = $key;
}?>
<meta name="keywords" content="<?php echo $keywords; ?>" />
<meta name="description" content="<?php echo $description; ?>" />
<?php if(_ceo('seo_open_graph')):?>
<?php
    if(is_singular() && !is_front_page()){
        global $paged;
        if(!$paged){$paged = 1;}
        $url = get_pagenum_link($paged);

        $img_url = get_the_post_thumbnail_url($post->ID, 'full');
        $GLOBALS['post-thumb'] = $img_url;
        if(!$img_url){
            preg_match_all('/<img[^>]*src=[\'"]([^\'"]+)[\'"].*>/iU', $post->post_content, $matches);
            if(isset($matches[1]) && isset($matches[1][0])){
                $img_url = $matches[1][0];
            }
        }

        $image = $img_url ? $img_url : $wx_thumb;

        $type = 'article';
        if(is_singular('page')){
            $type = 'webpage';
        }else if(is_singular('product')){
            $type = 'product';
        }
        $seo .= '<meta property="og:type" content="'.$type.'" />' . "\n";
        $seo .= '<meta property="og:url" content="'.$url.'" />' . "\n";
        $seo .= '<meta property="og:site_name" content="'.esc_attr(get_bloginfo( "name" )).'" />' . "\n";
        $seo .= '<meta property="og:title" content="'.esc_attr($post->post_title).'" />' . "\n";
        if($image) $seo .= '<meta property="og:image" content="'.esc_url($image).'" />' . "\n";
        if ($description) $seo .= '<meta property="og:description" content="'.esc_attr(trim(strip_tags($description))).'" />' . "\n";
    }else if (is_home() || is_front_page()) {
        global $page;
        if(!$page){$page = 1;}
        $url = get_pagenum_link($page);

        $image = $wx_thumb;
        $title = isset($options['home-title']) ? $options['home-title'] : '';;

        if($title=='') {
            $desc = get_bloginfo('description');
            if ($desc) {
                $title = get_option('blogname') . (isset($options['title_sep_home']) && $options['title_sep_home'] ? $options['title_sep_home'] : ' - ') . $desc;
            } else {
                $title = get_option('blogname');
            }
        }

        $seo .= '<meta property="og:type" content="webpage" />' . "\n";
        $seo .= '<meta property="og:url" content="'.$url.'" />' . "\n";
        $seo .= '<meta property="og:site_name" content="'.esc_attr(get_bloginfo( "name" )).'" />' . "\n";
        $seo .= '<meta property="og:title" content="'.esc_attr($title).'" />' . "\n";
        if($image) $seo .= '<meta property="og:image" content="'.esc_url($image).'" />' . "\n";
        if ($description) $seo .= '<meta property="og:description" content="'.esc_attr(trim(strip_tags($description))).'" />' . "\n";
    } else if (is_category() || is_tag() || is_tax() ) {
        global $paged;
        if(!$paged){$paged = 1;}
        $url = get_pagenum_link($paged);
        $image = $wx_thumb;

        $seo .= '<meta property="og:type" content="webpage" />' . "\n";
        $seo .= '<meta property="og:url" content="'.$url.'" />' . "\n";
        $seo .= '<meta property="og:site_name" content="'.esc_attr(get_bloginfo( "name" )).'" />' . "\n";
        $seo .= '<meta property="og:title" content="'.esc_attr(single_cat_title('', false)).'" />' . "\n";
        if($image) $seo .= '<meta property="og:image" content="'.esc_url($image).'" />' . "\n";
        if ($description) $seo .= '<meta property="og:description" content="'.esc_attr(trim(strip_tags($description))).'" />' . "\n";
    }

    if( ( (isset($options['xzh-appid']) && $options['xzh-appid']) || (isset($options['canonical']) && $options['canonical']=='1') ) && is_singular() ){
        $id = get_queried_object_id();
        if ( 0 !== $id && $url = wp_get_canonical_url( $id )) {
            $seo .= '<link rel="canonical" href="' . esc_url( $url ) . '" />' . "\n";
        }
    }
    echo $seo;
        ?>
<?php endif;?>
