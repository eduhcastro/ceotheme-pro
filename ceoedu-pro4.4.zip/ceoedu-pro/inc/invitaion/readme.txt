=== Ashuwp invitaion code ===
Contributors: ashuwp
Donate link: http://www.ashuwp.com
Tags: Invitation code, Register
Requires at least: 4.5
Tested up to: 4.9
Stable tag:4.9
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Ashuwp_Invitation_Code is a wordpress plugin, It helps adding invitation codes for your site.
Worked at multiste, Compatibility with buddypress.

= Plugin Page =
[Plugin page](http://www.ashuwp.com/package/ashuwp_invitation_code)
[Demo](http://register.ashuwp.com/)

== Installation ==

1. Download Ashuwp invitaion code.
2. Upload the ‘ashuwp_invitaion_code’ directory to your ‘/wp-content/plugins/’ directory, using your favorite method (ftp, sftp, scp, etc…).
3. Activate Ashuwp invitaion code from your Plugins page. 

== Screenshots ==

1. screenshot-1.png
2. screenshot-2.png
3. screenshot-3.png
4. screenshot-4.png


== Changelog ==

= 1.0 =
publish 2017-06-23.

= 1.1 =
Sanitized POST calls.

= 1.2 =
Compatible with version less than php5.5

= 1.3 =
Add invitation options.
Fix some bugs.

== Upgrade Notice ==

= 1.0 =
No more

= 1.1 =
Sanitized POST calls.

= 1.2 =
Compatible with version less than php5.5

= 1.3 =
Add invitation options.
Fix some bugs.