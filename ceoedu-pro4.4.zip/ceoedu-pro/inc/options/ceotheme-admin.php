<?php if (! defined('ABSPATH')) { die; }
/**
 * CeoEdu-Pro主题是一款轻量级，且简洁大气、强大的WordPress教育专类型主题。
 * 正版唯一购买地址：https://www.ceotheme.com/
 * 作者总裁QQ：110300260 （总裁）
 * CeoEdu-Pro主题定位于教育资源行业，当然也适用于各类资源站，同时也适用于企业站、企业产品展示等全方位覆盖，线上付费/免费产品下载全系列行业终端。
 * 能理解使用盗版的人，但是不能接受传播盗版。
 * CeoTheme总裁主题制作的CeoEdu-Pro主题正版用户可享受该主题不限制域名，不限制数量，无限授权，仅限本人享有此特权，外泄主题包将取消授权资格！
 * 开发者不易，感谢支持，全天候在线客户服务+技术支持为您服务。
 */
 


if (class_exists('CSF')) {
    $ceotheme = 'ceoedu';
    CSF::createOptions($ceotheme, array(
        'menu_title'      => 'CeoEdu-Pro主题设置',
        'menu_slug'       => 'my-framework',
        'framework_title' => '<i class="fa fa-laptop"></i> CeoEdu-Pro主题  │ <small><a href="https://www.ceotheme.com" target="_blank" style="text-decoration:none;color:#fff;">Theme By 总裁主题 CeoTheme.com</a></small>',
    ));

    /*
     * ------------------------------------------------------------------------------
     * 基本设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id'      => 'ceotheme_basic',
        'icon'    => 'fa fa-cog',
        'title'   => '基本设置',
        'fields'  => array(
            array(
                'id'           => 'head_logo',
                'type'         => 'upload',
                'title'        => '网站LOGO图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceotheme-logo.png',
            ),
            array(
                'id'           => 'favicon',
                'type'         => 'upload',
                'title'        => '网站favicon.ico图标',
                'desc'         => '浏览器/收藏夹图标 <a href="https://ico.ceotheme.com/" target="_blank" style="color: #0a8eff;">点击这里立即生成</a> 网站favicon.ico图标',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
            ),
            array(
                'id'     => 'ceo_color',
                'type'   => 'fieldset',
                'title'  => '主题配色设置',
                'fields' => array(
                    array(
                        'id'     => 'ceo_zcolor',
                        'type'   => 'color',
                        'title'  => '主配色',
                        'default'=>'#13C07E',
                    ),
                    array(
                        'id'     => 'ceo_an1color',
                        'type'   => 'color',
                        'title'  => '幻彩按钮1（与下面搭配）',
                        'default'=>'#13C07E',
                        'desc'   => '上下设置的颜色值不一样则是幻彩效果，上下设置的颜色值一样则是设置的传统效果（魔改需谨慎！！！）'
                    ),
                    array(
                        'id'     => 'ceo_an2color',
                        'type'   => 'color',
                        'title'  => '幻彩按钮2（与上面搭配）',
                        'default'=>'#00E766',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （用户组名称设置）',
            ),
            array(
                'id'     => 'user_group_name',
                'type'   => 'fieldset',
                'title'  => '用户组名称',
                'fields' => array(
                    array(
                        'id'      => 'user_admin',
                        'type'    => 'text',
                        'title'   => '管理员',
                        'desc'    => '管理员 用户组名称修改',
                        'default' => '管理员',
                    ),
                    array(
                        'id'      => 'user_edit',
                        'type'    => 'text',
                        'title'   => '编辑',
                        'desc'    => '编辑 用户组名称修改',
                        'default' => '编辑',
                    ),
                    array(
                        'id'      => 'user_author',
                        'type'    => 'text',
                        'title'   => '作者',
                        'desc'    => '作者 用户组名称修改',
                        'default' => '作者',
                    ),
                    array(
                        'id'      => 'user_contributor',
                        'type'    => 'text',
                        'title'   => '贡献者',
                        'desc'    => '贡献者 用户组名称修改',
                        'default' => '贡献者',
                    ),
                    array(
                        'id'      => 'user_subscriber',
                        'type'    => 'text',
                        'title'   => '订阅者',
                        'desc'    => '订阅者 用户组名称修改',
                        'default' => '订阅者',
                    ),
                ),
            ),
        ),

    ));

    /*
     * ------------------------------------------------------------------------------
     * SEO设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id'     => 'ceotheme_seo',
        'icon'   => 'fa fa-desktop',
        'title'  => 'SEO设置',
        'fields' => array(
            array(
                'id'    => 'website_title',
                'type'  => 'text',
                'title' => '网站标题',
            ),
            array(
                'id'    => 'website_keywords',
                'type'  => 'text',
                'title' => '网站关键词',
            ),
            array(
                'id'    => 'website_description',
                'type'  => 'textarea',
                'title' => '网站描述',
            ),
            array(
                'id'       => 'category',
                'type'     => 'switcher',
                'title'    => '去掉分类目录中的category',
                'default'  => true,
                'subtitle' => '去掉分类目录中的category，精简URL，有利于SEO，推荐去掉',
            ),
            array(
                'id'           => 'seo_open_graph',
                'type'         => 'switcher',
                'title'        => '是否开启Open Graph协议',
                'default'      => true,
            ),

        )
    ));

    /*
     * ------------------------------------------------------------------------------
     * 顶部设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id' => 'ceotheme_top',
        'icon'   => 'fa fa-paper-plane',
        'title' => '顶部设置',
    ));
    CSF::createSection($ceotheme, array(
        'parent'     => 'ceotheme_top',
        'title'  => '导航按钮设置',
        'fields' => array(
            array(
                'id'      => 'navbar_sticky',
                'type'    => 'switcher',
                'title'   => '顶部导航跟随',
                'desc'    => '开启或关闭顶部导航跟随 （默认开启）',
                'default' => true
            ),
            array(
                'id'      => 'navbar_search',
                'type'    => 'switcher',
                'title'   => '顶部导航搜索按钮',
                'desc'    => '开启或关闭顶部导航搜索按钮（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            array(
                'id'         => 'navbar_search_h',
                'type'       => 'switcher',
                'dependency' => array( 'navbar_search', '==', true ),
                'title'      => '搜索框热门标签',
                'desc'       => '开启或关闭弹出搜索框热门标签（开启则显示，关闭则隐藏）',
                'default'    => true
            ),
            array(
                'id'      => 'navbar_user',
                'type'    => 'switcher',
                'title'   => '顶部导航登录注册按钮',
                'desc'    => '开启或关闭顶部导航登录注册按钮（开启则显示，关闭则隐藏）',
                'default' => true
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent'     => 'ceotheme_top',
        'title'  => '顶部用户弹窗',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '以下默认参数正常情况下无需修改！',
            ),
            array(
                'id'      => 'ceo_user_t_yexf',
                'type'    => 'switcher',
                'title'   => '余额/消费模块',
                'desc'    => '开启或关闭余额/消费模块（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_user_t_vip',
                'type'    => 'switcher',
                'title'   => 'VIP级别/升级VIP',
                'desc'    => '开启或关闭VIP级别/升级VIP模块（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'         => 'ceo_user_t_vip_sz',
                'type'       => 'fieldset',
                'dependency' => array('ceo_user_t_vip', '==', true),
                'title'      => 'VIP模块设置',
                'fields'     => array(
                    array(
                        'id'      => 'ceo_user_t_vip_title',
                        'type'    => 'text',
                        'title'   => 'VIP标题',
                        'default' => '升级VIP',
                    ),
                    array(
                        'id'      => 'ceo_user_t_vip_link',
                        'type'    => 'text',
                        'title'   => '升级链接',
                        'default' => '/member/center/',
                    ),
                    array(
                        'id'      => 'ceo_user_t_vip_desc',
                        'type'    => 'text',
                        'title'   => 'VIP描述',
                        'default' => '升级VIP尊享全站海量下载！',
                    ),
                ),
            ),
            array(
                'id'         => 'ceo_user_gr_sz',
                'type'       => 'fieldset',
                'title'      => '个人中心按钮设置',
                'fields'     => array(
                    array(
                        'id'      => 'ceo_user_gr_title',
                        'type'    => 'text',
                        'title'   => '按钮标题',
                        'default' => '个人中心',
                    ),
                    array(
                        'id'      => 'ceo_user_gr_icon',
                        'type'    => 'text',
                        'title'   => '按钮图标',
                        'default' => 'ceoicon-user-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'ceo_user_gr_link',
                        'type'    => 'text',
                        'title'   => '按钮链接',
                        'default' => '/user',
                    ),
                ),
            ),
            array(
                'id'         => 'ceo_user_sc_sz',
                'type'       => 'fieldset',
                'title'      => '商城中心按钮设置',
                'fields'     => array(
                    array(
                        'id'      => 'ceo_user_sc_title',
                        'type'    => 'text',
                        'title'   => '按钮标题',
                        'default' => '商城中心',
                    ),
                    array(
                        'id'      => 'ceo_user_sc_icon',
                        'type'    => 'text',
                        'title'   => '按钮图标',
                        'default' => 'ceoicon-shopping-cart-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'ceo_user_sc_link',
                        'type'    => 'text',
                        'title'   => '按钮链接',
                        'default' => '/member/center/',
                    ),
                ),
            ),
            array(
                'id'         => 'ceo_user_tg_sz',
                'type'       => 'fieldset',
                'title'      => '投稿按钮设置',
                'fields'     => array(
                    array(
                        'id'      => 'ceo_user_tg_title',
                        'type'    => 'text',
                        'title'   => '按钮标题',
                        'default' => '创作中心',
                    ),
                    array(
                        'id'      => 'ceo_user_tg_link',
                        'type'    => 'text',
                        'title'   => '按钮链接',
                        'default' => '/tougao',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent'     => 'ceotheme_top',
        'title'  => '顶部导航条设置',
        'fields' => array(
            array(
                'id'      => 'navbar_top',
                'type'    => 'switcher',
                'title'   => '顶部导航条',
                'desc'    => '开启或关闭顶部导航条（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            array(
                'id'      => 'navbar_top_bg',
                'type'    => 'color',
                'title'   => '导航条背景颜色',
                'dependency' => array('navbar_top', '==', true),
                'default' => '#0c1529'
            ),
            array(
                'id'      => 'navbar_top_color',
                'type'    => 'color',
                'title'   => '导航条字体颜色',
                'dependency' => array('navbar_top', '==', true),
                'default' => '#ffffffb3'
            ),
            array(
                'type'       => 'notice',
                'style'      => 'warning',
                'dependency' => array('navbar_top', '==', true),
                'content'    => '分割线 （顶部导航条左侧设置）',
            ),
            array(
                'id'         => 'navbar_top_z_sz',
                'type'       => 'repeater',
                'title'      => '左侧弹窗设置',
                'dependency' => array('navbar_top', '==', true),
                'fields'     => array(
                    array(
                        'id'           => 'title',
                        'type'         => 'text',
                        'title'        => '按钮标题',
                        'default'      => '手机版'
                    ),
                    array(
                        'id'           => 'icon',
                        'type'         => 'text',
                        'title'        => '按钮图标',
                        'default'      => 'ceoicon-smartphone-line',
                        'desc'         => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'           => 'img',
                        'type'         => 'upload',
                        'title'        => '弹窗图片',
                        'library'      => 'image',
                        'placeholder'  => 'http://',
                        'button_title' => '上传',
                        'remove_title' => '删除',
                        'default'      => get_template_directory_uri() . '/static/images/ceo-ma.png',
                    ),
                    array(
                        'id'           => 'tctitle',
                        'type'         => 'text',
                        'title'        => '弹窗标题',
                        'default'      => '扫码体验手机版'
                    ),
                ),
            ),
            array(
                'type'       => 'notice',
                'style'      => 'warning',
                'dependency' => array('navbar_top', '==', true),
                'content'    => '分割线 （顶部导航条右侧设置）',
            ),
            array(
                'id'         => 'navbar_top_y_tc',
                'type'       => 'fieldset',
                'title'      => '右侧按钮弹窗设置',
                'dependency' => array('navbar_top', '==', true),
                'fields'     => array(
                    array(
                        'id'           => 'y_tc_an_title',
                        'type'         => 'text',
                        'title'        => '按钮标题',
                        'default'      => '加入VIP'
                    ),
                    array(
                        'id'           => 'y_tc_an_icon',
                        'type'         => 'text',
                        'title'        => '按钮图标',
                        'default'      => 'ceoicon-vip-crown-2-line',
                        'desc'         => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'           => 'y_tc_bq',
                        'type'         => 'text',
                        'title'        => '弹窗标签',
                        'default'      => '限时优惠'
                    ),
                    array(
                        'id'           => 'y_tc_title',
                        'type'         => 'text',
                        'title'        => '弹窗标题',
                        'default'      => '加入VIP尊享特权'
                    ),
                    array(
                        'id'         => 'y_tc_sz',
                        'type'       => 'repeater',
                        'title'      => '弹窗内容设置',
                        'fields'     => array(
                            array(
                                'id'           => 'icon',
                                'type'         => 'text',
                                'title'        => '图标',
                                'default'      => 'ceoicon-copper-diamond-line',
                                'desc'         => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                            ),
                            array(
                                'id'           => 'title',
                                'type'         => 'text',
                                'title'        => '标题',
                                'default'      => 'VIP尊享特权'
                            ),
                            array(
                                'id'           => 'describe',
                                'type'         => 'text',
                                'title'        => '描述',
                                'default'      => 'VIP会员尊享海量资源无限下载'
                            ),
                        ),
                    ),
                    array(
                        'id'           => 'y_tc_antitle',
                        'type'         => 'text',
                        'title'        => '弹窗按钮标题',
                        'default'      => '立即开通VIP'
                    ),
                    array(
                        'id'           => 'y_tc_anlink',
                        'type'         => 'text',
                        'title'        => '弹窗按钮标题链接',
                        'default'      => '/vip'
                    ),
                ),
            ),
            array(
                'id'         => 'y_an_sz',
                'type'       => 'repeater',
                'dependency' => array('navbar_top', '==', true),
                'title'      => '右侧按钮设置',
                'fields'     => array(
                    array(
                        'id'           => 'icon',
                        'type'         => 'text',
                        'title'        => '按钮图标',
                        'default'      => 'ceoicon-trophy-line',
                        'desc'         => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'           => 'title',
                        'type'         => 'text',
                        'title'        => '按钮标题',
                        'default'      => '充值积分'
                    ),
                    array(
                        'id'           => 'link',
                        'type'         => 'text',
                        'title'        => '按钮链接',
                        'default'      => '/member/center/'
                    ),
                ),
            ),
        )
    ));

    /*
     * ------------------------------------------------------------------------------
     * 用户中心
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id'    => 'ceotheme_user',
        'icon'  => 'fa fa-user',
        'title' => '用户中心',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_user',
        'title'  => '基本设置 ',
        'fields' => array(
            array(
                'id'           => 'side_author_homeimg',
                'type'         => 'upload',
                'title'        => '用户个人主页背景图片',
                'desc'         => '用户个人主页默认背景图，用户也可以在个人中心独立设置用户个人主页背景图~未独立设置则自动调用该设置中默认背景图',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （用户中心快捷按钮设置）',
            ),
            array(
                'id'      => 'ceo_author_ank',
                'type'    => 'switcher',
                'title'   => '用户快捷按钮',
                'desc'    => '开启或关闭用户快捷按钮（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'         => 'ceo_author_ank_sz',
                'type'       => 'fieldset',
                'title'      => '用户快捷按钮设置',
                'dependency' => array('ceo_author_ank', '==', true),
                'fields'     => array(
                    array(
                        'id'      => 'author_ank_title1',
                        'type'    => 'text',
                        'title'   => '按钮1标题',
                        'default' => '创作中心',
                    ),
                    array(
                        'id'      => 'author_ank_icon1',
                        'type'    => 'text',
                        'title'   => '按钮1图标',
                        'default' => 'ceoicon-edit-box-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'author_ank_link1',
                        'type'    => 'text',
                        'title'   => '按钮1链接',
                        'default' => '/tougao',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                    array(
                        'id'      => 'author_ank_title2',
                        'type'    => 'text',
                        'title'   => '按钮2标题',
                        'default' => '商城中心',
                    ),
                    array(
                        'id'      => 'author_ank_icon2',
                        'type'    => 'text',
                        'title'   => '按钮2图标',
                        'default' => 'ceoicon-shopping-cart-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'author_ank_link2',
                        'type'    => 'text',
                        'title'   => '按钮2链接',
                        'default' => '/member/center/',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （用户中心菜单设置，以下功能开启则显示，关闭则隐藏）',
            ),
            array(
                'id'      => 'ceo_author_cd1',
                'type'    => 'switcher',
                'title'   => '我的发布',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_author_cd2',
                'type'    => 'switcher',
                'title'   => '我的收藏',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_author_cd3',
                'type'    => 'switcher',
                'title'   => '我的关注',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_author_cd4',
                'type'    => 'switcher',
                'title'   => '我的私信',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_author_cd5',
                'type'    => 'switcher',
                'title'   => '我的帖子',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_author_cd6',
                'type'    => 'switcher',
                'title'   => '我的提问',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_author_cd7',
                'type'    => 'switcher',
                'title'   => '我的评论',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_author_cd8',
                'type'    => 'switcher',
                'title'   => '网站收录',
                'default' => true,
            ),
            array(
                'id'       => 'ceo_author_cd8x',
                'type'     => 'textarea',
                'dependency' => array('ceo_author_cd8', '==', true),
                'title'    => '网站收录提示信息',
                'desc'     => '请务必按照以上格式修改或添加',
                'default'  => '<p>欢迎优质网站提交收录，本站免费收录，提交后需后台审核，请勿重复提交。</p>
<p>申请网站收录前请先加上本站链接；</p>
<p>本站不收录违法违规站点；</p>
<p>禁止一切产品营销、广告联盟类型的站点，优先通过原创、内容相近的网站；</p>',
            ),

        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_user',
        'title'  => '登录注册 ',
        'fields' => array(
            array(
                'id'      => 'navbar_login',
                'type'    => 'button_set',
                'title'   => '登录注册模式',
                'options' => array(
                    '1' => '弹窗模式',
                    '2' => '页面模式',
                ),
                'default' => '1',
                'desc'    => '（默认弹窗模式）选择弹窗模式时可在任意界面弹出登录注册框，页面模式则跳转登录注册页面。',
            ),
            array(
                'id'           => 'login_bg',
                'type'         => 'upload',
                'title'        => '登录注册背景图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
            ),
            array(
                'id'      => 'login_notice',
                'type'    => 'textarea',
                'title'   => '登录注册页面通知文字',
                'default' => '好久不见甚是想念。',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （邀请码注册设置）',
            ),
            array(
                'id'      => 'is_invitaion_code',
                'type'    => 'switcher',
                'title'   => '邀请码注册',
                'desc'    => '开启或关闭邀请码注册功能（开启则需要填写正确邀请码才能注册，关闭则无需）提示：在后台菜单左侧的 <a href="/wp-admin/admin.php?page=invitation_code_add" style="color: #0a8eff;">“邀请码”</a> 中生成邀请码',
                'default' => false,
            ),
            array(
                'id'      => 'is_invitaion_title',
                'type'    => 'text',
                'title'   => '按钮标题',
                'default' => '获取邀请码',
                'dependency' => array('is_invitaion_code', '==', true),
            ),
            array(
                'id'      => 'is_invitaion_link',
                'type'    => 'text',
                'title'   => '按钮链接',
                'dependency' => array('is_invitaion_code', '==', true),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （表单登录/注册设置）',
            ),
            array(
                'id'      => 'ceo_login_txt',
                'type'    => 'switcher',
                'title'   => '表单登录/注册',
                'desc'    => '开启或关闭表单账号密码登录/注册（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_login_zcxy',
                'type'    => 'text',
                'title'   => '注册协议标题',
                'default' => '《注册协议》',
                'dependency' => array('ceo_login_txt', '==', true),
            ),
            array(
                'id'      => 'ceo_login_zcxy_link',
                'type'    => 'text',
                'title'   => '注册协议链接',
                'dependency' => array('ceo_login_txt', '==', true),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （QQ登录设置）',
            ),
            array(
                'id'      => 'qq_login',
                'type'    => 'switcher',
                'title'   => 'QQ登录',
                'default' => false,
            ),
            array(
                'type'       => 'content',
                'content'    => 'QQ登录申请：<a href="https://connect.qq.com" target="_blank">点击去申请</a>',
                'dependency' => array('qq_login', '==', true),
            ),
            array(
                'type'       => 'content',
                'content'    => 'QQ回调地址：'. get_stylesheet_directory_uri() . '/qq.php',
                'dependency' => array( 'qq_login', '==', true ),
            ),
            array(
                'id'         => 'qq_app_id',
                'type'       => 'text',
                'title'      => 'QQ-APP ID',
                'attributes' => array('style'=> 'width: 100%;'),
                'dependency' => array( 'qq_login', '==', true ),
            ),
            array(
                'id'         => 'qq_app_key',
                'type'       => 'text',
                'title'      => 'QQ-APP KEY',
                'attributes' => array('style'=> 'width: 100%;'),
                'dependency' => array( 'qq_login', '==', true ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （微信登录设置）',
            ),
            // 微信登录
            array(
                'id'      => 'weixin_login',
                'type'    => 'switcher',
                'title'   => '微信登录（开放平台模式）',
                'default' => false,
            ),
            array(
                'type'       => 'content',
                'content'    => '微信登录申请：<a href="https://open.weixin.qq.com/" target="_blank">点击去申请</a>',
                'dependency' => array('weixin_login', '==', true),
            ),
            array(
                'id'         => 'oauth_weixin',
                'type'       => 'fieldset',
                'title'      => '微信登录配情',
                'fields'     => array(
                    array(
                        'id'         => 'backurl',
                        'type'       => 'text',
                        'title'      => '开放平台 回调地址',
                        'attributes' => array(
                            'readonly' => 'readonly',
                        ),
                        'default' => esc_url(home_url('')).'/oauth/weixin/callback',
                        'desc'    => '更换域名时请重置当前分区即可刷新为最新回调地址，操作前注意备份appid参数<br />注意：回调地址只需填写网站域名，无需填写http://或https://<br />例：www.ceotheme.com',
                    ),
                    array(
                        'id'      => 'appid',
                        'type'    => 'text',
                        'title'   => '开放平台 Appid',
                        'default' => '',
                    ),
                    array(
                        'id'      => 'appkey',
                        'type'    => 'text',
                        'title'   => '开放平台 AppSecret',
                        'default' => '',
                        'attributes'  => array(
                            'type'      => 'password',
                            'autocomplete' => 'off',
                        ),
                    ),
                ),
                'dependency' => array('weixin_login', '==', 'true'),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （微信公众号登录设置）',
            ),

            // 微信公众号登录
            array(
                'id'      => 'is_oauth_mpweixin',
                'type'    => 'switcher',
                'title'   => '微信公众号登录（公众号模式）',
                'desc'   => '总裁主题提示您：需要认证微信服务号，配置以下信息后，用户首次使用微信注册登录需要在你的网站扫码关注公众号后自动注册并登录，第二次登录直接扫码即可登录，同时可以直接在公众号内登录',
                'default' => false,
            ),
            array(
                'type'       => 'content',
                'content'    => '微信公众号登录申请：<a href="https://mp.weixin.qq.com/" target="_blank">点击去申请</a>',
                'dependency' => array('is_oauth_mpweixin', '==', true),
            ),
            array(
                'id'         => 'oauth_mpweixin',
                'type'       => 'fieldset',
                'title'      => '配置详情',
                'fields'     => array(
                    array(
                        'id'      => 'mp_appid',
                        'type'    => 'text',
                        'title'   => '公众号Appid',
                        'default' => '',
                    ),
                    array(
                        'id'      => 'mp_appsecret',
                        'type'    => 'text',
                        'title'   => '公众号appsecret',
                        'default' => '',
                        'attributes'  => array(
                            'type'      => 'password',
                            'autocomplete' => 'off',
                        ),
                    ),
                    array(
                        'id'      => 'mp_token',
                        'type'    => 'text',
                        'title'   => '公众号Token',
                        'default' => '',
                        'attributes'  => array(
                            'type'      => 'password',
                            'autocomplete' => 'off',
                        ),
                    ),

                    array(
                        'id'         => 'mp_backurl',
                        'type'       => 'text',
                        'title'      => '授权回调页面域名',
                        'attributes' => array(
                            'readonly' => 'readonly',
                        ),
                        'default'    => esc_url(home_url('/oauth/mpweixin/callback')),
                        'desc'    => '更换域名时请重置当前分区即可刷新为最新回调地址，操作前注意备份appid参数',
                    ),
                    array(
                        'id'      => 'mp_msg',
                        'type'    => 'textarea',
                        'title'   => '关注后自动回复的消息',
                        'default' => '您好，感谢关注我们！发送“签到”可获得奖励，发生关键词可搜索站内相关文章~',
                    ),

                ),
                'dependency' => array('is_oauth_mpweixin', '==', 'true'),
            ),

            array(
                'id'     => 'mpweixin_menu',
                'type'   => 'repeater',
                'title'  => '自定义公众号菜单',
                'desc'  => '总裁主题提示您：<br>
自定义公众号菜单可创建3个一级菜单，每个一级菜单可创建5个二级菜单。<br>
一级菜单不超过4个汉字，二级菜单不超过8个汉字，超过的文字会被以“...”代替。<br>',
                'dependency' => array('is_oauth_mpweixin', '==', 'true'),
                'fields' => array(
                    array(
                        'id'      => 'menu_name',
                        'type'    => 'text',
                        'title'   => '菜单名称',
                        'default' => '',
                    ),
                    array(
                        'id'      => 'menu_url',
                        'type'    => 'text',
                        'title'   => '菜单链接',
                        'default' => '',
                        'desc'    => '如果设置了二级菜单，那么一级菜单的菜单链接将会失效，这是公众号的规则。',
                    ),
                    array(
                        'id'     => 'mpweixin_menu_sub',
                        'type'   => 'repeater',
                        'title'  => '二级菜单',
                        'fields' => array(
                            array(
                                'id'      => 'menu_name',
                                'type'    => 'text',
                                'title'   => '菜单名称',
                                'default' => '',
                            ),
                            array(
                                'id'      => 'menu_url',
                                'type'    => 'text',
                                'title'   => '菜单链接',
                                'validate' => 'csf_validate_url',
                                'default' => '',
                            ),
                            array(
                                'type'    => 'notice',
                                'style'   => 'warning',
                                'content' => '分割线',
                            ),
                        ),
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
            array(
                'id'    => 'mpweixin_menu_update',
                'type'  => 'subheading',
                'title' => '刷新公众号菜单',
                'dependency' => array('is_oauth_mpweixin', '==', 'true'),
                'content'       => '<a href="admin-ajax.php?action=mpweixin_menu_update" target="_blank"><input type="button" value="点击刷新公众号菜单"></a> <br /><br />一：创建好公众号菜单，二：点击右上角保存，三：在点击刷新公众号菜单按钮',
            ),

            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （微博登录设置）',
            ),
            array(
                'id'      => 'weibo_login',
                'type'    => 'switcher',
                'title'   => '微博登录',
                'default' => false,
            ),
            array(
                'type'       => 'content',
                'content'    => '微博登录申请：<a href="https://open.weibo.com/authentication/" target="_blank">点击去申请</a>',
                'dependency' => array('weibo_login', '==', true),
            ),
            array(
                'type'       => 'content',
                'content'    => '微博回调地址：'. get_page_link( get_option('joy_framework')['login_page'] ) .'/?type=sina',
                'dependency' => array( 'weibo_login', '==', true ),
            ),
            array(
                'id'         => 'weibo_app_key',
                'type'       => 'text',
                'title'      => '微博 App Key',
                'attributes' => array('style'=> 'width: 100%;'),
                'dependency' => array( 'weibo_login', '==', true ),
            ),
            array(
                'id'         => 'weibo_app_id',
                'type'       => 'text',
                'title'      => '微博 App Secret',
                'attributes' => array('style'=> 'width: 100%;'),
                'dependency' => array( 'weibo_login', '==', true ),
            ),

        )
    ));
    CSF::createSection($ceotheme, array(
        'parent'     => 'ceotheme_user',
        'title'  => '商城中心',
        'fields' => array(
            array(
                'id'      => 'ceo_user_member_btn',
                'type'    => 'switcher',
                'title'   => '商城快捷按钮',
                'desc'    => '开启或关闭商城快捷按钮（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'         => 'ceo_user_member_btn_set',
                'type'       => 'fieldset',
                'title'      => '商城快捷按钮设置',
                'dependency' => array('ceo_user_member_btn', '==', true),
                'fields'     => array(
                    array(
                        'id'      => 'title1',
                        'type'    => 'text',
                        'title'   => '按钮1标题',
                        'default' => '创作中心',
                    ),
                    array(
                        'id'      => 'icon1',
                        'type'    => 'text',
                        'title'   => '按钮1图标',
                        'default' => 'ceoicon-edit-box-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'link1',
                        'type'    => 'text',
                        'title'   => '按钮1链接',
                        'default' => '/tougao',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                    array(
                        'id'      => 'title2',
                        'type'    => 'text',
                        'title'   => '按钮2标题',
                        'default' => '个人中心',
                    ),
                    array(
                        'id'      => 'icon2',
                        'type'    => 'text',
                        'title'   => '按钮2图标',
                        'default' => 'ceoicon-user-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'link2',
                        'type'    => 'text',
                        'title'   => '按钮2链接',
                        'default' => '/user',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent'     => 'ceotheme_user',
        'title'  => '创作中心',
        'fields' => array(
            array(
                'id'         => 'tougao_down_url_upload',
                'type'       => 'switcher',
                'title'      => '创作中心上传资源',
                'default'    => false,
                'desc'       => '开启或关闭创作中心上传资源（开启则允许直接上传资源，关闭则不允许）',
            ),
            array(
                'id'          => 'tougao_cat_ids',
                'type'        => 'select',
                'title'       => '创作中心允许投稿的分类',
                'placeholder' => '',
                'desc'        => '如果不选择，则默认显示允许投稿全部分类',
                'chosen'      => true,
                'multiple'    => true,
                'options'     => 'categories',
            ),
        )
    ));

    require __DIR__ .'/../../ceoshop/inc/options/ceotheme-admin.php';
    
    /*
     * ------------------------------------------------------------------------------
     * 首页设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id'    => 'ceotheme_home',
        'icon'  => 'fa fa-home',
        'title' => '首页设置',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '首页布局',
        'fields' => array(
            array(
                'id'      => 'index_type',
                'type'    => 'image_select',
                'title'   => '<h3>首页布局</h3>',
                'options' => array(
                    '1' => get_template_directory_uri() . '/static/images/ceo-index-1.png',
                    '2' => get_template_directory_uri() . '/static/images/ceo-index-2.png',
                ),
                'desc'    => '1：门户布局，2：文章布局',
                'default' => '1'
            ),
            /*门户布局*/
            array(
                'id'           => 'layout',
                'type'         => 'sorter',
                'title'        => '门户布局首页模块布局拖拽设置',
                'dependency'   => array('index_type', '==', '1'),
                'default'      => array(
                    'enabled'  => array(
                        'slide'       => '幻灯模块',
                        'switch'      => '分类切换',
                        'special'     => '专题模块',
                        'user'        => '用户模块',
                        'forum'       => '社区模块',
                        'case'        => '案例模块',
                        'news'        => '新闻模块',
                        'enterprise'  => '企业模块',
                    ),
                    'disabled'   => array(
                        'infinite'    => '无限分类',
                        'ads'         => '图文广告',
                    ),
                ),
            ),
            /*文章布局*/
            array(
                'id'           => 'layout_article',
                'type'         => 'sorter',
                'title'        => '文章布局首页模块布局拖拽设置',
                'dependency'   => array('index_type', '==', '2'),
                'default'      => array(
                    'enabled'  => array(
                        'slide'     => '首页幻灯模块',
                        'hot'       => '热门滚动模块',
                        'special'   => '首页专题模块',
                        'list'      => '文章分类切换',
                    ),
                    'disabled'   => array(
                        'guanggao'  => '首页广告模块',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '幻灯模块设置',
        'fields' => array(
            array(
                'id'     => 'slide',
                'type'   => 'repeater',
                'title'  => '幻灯图片添加',
                'desc'   => '幻灯片尺寸：宽1920px高360px',
                'fields' => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'url',
                        'type'    => 'text',
                        'title'   => '链接',
                        'default' =>'/',
                    ),
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '幻灯片图片',
                    ),
                ),
            ),
            array(
                'id'         => 'slide_cmsmk',
                'type'       => 'switcher',
                'title'      => '幻灯底部CMS模块',
                'default'    => true
            ),
            array(
                'id'     => 'slide_cms',
                'type'   => 'repeater',
                'max'    => '5',
                'title'  => '幻灯底部CMS模块设置',
                'desc'   => '请添加5个模块内容',
                'dependency' => array('slide_cmsmk', '==', true),
                'fields' => array(
                    array(
                        'id'           => 'img',
                        'type'         => 'upload',
                        'title'        => '图标',
                        'desc'         => '建议尺寸：高40px宽40px',
                        'placeholder'  => 'http://',
                        'button_title' => '上传',
                        'remove_title' => '删除',
                        'default' => get_template_directory_uri() . '/static/images/ceo-slidecms-icon.png',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => '描述',
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '链接',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '分类切换设置',
        'fields' => array(
            array(
                'id'        => 'switch_title',
                'type'      => 'text',
                'title'     => '模块标题',
                'default'   => '精选好课，助您高薪就业'
            ),
            array(
                'id'        => 'switch_subtitle',
                'type'      => 'text',
                'title'     => '副标题',
                'default'   => '更全面的实战案例、更细致的讲解和课后辅导，让你的职业生涯能更轻松的完成进阶。'
            ),
            array(
                'id'        => 'switch_antitle',
                'type'      => 'text',
                'title'     => '最新发布标题',
                'default'   => '最新发布'
            ),
            array(
                'id'        => 'switch_anlink',
                'type'      => 'text',
                'title'     => '最新发布 查看更多链接',
                'default'   => ''
            ),
            array(
                'id'          => 'newest_content_cat',
                'type'        => 'select',
                'title'       => '最新发布展示内容',
                'desc'        => '选择最新发布模块要展示的内容',
                'chosen'      => true,
                'multiple'    => true,
                'options'     => 'categories',
            ),
            array(
                'id'          => 'switch_title_cat',
                'type'        => 'select',
                'title'       => '分类切换',
                'desc'        => '选择分类切换模块要展示的分类',
                'chosen'      => true,
                'multiple'    => true,
                'options'     => 'categories',
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '无限分类设置',
        'fields' => array(
            array(
                'id'     => 'infinite',
                'type'   => 'repeater',
                'title'  => '无限分类模块设置',
                'fields' => array(
                    array(
                        'id'          => 'id',
                        'type'        => 'select',
                        'title'       => '选择分类栏目',
                        'placeholder' => '选择分类栏目',
                        'options'     => 'categories',
                    ),
                    array(
                        'id'          => 'title',
                        'type'        => 'text',
                        'title'       => '自定义模块标题（选填）',
                    ),
                    array(
                        'id'          => 'subtitle',
                        'type'        => 'text',
                        'title'       => '模块副标题',
                        'default'     => '在这里学习优质高校课程，与名师零距离交流，并获得认证证书。'
                    ),
                    array(
                        'id'          => 'num',
                        'type'        => 'text',
                        'title'       => '显示数量',
                        'default'     => '8',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '专题模块设置',
        'fields' => array(
            array(
                'id'      => 'ceo_special_title',
                'type'    => 'text',
                'title'   => '模块标题',
                'default' => '独创学习进阶路线 助你成就高薪梦想'
            ),
            array(
                'id'      => 'ceo_special_subtitle',
                'type'    => 'text',
                'title'   => '副标题',
                'default' => '囊括行业讲师大咖，一线培训老司机，为你提供最全面、最优质、最系统的免费学习资源。'
            ),
            array(
                'id'      => 'ceo_special_url',
                'type'    => 'text',
                'title'   => '查看更多链接',
                'default' => '/special'
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '用户模块设置',
        'fields' => array(
            array(
                'id'      => 'ceo_user_title',
                'type'    => 'text',
                'title'   => '模块标题',
                'default' => '精英学员，一起全方位成长'
            ),
            array(
                'id'      => 'ceo_user_subtitle',
                'type'    => 'text',
                'title'   => '副标题',
                'default' => '与精英学员共同学习交流，让你的职业生涯能更轻松的完成进阶。'
            ),
            array(
                'id'      => 'ceo_user_url',
                'type'    => 'text',
                'title'   => '查看更多链接',
                'default' => '/members'
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '社区模块设置',
        'fields' => array(
            array(
                'id'      => 'ceo_forum_title',
                'type'    => 'text',
                'title'   => '模块标题',
                'default' => '课堂讨论，行业大牛疑难解答'
            ),
            array(
                'id'      => 'ceo_forum_subtitle',
                'type'    => 'text',
                'title'   => '副标题',
                'default' => '汇聚技术领域名师大咖，共同学习讨论，知识问答、讲师学员交流，知识点分享等。'
            ),
            array(
                'id'      => 'ceo_forum_boxmk',
                'type'    => 'switcher',
                'title'   => '顶部快捷模块',
                'desc'    => '开启或关闭顶部快捷模块（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            array(
                'id'         => 'ceo_forum_box',
                'type'       => 'repeater',
                'max'        => '5',
                'title'      => '顶部模块设置',
                'desc'       => '请添加5个模块内容',
                'dependency' => array('ceo_forum_boxmk', '==', true),
                'fields'     => array(
                    array(
                        'id'    => 'img',
                        'type'  => 'upload',
                        'title' => '模块图标',
                        'desc'  => '建议尺寸：宽49px高49px'
                    ),
                    array(
                        'id'    => 'title',
                        'type'  => 'text',
                        'title' => '模块标题',
                    ),
                    array(
                        'id'    => 'desc',
                        'type'  => 'text',
                        'title' => '模块描述',
                    ),
                    array(
                        'id'    => 'antitle',
                        'type'  => 'text',
                        'title' => '按钮标题',
                    ),
                    array(
                        'id'    => 'link',
                        'type'  => 'text',
                        'title' => '模块连接',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
            array(
                'id'           => 'ceo_forum_q_sz',
                'type'         => 'fieldset',
                'title'        => '问答模块设置',
                'fields'       => array(
                    array(
                        'id'           => 'forum_q_title',
                        'type'         => 'text',
                        'title'        => '模块标题',
                        'default'      => '问答社区',
                    ),
                    array(
                        'id'           => 'forum_q_img',
                        'type'         => 'upload',
                        'title'        => '模块图标',
                        'placeholder'  => 'http://',
                        'button_title' => '上传',
                        'remove_title' => '删除',
                        'default' => get_template_directory_uri() . '/static/images/ceo-home-forum-q.png',
                    ),
                    array(
                        'id'           => 'forum_q_link',
                        'type'         => 'text',
                        'title'        => '模块连接',
                        'default'      => '/question',
                    ),
                ),
            ),
            array(
                'id'           => 'ceo_forum_f_sz',
                'type'         => 'fieldset',
                'title'        => '论坛模块设置',
                'fields'       => array(
                    array(
                        'id'           => 'forum_f_title',
                        'type'         => 'text',
                        'title'        => '模块标题',
                        'default'      => '论坛大厅',
                    ),
                    array(
                        'id'           => 'forum_f_img',
                        'type'         => 'upload',
                        'title'        => '模块图标',
                        'placeholder'  => 'http://',
                        'button_title' => '上传',
                        'remove_title' => '删除',
                        'default' => get_template_directory_uri() . '/static/images/ceo-home-forum-f.png',
                    ),
                    array(
                        'id'           => 'forum_f_link',
                        'type'         => 'text',
                        'title'        => '模块连接',
                        'default'      => '/forum',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '案例模块设置',
        'fields' => array(
            array(
                'id'           => 'ceo_case_img',
                'type'         => 'upload',
                'title'        => '模块背景图',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'desc'         => '建议尺寸：宽1920px高657px',
                'default'      => get_template_directory_uri() . '/static/images/ceo-home-case.jpg',
            ),
            array(
                'id'      => 'ceo_case_title',
                'type'    => 'text',
                'title'   => '模块标题',
                'default' => '成功教育案例展示'
            ),
            array(
                'id'      => 'ceo_case_subtitle',
                'type'    => 'text',
                'title'   => '副标题',
                'default' => '汇聚产品、设计、技术领域名师大咖，精英学员访谈 真实成功案例。'
            ),
            array(
                'id'        => 'ceo_case_sz',
                'type'      => 'fieldset',
                'title'     => '右侧网格分类设置',
                'fields'    => array(
                    array(
                        'id'          => 'cat_id',
                        'type'        => 'select',
                        'title'       => '分类选择',
                        'placeholder' => '选择分类',
                        'options'     => 'categories',
                    ),
                    array(
                        'id'          => 'num',
                        'type'        => 'text',
                        'title'       => '显示数量',
                        'default'     => '8',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '新闻资讯模块',
        'fields' => array(
            array(
                'id'      => 'ceo_news_title',
                'type'    => 'text',
                'title'   => '模块标题',
                'default' => '教育培训行业新闻'
            ),
            array(
                'id'      => 'ceo_news_subtitle',
                'type'    => 'text',
                'title'   => '副标题',
                'default' => '实时掌握行业和动态，个性化新闻推荐，在线分享精华、优质知识内容，带你走进行业前沿。'
            ),
            array(
                'id'     => 'ceo_news_only',
                'type'   => 'repeater',
                'title'  => '分类标题模块设置',
                'fields' => array(
                    array(
                        'id'          => 'id',
                        'type'        => 'select',
                        'title'       => '选择分类栏目',
                        'placeholder' => '选择分类栏目',
                        'options'     => 'categories',
                    ),
                    array(
                        'id'           => 'img',
                        'type'         => 'upload',
                        'title'        => '封面图片',
                        'library'      => 'image',
                        'placeholder'  => 'http://',
                        'button_title' => '上传',
                        'remove_title' => '删除',
                    ),
                    array(
                        'id'      => 'num',
                        'type'    => 'text',
                        'title'   => '显示数量',
                        'default' => '8',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '企业模块设置',
        'fields' => array(
            array(
                'id'      => 'ceo_qiye_title',
                'type'    => 'text',
                'title'   => '模块标题',
                'default' => '合作高薪就业企业'
            ),
            array(
                'id'      => 'ceo_qiye_subtitle',
                'type'    => 'text',
                'title'   => '副标题',
                'default' => '卓越，彼此共认同。教学品质俘获诸多名校偏爱，学员能力赢得众多企业青睐'
            ),
            array(
                'id'     => 'ceo_qiye_sz',
                'type'   => 'repeater',
                'title'  => '合作伙伴模块设置',
                'fields' => array(
                    array(
                        'id'       => 'title',
                        'type'     => 'text',
                        'title'    => '标题',
                        'default'  => ''
                    ),
                    array(
                        'id'       => 'url',
                        'type'     => 'text',
                        'title'    => '链接',
                        'default'  => ''
                    ),
                    array(
                        'id'       => 'img',
                        'type'     => 'upload',
                        'title'    => '图片',
                        'default'  => get_template_directory_uri() . '/static/images/ceotheme-logo.png',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '图文广告模块',
        'fields' => array(
            array(
                'id'      => 'ceo_ads_spp',
                'type'    => 'switcher',
                'title'   => '手机端是否隐藏图片广告',
                'desc'    => '注意：开启则隐藏，关闭则显示',
                'default' => true
            ),
            array(
                'id'      => 'ceo_adsw_app',
                'type'    => 'switcher',
                'title'   => '手机端是否隐藏文字广告',
                'desc'    => '注意：开启则隐藏，关闭则显示',
                'default' => true
            ),
            //多图广告
            array(
                'id'      => 'ceo_ads',
                'type'    => 'switcher',
                'title'   => '多图广告',
                'default' => false
            ),
            array(
                'id'         => 'ceo_ads_sz',
                'dependency' => array('ceo_ads', '==', true),
                'type'       => 'repeater',
                'title'      => '添加广告',
                'fields'     => array(
                    array(
                        'id'    => 'img',
                        'type'  => 'upload',
                        'title' => '上传图片',
                    ),
                    array(
                        'id'    => 'title',
                        'type'  => 'text',
                        'title' => '标题'
                    ),
                    array(
                        'id'    => 'link',
                        'type'  => 'text',
                        'title' => '链接'
                    ),
                    array(
                        'id'    => 'date',
                        'type'  => 'text',
                        'title' => '到期时间'
                    ),
                ),
                'desc'       =>'一排3个图片广告，广告尺寸400px*70px'
            ),
            //文字广告
            array(
                'id'      => 'ceo_adsw',
                'type'    => 'switcher',
                'title'   => '文字广告',
                'default' => false
            ),
            array(
                'id'         => 'ceo_adsw_sz',
                'dependency' => array('ceo_adsw', '==', true),
                'type'       => 'repeater',
                'title'      => '添加广告',
                'fields'     => array(
                    array(
                        'id'    => 'title',
                        'type'  => 'text',
                        'title' => '标题'
                    ),
                    array(
                        'id'    => 'link',
                        'type'  => 'text',
                        'title' => '链接'
                    ),
                    array(
                        'id'      => 'color',
                        'type'    => 'color',
                        'title'   => '字体颜色',
                        'default' => '#026eff'
                    ),
                    array(
                        'id'    => 'date',
                        'type'  => 'text',
                        'title' => '到期时间'
                    ),
                ),
                'desc'       =>'一排5个文字广告，文字数量建议不超过16个字'
            ),
        )
    ));
    /*文章布局首页模块设置*/
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '首页文章布局-幻灯模块设置',
        'fields' => array(
            array(
                'id'      => 'article_slide_type',
                'type'    => 'image_select',
                'title'   => '<h3>选择幻灯片样式</h3>',
                'options' => array(
                    '1' => get_template_directory_uri() . '/static/images/ceo-article-slide1.jpg',
                    '2' => get_template_directory_uri() . '/static/images/ceo-article-slide2.jpg',
                ),
                'desc'    => '1：大图幻灯片样式，2：三格幻灯片样式',
                'default' => '1'
            ),
            //幻灯样式1
            array(
                'id'         => 'article_slide1',
                'type'       => 'repeater',
                'title'      => '幻灯样式1图片设置',
                'desc'       => '幻灯片尺寸：宽838px高300px',
                'dependency' => array('article_slide_type', '==', '1'),
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'url',
                        'type'    => 'text',
                        'title'   => '图片链接',
                        'default' =>'/',
                    ),
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '幻灯片图片',
                    ),
                ),
            ),
            //幻灯样式2
            array(
                'id'         => 'article_slide2',
                'type'       => 'repeater',
                'title'      => '幻灯样式2图片设置',
                'desc'       => '幻灯片尺寸：宽625px高293px',
                'dependency' => array('article_slide_type', '==', '2'),
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'url',
                        'type'    => 'text',
                        'title'   => '图片链接',
                        'default' =>'/',
                    ),
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '幻灯片图片',
                    ),
                ),
            ),
            array(
                'id'         => 'simg_01',
                'type'       => 'fieldset',
                'dependency' => array('article_slide_type', '==', '2'),
                'title'      => '右侧图片（上）',
                'fields'     => array(
                    array(
                        'id'      => 'simg_01_img',
                        'type'    => 'upload',
                        'title'   => '上传图片',
                        'desc'    => '幻灯片尺寸：宽199px高139px',
                    ),
                    array(
                        'id'      => 'simg_01_title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'simg_01_link',
                        'type'    => 'text',
                        'title'   => '链接',
                    ),
                ),
            ),
            array(
                'id'         => 'simg_02',
                'type'       => 'fieldset',
                'dependency' => array('article_slide_type', '==', '2'),
                'title'      => '右侧图片（下）',
                'fields'     => array(
                    array(
                        'id'      => 'simg_02_img',
                        'type'    => 'upload',
                        'title'   => '上传图片',
                        'desc'    => '幻灯片尺寸：宽199px高139px',
                    ),
                    array(
                        'id'      => 'simg_02_title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'simg_02_link',
                        'type'    => 'text',
                        'title'   => '链接',
                    ),
                ),
            ),
            array(
                'id'      => 'simg_tia',
                'type'    => 'switcher',
                'title'   => '右侧图片标题',
                'desc'    => '隐藏/显示右侧图片标题（开启则显示，关闭则隐藏）',
                'dependency' => array('article_slide_type', '==', '2'),
                'default' => true,
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '首页文章布局-分类切换设置',
        'fields' => array(
            array(
                'id'         => 'article_switcher_new_enable',
                'type'       => 'switcher',
                'title'      => '最新发布模块',
                'desc'       => '开启或关闭分类切换模块标题（开启则显示，关闭则隐藏）',
                'default'    => true
            ),
            array(
                'id'       => 'article_switcher_new_title',
                'type'     => 'text',
                'title'    => '最新发布标题',
                'default'  => '最新发布',
                'dependency' => array('article_switcher_new_enable', '==', true),
            ),
            array(
                'id'       => 'article_switcher_new_url',
                'type'     => 'text',
                'title'    => '查看更多链接',
                'default'  => '',
                'dependency' => array('article_switcher_new_enable', '==', true),
            ),
            array(
                'id'          => 'article_content_cat',
                'type'        => 'select',
                'title'       => '最新发布展示内容',
                'desc'        => '选择最新发布模块要展示的内容',
                'dependency'  => array('article_switcher_new_enable', '==', true),
                'chosen'      => true,
                'multiple'    => true,
                'options'     => 'categories',
            ),
            array(
                'id'          => 'article_title_cat',
                'type'        => 'select',
                'title'       => '分类切换',
                'desc'        => '选择分类切换模块要展示的分类',
                'chosen'      => true,
                'multiple'    => true,
                'options'     => 'categories',
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '首页文章布局-专题模块设置',
        'fields' => array(
            array(
                'id'      => 'ceo_article_special_tia',
                'type'    => 'switcher',
                'title'   => '专题模块标题总开关',
                'desc'    => '隐藏/显示模块标题、副标题、更多链接（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_article_special_title',
                'type'    => 'text',
                'title'   => '模块标题',
                'default' => '热门专题'
            ),
            array(
                'id'      => 'ceo_article_special_subtitle',
                'type'    => 'text',
                'title'   => '副标题',
                'default' => '独创学习进阶路线 助你成就高薪梦想'
            ),
            array(
                'id'      => 'ceo_article_special_url',
                'type'    => 'text',
                'title'   => '查看更多链接',
                'default' => '/special'
            ),
            array(
                'id'      => 'ceo_article_special_ati',
                'type'    => 'switcher',
                'title'   => '专题内容标题',
                'desc'    => '隐藏/显示专题模块内容标题（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_home',
        'title'  => '首页文章布局-广告模块设置',
        'fields' => array(
            array(
                'id'     => 'ceo_article_guanggao',
                'type'   => 'repeater',
                'title'  => '广告添加',
                'desc'   => '广告尺寸：宽838px高不限',
                'fields' => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'url',
                        'type'    => 'text',
                        'title'   => '链接',
                        'default' =>'/',
                    ),
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '幻灯片图片',
                    ),
                ),
            ),
        )
    ));

    /*
 * ------------------------------------------------------------------------------
 * 侧边栏设置
 * ------------------------------------------------------------------------------
 */
    CSF::createSection($ceotheme, array(
        'id'    => 'ceotheme_side',
        'icon'  => 'fa fa-th-list',
        'title' => '右侧边栏',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_side',
        'title'  => '侧边栏布局',
        'fields' => array(
            array(
                'id'           => 'sidebar_layout',
                'type'         => 'sorter',
                'title'        => '侧边栏布局拖拽设置',
                'default'      => array(
                    'enabled'      => array(
                        'author'   => '作者模块',
                        'focus'    =>'社交模块',
                        'imgtext'  =>'图文展示',
                        'zz'       => '广告模块',
                        'text'     =>'文章展示',
                        'tags'     => '随机标签',
                        'comment'  => '评论列表',
                        'vip'    => 'VIP模块',
                    ),
                    'disabled'     => array(
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_side',
        'title'  => '作者模块',
        'fields' => array(
            array(
                'id'           => 'side_author_img',
                'type'         => 'upload',
                'title'        => '作者模块背景图片',
                'desc'         => '作者模块默认背景图，用户也可以在个人中心独立设置作者模块背景图~未独立设置则自动调用该设置中默认背景图',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo-author-bg.png',
            ),
            array(
                'id'      => 'side_author_statistics',
                'type'    => 'switcher',
                'title'   => '作者数据统计',
                'desc'    => '隐藏/显示作者数据统计（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'      => 'side_author_gzsx',
                'type'    => 'switcher',
                'title'   => '关注/私信功能',
                'desc'    => '隐藏/显示关注/私信功能按钮（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线（以下是商城内页的作者侧边栏设置）',
            ),
            array(
                'id'      => 'shop_author_other',
                'type'    => 'switcher',
                'title'   => '商户动态',
                'desc'    => '隐藏/显示商户资源动态（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'         => 'shop_author_other_title',
                'type'       => 'text',
                'dependency' => array('shop_author_other', '==', 'true'),
                'title'      => '修改标题',
                'default'    => 'Ta的更多资源'
            ),
            array(
                'id'         => 'shop_author_other_num',
                'type'       => 'text',
                'dependency' => array('shop_author_other', '==', 'true'),
                'title'      => '显示数量',
                'default'    => 4
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_side',
        'title'  => '社交模块',
        'fields' => array(
            array(
                'id'           => 'side_focus_img',
                'type'         => 'upload',
                'title'        => '社交模块背景图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo_focus_bg.jpg',
            ),
            array(
                'id'           => 'side_focus_ma',
                'type'         => 'upload',
                'title'        => '模块二维码',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo-ma.png',
            ),
            array(
                'id'      => 'side_focus_title',
                'type'    => 'text',
                'title'   => '模块标题',
                'default' => '扫一扫关注公众号'
            ),
            array(
                'id'      => 'side_focus_subtitle',
                'type'    => 'text',
                'title'   => '副标题',
                'default' => '最新讯息尽在总裁主题'
            ),
            array(
                'id'      => 'side_focus_an1title',
                'type'    => 'text',
                'title'   => '按钮1标题',
                'default' => '加入QQ群'
            ),
            array(
                'id'      => 'side_focus_an1link',
                'type'    => 'text',
                'title'   => '按钮1链接',
                'default' => '/'
            ),
            array(
                'id'      => 'side_focus_an2title',
                'type'    => 'text',
                'title'   => '按钮2标题',
                'default' => '关注微博'
            ),
            array(
                'id'      => 'side_focus_an2link',
                'type'    => 'text',
                'title'   => '按钮2链接',
                'default' => '/'
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_side',
        'title'  => '图文展示',
        'fields' => array(
            array(
                'id'      => 'imgtext-title',
                'type'    => 'text',
                'title'   => '标题',
                'default' => '图文展示'
            ),
            array(
                'id'      => 'imgtext-url',
                'type'    => 'text',
                'title'   => '右侧链接',
                'default' => '/'
            ),
            array(
                'id'          => 'imgtext-cat',
                'type'        => 'select',
                'title'       => '选择展示分类',
                'placeholder' => '请选择分类',
                'chosen'      => true,
                'multiple'    => true,
                'options'     => 'categories',
            ),
            array(
                'id'      => 'imgtext-orderby',
                'type'    => 'radio',
                'title'   => '排序',
                'inline'  => true,
                'options' => array(
                    'date'          => esc_html__('日期'),
                    'rand'          => esc_html__('随机'),
                    'comment_count' => esc_html__('评论数量'),
                    'id'            => esc_html__('文章ID'),
                ),
                'default' => 'date',
            ),
            array(
                'id'      => 'imgtext-number',
                'type'    => 'text',
                'title'   => '显示数量',
                'default' => '6'
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_side',
        'title'  => '文章展示',
        'fields' => array(
            array(
                'id'      => 'text-title',
                'type'    => 'text',
                'title'   => '标题',
                'default' => '文章展示'
            ),
            array(
                'id'      => 'text-url',
                'type'    => 'text',
                'title'   => '右侧链接',
                'default' => '/'
            ),
            array(
                'id'          => 'text-cat',
                'type'        => 'select',
                'title'       => '选择展示分类',
                'placeholder' => '请选择分类',
                'options'     => 'categories',
            ),
            array(
                'id'      => 'text-orderby',
                'type'    => 'radio',
                'title'   => '排序',
                'inline'  => true,
                'options' => array(
                    'date'          => esc_html__('日期'),
                    'rand'          => esc_html__('随机'),
                    'comment_count' => esc_html__('评论数量'),
                    'id'            => esc_html__('文章ID'),
                ),
                'default' => 'date',
            ),
            array(
                'id'      => 'text-number',
                'type'    => 'text',
                'title'   => '显示数量',
                'default' => '6'
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_side',
        'title'  => '随机标签',
        'fields' => array(
            array(
                'id'      => 'side-tag-title',
                'type'    => 'text',
                'title'   => '标题',
                'default' => '随机标签'
            ),
            array(
                'id'      => 'side-tag-num',
                'type'    => 'text',
                'title'   => '标签数量',
                'default' => 20
            ),
            array(
                'id'      => 'side-tag-url',
                'type'    => 'text',
                'title'   => '查看更多',
                'default' => '/tags',
            ),

        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_side',
        'title'  => '评论列表',
        'fields' => array(
            array(
                'id'      => 'comment-title',
                'type'    => 'text',
                'title'   => '标题',
                'default' => '最新评论'
            ),
            array(
                'id'      => 'comment-title-num',
                'type'    => 'text',
                'title'   => '评论数量',
                'default' => '6'
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_side',
        'title'  => 'VIP模块',
        'fields' => array(
            array(
                'id'           => 'side_vip_img',
                'type'         => 'upload',
                'title'        => '模块图片',
                'library'      => 'image',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo-sidebar-vip.png',
            ),
            array(
                'id'      => 'side_vip_title',
                'type'    => 'text',
                'title'   => '按钮标题',
                'default' => '立即升级VIP'
            ),
            array(
                'id'      => 'side_vip_link',
                'type'    => 'text',
                'title'   => '按钮连接',
                'default' => '/vip'
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_side',
        'title'  => '广告模块',
        'fields' => array(
            array(
                'id'     => 'side_zz',
                'type'   => 'repeater',
                'title'  => '广告模块设置',
                'fields' => array(
                    array(
                        'id'           => 'img',
                        'type'         => 'upload',
                        'title'        => '广告图片',
                        'library'      => 'image',
                        'placeholder'  => 'http://',
                        'button_title' => '上传',
                        'remove_title' => '删除',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '广告标题',
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '广告连接',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
        )
    ));
    /*
 * ------------------------------------------------------------------------------
 * 分类页设置
 * ------------------------------------------------------------------------------
 */
    CSF::createSection($ceotheme, array(
        'id'    => 'ceotheme_cat',
        'icon'   => 'fa fa-folder-open',
        'title' => '分类设置',
    ));
    CSF::createSection($ceotheme, array(
        'parent'     => 'ceotheme_cat',
        'title'  => '分类基础设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （缩略图裁剪设置）',
            ),
            array(
                'id'      => 'thumbnail_cj',
                'type'    => 'radio',
                'title'   => '缩略图裁剪模式',
                'options' => array(
                    'timthumb_php' => 'timthumb.php裁剪（默认推荐，可保留高清晰度，图片规范）',
                    'timthumb_theme'  => '主题框架裁剪（原图压缩裁剪，可保留高清晰度，图片规范，服务器带宽太低会影响图片加载速度）',
                    'timthumb_yun'  => '自定义参数裁剪（例如OSS云储存裁剪模式）',
                ),
                'default' => 'timthumb_php',
                'subtitle' => '总裁主题提供的3种模式都可以将缩略图以最完美的标准展示，您可以根据自己的需求选择',
            ),
            array(
                'id'         => 'thumbnail_yun_custom',
                'type'       => 'text',
                'title'      => '自定义参数裁剪设置',
                'dependency' => array('thumbnail_cj', '==', 'timthumb_yun'),
                'default'    => '?x-oss-process=image/resize,m_fill',
                'desc'       => "如阿里云OSS在图片地址后加（?x-oss-process=image/resize,m_fill）<br>
                原理说明，例如本身图片地址是：https://本站域名.com/wp-content/uploads/2019/08/a.jpg<br>
                使用云储存插件接入oss后是https://oss云储存域名.com/wp-content/uploads/2021/01/01.png<br>
                加入自定义参数后是，https://oss域名.com/wp-content/uploads/2021/01/01.png?x-oss-process=image/resize,m_fill，即可实现oss裁剪<br>
                注意：主题已经在对应位置添加了图片宽高，因此无需添加h_xxx,w_xxx,h_高度，w_宽度",
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （分类基础信息设置）',
            ),
            array(
                'id'         => 'default_thumb',
                'type'       => 'switcher',
                'title'      => '开启/关闭默认缩略图',
                'desc'       => '开启/关闭显示默认缩略图，已设置的文章缩略图依旧显示！',
                'default'    =>  true
            ),
            array(
                'id'           => 'default_thum',
                'type'         => 'upload',
                'title'        => '设置文章默认缩略图',
                'desc'         => '文章没有设置独立特色图时则调用该图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceotheme_no.jpg',
            ),
            array(
                'id'           => 'category_default_bg',
                'type'         => 'upload',
                'title'        => '栏目默认背景图片',
                'desc'         => '也可以在后台分类目录中独立设置栏目背景图片~未独立设置则自动调用该设置中默认背景图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'id'      => 'ceo-cat-tj',
                'type'    => 'switcher',
                'title'   => '课程分类资源数量统计',
                'desc'    => '隐藏/显示课程分类资源数量统计（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'      => 'target_blank',
                'type'    => 'switcher',
                'title'   => '新窗口打开文章',
                'desc'    => '点击列表文章跳转新窗口（开启则跳转新窗口，关闭则当前窗口跳转）',
                'label'   => '',
                'default' => false,
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '列表文章设置（以下功能开启则显示，关闭则隐藏）',
            ),
            array(
                'id'      => 'ceo_cat_jg',
                'type'    => 'switcher',
                'title'   => '资源价格',
                'desc'    => '隐藏/显示列表资源价格',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_viptb',
                'type'    => 'switcher',
                'title'   => 'VIP图标',
                'desc'    => '隐藏/显示列表VIP图标',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_fl',
                'type'    => 'switcher',
                'title'   => '文章所属分类',
                'desc'    => '隐藏/显示列表文章所属分类',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_tx',
                'type'    => 'switcher',
                'title'   => '作者头像',
                'desc'    => '隐藏/显示列表文章作者头像',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_mc',
                'type'    => 'switcher',
                'title'   => '作者名称',
                'desc'    => '隐藏/显示列表文章作者名称',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_rq',
                'type'    => 'switcher',
                'title'   => '发布日期',
                'desc'    => '隐藏/显示列表发布日期',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_dz',
                'type'    => 'switcher',
                'title'   => '文章点赞量',
                'desc'    => '隐藏/显示列表文章点赞量',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_ll',
                'type'    => 'switcher',
                'title'   => '文章浏览量',
                'desc'    => '隐藏/显示列表文章浏览量',
                'default' => true,
            ),
        )
    ));

    CSF::createSection($ceotheme, array(
        'parent'     => 'ceotheme_cat',
        'title'  => '分类商城设置',
        'fields' => array(
            array(
                'id'      => 'ceo_cat_nav_title2',
                'type'    => 'text',
                'title'   => '自定义二级分类标题',
                'default' => '课程分类',
            ),
            array(
                'id'      => 'ceo_cat_nav_title3',
                'type'    => 'text',
                'title'   => '自定义三级分类标题',
                'default' => '分类筛选',
            ),
            array(
                'id'      => 'ceo_cat_ss',
                'type'    => 'switcher',
                'title'   => '课程分类价格筛选',
                'desc'    => '隐藏/显示课程分类价格筛选（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_wss',
                'type'    => 'switcher',
                'title'   => '课程分类最新/最热/随机',
                'desc'    => '隐藏/显示课程分类最新/最热/随机（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
        )
    ));
    //高级自定义筛选
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_cat',
        'title'  => '高级分类筛选',
        'fields' => array(
            array(
                'id'      => 'ceo_choice',
                'type'    => 'switcher',
                'title'   => '高级自定义筛选',
                'desc'    => '高级自定义筛选功能主要为资源进行详细属性分类筛选<b><font color="red">需要注意每个筛选名称，必须有两个或两个属性选项，否则无法使用且会报错</font></b>',
                'default' => false,
            ),
            array(
                'id'         => 'ceo_choice_sz',
                'type'       => 'group',
                'title'      => '自定义筛选设置',
                'max'        => '50',
                'fields'     => array(

                    array(
                        'id'      => 'meta_name',
                        'type'    => 'text',
                        'title'   => '主筛选标题',
                        'default' => '颜色',
                        'desc'    => '例如：颜色、格式、型号等主筛选标题<b><font color="red">注意：任何筛选主标题必须唯一，不可重复，只要不一样就行！！！</font></b>'
                    ),
                    array(
                        'id'      => 'meta_ua',
                        'type'    => 'text',
                        'title'   => '标题英文标识',
                        'default' => 'ceo_meta_1',
                        'desc'    => '例如：ceo_meta_1、abc_1等英文标识<b><font color="red">注意：任何筛选英文标识必须唯一，不可重复，只要不一样就行！！！建议英文+数字序号排序</font></b>'
                    ),
                    array(
                        'id'          => 'meta_category',
                        'type'        => 'select',
                        'title'       => '只在该分类下显示高级筛选属性',
                        'placeholder' => '全部显示',
                        'chosen'      => true,
                        'multiple'    => true,
                        'options'     => 'categories',
                        'desc'        => '默认为全部显示，需要在某个分类才显示时请选择该分类'
                    ),
                    array(
                        'id'     => 'meta_opt',
                        'type'   => 'group',
                        'title'  => '属性选项',
                        'fields' => array(
                            array(
                                'id'      => 'opt_name',
                                'type'    => 'text',
                                'title'   => '属性选项名称',
                                'default' => '黄色',
                                'desc'    => '例如：黄色、PSD、型号1等属性选项名称<b><font color="red">注意：任何属性选项名称必须唯一，不可重复，只要不一样就行！！！</font></b>'
                            ),
                            array(
                                'id'      => 'opt_ua',
                                'type'    => 'text',
                                'title'   => '选项英文标识',
                                'default' => 'ceo_opt_1',
                                'desc'    => '例如：ceo_opt_1、def_1等英文标识<b><font color="red">注意：任何属性选项英文标识必须唯一，不可重复，只要不一样就行！！！建议英文+数字序号排序</font></b>'
                            ),
                        ),
                    ),

                ),
                'dependency' => array('ceo_choice', '==', 'true'),
            ),

        ),
    ));
    /*
 * ------------------------------------------------------------------------------
 * 文章页设置
 * ------------------------------------------------------------------------------
 */
    CSF::createSection($ceotheme, array(
        'id'    => 'ceotheme_single',
        'icon'  => 'fa fa-window-maximize',
        'title' => '内页设置',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_single',
        'title'  => '内页基础设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （内页信息设置，以下开关开启则显示功能，关闭则隐藏功能）',
            ),
            array(
                'id'      => 'single_info_tx',
                'type'    => 'switcher',
                'title'   => '文章作者头像',
                'default' => true,
            ),
            array(
                'id'      => 'single_info_mc',
                'type'    => 'switcher',
                'title'   => '文章作者名称',
                'default' => true,
            ),
            array(
                'id'      => 'single_info_fl',
                'type'    => 'switcher',
                'title'   => '文章所属分类',
                'default' => true,
            ),
            array(
                'id'      => 'single_info_rq',
                'type'    => 'switcher',
                'title'   => '文章发布日期',
                'default' => true,
            ),
            array(
                'id'      => 'single_info_sc',
                'type'    => 'switcher',
                'title'   => '文章收藏数量',
                'default' => true,
            ),
            array(
                'id'      => 'single_info_dz',
                'type'    => 'switcher',
                'title'   => '文章点赞数量',
                'default' => true,
            ),
            array(
                'id'      => 'single_info_ll',
                'type'    => 'switcher',
                'title'   => '文章浏览数量',
                'default' => true,
            ),
            array(
                'id'      => 'single_info_wz',
                'type'    => 'switcher',
                'title'   => '文章文字数量',
                'default' => true,
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （自动文章摘要功能）',
            ),
            array(
                'id'      => 'single_content_zy',
                'type'    => 'switcher',
                'title'   => '自动文章摘要功能',
                'desc'    => '开启/关闭自动文章摘要功能（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （以下开关开启则显示功能，关闭则隐藏功能）',
            ),
            array(
                'id'      => 'single_commodity',
                'type'    => 'switcher',
                'title'   => '文章关联商品',
                'desc'    => '开启/关闭文章关联商品（开启则显示，关闭则隐藏，注意：这里的开关如果关闭后将隐藏所有文章内的关联商品，请视情况而定）',
                'default' => true,
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （以下开关开启则显示功能，关闭则隐藏功能）',
            ),
            array(
                'id'      => 'single_foo_sc',
                'type'    => 'switcher',
                'title'   => '文章收藏按钮',
                'default' => true,
            ),
            array(
                'id'      => 'single_foo_ds',
                'type'    => 'switcher',
                'title'   => '文章打赏按钮',
                'default' => true,
            ),
            array(
                'id'         => 'single_foo_ds_wxtext',
                'dependency' => array('single_foo_ds', '==', 'true'),
                'type'       => 'text',
                'title'      => '微信扫码标题',
                'default'    => '微信扫一扫',
            ),
            array(
                'id'           => 'single_foo_ds_wximg',
                'type'         => 'upload',
                'title'        => '微信二维码图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'dependency'   => array('single_foo_ds', '==', 'true'),
                'default'      => get_template_directory_uri() . '/static/images/ceo-ma.png',
            ),
            array(
                'id'         => 'single_foo_ds_zfbtext',
                'dependency' => array('single_foo_ds', '==', 'true'),
                'type'       => 'text',
                'title'      => '支付宝扫码标题',
                'default'    => '支付宝扫一扫',
            ),
            array(
                'id'           => 'single_foo_ds_zfbimg',
                'type'         => 'upload',
                'title'        => '支付宝二维码图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'dependency'   => array('single_foo_ds', '==', 'true'),
                'default'      => get_template_directory_uri() . '/static/images/ceo-ma.png',
            ),
            array(
                'id'      => 'single_foo_dz',
                'type'    => 'switcher',
                'title'   => '文章点赞按钮',
                'default' => true,
            ),
            array(
                'id'      => 'single_foo_bq',
                'type'    => 'switcher',
                'title'   => '文章底部版权',
                'default' => true,
            ),
            array(
                'id'         => 'single_foo_bq_text',
                'dependency' => array('single_foo_bq', '==', 'true'),
                'type'       => 'textarea',
                'title'      => '版权文字',
            ),
            array(
                'id'      => 'single_foo_tag',
                'type'    => 'switcher',
                'title'   => '文章底部标签',
                'default' => true,
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （以下开关开启则显示功能，关闭则隐藏功能）',
            ),
            array(
                'id'      => 'single_foo_fy',
                'type'    => 'switcher',
                'title'   => '底部文章分页',
                'default' => true,
            ),
            //发表评论模块
            array(
                'id'      => 'comments_close',
                'type'    => 'switcher',
                'title'   => '整站评论',
                'desc'    =>'开启或关闭整站评论功能，不需要评论可以关闭（按钮开启既关闭整站评论）',
                'default' => false
            ),
            array(
                'id'         => 'comments_title',
                'type'       => 'text',
                'title'      => '发表评论标题',
                'dependency' => array('comments_close', '==', 'false'),
                'default'    => '发表评论'
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_single',
        'title'  => '内页模块设置',
        'fields' => array(
            //相关文章模块
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （相关文章模块设置）',
            ),
            array(
                'id'      => 'xg_show',
                'type'    => 'switcher',
                'title'   => '底部相关文章',
                'default' => true,
            ),
            array(
                'id'         => 'xg_title',
                'type'       => 'text',
                'title'      => '相关文章标题',
                'dependency' => array('xg_show', '==', 'true'),
                'default'    => '相关推荐'
            ),
            array(
                'id'         => 'xg_num',
                'type'       => 'text',
                'title'      => '相关文章数量',
                'dependency' => array('xg_show', '==', 'true'),
                'default'    => '6'
            ),
            //常见问题模块
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （常见问题模块设置）',
            ),
            array(
                'id'         => 'single_qa',
                'type'       => 'switcher',
                'title'      => '常见问题模块',
                'desc'       => '开启或关闭内容页常见问题（开启则显示，关闭则隐藏）',
                'default'    => true
            ),
            array(
                'id'      => 'single_qa_shop',
                'type'    => 'switcher',
                'title'   => '是否在商城内页显示',
                'default' => true,
                'dependency' => array('single_qa', '==', 'true'),
            ),
            array(
                'id'      => 'single_qa_article',
                'type'    => 'switcher',
                'title'   => '是否在文章内页显示',
                'default' => false,
                'dependency' => array('single_qa', '==', 'true'),
            ),
            array(
                'id'      => 'single_qa_title',
                'type'    => 'text',
                'title'   => '常见问题标题',
                'default' => '常见问题',
                'dependency' => array('single_qa', '==', 'true'),
            ),
            array(
                'id'         => 'single_qa_sz',
                'type'       => 'repeater',
                'title'      => '常见问题设置',
                'dependency' => array('single_qa', '==', 'true'),
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'content',
                        'type'    => 'textarea',
                        'title'   => '内容',
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '链接',
                        'default' => '/question',
                    ),
                    array(
                        'id'      => 'antitle',
                        'type'    => 'text',
                        'title'   => '按钮标题',
                        'default' => '不太了解？去提问！',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_single',
        'title'  => '商城内页设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线（购买框设置）',
            ),
            array(
                'id'         => 'ceo_shop_single_ts',
                'type'       => 'text',
                'title'      => '资源短语提示',
                'default'    => '当前信息若含有违规不良内容，请点此举报！',
            ),
            array(
                'id'         => 'ceo_shop_single_ts_link',
                'type'       => 'radio',
                'title'      => '短语链接模式',
                'inline'     => true,
                'options'    => array(
                    '1' => '短语链接模式一【调用联系QQ】',
                    '2' => '短语链接模式二【自定义链接】',
                ),
                'default' => '1',
            ),
            array(
                'id'         => 'ceo_shop_single_ts_linkn',
                'type'       => 'text',
                'dependency' => array('ceo_shop_single_ts_link', '==', '2'),
                'title'      => '填写跳转的链接',
                'default'    => '',
                'desc'       => '请以http://或https://开头',
            ),
            array(
                'id'      => 'ceo_shop_single_jianjie',
                'type'    => 'switcher',
                'title'   => '简介宣传模块',
                'default' => true,
            ),
            array(
                'id'           => 'ceo_shop_single_jianjie_img',
                'dependency' => array('ceo_shop_single_jianjie', '==', true),
                'type'         => 'upload',
                'title'        => '宣传模块背景图设置',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo-back.png',
            ),
            array(
                'id'         => 'ceo_shop_single_jianjie_title',
                'dependency' => array('ceo_shop_single_jianjie', '==', true),
                'type'       => 'text',
                'title'      => '宣传标题',
                'default'    => '郑重承诺',
            ),
            array(
                'id'         => 'ceo_shop_single_jianjie_title2',
                'dependency' => array('ceo_shop_single_jianjie', '==', true),
                'type'       => 'text',
                'title'      => '宣传副标题',
                'default'    => '总裁主题提供安全交易、信息保真!',
            ),
            array(
                'id'         => 'ceo_shop_single_jianjie_title_y',
                'dependency' => array('ceo_shop_single_jianjie', '==', true),
                'type'       => 'text',
                'title'      => '右侧按钮标题',
                'default'    => '升级会员',
            ),
            array(
                'id'         => 'ceo_shop_single_jianjie_title_i',
                'dependency' => array('ceo_shop_single_jianjie', '==', true),
                'type'       => 'text',
                'title'      => '右侧按钮图标',
                'default'    => 'ceoicon-vip-crown-2-line',
                'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
            ),
            array(
                'id'         => 'ceo_shop_single_jianjie_title_l',
                'dependency' => array('ceo_shop_single_jianjie', '==', true),
                'type'       => 'text',
                'title'      => '右侧按钮链接',
                'default'    => '/vip',
            ),
            array(
                'id'         => 'ceo_shop_download_hide_text_l',
                'dependency' => array('ceo_shop_single_jianjie', '==', true),
                'type'       => 'text',
                'title'      => '隐藏信息自定义1',
                'default'    => '隐藏信息',
            ),
            array(
                'id'         => 'ceo_shop_download_hide_text_2',
                'dependency' => array('ceo_shop_single_jianjie', '==', true),
                'type'       => 'text',
                'title'      => '隐藏信息自定义2',
                'default'    => '隐藏信息',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线（商城默认按钮设置）',
            ),
            array(
                'id'         => 'ceo_shop_single_an',
                'type'       => 'fieldset',
                'title'      => '商城默认按钮',
                'fields'     => array(
                    array(
                        'id'      => 'ceo_shop_single_an_xz',
                        'type'    => 'text',
                        'title'   => '购买按钮标题',
                        'default' => '立即购买',
                    ),
                    array(
                        'id'      => 'ceo_shop_single_an_cxz',
                        'type'    => 'text',
                        'title'   => '已购买按钮标题',
                        'desc'    => '仅限虚拟商品单套餐时有效',
                        'default' => '立即下载',
                    ),
                    array(
                        'id'      => 'ceo_shop_single_an_hy',
                        'type'    => 'text',
                        'title'   => '加入VIP按钮标题',
                        'default' => '加入VIP',
                    ),
                    array(
                        'id'      => 'ceo_shop_single_an_hyl',
                        'type'    => 'text',
                        'title'   => '加入VIP链接',
                        'default' => '/vip',
                    ),
                ),
            ),
            array(
                'id'      => 'ceo_shop_single_an_zxb',
                'type'    => 'switcher',
                'title'   => '在线咨询按钮',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_shop_single_an_zx',
                'type'    => 'text',
                'dependency' => array('ceo_shop_single_an_zxb', '==', true),
                'title'   => '在线咨询按钮标题',
                'default' => '在线咨询',
                'desc'    => '在线咨询按钮链接调用用户个人中心中填写的QQ（文章是谁发的就是调用的该用户的QQ）',
            ),
            array(
                'id'      => 'ceo_shop_single_an_zdyb',
                'type'    => 'switcher',
                'title'   => '自定义按钮',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_shop_single_an_zdy',
                'type'    => 'text',
                'dependency' => array('ceo_shop_single_an_zdyb', '==', true),
                'title'   => '自定义按钮标题',
                'default' => '总裁主题',
            ),
            array(
                'id'      => 'ceo_shop_single_an_zdyl',
                'type'    => 'text',
                'dependency' => array('ceo_shop_single_an_zdyb', '==', true),
                'title'   => '自定义按钮链接',
                'default' => 'https://www.ceotheme.com',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 信息属性框设置 （以下开关开启则显示功能，关闭则隐藏功能）',
            ),
            array(
                'id'      => 'ceo_shop_single_xx',
                'type'    => 'switcher',
                'title'   => '资源信息属性【总开关】',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_shop_single_xx_bh',
                'type'    => 'switcher',
                'title'   => '资源编号',
                'desc'    => '是否显示资源编号（默认编号是文章的ID）',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_shop_single_xx_bhbt',
                'dependency' => array('ceo_shop_single_xx_bh', '==', true),
                'type'    => 'text',
                'title'   => '资源编号标题',
                'default' => '资源编号',
            ),
            array(
                'id'      => 'ceo_shop_single_xx_gx',
                'type'    => 'switcher',
                'title'   => '最后更新',
                'desc'    => '是否显示最后更新时间（最后更新时间是最后编辑的时间）',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_shop_single_xx_gxbt',
                'dependency' => array('ceo_shop_single_xx_gx', '==', true),
                'type'    => 'text',
                'title'   => '最后更新标题',
                'default' => '最后更新',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线（增值服务设置）',
            ),
            array(
                'id'      => 'ceo_shop_single_zz',
                'type'    => 'switcher',
                'title'   => '增值服务',
                'desc'    => '开启或隐藏增值服务（开启则显示关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_shop_single_zz_title',
                'dependency' => array('ceo_shop_single_zz', '==', true),
                'type'    => 'text',
                'title'   => '增值服务标题',
                'default' => '增值服务：',
            ),
            array(
                'id'         => 'ceo_shop_single_zzsz',
                'type'       => 'repeater',
                'title'      => '增值服务内容设置',
                'dependency' => array('ceo_shop_single_zz', '==', true),
                'fields'     => array(
                    array(
                        'id'      => 'content',
                        'type'    => 'text',
                        'title'   => '内容',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线（商城基础设置）',
            ),
            array(
                'id'      => 'ceo_shop_single_nertitle',
                'type'    => 'text',
                'title'   => '内容模块标题',
                'default' => '详情介绍',
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_single',
        'title'  => '视频商城设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线（视频商城模块设置）',
            ),
            array(
                'id'      => 'ceoshop_video_logo',
                'type'    => 'switcher',
                'title'   => '视频模块LOGO',
                'desc'    => '隐藏/显示视频模块LOGO图片',
                'default' => true,
            ),
            array(
                'id'           => 'ceoshop_video_logo_img',
                'type'         => 'upload',
                'title'        => '视频模块LOGO图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceotheme-video-logo.png',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线（视频商城基础设置）',
            ),
            array(
                'id'      => 'ceoshop_video_topan',
                'type'    => 'switcher',
                'title'   => '顶部右侧按钮',
                'desc'    => '隐藏/显示顶部右侧按钮',
                'default' => true,
            ),
            array(
                'id'         => 'ceoshop_video_topan_sz',
                'type'       => 'fieldset',
                'title'      => '顶部右侧按钮设置',
                'dependency' => array('ceoshop_video_topan', '==', true),
                'fields'     => array(
                    array(
                        'id'      => 'topan_title',
                        'type'    => 'text',
                        'title'   => '按钮标题',
                        'default' => '开通会员免费学',
                    ),
                    array(
                        'id'      => 'topan_link',
                        'type'    => 'text',
                        'title'   => '按钮链接',
                        'default' => '/vip',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线（视频商城广告设置）',
            ),
            array(
                'id'         => 'ceoshop_video_ad_sz',
                'type'       => 'fieldset',
                'title'      => '右侧模块广告设置',
                'fields'     => array(
                    array(
                        'id'      => 'video_ad_title',
                        'type'    => 'text',
                        'title'   => '广告标题',
                        'default' => '总裁主题',
                    ),
                    array(
                        'id'      => 'video_ad_link',
                        'type'    => 'text',
                        'title'   => '广告链接',
                        'default' => 'https://www.ceotheme.com',
                    ),
                    array(
                        'id'           => 'video_ad_img',
                        'type'         => 'upload',
                        'title'        => '广告图片',
                        'placeholder'  => 'http://',
                        'button_title' => '上传',
                        'remove_title' => '删除',
                        'default'      => get_template_directory_uri() . '/static/images/ceo-xxgg.png',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_single',
        'title'  => '内页优化设置',
        'fields' => array(
            array(
                'id'      => 'auto_add_tags',
                'type'    => 'switcher',
                'title'   => '自动添加已有关键词 ',
                'default' => false,
            ),
            array(
                'id'      => 'single_tag_link',
                'type'    => 'switcher',
                'title'   => 'Tag标签自动内链 ',
                'default' => false,
            ),
            array(
                'id'       => 'single_nofollow',
                'type'     => 'switcher',
                'title'    => '文章外链自动添加nofollow',
                'default'  => true,
                'subtitle' => '防止导出权重',
            ),
            array(
                'id'      => 'single_img_alt',
                'type'    => 'switcher',
                'title'   => '图片自动添加alt',
                'default' => true,
            ),
            array(
                'id'      => 'single_upload_filter',
                'type'    => 'switcher',
                'title'   => '上传文件重命名',
                'default' => true,
            ),
            array(
                'id'      => 'single_delete_post_and_img',
                'type'    => 'switcher',
                'title'   => '删除文章时删除图片附件',
                'default' => true,
            ),

        )
    ));
    CSF::createSection($ceotheme, array(
        'id'    => 'ceotheme_danye',
        'title' => '单页设置',
        'icon'  => 'fa fa-window-restore',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_danye',
        'title'  => '单页基本设置',
        'fields' => array(
            //默认页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '默认页设置',
            ),
            array(
                'id'      => 'page-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'page-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),

            //网址导航页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '网址导航页设置',
            ),
            array(
                'id'      => 'site-title',
                'type'    => 'text',
                'title'   => '页面标题',
                'default' => '网址导航',
            ),
            array(
                'id'      => 'site-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            //友链页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '友链页设置',
            ),
            array(
                'id'      => 'links-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'links-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            //标签页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '标签页设置',
            ),
            array(
                'id'      => 'tag-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'tag-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            //存档页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '存档页设置',
            ),
            array(
                'id'      => 'archives-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'archives-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            //合集页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '单页合集设置',
            ),
            array(
                'id'      => 'onepage-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'onepage-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            //投稿页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '投稿页设置',
            ),
            array(
                'id'      => 'togao-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'togao-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            //用户列表页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '用户列表页设置',
            ),
            array(
                'id'      => 'user-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'user-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_danye',
        'title'  => '专题页面设置',
        'fields' => array(
            //专题页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '专题页面顶部设置',
            ),
            array(
                'id'      => 'special-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'id'      => 'special-subtitle',
                'type'    => 'text',
                'title'   => '副标题',
                'default' => '跟着学就对了',
            ),
            array(
                'id'         => 'special_desc_sz',
                'type'       => 'repeater',
                'title'      => '顶部介绍设置',
                'fields'     => array(
                    array(
                        'id'         => 'icon',
                        'type'       => 'text',
                        'title'      => '图标',
                        'default'    => 'ceoicon-checkbox-circle-fill',
                        'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'    => 'title',
                        'type'  => 'text',
                        'title' => '标题',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线',
            ),
            array(
                'id'      => 'special-bg-mk',
                'type'    => 'upload',
                'title'   => '专题列表模块背景图',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
                'desc'    => '也可以在后台专题目录中独立设置专题列表模块背景图片~未独立设置则自动调用该设置中默认模块背景图片'
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线',
            ),
            array(
                'id'      => 'special-bg-db',
                'type'    => 'upload',
                'title'   => '专题内页顶部背景图',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
                'desc'    => '也可以在后台专题目录中独立设置专题内页顶部背景图~未独立设置则自动调用该设置中默认专题内页顶部背景图'
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线',
            ),
            array(
                'id'         => 'special-an',
                'type'       => 'switcher',
                'title'      => '申请专题',
                'desc'       => '开启或关闭是否申请专题按钮（开启则显示，关闭则隐藏）',
                'default'    => true
            ),
            array(
                'id'         => 'special-an-text',
                'type'       => 'text',
                'dependency' => array( 'special-an', '==', true ),
                'title'      => '申请专题按钮标题',
                'default'    => '申请专题',
            ),
            array(
                'id'         => 'special-an-link',
                'type'       => 'text',
                'dependency' => array( 'special-an', '==', true ),
                'title'      => '申请专题按钮链接',
                'default'    => '/',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线',
            ),
            array(
                'id'         => 'special_foo',
                'type'       => 'switcher',
                'title'      => '专题底部模块',
                'desc'       => '开启或关闭专题底部模块（开启则显示，关闭则隐藏）',
                'default'    => true
            ),
            array(
                'id'         => 'special_foomk',
                'type'       => 'fieldset',
                'title'      => '专题底部模块设置',
                'dependency' => array('special_foo', '==', true),
                'fields'     => array(
                    array(
                        'id'      => 'special_foomk_title',
                        'type'    => 'text',
                        'title'   => '主标题',
                        'default' => '职场，是一个不断打怪升级的过程',
                    ),
                    array(
                        'id'      => 'special_foomk_subtitle',
                        'type'    => 'text',
                        'title'   => '副标题',
                        'default' => '而职业路径，就是那个助你通关的秘密武',
                    ),
                    array(
                        'id'      => 'special_foomk_desc',
                        'type'    => 'text',
                        'title'   => '描述',
                        'default' => '以广告设计师为例，职业路径带你全面学习每个阶段的所需技能<br>你负责升级打怪 我们负责帮你加Buff',
                    ),
                    array(
                        'id'      => 'special_foomk_img',
                        'type'    => 'upload',
                        'title'   => '图片',
                        'default' => get_template_directory_uri() . '/static/images/ceo-special-item.png',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_danye',
        'title'  => '申请入驻设置',
        'fields' => array(
            //申请入驻页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '申请入驻页顶部设置',
            ),
            array(
                'id'      => 'apply-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'apply-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '申请入驻页模块设置',
            ),
            array(
                'id'      => 'apply-title',
                'type'    => 'text',
                'title'   => '主标题',
                'default' => '创作者入驻申请',
            ),
            array(
                'id'     => 'apply_zz',
                'type'   => 'repeater',
                'title'  => '介绍模块设置',
                'fields' => array(
                    array(
                        'id'           => 'img',
                        'type'         => 'upload',
                        'title'        => '图片',
                        'library'      => 'image',
                        'placeholder'  => 'http://',
                        'button_title' => '上传',
                        'remove_title' => '删除',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'subtitle',
                        'type'    => 'text',
                        'title'   => '副标题',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '申请入驻页资料设置',
            ),
            array(
                'id'      => 'apply_sz_username',
                'type'    => 'switcher',
                'title'   => '账号名称',
                'desc'    => '是否需要填写账号名称（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            array(
                'id'      => 'apply_sz_bankno',
                'type'    => 'switcher',
                'title'   => '真实姓名',
                'desc'    => '是否需要填写真实姓名（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            array(
                'id'      => 'apply_sz_score',
                'type'    => 'switcher',
                'title'   => '身份证号',
                'desc'    => '是否需要填写身份证号（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            array(
                'id'      => 'apply_sz_hyid',
                'type'    => 'switcher',
                'title'   => '会员ID',
                'desc'    => '是否需要填写会员ID（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            array(
                'id'      => 'apply_sz_sfz',
                'type'    => 'switcher',
                'title'   => '身份证照',
                'desc'    => '是否需要上传身份证照（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            array(
                'id'      => 'apply_sz_phone',
                'type'    => 'switcher',
                'title'   => '手机号码',
                'desc'    => '是否需要填写手机号码（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            array(
                'id'      => 'apply_sz_price',
                'type'    => 'switcher',
                'title'   => '微信号码',
                'desc'    => '是否需要填写微信号码（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            array(
                'id'      => 'apply_sz_yzmcode',
                'type'    => 'switcher',
                'title'   => '备注信息',
                'desc'    => '是否需要填写备注信息（开启则显示，关闭则隐藏）',
                'default' => true
            ),

        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_danye',
        'title'  => '问答页面设置',
        'fields' => array(
            //问答页面设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '问答社区顶部设置',
            ),
            array(
                'id'      => 'is_enable_question',
                'type'    => 'switcher',
                'title'   => '开启问答功能',
                'default' => true,
                'desc'    => '此按钮关闭后将关闭问答全部功能',
            ),
            array(
                'id'      => 'question-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'id'      => 'question-title',
                'type'    => 'text',
                'title'   => '问答社区标题',
                'default' => '问答社区',
            ),
            array(
                'id'      => 'question-subtitle',
                'type'    => 'text',
                'title'   => '副标题',
                'default' => '有问必答',
            ),
            array(
                'id'         => 'question_desc_sz',
                'type'       => 'repeater',
                'title'      => '顶部介绍设置',
                'fields'     => array(
                    array(
                        'id'         => 'icon',
                        'type'       => 'text',
                        'title'      => '图标',
                        'default'    => 'ceoicon-checkbox-circle-fill',
                        'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'    => 'title',
                        'type'  => 'text',
                        'title' => '标题',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '问答审核设置',
            ),
            array(
                'id'      => 'question_check',
                'type'    => 'switcher',
                'title'   => '提问审核',
                'desc'    => '开启按钮则无需审核直接显示，关闭按钮则需要审核后显示',
                'default' => true
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '悬赏问答设置',
            ),
            array(
                'id'      => 'answer_question_money',
                'type'    => 'switcher',
                'title'   => '问答悬赏功能',
                'desc'    => '开启或关闭问答悬赏功能',
                'default' => false,
                'desc' => '开启后将允许用户在问答中心发布悬赏问答',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '友情提示设置',
            ),
            array(
                'id'      => 'question_ts_title',
                'type'    => 'text',
                'title'   => '友情提示标题',
                'default' => '友情提示：',
            ),
            array(
                'id'      => 'question_ts_text',
                'type'    => 'textarea',
                'title'   => '友情提示内容',
                'default' => '<li>①：请勿重复提交内容</li><li>②：请勿提交违法违规内容</li><li>③：提交违法违规内容者将给予永久封号</li>',
                'desc'    => '请根据以上示例添加',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '问答内页设置',
            ),
            array(
                'id'      => 'question_single_bq',
                'type'    => 'textarea',
                'title'   => '版权声明',
                'default' => '版权：言论仅代表个人观点，不代表官方立场。',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '问答侧边栏设置',
            ),
            array(
                'id'      => 'question_sidebar_ad',
                'type'    => 'upload',
                'title'   => '广告图片',
                'default' => get_template_directory_uri() . '/static/images/ceo-question-ad.png',
            ),
            array(
                'id'      => 'question_sidebar_ad_title',
                'type'    => 'text',
                'title'   => '广告标题',
                'default' => '总裁主题',
            ),
            array(
                'id'      => 'question_sidebar_ad_link',
                'type'    => 'text',
                'title'   => '广告链接',
                'default' => 'https://www.ceotheme.com',
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_danye',
        'title'  => '论坛页面设置',
        'fields' => array(
            //论坛页面设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '论坛顶部设置',
            ),
            array(
                'id'      => 'is_enable_forum',
                'type'    => 'switcher',
                'title'   => '是否开启论坛功能',
                'desc'    => '此按钮关闭后将关闭论坛全部功能',
                'default' => true,
            ),
            array(
                'id'      => 'forum-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'id'      => 'forum-title',
                'type'    => 'text',
                'title'   => '论坛标题',
                'default' => '论坛大厅',
            ),
            array(
                'id'      => 'forum-subtitle',
                'type'    => 'text',
                'title'   => '副标题',
                'default' => '交流社区',
            ),
            array(
                'id'         => 'forum_desc_sz',
                'type'       => 'repeater',
                'title'      => '顶部介绍设置',
                'fields'     => array(
                    array(
                        'id'         => 'icon',
                        'type'       => 'text',
                        'title'      => '图标',
                        'default'    => 'ceoicon-checkbox-circle-fill',
                        'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'    => 'title',
                        'type'  => 'text',
                        'title' => '标题',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '论坛审核设置',
            ),
            array(
                'id'      => 'forum_check',
                'type'    => 'switcher',
                'title'   => '提问审核',
                'desc'    => '开启按钮则无需审核直接显示，关闭按钮则需要审核后显示',
                'default' => true
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '友情提示设置',
            ),
            array(
                'id'      => 'forum_ts_title',
                'type'    => 'text',
                'title'   => '友情提示标题',
                'default' => '友情提示：',
            ),
            array(
                'id'      => 'forum_ts_text',
                'type'    => 'textarea',
                'title'   => '友情提示内容',
                'default' => '<li>①：请勿重复提交内容</li><li>②：请勿提交违法违规内容</li><li>③：提交违法违规内容者将给予永久封号</li>',
                'desc'    => '请根据以上示例添加',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '论坛内页设置',
            ),
            array(
                'id'      => 'forum_single_bq',
                'type'    => 'textarea',
                'title'   => '版权声明',
                'default' => '版权：言论仅代表个人观点，不代表官方立场。',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '论坛侧边栏设置',
            ),
            array(
                'id'      => 'forum_sidebar_ad',
                'type'    => 'upload',
                'title'   => '广告图片',
                'default' => get_template_directory_uri() . '/static/images/ceo-question-ad.png',
            ),
            array(
                'id'      => 'forum_sidebar_ad_title',
                'type'    => 'text',
                'title'   => '广告标题',
                'default' => '总裁主题',
            ),
            array(
                'id'      => 'forum_sidebar_ad_link',
                'type'    => 'text',
                'title'   => '广告链接',
                'default' => 'https://www.ceotheme.com',
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_danye',
        'title'  => '会员页面设置',
        'fields' => array(
            //会员页面设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '会员页面顶部设置',
            ),
            array(
                'id'      => 'vip-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'id'      => 'vip-subtitle',
                'type'    => 'text',
                'title'   => '副标题',
                'default' => '精品课程随心学',
            ),
            array(
                'id'         => 'vip_desc_sz',
                'type'       => 'repeater',
                'title'      => '顶部介绍设置',
                'fields'     => array(
                    array(
                        'id'         => 'icon',
                        'type'       => 'text',
                        'title'      => '图标',
                        'default'    => 'ceoicon-checkbox-circle-fill',
                        'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'    => 'title',
                        'type'  => 'text',
                        'title' => '标题',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '会员特权设置',
            ),
            array(
                'id'      => 'vip_tq_title',
                'type'    => 'text',
                'title'   => '会员特权标题',
                'default' => '尊享特权',
            ),
            array(
                'id'      => 'vip_tq_subtitle',
                'type'    => 'text',
                'title'   => '会员特权副标题',
                'default' => '加入VIP，精品学习课程随心学！',
            ),
            array(
                'id'         => 'vip_tq_sz',
                'type'       => 'repeater',
                'title'      => '会员特权内容设置',
                'fields'     => array(
                    array(
                        'id'         => 'ico',
                        'type'       => 'text',
                        'title'      => '图标',
                        'default'    => 'ceoicon-gift-2-line',
                        'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'content',
                        'type'    => 'textarea',
                        'title'   => '副标题',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '常见问题设置',
            ),
            array(
                'id'      => 'vip_qa_title',
                'type'    => 'text',
                'title'   => '常见问题标题',
                'default' => '常见问题',
            ),
            array(
                'id'      => 'vip_qa_subtitle',
                'type'    => 'text',
                'title'   => '常见问题副标题',
                'default' => '为您解决烦忧，总裁主题势在必行！',
            ),
            array(
                'id'         => 'vip_qa_sz',
                'type'       => 'repeater',
                'title'      => '常见问题内容设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'content',
                        'type'    => 'textarea',
                        'title'   => '内容',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_danye',
        'title'  => '服务页面设置',
        'fields' => array(
            //服务页面设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '服务页面顶部设置',
            ),
            array(
                'id'      => 'pageservice-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'id'      => 'pageservice-subtitle',
                'type'    => 'text',
                'title'   => '副标题',
                'default' => '专业有保障',
            ),
            array(
                'id'         => 'pageservice_desc_sz',
                'type'       => 'repeater',
                'title'      => '顶部介绍设置',
                'fields'     => array(
                    array(
                        'id'         => 'icon',
                        'type'       => 'text',
                        'title'      => '图标',
                        'default'    => 'ceoicon-checkbox-circle-fill',
                        'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'    => 'title',
                        'type'  => 'text',
                        'title' => '标题',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '服务页面顶部简介设置',
            ),
            array(
                'id'         => 'pageservice_top_sz',
                'type'       => 'repeater',
                'title'      => '顶部介绍设置',
                'fields'     => array(
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '图片',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => '描述',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '服务办理设置',
            ),
            array(
                'id'      => 'pageservice_ban_title',
                'type'    => 'text',
                'title'   => '模块标题',
                'default' => '业务办理',
            ),
            array(
                'id'      => 'pageservice_ban_subtitle',
                'type'    => 'text',
                'title'   => '模块副标题',
                'default' => '一站式服务，让战略落地，让业绩起飞',
            ),
            array(
                'id'         => 'pageservice_ban_sz',
                'type'       => 'repeater',
                'title'      => '模块内容设置',
                'fields'     => array(
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '背景图片',
                        'default' => get_template_directory_uri() . '/static/images/ceo-service-banbg.jpg',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '业务标题',
                        'default' => '公司注册+代账',
                    ),
                    array(
                        'id'      => 'price',
                        'type'    => 'text',
                        'title'   => '业务价格',
                        'default' => '999元起',
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'textarea',
                        'title'   => '业务描述',
                        'desc'    => '请根据以上格式填写',
                        'default' => '<p>优化记账方式为客户降低成本</p>
<p>注册公司核名查询</p>
<p>帮您跑公司注册流程</p>
<p>专属财税顾问免费</p>',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '服务保障设置',
            ),
            array(
                'id'      => 'pageservice_bao_title',
                'type'    => 'text',
                'title'   => '模块标题',
                'default' => '服务保障',
            ),
            array(
                'id'      => 'pageservice_bao_subtitle',
                'type'    => 'text',
                'title'   => '模块副标题',
                'default' => '积累丰富的经验，只为给你提供更好的服务',
            ),
            array(
                'id'         => 'pageservice_bao_sz',
                'type'       => 'repeater',
                'title'      => '模块内容设置',
                'fields'     => array(
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '图片',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => '描述',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '常见问题设置',
            ),
            array(
                'id'      => 'pageservice_qa_title',
                'type'    => 'text',
                'title'   => '模块标题',
                'default' => '常见问题',
            ),
            array(
                'id'         => 'pageservice_qa_sz',
                'type'       => 'repeater',
                'title'      => '模块内容设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => '描述',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '底部更多设置',
            ),
            array(
                'id'      => 'pageservice_gd_title',
                'type'    => 'text',
                'title'   => '模块标题',
                'default' => '我们还提供',
            ),
            array(
                'id'         => 'pageservice_gd_sz',
                'type'       => 'repeater',
                'title'      => '模块内容设置',
                'fields'     => array(
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '图片',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                ),
            ),
        )
    ));
    /*
     * ------------------------------------------------------------------------------
     * 广告设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id'     => 'ceotheme_ad',
        'icon'   => 'fa fa-bell',
        'title'  => '广告设置',
        'fields' => array(
            array(
                'id'      => 'cat_zz_show',
                'type'    => 'switcher',
                'title'   => '分类顶部广告',
                'desc'    => '栏目分类顶部广告（开启则显示，关闭则隐藏）',
                'default' => false,
            ),
            array(
                'id'         => 'cat_zz_link',
                'type'       => 'text',
                'title'      => '图片链接',
                'dependency' => array('cat_zz_show', '==', 'true'),
                'default'    => '/'
            ),
            array(
                'id'           => 'cat_zz_img',
                'type'         => 'upload',
                'title'        => '上传图片',
                'dependency'   => array('cat_zz_show', '==', 'true'),
                'library'      => 'image',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （内页顶部广告设置）',
            ),
            //内页顶部广告
            array(
                'id'      => 'single_zz_top',
                'type'    => 'switcher',
                'title'   => '内页顶部广告',
                'desc'    => '内页顶部广告（开启则显示，关闭则隐藏）',
                'default' => false,
            ),
            array(
                'id'         => 'single_zz_top_link',
                'type'       => 'text',
                'title'      => '图片链接',
                'dependency' => array('single_zz_top', '==', 'true'),
                'default'    => '/'
            ),
            array(
                'id'           => 'single_zz_top_img',
                'type'         => 'upload',
                'title'        => '上传图片',
                'dependency'   => array('single_zz_top', '==', 'true'),
                'library'      => 'image',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （内页内容顶部广告设置）',
            ),
            //内页内容顶部广告
            array(
                'id'      => 'single_zz_top_content',
                'type'    => 'switcher',
                'title'   => '内页内容顶部广告',
                'desc'    => '内页内容顶部广告（开启则显示，关闭则隐藏）',
                'default' => false,
            ),
            array(
                'id'         => 'single_zz_top_content_link',
                'type'       => 'text',
                'title'      => '图片链接',
                'dependency' => array('single_zz_top_content', '==', 'true'),
                'default'    => '/'
            ),
            array(
                'id'           => 'single_zz_top_content_img',
                'type'         => 'upload',
                'title'        => '上传图片',
                'dependency'   => array('single_zz_top_content', '==', 'true'),
                'library'      => 'image',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （内页底部广告设置）',
            ),
            //内页底部广告
            array(
                'id'      => 'single_zz_foo_content',
                'type'    => 'switcher',
                'title'   => '内页底部广告',
                'desc'    => '内页底部广告（开启则显示，关闭则隐藏）',
                'default' => false,
            ),
            array(
                'id'         => 'single_zz_foo_content_link',
                'type'       => 'text',
                'title'      => '图片链接',
                'dependency' => array('single_zz_foo_content', '==', 'true'),
                'default'    => '/'
            ),
            array(
                'id'           => 'single_zz_foo_content_img',
                'type'         => 'upload',
                'title'        => '上传图片',
                'dependency'   => array('single_zz_foo_content', '==', 'true'),
                'library'      => 'image',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
            ),
        )
    ));
    /*
     * ------------------------------------------------------------------------------
     * 底部设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id'     => 'ceotheme_boo',
        'icon'   => 'fa fa-gears',
        'title'  => '底部设置',
    ));
    CSF::createSection($ceotheme, array(
        'parent'     => 'ceotheme_boo',
        'title'  => '底部Banner模块',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （底部Banner模块设置）',
            ),
            array(
                'id'      => 'ceo_foo_banner',
                'type'    => 'switcher',
                'title'   => '底部Banner模块',
                'desc'    =>'隐藏/显示底部Banner模块（开启则显示，关闭则隐藏，<b style="color: red;"></i>此按钮关闭后将关闭以下全部功能</b>）',
                'default' => true
            ),
            array(
                'id'          => 'ceo_footer_display',
                'type'        => 'select',
                'title'       => '底部Banner模块显示设置',
                'desc'        => '首页显示/全站显示（默认首页显示）',
                'options'     => array(
                    'index' => '首页显示',
                    'all'   => '全站显示',
                ),
                'default'     => 'index'
            ),
            array(
                'id'          => 'ceo_footer_style',
                'type'        => 'radio',
                'title'       => '底部Banner模块样式',
                'inline'      => true,
                'options'     => array(
                    '1' => '样式一【统计版】',
                    '2' => '样式二【极简版】',
                ),
                'desc'        => '两个样式都在以下底部Banner模块设置内容，选择极简版时不用设置【底部Banner统计设置和建站日期】',
                'default'     => '1',
            ),
            array(
                'id'          => 'ceo_footer_sz',
                'type'        => 'fieldset',
                'title'       => '样式一底部Banner模块设置',
                'dependency'  => array('ceo_footer_style', '==', '1'),
                'fields'      => array(
                    array(
                        'id'      => 'ceo_foo_bannerbg',
                        'type'    => 'upload',
                        'title'   => '底部Banner模块背景图',
                        'default' => get_template_directory_uri() . '/static/images/ceo-footer-banner.jpg'
                    ),
                    array(
                        'id'         => 'ceo_foo_banner_title',
                        'type'       => 'text',
                        'title'      => '主标题',
                        'default'    => '你的前景，远超我们想象',
                    ),
                    array(
                        'id'         => 'ceo_foo_banner_antitle',
                        'type'       => 'text',
                        'title'      => '按钮标题',
                        'default'    => '申请入驻',
                    ),
                    array(
                        'id'         => 'ceo_foo_banner_anlink',
                        'type'       => 'text',
                        'title'      => '按钮链接',
                        'default'    => '/',
                    ),
                ),
            ),
            array(
                'id'          => 'ceo_footer_count_sz',
                'type'        => 'fieldset',
                'title'       => '样式一底部Banner统计设置',
                'dependency'  => array('ceo_footer_style', '==', '1'),
                'fields'      => array(
                    array(
                        'id'         => 'all_view_count_title',
                        'type'       => 'text',
                        'title'      => '更换全站访问数量统计标题',
                        'default'    => '访问总数',
                    ),
                    array(
                        'id'         => 'all_huiyuan_count_title',
                        'type'       => 'text',
                        'title'      => '更换会员数量统计标题',
                        'default'    => '会员总数',
                    ),
                    array(
                        'id'         => 'all_site_count_title',
                        'type'       => 'text',
                        'title'      => '更换全站文章统计标题',
                        'default'    => '文章总数',
                    ),
                    array(
                        'id'         => 'all_jinri_count_title',
                        'type'       => 'text',
                        'title'      => '更换今日发布统计标题',
                        'default'    => '今日发布',
                    ),
                    array(
                        'id'         => 'all_benzhou_count_title',
                        'type'       => 'text',
                        'title'      => '更换本周发布统计标题',
                        'default'    => '本周发布',
                    ),
                    array(
                        'id'         => 'all_yunxing_count_title',
                        'type'       => 'text',
                        'title'      => '更换运行天数统计标题',
                        'default'    => '运行天数',
                    ),
                ),
            ),
            array(
                'id'          => 'all_yunxing_count',
                'type'        => 'text',
                'dependency'  => array('ceo_footer_style', '==', '1'),
                'title'       => '建站日期',
                'desc'        => '填写建站日期进行时间统计，格式：2011-11-11',
            ),
            array(
                'id'          => 'ceo_footerer_sz',
                'type'        => 'fieldset',
                'title'       => '样式二底部Banner模块设置',
                'dependency'  => array('ceo_footer_style', '==', '2'),
                'fields'      => array(
                    array(
                        'id'      => 'ceo_fooer_bannerbg',
                        'type'    => 'upload',
                        'title'   => '底部Banner模块背景图',
                        'default' => get_template_directory_uri() . '/static/images/ceo-footer-bannerer.jpg'
                    ),
                    array(
                        'id'         => 'ceo_fooer_banner_title',
                        'type'       => 'text',
                        'title'      => '主标题',
                        'default'    => '你的前景，远超我们想象',
                    ),
                    array(
                        'id'         => 'ceo_fooer_banner_antitle',
                        'type'       => 'text',
                        'title'      => '按钮标题',
                        'default'    => '申请入驻',
                    ),
                    array(
                        'id'         => 'ceo_fooer_banner_anlink',
                        'type'       => 'text',
                        'title'      => '按钮链接',
                        'default'    => '/',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent'     => 'ceotheme_boo',
        'title'  => '底部基本设置',
        'fields' => array(

            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （底部模块设置）',
            ),
            array(
                'id'         => 'foot_gz',
                'type'       => 'fieldset',
                'title'      => '二维码模块',
                'fields'     => array(
                    array(
                        'id'         => 'foot_gztitle',
                        'type'       => 'text',
                        'title'      => '二维码标题',
                        'default'    => '关注我们',
                    ),
                    array(
                        'id'         => 'foot_gzsubtitle',
                        'type'       => 'text',
                        'title'      => '二维码副标题',
                        'default'    => '总裁主题专注教育培训',
                    ),
                    array(
                        'id'      => 'foot_gzimg',
                        'type'    => 'upload',
                        'title'   => '底部二维码',
                        'default' => get_template_directory_uri() . '/static/images/ceo-ma.png'
                    ),
                ),
            ),
            array(
                'id'     => 'foot_menu',
                'type'   => 'group',
                'max'    => '4',
                'title'  => '底部快捷导航',
                'fields' => array(
                    array(
                        'id'    => 'h4',
                        'type'  => 'text',
                        'title' => '菜单标题',
                    ),
                    array(
                        'id'     => 'foot_menu_item',
                        'type'   => 'repeater',
                        'title'  => '添加菜单',
                        'fields' => array(
                            array(
                                'id'    => 'title',
                                'type'  => 'text',
                                'title' => '标题',
                            ),
                            array(
                                'id'    => 'link',
                                'type'  => 'text',
                                'title' => '链接',
                            ),
                        ),
                    ),
                ),
            ),
            array(
                'id'         => 'foot_lainx',
                'type'       => 'fieldset',
                'title'      => '右侧联系模块',
                'fields'     => array(
                    array(
                        'id'         => 'foot_lainx_title',
                        'type'       => 'text',
                        'title'      => '按钮标题',
                        'default'    => '客服QQ : 88888888',
                    ),
                    array(
                        'id'      => 'foot_lainx_icon',
                        'type'    => 'text',
                        'title'   => '按钮图标',
                        'default' => 'ceoicon-qq-fill',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'         => 'foot_lainx_link',
                        'type'       => 'text',
                        'title'      => '按钮链接',
                        'default'    => 'tencent://Message/?Uin=88888888&amp;websiteName=#=&amp;Menu=yes',
                    ),
                    array(
                        'id'         => 'foot_lainx_desc',
                        'type'       => 'textarea',
                        'title'      => '更多信息',
                        'desc'       => '请务必按照以上格式修改或添加',
                        'default'    => '<p>客服电话：400-888-8888</p>
<p>客服邮箱：vip@88888888.com</p>
<p>周一至周五 9:00-18:00</p>
<p>公司地址：广东省广州市荔湾区景城广场商务办公楼A001座A9233</p>',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （底部友情链接设置）',
            ),
            array(
                'id'      => 'link_show',
                'type'    => 'switcher',
                'title'   => '友情链接',
                'desc'    =>'隐藏/显示底部友情链接（开启则显示，关闭则隐藏）<a href="/wp-admin/link-manager.php" style="color: #0a8eff;">前往添加友链</a>',
                'default' => true
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （底部基本设置）',
            ),
            array(
                'id'      => 'cop_text',
                'type'    => 'textarea',
                'title'   => '网站底部版权文字',
                'desc'    => '可以使用html编辑',
                'default' => '© 2022 总裁主题 - CEOTHEME.COM & WordPress Theme. All rights reserved'
            ),
            array(
                'id'      => 'foot_xml-y',
                'type'    => 'switcher',
                'title'   => '网站地图',
                'label'   => '隐藏/显示底部网站地图（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'         => 'foot_xml',
                'type'       => 'text',
                'title'      => '地图地址',
                'desc'       => '<p>网站地图链接地址<h5 class="csf-text-desc" style="color: #0a8eff;">（推荐使用：Google XML Sitemaps 插件）</h5>后台-插件-搜索Google XML Sitemaps-安装谷歌 XML 站点地图-启用',
                'default'    => '/sitemap.xml',
                'dependency' => array('foot_xml-y', '==', 'true'),
            ),
            array(
                'id'      => 'show_beian',
                'type'    => 'switcher',
                'title'   => '网站底部备案号',
                'desc'    =>'隐藏/显示网站备案号（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            array(
                'id'         => 'beian',
                'type'       => 'text',
                'dependency' => array('show_beian', '==', true),
                'title'      => '网站备案号',
                'default'    => '闽ICP备888888888号'
            ),
            array(
                'id'      => 'foot_gongan',
                'type'    => 'switcher',
                'title'   => '是否显示公安备案',
                'desc'    => '隐藏/显示底部公安备案号（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'         => 'foot_gongan_beianhao',
                'dependency' => array('foot_gongan', '==', 'true'),
                'type'       => 'text',
                'title'      => '公安备案号',
                'default'    => '闽公安网备888888888号'
            ),
            array(
                'id'      => 'theme_cop',
                'type'    => 'switcher',
                'title'   => '隐藏/显示主题版权',
                'desc'    => '隐藏版权希望可以在底部友情链接中添加作者网站链接（版权展示已经添加了nofollow标签，搜索引擎不会对作者网站进行追踪，所以如果可以请显示，感谢支持！）',
                'default' => true
            ),
        )
    ));
    /*
     * ------------------------------------------------------------------------------
     * 手机设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id'     => 'ceotheme_app',
        'icon'   => 'fa fa-tablet',
        'title'  => '手机设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （手机中部菜单设置）',
            ),
            array(
                'id'      => 'ceo_app_zcd',
                'type'    => 'switcher',
                'title'   => '手机中部菜单',
                'desc'    => '开启或关闭手机中部菜单（开启则显示，关闭则隐藏）',
                'default' => false,
            ),
            array(
                'id'         => 'ceo_app_zcd_sz',
                'type'       => 'repeater',
                'title'      => '手机中部菜单设置',
                'dependency' => array('ceo_app_zcd', '==', true),
                'fields'     => array(
                    array(
                        'id'      => 'img',
                        'type'    => 'text',
                        'title'   => '图标',
                        'type'    => 'upload',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '链接',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （手机中部CMS模块设置）',
            ),
            array(
                'id'      => 'ceo_app_cms',
                'type'    => 'switcher',
                'title'   => '手机中部CMS模块',
                'desc'    => '开启或关闭手机中部CMS模块（开启则显示，关闭则隐藏）',
                'default' => false,
            ),
            array(
                'id'         => 'ceo_app_cms_sz',
                'type'       => 'repeater',
                'title'      => '手机中部CMS模块设置',
                'dependency' => array('ceo_app_cms', '==', true),
                'fields'     => array(
                    array(
                        'id'      => 'style',
                        'type'    => 'text',
                        'title'   => '模块颜色',
                        'default' => 'linear-gradient(to right bottom,#b4b4fe,#7574fc)',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'subtitle',
                        'type'    => 'text',
                        'title'   => '副标题',
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '链接',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （手机底部菜单设置）',
            ),
            array(
                'id'      => 'ceo_app_foo',
                'type'    => 'switcher',
                'title'   => '手机底部菜单',
                'desc'    => '开启或关闭手机底部菜单（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'         => 'ceo_app_foo_sz',
                'type'       => 'fieldset',
                'title'      => '手机底部菜单设置',
                'dependency' => array('ceo_app_foo', '==', true),
                'fields'     => array(
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线 （手机底部左侧菜单设置）',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_ico1',
                        'type'    => 'text',
                        'title'   => '左侧菜单1图标',
                        'default' => 'ceoicon-home-3-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_title1',
                        'type'    => 'text',
                        'title'   => '左侧菜单1标题',
                        'default' => '首页',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_link1',
                        'type'    => 'text',
                        'title'   => '左侧菜单1链接',
                        'default' => '/',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_ico2',
                        'type'    => 'text',
                        'title'   => '左侧菜单2图标',
                        'default' => 'ceoicon-home-3-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_title2',
                        'type'    => 'text',
                        'title'   => '左侧菜单2标题',
                        'default' => '首页',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_link2',
                        'type'    => 'text',
                        'title'   => '左侧菜单2链接',
                        'default' => '/',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线 （手机底部右侧菜单设置）',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_icoy1',
                        'type'    => 'text',
                        'title'   => '右侧菜单1图标',
                        'default' => 'ceoicon-home-3-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_titley1',
                        'type'    => 'text',
                        'title'   => '右侧菜单1标题',
                        'default' => '首页',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_linky1',
                        'type'    => 'text',
                        'title'   => '右侧菜单1链接',
                        'default' => '/',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_icoy2',
                        'type'    => 'text',
                        'title'   => '右侧菜单2图标',
                        'default' => 'ceoicon-home-3-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_titley2',
                        'type'    => 'text',
                        'title'   => '右侧菜单2标题',
                        'default' => '首页',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_linky2',
                        'type'    => 'text',
                        'title'   => '右侧菜单2链接',
                        'default' => '/',
                    ),
                ),
            ),
        )
    ));
    //扩展功能设置
    CSF::createSection($ceotheme, array(
        'id'    => 'ceotheme_function',
        'icon'  => 'fa fa-laptop',
        'title' => '扩展功能',
    ));
    CSF::createSection($ceotheme, array(
        'parent'     => 'ceotheme_function',
        'title'  => '扩展功能设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （文章随机阅读量）',
            ),
            array(
                'id'      => 'is_rand_views',
                'type'    => 'switcher',
                'title'   => '文章随机阅读量',
                'desc'    => '开启或关闭自动文章阅读量功能（开启则发布文章自动生成，关闭则无）',
                'default' => true,
            ),
            array(
              'id'      => 'is_rand_views_sz_q',
              'dependency' => array('is_rand_views', '==', true),
              'type'    => 'number',
              'title'   => '自定义随机阅读量（起）',
              'default' => 100,
            ),
            array(
              'id'      => 'is_rand_views_sz_z',
              'dependency' => array('is_rand_views', '==', true),
              'type'    => 'number',
              'title'   => '自定义随机阅读量（止）',
              'default' => 1000,
            ),
            array(
              'type'    => 'submessage',
              'style'   => 'info',
              'content' => '自定义随机阅读量（起）与自定义随机阅读量（止）表示如：从100起1000止，100-1000内数值随机，可以自定义自由设置随机值',
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent'     => 'ceotheme_function',
        'title'       => '邮箱功能设置',
        'fields'      => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '总裁主题推荐使用163邮箱发信，更稳定、更高效~',
            ),
            array(
                'id'      => 'mail_smtps',
                'type'    => 'switcher',
                'title'   => 'SMTP邮箱功能',
                'desc'    => '开启或关闭SMTP邮箱功能（注意：开启时请关闭相关功能插件）',
                'default' => false,
            ),
            array(
                'id'       => 'mail_name',
                'type'     => 'text',
                'title'    => '发信邮箱',
                'desc'     => '请填写发信人邮箱帐号',
                'default'  => '88888888@163.com',
                'validate' => 'csf_validate_email',
            ),
            array(
                'id'       => 'mail_nicname',
                'type'     => 'text',
                'title'    => '发信人昵称',
                'desc'     => '请填写发信人昵称',
                'default'  => 'CeoEdu-Pro主题',
            ),
            array(
                'id'       => 'mail_host',
                'type'     => 'text',
                'title'    => '邮箱服务器',
                'desc'     => '请填写SMTP邮箱服务器地址',
                'default'  => 'smtp.163.com',
            ),
            array(
                'id'       => 'mail_port',
                'type'     => 'text',
                'title'    => '服务器端口',
                'desc'     => '请填写SMTP邮箱服务器端口',
                'default'  => '465',
            ),
            array(
                'id'       => 'mail_passwd',
                'type'     => 'text',
                'title'    => '邮箱独立密码',
                'desc'     => '请填写SMTP服务器邮箱独立密码（注意：非账号密码）',
                'default'  => '88888888',
                'attributes'  => array(
                    'type'      => 'password',
                    'autocomplete' => 'off',
                ),
            ),
            array(
                'id'      => 'mail_smtpauth',
                'type'    => 'switcher',
                'title'   => '启用SMTPAuth服务',
                'desc'    => '是否启用SMTPAuth服务',
                'default' => true,
            ),
            array(
                'id'       => 'mail_smtpsecure',
                'type'     => 'text',
                'title'    => 'SMTPSecure设置',
                'desc'     => '若启用SMTPAuth服务则填写ssl，若不启用则留空',
                'default'  => 'ssl',
            ),

        ),
    ));
    /*
     * ------------------------------------------------------------------------------
     * 美化设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id'     => 'ceotheme_qita',
        'icon'   => 'fa fa-paper-plane',
        'title'  => '美化设置',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_qita',
        'title'  => '右侧跟随设置',
        'fields' => array(
            array(
                'id'      => 'goTop',
                'type'    => 'switcher',
                'title'   => '网站右下角跟随总开关',
                'default' => true
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （活动按钮设置）',
            ),
            array(
                'id'         => 'goTop_hd',
                'type'       => 'switcher',
                'title'      => '活动图标按钮',
                'desc'       =>'开启或关闭活动图标按钮（开启则显示，关闭则隐藏）',
                'dependency' => array('goTop', '==', true),
                'default'    => true
            ),
            array(
                'id'         => 'goTop_hd_img',
                'type'       => 'upload',
                'title'      => '活动图片',
                'dependency' => array('goTop_hd', '==', true),
                'default'    => get_template_directory_uri() . '/static/images/ceo_follow_img.png',
                'desc'       => '建议弹窗图片尺寸：宽36px高63px',
            ),
            array(
                'id'         => 'goTop_hd_timg',
                'type'       => 'upload',
                'title'      => '活动弹窗图片',
                'dependency' => array('goTop_hd', '==', true),
                'default'    => get_template_directory_uri() . '/static/images/ceo-vip-tan.png',
                'desc'       => '建议弹窗图片尺寸：宽460px高460px',
            ),
            array(
                'id'         => 'goTop_hd_tlink',
                'type'       => 'text',
                'title'      => '活动弹窗链接',
                'dependency' => array('goTop_hd', '==', true),
                'default'    => '/vip',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （签到按钮设置）',
            ),
            array(
                'id'         => 'goTop_qd',
                'type'       => 'switcher',
                'title'      => '签到按钮',
                'desc'       =>'开启或关闭签到按钮（开启则显示，关闭则隐藏）',
                'default'    => true
            ),
            array(
                'id'         => 'goTop_qd_icon',
                'type'       => 'text',
                'title'      => '按钮图标',
                'default'    => 'ceoicon-calendar-line',
                'dependency' => array('goTop_qd', '==', true),
                'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （抽奖活动按钮设置）',
            ),
            array(
                'id'         => 'goTop_encourage',
                'type'       => 'switcher',
                'title'      => '抽奖按钮',
                'desc'       =>'开启或关闭抽奖活动按钮（开启则显示，关闭则隐藏）',
                'dependency' => array('goTop', '==', true),
                'default'    => true
            ),
            array(
                'id'         => 'goTop_encourage_icon',
                'type'       => 'text',
                'title'      => '按钮图标',
                'dependency' => array('goTop_encourage', '==', true),
                'default'    => 'ceoicon-gift-2-line',
                'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （快捷按钮设置）',
            ),
            array(
                'id'         => 'goTop_quick',
                'type'       => 'switcher',
                'title'      => '快捷按钮',
                'desc'       =>'开启或关闭跟随快捷按钮（开启则显示，关闭则隐藏）',
                'dependency' => array('goTop', '==', true),
                'default'    => true
            ),
            array(
                'id'         => 'goTop_quick_sz',
                'type'       => 'fieldset',
                'title'      => '快捷按钮设置',
                'dependency' => array('goTop_quick', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'goTop_quick_icon',
                        'type'       => 'text',
                        'title'      => '按钮图标',
                        'default'    => 'ceoicon-edit-2-line',
                        'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'         => 'goTop_quick_title',
                        'type'       => 'text',
                        'title'      => '主标题',
                        'default'    => '助力内容变现',
                    ),
                    array(
                        'id'         => 'goTop_quick_subtitle',
                        'type'       => 'text',
                        'title'      => '副标题',
                        'default'    => '将您的收入提升到一个新的水平',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线 （快捷按钮设置）',
                    ),
                    array(
                        'id'      => 'goTop_quick_1img',
                        'type'    => 'upload',
                        'title'   => '快捷按钮1图片',
                        'default' => get_template_directory_uri() . '/static/images/ceo-follow-k1.png',
                    ),
                    array(
                        'id'      => 'goTop_quick_1title',
                        'type'    => 'text',
                        'title'   => '快捷按钮1标题',
                        'default' => '发文章',
                    ),
                    array(
                        'id'      => 'goTop_quick_1link',
                        'type'    => 'text',
                        'title'   => '快捷按钮1链接',
                        'default' => '/tougao',
                    ),
                    array(
                        'id'      => 'goTop_quick_2img',
                        'type'    => 'upload',
                        'title'   => '快捷按钮2图片',
                        'default' => get_template_directory_uri() . '/static/images/ceo-follow-k2.png',
                    ),
                    array(
                        'id'      => 'goTop_quick_2title',
                        'type'    => 'text',
                        'title'   => '快捷按钮2标题',
                        'default' => '提问题',
                    ),
                    array(
                        'id'      => 'goTop_quick_2link',
                        'type'    => 'text',
                        'title'   => '快捷按钮2链接',
                        'default' => '/question?type=ask',
                    ),
                    array(
                        'id'      => 'goTop_quick_3img',
                        'type'    => 'upload',
                        'title'   => '快捷按钮3图片',
                        'default' => get_template_directory_uri() . '/static/images/ceo-follow-k3.png',
                    ),
                    array(
                        'id'      => 'goTop_quick_3title',
                        'type'    => 'text',
                        'title'   => '快捷按钮3标题',
                        'default' => '发帖子',
                    ),
                    array(
                        'id'      => 'goTop_quick_3link',
                        'type'    => 'text',
                        'title'   => '快捷按钮3链接',
                        'default' => '/forum?type=ask',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线 （主按钮设置）',
                    ),
                    array(
                        'id'      => 'goTop_quick_ztitle',
                        'type'    => 'text',
                        'title'   => '主按钮标题',
                        'default' => '发布资源',
                    ),
                    array(
                        'id'      => 'goTop_quick_zlink',
                        'type'    => 'text',
                        'title'   => '主按钮链接',
                        'default' => '/tougao',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （客服按钮设置）',
            ),
            array(
                'id'         => 'goTop_service',
                'type'       => 'switcher',
                'title'      => '客服按钮',
                'desc'       =>'开启或关闭跟随客服按钮（开启则显示，关闭则隐藏）',
                'dependency' => array('goTop', '==', true),
                'default'    => true
            ),
            array(
                'id'         => 'goTop_service_sz',
                'type'       => 'fieldset',
                'title'      => '客服按钮设置',
                'dependency' => array('goTop_service', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'goTop_service_icon',
                        'type'       => 'text',
                        'title'      => '按钮图标',
                        'default'    => 'ceoicon-customer-service-2-line',
                        'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'goTop_service_img',
                        'type'    => 'upload',
                        'title'   => '客服图片',
                        'default' => get_template_directory_uri() . '/static/images/ceo-gotop-qq.png',
                    ),
                    array(
                        'id'      => 'goTop_service_bt',
                        'type'    => 'text',
                        'title'   => '客服标题',
                        'default' => '点击联系客服',
                    ),
                    array(
                        'id'         => 'goTop_qq_qq',
                        'type'       => 'text',
                        'title'      => '客服QQ',
                        'default'    => '88888888'
                    ),
                    array(
                        'id'      => 'goTop_service_sj',
                        'type'    => 'text',
                        'title'   => '工作时间',
                        'default' => '在线时间：8:00-16:00',
                    ),
                    array(
                        'id'      => 'goTop_service_dhbt',
                        'type'    => 'text',
                        'title'   => '客服电话标题',
                        'default' => '客服电话',
                    ),
                    array(
                        'id'      => 'goTop_service_dhhm',
                        'type'    => 'text',
                        'title'   => '客服电话号码',
                        'default' => '400-888-8888',
                    ),
                    array(
                        'id'      => 'goTop_service_yxbt',
                        'type'    => 'text',
                        'title'   => '客服邮箱标题',
                        'default' => '客服邮箱',
                    ),
                    array(
                        'id'      => 'goTop_service_yxhm',
                        'type'    => 'text',
                        'title'   => '客服邮箱账号',
                        'default' => 'ceotheme@ceo.com',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （微信按钮设置）',
            ),
            array(
                'id'         => 'goTop_wx',
                'type'       => 'switcher',
                'title'      => '微信按钮',
                'desc'       =>'开启或关闭跟随微信按钮（开启则显示，关闭则隐藏）',
                'dependency' => array('goTop', '==', true),
                'default'    => true
            ),
            array(
                'id'         => 'goTop_wx_sz',
                'type'       => 'fieldset',
                'title'      => '微信按钮设置',
                'dependency' => array('goTop_wx', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'goTop_wx_icon',
                        'type'       => 'text',
                        'title'      => '按钮图标',
                        'default'    => 'ceoicon-qr-code-line',
                        'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'         => 'goTop_wx_title',
                        'type'       => 'text',
                        'title'      => '主标题',
                        'default'    => '扫描二维码',
                    ),
                    array(
                        'id'         => 'goTop_wx_subtitle',
                        'type'       => 'text',
                        'title'      => '副标题',
                        'default'    => '关注微信公众号',
                    ),
                    array(
                        'id'         => 'goTop_wx_img',
                        'type'       => 'upload',
                        'title'      => '微信二维码',
                        'default' => get_template_directory_uri() . '/static/images/ceo-ma.png',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （手机按钮设置）',
            ),
            array(
                'id'         => 'goTop_sj',
                'type'       => 'switcher',
                'title'      => '手机按钮',
                'desc'       =>'开启或关闭跟随手机按钮（开启则显示，关闭则隐藏）',
                'dependency' => array('goTop', '==', true),
                'default'    => true
            ),
            array(
                'id'         => 'goTop_sj_sz',
                'type'       => 'fieldset',
                'title'      => '手机按钮设置',
                'dependency' => array('goTop_sj', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'goTop_sj_icon',
                        'type'       => 'text',
                        'title'      => '按钮图标',
                        'default'    => 'ceoicon-smartphone-line',
                        'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'         => 'goTop_sj_title',
                        'type'       => 'text',
                        'title'      => '主标题',
                        'default'    => '扫描二维码',
                    ),
                    array(
                        'id'         => 'goTop_sj_subtitle',
                        'type'       => 'text',
                        'title'      => '副标题',
                        'default'    => '手机访问本站',
                    ),
                    array(
                        'id'         => 'goTop_sj_img',
                        'type'       => 'upload',
                        'title'      => '二维码',
                        'default' => get_template_directory_uri() . '/static/images/ceo-ma.png',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_qita',
        'title'  => '底部跟随设置',
        'fields' => array(
            array(
                'id'         => 'ceo_footer_vip',
                'type'       => 'switcher',
                'title'      => '底部跟随模块',
                'desc'       =>'开启或关闭底部跟随模块（开启则显示，关闭则隐藏）',
                'default'    => true
            ),
            array(
                'id'         => 'ceo_footer_vip_sz',
                'type'       => 'fieldset',
                'title'      => '底部跟随模块设置',
                'dependency' => array('ceo_footer_vip', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'footer_vip_img',
                        'type'       => 'upload',
                        'title'      => '模块图片',
                        'default'    => get_template_directory_uri() . '/static/images/vipmk-nz.png',
                        'desc'       =>'图片尺寸：宽700px高116px',
                    ),
                    array(
                        'id'      => 'footer_vip_1title',
                        'type'    => 'text',
                        'title'   => '按钮1标题',
                        'default' => '升级会员',
                    ),
                    array(
                        'id'      => 'footer_vip_1link',
                        'type'    => 'text',
                        'title'   => '按钮1链接',
                        'default' => '/vip',
                    ),
                    array(
                        'id'      => 'footer_vip_2title',
                        'type'    => 'text',
                        'title'   => '按钮2标题',
                        'default' => '客户服务',
                    ),
                    array(
                        'id'      => 'footer_vip_2link',
                        'type'    => 'text',
                        'title'   => '按钮2链接',
                        'default' => 'https://wpa.qq.com/msgrd?v=3&uin=88888888&site=qq&menu=yes',
                    ),
                    array(
                        'id'      => 'footer_vip_3title',
                        'type'    => 'text',
                        'title'   => '按钮3标题',
                        'default' => '服务办理',
                    ),
                    array(
                        'id'      => 'footer_vip_3link',
                        'type'    => 'text',
                        'title'   => '按钮3链接',
                        'default' => '/service',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_qita',
        'title'  => '主题美化设置',
        'fields' => array(
            array(
                'id'       => 'head_js',
                'type'     => 'textarea',
                'title'    => '网站底部自定义JS代码',
                'desc'     => '可用于添加第三方网站流量数据统计代码，如：百度统计或美化效果',
                'sanitize' => false,
                'default'  => '',
            ),
            array(
                'id'        => 'diy_css',
                'type'      => 'code_editor',
                'title'     => '自定义css样式',
                'desc'      => '少量css可以直接写在这里,注意：不需要添加《style》《/style》',
                'settings'  => array(
                    'theme' => 'mbo',
                    'mode'  => 'css',
                ),
            ),
        )
    ));

    /*
     * ------------------------------------------------------------------------------
     * 优化设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($ceotheme, array(
        'id'    => 'ceotheme_optimization',
        'icon'  => 'fa fa-rocket',
        'title' => '优化设置',
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_optimization',
        'title'  => '优化加速',
        'fields' => array(
            array(
                'id'       => 'gtb_editor',
                'type'     => 'switcher',
                'title'    => '禁用古腾堡编辑器',
                'default'  => true,
                'subtitle' => '古腾堡用不习惯吗？那就关闭吧！(默认关闭)',
            ),
            array(
                'id'       => 'googleapis',
                'type'     => 'switcher',
                'title'    => '后台禁止加载谷歌字体',
                'default'  => true,
                'subtitle' => '后台禁止加载谷歌字体，加快后台访问速度',
            ),
            array(
                'id'       => 'emoji',
                'type'     => 'switcher',
                'title'    => '禁用emoji表情',
                'default'  => true,
                'subtitle' => '禁用WordPress的Emoji功能和禁止head区域Emoji css加载',
            ),
            array(
                'id'       => 'article_revision',
                'type'     => 'switcher',
                'title'    => '屏蔽文章修订功能',
                'default'  => true,
                'subtitle' => '文章多，修订次数的用户建议关闭此功能',
            ),
        )
    ));
    CSF::createSection($ceotheme, array(
        'parent' => 'ceotheme_optimization',
        'title'  => '精简头部',
        'fields' => array(
            array(
                'id'       => 'toolbar',
                'type'     => 'switcher',
                'title'    => '移除顶部工具条',
                'default'  => true,
                'subtitle' => '这个大家应该都懂',
            ),
            array(
                'id'       => 'rest_api',
                'type'     => 'switcher',
                'title'    => '禁用REST API',
                'default'  => false,
                'subtitle' => '不准备打通WordPress小程序的用户建议关闭',
            ),
            array(
                'id'       => 'wpjson',
                'type'     => 'switcher',
                'title'    => '移除wp-json链接代码',
                'default'  => true,
                'subtitle' => '移除头部区域wp-json链接代码，精简头部区域代码',
            ),
            array(
                'id'       => 'emoji_script',
                'type'     => 'switcher',
                'title'    => '移除头部多余Emoji JavaScript代码',
                'default'  => true,
                'subtitle' => '移除头部多余Emoji JavaScript代码，精简头部区域代码',
            ),
            array(
                'id'       => 'wp_generator',
                'type'     => 'switcher',
                'title'    => '移除头部WordPress版本',
                'default'  => true,
                'subtitle' => '移除头部WordPress版本，精简头部区域代码',
            ),
            array(
                'id'       => 'wp_headcssjs',
                'type'     => 'switcher',
                'title'    => '移除头部JS和CSS链接中的Wordpress版本号',
                'default'  => true,
                'subtitle' => '移除头部JS和CSS链接中的Wordpress版本号，精简头部区域代码',
            ),
            array(
                'id'       => 'rsd_link',
                'type'     => 'switcher',
                'title'    => '移除离线编辑器开放接口',
                'default'  => true,
                'subtitle' => '移除WordPress自动添加两行离线编辑器的开放接口，精简头部区域代码',
            ),
            array(
                'id'       => 'index_rel_link',
                'type'     => 'switcher',
                'title'    => '清除前后文、第一篇文章、主页meta信息',
                'default'  => true,
                'subtitle' => 'WordPress把前后文、第一篇文章和主页链接全放在meta中。我认为于SEO帮助不大，反使得头部信息巨大，建议移出。',
            ),
            array(
                'id'       => 'feed',
                'type'     => 'switcher',
                'title'    => '移除文章、分类和评论feed',
                'default'  => true,
                'subtitle' => '移除文章、分类和评论feed，精简头部区域代码。',
            ),
            array(
                'id'       => 'dns_prefetch',
                'type'     => 'switcher',
                'title'    => '移除头部加载DNS预获取',
                'default'  => true,
                'subtitle' => '移出head区域dns-prefetch代码，精简头部区域代码。',
            ),

        )
    ));
}
