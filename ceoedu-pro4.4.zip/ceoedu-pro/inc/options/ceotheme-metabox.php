<?php if ( ! defined( 'ABSPATH' )  ) { die; }

if( class_exists( 'CSF' ) ) {
	$prefix_info = 'ceo_post_info';
	CSF::createMetabox( $prefix_info, array(
		'title'     => '<span class="ceotheme_com"><i class="fa fa-laptop"></i> CeoEdu-Pro主题 - 资源信息配置</span>',
		'nav'       => 'inline',
		'post_type' => 'post',
		'data_type' => 'unserialize',
		'context'   => 'normal',

	) );
	CSF::createSection($prefix_info, array(
	    'title'  => '资源信息',
        'fields' => array(
            array(
                'id'      => 'ceo-tese-tag',
                'type'    => 'text',
                'title'   => '文章标签',
                'desc'    => '文章标题前显示特色标签（例：热门、原创、转载等，填写后会显示在文章列表和文章内页标题前）',
            ),
            array(
                'id'      => 'ceo_video',
                'type'    => 'upload',
                'title'   => '视频文章',
                'desc'    => '可直接上传MP4视频，同时也可以填写MP4视频地址，或者使用第三方视频分享代码，如B站、腾讯视频、优酷等。',
            ),
            array(
                'id'      => 'ceo-tese-source',
                'type'    => 'text',
                'title'   => '文章来源',
                'desc'    => '填写后将显示在文章内容页底部，不填则不显示',
            ),
            //信息属性
            array(
                'id'         => 'down_info',
                'type'       => 'repeater',
                'title'      => '资源信息属性',
                'desc'       => '付费资源内页显示资源信息属性',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                        'default' => '标题',
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => '描述内容',
                        'default' => '这里是描述内容',
                    ),
                ),
                /*'default' => array(
                    array(
                        'title' => '模板类型',
                        'desc'  => '',
                    ),
                ),*/
            ),
            array(
                'id'    => 'ceo_commodity_kg',
                'type'  => 'switcher',
                'title' => '商品关联',
                'desc'  => '可用于关联各个商城平台的商品，显示在文章内页底部（高端玩家可利用此盈利）',
            ),
            array(
                'id'         => 'commodity_info',
                'type'       => 'repeater',
                'dependency' => array('ceo_commodity_kg', '==', 'true'),
                'title'      => '商品关联信息',
                'desc'       => '付费资源内页显示资源信息属性',
                'fields'     => array(
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '缩略图',
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '链接',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'platform',
                        'type'    => 'text',
                        'title'   => '平台',
                    ),
                    array(
                        'id'      => 'price',
                        'type'    => 'text',
                        'title'   => '价格',
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => '其他信息',
                    ),
                ),
                /*'default' => array(
                    array(
                        'title' => '模板类型',
                        'desc'  => '',
                    ),
                ),*/
            ),
        )

	) );
	
	CSF::createSection($prefix_info, array(
	    'title'  => '自定义SEO',
        'fields' => array(
            array(
                'id'      => 'ceo-seo-title',
                'type'    => 'text',
                'title'   => '自定义SEO标题',
                'desc'    => '填写自定义SEO标题，未填写则调用默认文章标题',
            ),
            array(
                'id'      => 'ceo-seo-keywords',
                'type'    => 'text',
                'title'   => '自定义SEO关键词',
                'desc'    => '填写自定义SEO关键词，未填写则调用默认文章标签',
            ),
            array(
                'id'      => 'ceo-seo-description',
                'type'    => 'textarea',
                'title'   => '自定义SEO描述',
                'desc'    => '填写自定义SEO描述，未填写则调用默认文章内容前段',
            ),
        )

	) );
}

//文章绑定专题
if (class_exists('CSF')) {
    $prefix = 'my_post_special';
    CSF::createMetabox($prefix, array(
        'title'     => '专题',
        'post_type' => 'post',
        'context'   => 'side',
    ));
    CSF::createSection($prefix, [
        'fields' => array(
            [
                'id'          => 'special_select',
                'type'        => 'select',
                'title'       => '',
                'placeholder' => '选择专题',
                'options'     => 'categories',
                'query_args'  => array(
                'taxonomy'    => 'special',
                ),
            ]

        )
    ]);


    $prefix = 'my_post_custom_url_image';
    CSF::createMetabox($prefix, array(
        'title'     => '自定义外链特色图片',
        'post_type' => 'post',
        'context'   => 'side',
        'priority'   => 'low',
        'data_type'   => 'unserialize',
        'class'   => 'my_post_custom_url_image',
    ));
    CSF::createSection($prefix, [
        'fields' => array(
            [
                'id'          => 'custom_url_image',
                'type'        => 'text',
                'title'       => '',
                'placeholder'       => '自定义外链',
                'desc'       => '自定义外链填写了就优先调用',
            ]

        )
    ]);
}
