<div class="site-item b-a b-r-4 ceo-background-default ceo-dongtai">
	<div class="ceo-grid-ceosmls" ceo-grid>
	    <div class="ceo-width-auto">
    	    <a href="<?php the_permalink(); ?>" target="_blank" class="site-item-img ceo-display-block">
    			<img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>"/>
    		</a>
		</div>
		<div class="ceo-width-expand site-descbox">
    		<div class="site-desc">
    			<a href="<?php the_permalink(); ?>" target="_blank" class="ceo-flex-1"><?php the_title(); ?></a>
    			<p class="ceo-text-truncate">
    				<?php 
    				if (has_excerpt()) {
    					echo $description = get_the_excerpt();
    				}else {
    					echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 50,"…");
    				} 
    				?>
    			</p>
    		</div>
		</div>
	</div>
</div>