<div class="site-main">
	<ul class="cat-switcher switcher-title b-b ceo-padding-remove-left ceo-background-default" ceo-switcher>
		<li class="ceo-display-inline-block ceo-position-relative ceo-margin-right ceo-active" aria-expanded="true">
			<h3 class="ceo-margin-remove-bottom"><a class="ceo-text-bolder"><i class="ceofont ceoicon-time-line"></i>最新网址</a></h3>
		</li>
		<li class="ceo-display-inline-block ceo-position-relative" aria-expanded="false">
			<h3 class="ceo-margin-remove-bottom"><a class="ceo-text-bolder"><i class="ceofont ceoicon-refresh-line"></i>随机推荐</a></h3>
		</li>
	</ul>
	<ul id="site" class="ceo-switcher">
	    <div class="ceo-container">
    		<div class="ceo-animation-slide-left-small">
    			<div class="ceo-grid-ceosmls" ceo-grid>
    				<?php
    				$args = array( 'post_type' => 'site', 'posts_per_page' => 8 );
    				$loop = new WP_Query( $args );
    				while ( $loop->have_posts() ) : $loop->the_post(); 
    				?>
    
    				<div class="ceo-width-1-1@s ceo-width-1-4@m ceo-width-1-4@l ceo-width-1-4@xl">
    					<?php include(TEMPLATEPATH . '/inc/sitenav/loop/card.php'); ?>
    
    				</div>
    				<?php endwhile; ?>
    
    			</div>
    		</div>
		</div>
		<div class="ceo-container">
    		<div class="ceo-animation-slide-left-small">
    			<div class="ceo-grid-ceosmls" ceo-grid>
    				<?php
    				$args = array( 
    					'post_type' => 'site', 
    					'posts_per_page' => 8,
    					'orderby' => 'rand',
    				);
    				$loop = new WP_Query( $args );
    				while ( $loop->have_posts() ) : $loop->the_post(); 
    				?>
    
    				<div class="ceo-width-1-1@s ceo-width-1-4@m ceo-width-1-4@l ceo-width-1-4@xl">
    					<?php include(TEMPLATEPATH . '/inc/sitenav/loop/card.php'); ?>
    
    				</div>
    				<?php endwhile; ?>
    
    			</div>
    		</div>
		</div>
	</ul>
</div>
