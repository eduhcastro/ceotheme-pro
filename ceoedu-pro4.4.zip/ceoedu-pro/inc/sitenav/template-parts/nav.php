<div class="sitenav ceo-visible@s" ceo-sticky="animation: ceo-animation-slide-top;">
    <div class="sitenavbox ceo-background-default b-a b-r-4">
		<span>直达导航</span>
    	<ul class="ceo-width-expand ceo-padding-small ceo-text-truncate ceo-overflow-auto">
    		<?php
    		$args=array(
    		'taxonomy' => 'sitecat',
    		'hide_empty'=>'0',
    		'hierarchical'=>1,
    		'parent'=>'0',
    		);
    		$categories=get_categories($args);
    		foreach($categories as $category){
    		$cat_id = $category->term_id;
    		?>
    		<li><a href="#site<?php echo $category->term_id;?>" class="ceo-display-block" ceo-scroll><i class="ceofont ceoicon-arrow-right-s-line"></i><?php echo $category->name;?></a></li>
    		<?php }?>	
    	</ul>
    	<div class="site-navbtn">
		    <a href="/user/site/" target="_blank">申请收录</a>
		</div>
    </div>
</div>
