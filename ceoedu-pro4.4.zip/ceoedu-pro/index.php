<?php get_header(); ?>

<?php ceo_index_home(); ?>

<?php get_footer(); ?>

