<?php
/*
Template Name: 申请入驻
*/
get_header(); 
$text = _ceo('apply-text');
$bg = _ceo('apply-bg');
$ad = _ceo('apply_zz');
if( is_user_logged_in() ){
?>
<div class="ceo-tag-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);margin-bottom: 20px">
    <div class="ceo-container ceo-containertag">
        <div class="ceo-tag-bgleft">
            <h3 class="ceo-hs"><?php the_title(); ?></h3>
            <p class="ceo-visible@s"><?php echo $text; ?></p>
        </div>
    </div>
</div>
<div class="ceo-pages-apply">
    <div class="ceo-pages-apply-top">
        <div class="ceo-apply-top-title">
            <h2><?php echo _ceo('apply-title'); ?></h2>
        </div>
        <div class="ceo-apply-top" ceo-grid>
            <?php
            if ($ad) {
            foreach ( $ad as $key => $value) {
            ?>
            <div class="ceo-apply-top-box ceo-width-1-2 ceo-width-1-4@m ceo-width-1-4@l ceo-width-1-4@xl">
                <div class="ceo-apply-top-box-img">
                    <img src="<?php echo $ad[$key]['img']; ?>">
                </div>
                <h3 class="ceo-apply-top-box-title"><?php echo $ad[$key]['title']; ?></h3>
                <p><?php echo $ad[$key]['subtitle']; ?></p>
            </div>
            <?php } } ?>
        </div>
    </div>
    <div class="ceo-pages-apply-box">
        <form class="loginForm" id="custom_loginForm">
            <div class="ceo-grid-ceosmls" ceo-grid>
                <?php if(_ceo('apply_sz_username') == true ): ?>
                <div class="ceo-apply-txt ceo-width-1-2">
                    账号名称：<input type="text" name="username" lay-verify="required|userName" placeholder="* 请填写认证账号名称"/></input>
                </div>
                <?php endif; ?>
                <?php if(_ceo('apply_sz_bankno') == true ): ?>
                <div class="ceo-apply-txt ceo-width-1-2">
                    真实姓名：<input type="text" name="bankno" placeholder="* 请填写真实姓名" lay-verify="required"/>
                </div>
                <?php endif; ?>
            </div>
            <div class="ceo-grid-ceosmls" ceo-grid>
                <?php if(_ceo('apply_sz_score') == true ): ?>
                <div class="ceo-apply-txt ceo-width-1-2">
                    身份证号：<input type="text" name="score" placeholder="* 请填写身份证号" lay-verify="required"/>
                </div>
                <?php endif; ?>
                <?php if(_ceo('apply_sz_hyid') == true ): ?>
                <div class="ceo-apply-txt ceo-width-1-2">
                    会员ID：<input type="text" name="hyid" placeholder="* 请填写会员id" lay-verify="required"/>
                </div>
                <?php endif; ?>
            </div>
            <?php if(_ceo('apply_sz_sfz') == true ): ?>
            <div class="ceo_apple_is">
                <div class="ceo-apply-txt">
                    身份证照：
                </div>
                <div class="ceo-apply-sfz" ceo-grid>
                    <div class="ceo-apply-sfzimg ceo-width-1-2">
                        <input type="text" name="yfz1" id="yfz1" placeholder="* 请上传身份证正面" lay-verify="required"/>
                        <input type="button" class="applybat codeBtn filebtn" data-id="fileyfz1" value="上传" />
                        <img style="display: none;margin-bottom: 30px;border-radius: 4px;" class="previewyfz1">
                        <input type="file" class="fileyfz" data-id="yfz1" id="fileyfz1" name="fileyfz1" placeholder="图片" />
                    </div>
                    <div class="ceo-apply-sfzimg ceo-width-1-2">
                        <input type="text" name="yfz2" id="yfz2" placeholder="* 请上传身份证反面" lay-verify="required"/>
                        <input type="button" class="applybat codeBtn filebtn" data-id="fileyfz2" value="上传" />
                        <img style="display: none;margin-bottom: 30px;border-radius: 4px;" class="previewyfz2">
                        <input type="file" class="fileyfz" data-id="yfz2" id="fileyfz2" name="fileyfz2" placeholder="图片" />
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <div class="ceo-grid-ceosmls" ceo-grid>
                <?php if(_ceo('apply_sz_phone') == true ): ?>
                <div class="ceo-apply-txt ceo-width-1-2">
                    手机号码：<input type="text" name="phone" class="userLogo" placeholder="* 请填写手机号码" lay-verify="phone" />
                </div>
                <?php endif; ?>
                <?php if(_ceo('apply_sz_price') == true ): ?>
                <div class="ceo-apply-txt ceo-width-1-2">
                    微信号码：<input type="text" name="price" placeholder="* 请填写微信号码"  lay-verify="required"/>
                </div>
                <?php endif; ?>
            </div>
            <?php if(_ceo('apply_sz_yzmcode') == true ): ?>
            <div class="ceo-apply-txt">
                备注信息：<input type="text" name="yzmcode" placeholder="请填写备注信息"/>
            </div>
            <?php endif; ?>
            <div class="">
                <input type="button" value="提交申请" id="regBtn" />
            </div>
            <div class="extra-info">信息仅用于身份认证，我们将严格保护您的数据和隐私安全</div>
        </form>
    </div>
</div>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri().'/static';?>/js/base.js"></script>
<?php }else{ ?>
<div class="ceo-container">
    <div class="apply-login">
        <i class="ceofont ceoicon-information-line apply-login-i"></i>
        <p>Hi，请登录后操作~</p>
        <a href="/user/login/">立即登录<i class="ceofont ceoicon-share-forward-line"></i></a>
    </div>
</div>
<?php } ?>
<?php get_footer(); ?>