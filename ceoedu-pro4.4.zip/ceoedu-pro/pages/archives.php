<?php 
/* Template Name: 存档页面 */ 
get_header(); 
$text = _ceo('archives-text');
$bg = _ceo('archives-bg');
?>
<div class="ceo-tag-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);margin-bottom: 20px">
    <div class="ceo-container ceo-containertag">
        <div class="ceo-tag-bgleft">
            <h3 class="ceo-hs"><?php the_title(); ?></h3>
            <p class="ceo-visible@s"><?php echo $text; ?></p>
        </div>
    </div>
</div>

<div class="ceo-container">
    <div class="ceo-grid-ceosmls" ceo-grid>
        <div class="ceo-width-1-1 ceo-width-auto@s">
            <div class="wp">
                <article id="post-<?php the_ID(); ?>" <?php post_class( 'post archives' ); ?>>
                  <div class="ceo-archives-container">
                   <?php
                    $previous_year = $year = 0;
                    $previous_month = $month = 0;
                    $ul_open = false;
                    $numberposts = _ceo('archives_postnum','99');
                    $myposts = get_posts('numberposts='.$numberposts.'&orderby=post_date&order=DESC');
                    foreach($myposts as $post) :
                        setup_postdata($post);
                        $year = mysql2date('Y', $post->post_date);
                        $month = mysql2date('n', $post->post_date);
                        $day = mysql2date('j', $post->post_date);
                        if($year != $previous_year || $month != $previous_month) :
                            if($ul_open == true) : 
                                echo '</ul></div>';
                            endif;
                     
                            echo '<div class="ceo-archives-item b-r-4 b-a ceo-margin-bottom ceo-background-default"><h3><i></i>'; echo the_time('F Y'); echo '</h3>';
                            echo '<ul class="ceo-archives-list">';
                            $ul_open = true;
                        endif;
                        $previous_year = $year; $previous_month = $month;

                    ?>
                        <li>
                            <time><?php the_time('j'); ?>日</time>
                            <a href="<?php the_permalink(); ?>" <?php echo _target_blank();?>><?php the_title(); ?> </a>
                            <span class="text-muted"><?php comments_number('', '1评论', '%评论'); ?></span>
                        </li>
                    <?php endforeach; ?>
                    </ul>
                  </div>
                </article>
            </div>
        </div>
        <?php get_sidebar(); ?>
        
    </div>
</div>

<?php get_footer(); ?>
