<?php
/* Template Name: 服务办理 */
get_header();
$subtitle = _ceo('pageservice-subtitle');
$bg = _ceo('pageservice-bg');
$pd = _ceo('pageservice_desc_sz');
$top = _ceo('pageservice_top_sz');
$ban = _ceo('pageservice_ban_sz');
$bao = _ceo('pageservice_bao_sz');
$qa = _ceo('pageservice_qa_sz');
$gd = _ceo('pageservice_gd_sz');
?>
<div class="ceo-tag-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);">
    <div class="ceo-container ceo-containertag">
        <div class="ceo-tag-bgleft ceo-pages-vip-title">
            <h3 class="ceo-hs"><?php the_title(); ?><em>·</em><span><?php echo $subtitle; ?></span></h3>
            <ul class="ceo-visible@s">
                <?php
        		if ($pd) {
        			foreach ( $pd as $key => $value) {
        		?>
                <li><i class="ceofont <?php echo $pd[$key]['icon']; ?>"></i><?php echo $pd[$key]['title']; ?></li>
                <?php } } ?>
            </ul>
        </div>
    </div>
</div>
<div class="ceo-page-service-nav ceo-background-default ceo-visible@s">
    <div class="ceo-container">
        <div class="ceo-grid-ceosmls" ceo-grid>
            <?php
    		if ($top) {
    			foreach ( $top as $key => $value) {
    		?>
            <div class="ceo-width-1-1 ceo-width-1-4@s">
                <div class="ceo-grid-ceosmls" ceo-grid>
                    <div class="ceo-width-auto">
                        <img src="<?php echo $top[$key]['img']; ?>" alt="<?php echo $top[$key]['title']; ?>">
                    </div>
                    <div class="ceo-overflow-hidden ceo-width-expand">
                        <span>
                            <b><?php echo $top[$key]['title']; ?></b>
                            <p><?php echo $top[$key]['desc']; ?></p>
                        </span>
                    </div>
                </div>
            </div>
            <?php } } ?>
        </div>
    </div>
</div>
            
<section class="ceo-page-service">
    <div class="service-handle">
        <div class="ceo-container">
            <div class="service-handle-title">
                <span><?php echo _ceo('pageservice_ban_title'); ?></span>
                <p><?php echo _ceo('pageservice_ban_subtitle'); ?></p>
            </div>
            <div class="ceo-grid-medium" ceo-grid>
                <?php
        		if ($ban) {
        			foreach ( $ban as $key => $value) {
        		?>
        	    <div class="ceo-width-1-1 ceo-width-1-4@s">
        	        <div class="service-handle-box ceo-background-default ceo-dongtai">
        	            <div class="ceo-background-cover" style="background-image: url(<?php echo $ban[$key]['img']; ?>);">
                            <span><?php echo $ban[$key]['title']; ?></span>
                            <p><?php echo $ban[$key]['price']; ?></p>
                        </div>
        	            <div class="ner">
        	                <?php echo $ban[$key]['desc']; ?>
    	                </div>
        	        </div>
    	        </div>
    	        <?php } } ?>
	        </div>
        </div>
        <a href="tencent://Message/?Uin=<?php if(_ceo('goTop_service_sz'))echo _ceo('goTop_service_sz')['goTop_qq_qq']; ?>&amp;websiteName=#=&amp;Menu=yes" rel="noreferrer nofollow">立即咨询办理</a>
    </div>
    
    <div class="service-guarantee ceo-background-default">
        <div class="ceo-container">
            <div class="service-guarantee-title">
                <span><?php echo _ceo('pageservice_bao_title'); ?></span>
                <p><?php echo _ceo('pageservice_bao_subtitle'); ?></p>
            </div>
            <div class="ceo-grid-medium" ceo-grid>
                <?php
        		if ($bao) {
        			foreach ( $bao as $key => $value) {
        		?>
        	    <div class="ceo-width-1-1 ceo-width-1-3@s">
        	        <div class="service-guarantee-box ceo-dongtai">
        	            <img src="<?php echo $bao[$key]['img']; ?>" alt="<?php echo $bao[$key]['title']; ?>">
        	            <span><?php echo $bao[$key]['title']; ?></span>
        	            <p><?php echo $bao[$key]['desc']; ?></p>
        	        </div>
    	        </div>
    	        <?php } } ?>
	        </div>
        </div>
    </div>
    
    <div class="service-qa">
        <div class="ceo-container">
            <div class="service-qa-title">
                <span><?php echo _ceo('pageservice_qa_title'); ?></span>
            </div>
            <div class="ceo-grid-ceosmls" ceo-grid>
                <?php
        		if ($qa) {
        			foreach ( $qa as $key => $value) {
        		?>
        	    <div class="ceo-width-1-1 ceo-width-1-2@s">
        	        <div class="service-qa-box ceo-background-default">
        	            <span><?php echo $qa[$key]['title']; ?></span>
        	            <p><?php echo $qa[$key]['desc']; ?></p>
    	            </div>
    	        </div>
    	        <?php } } ?>
	        </div>
        </div>
    </div>
    
    <div class="service-provide">
        <div class="ceo-container">
            <div class="service-provide-title">
                <span><?php echo _ceo('pageservice_gd_title'); ?></span>
            </div>
            <div class="ceo-grid-ceosmls" ceo-grid>
                <?php
        		if ($gd) {
        			foreach ( $gd as $key => $value) {
        		?>
        	    <div class="ceo-width-1-3 ceo-width-1-6@s">
        	        <div class="service-provide-box ceo-background-default">
        	            <img src="<?php echo $gd[$key]['img']; ?>" alt="<?php echo $gd[$key]['title']; ?>">
                        <p><?php echo $gd[$key]['title']; ?></p>
                    </div>
    	        </div>
        	    <?php } } ?>
	        </div>
        </div>
    </div>
</section>
<?php get_footer();?>