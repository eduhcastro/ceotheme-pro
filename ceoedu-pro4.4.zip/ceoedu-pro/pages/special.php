<?php
/*
Template Name: 专题页面
*/
get_header();
$bg = _ceo('special-bg');
$subtitle = _ceo('special-subtitle');
$sd = _ceo('special_desc_sz');
?>
<div class="ceo-tag-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);margin-bottom: 30px">
    <div class="ceo-container ceo-containertag">
        <div class="ceo-tag-bgleft ceo-pages-special-title">
            <h3 class="ceo-hs"><?php the_title(); ?><em>·</em><span><?php echo $subtitle; ?></span></h3>
            <ul class="ceo-visible@s">
                <?php
        		if ($sd) {
        			foreach ( $sd as $key => $value) {
        		?>
                <li><i class="ceofont <?php echo $sd[$key]['icon']; ?>"></i><?php echo $sd[$key]['title']; ?></li>
                <?php } } ?>
            </ul>
        </div>
    </div>
</div>
<div class="ceo-special">
    <section class="ceo-container">
        <div class="ceo-grid-ceosmls" ceo-grid>
            <?php
        		$args=array(
        			'taxonomy' => 'special',
        			'hide_empty'=>'0',
        			'hierarchical'=>1,
        			'parent'=>'0',
        		);
        		$categories=get_categories($args);
        		foreach($categories as $category){
        			$cat_id = $category->term_id;

                    $backgroud_img = '';
                    $cate_background_img_arrs = get_term_meta($cat_id, 'cate_background_img', 1);
                    if ($cate_background_img_arrs && ! empty($cate_background_img_arrs['url'])) {
                        $backgroud_img = $cate_background_img_arrs['url'];
                    }
        	?>
            <div class="ceo-width-1-2 ceo-width-1-4@s">
                <div class="ceo-home-special-boxmk">
                        <div class="ceo-home-special-boxmkimg">
                        	<a href="<?php echo get_category_link( $category->term_id )?>" target="_blank" class="ceo-display-block ceo-cover-container">
                        	    <img src="<?php echo $backgroud_img; ?>" ceo-cover>
                        	    <?php if(!$backgroud_img){?>
                        		<img src="<?php echo _ceo('special-bg-mk'); ?>" ceo-cover/>
                                <?php }?>
                        	</a>
                    	</div>
                        <div class="ceo-home-special-boxmktext">
                            <div class="box">
                                <div class="title">
                                    <a href="<?php echo get_category_link( $category->term_id )?>" target="_blank"><?php echo $category->name;?></a>
                                </div>
                                <div class="desc">
                                    <p><?php echo $category->description;?></p>
                                </div>
                                <div class="btns">
                                    <div class="ceo-grid-ceosmls" ceo-grid>
                                        <?php if(_ceo('special-an') == true ): ?>
                                        <div class="ceo-width-1-2 ceo-visible@s">
                                            <a href="<?php echo _ceo('special-an-link'); ?>" target="_blank"><i class="ceofont ceoicon-add-line"></i><?php echo _ceo('special-an-text'); ?></a>
                                        </div>
                                        <?php endif; ?>
                                        <div class="ceo-width-1-1 ceo-width-1-2@s">
                                            <a href="<?php echo get_category_link( $category->term_id )?>" target="_blank"><i class="ceofont ceoicon-eye-line"></i>查看专题</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
            <?php }?>
        </div>
    </section>
    <?php if(_ceo('special_foomk') == true ): ?>
    <div class="ceo-pages-problem">
        <div class="ceo-special-bitem">
            <p class="p1"><?php if(_ceo('special_foomk'))echo _ceo('special_foomk')['special_foomk_title']; ?><br><?php if(_ceo('special_foomk'))echo _ceo('special_foomk')['special_foomk_subtitle']; ?></p>
            <p class="p2"><?php if(_ceo('special_foomk'))echo _ceo('special_foomk')['special_foomk_desc']; ?></p>
            <div class="pos-box">
                <img src="<?php if(_ceo('special_foomk'))echo _ceo('special_foomk')['special_foomk_img']; ?>" alt="专题">
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php get_footer(); ?>