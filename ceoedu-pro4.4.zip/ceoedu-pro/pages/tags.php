<?php 
/* Template Name: 热门标签 */ 
get_header(); 
$text = _ceo('tag-text');
$bg = _ceo('tag-bg');
?>
<div class="ceo-tag-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);margin-bottom: 20px">
    <div class="ceo-container ceo-containertag">
        <div class="ceo-tag-bgleft">
            <h3 class="ceo-hs"><?php the_title(); ?></h3>
            <p class="ceo-visible@s"><?php echo $text; ?></p>
        </div>
    </div>
</div>
<section class="ceo-container">
	<div class="ceo-margin-large-bottom ceo-grid-ceosmls" ceo-grid>
		<?php
		$tags_list = get_tags('orderby=count&order=DESC&number=44');
		if($tags_list) {
			foreach($tags_list as $tag) {
				echo '<div class="ceo-width-1-2 ceo-width-1-4@s">
				      <div class="page-tags-item ceo-background-default b-a b-r-4">
				          <a class="" href="'.get_tag_link($tag).'">
				          <h2 class="ceo-text-truncate"><span class="ceo-tagsj">#</span>'. $tag->name .'</h2>
				          <div class="ceo-flex">
				          <small class="ceo-text-muted ceo-text-truncate ceo-flex-1">共 <span class="ceo-text-warning ceo-text-bold">'. $tag->count .'</span> 篇相关文章</small>
				          <small class="ceo-page-tags-a ceo-visible@s">查看详情<i class="ceofont ceoicon-arrow-right-s-line"></i></small>
				          </div>';
				echo '</a></div></div>';
			}
		}
		?>

	</div>
</section>
<?php get_footer(); ?>
