<?php 
/*
Template Name: 主题介绍
*/
get_header();
?>
<style>
	.theme-top {
		height: 400px;
		position: relative;
	}
	.theme-top h1{
	    font-size: 2.625rem;
	}
	.theme-top-cover {
		background: rgb(19 192 126 / 68%);
	}
	.theme-prototype {
		margin-top: -160px
	}
	.theme-title {
		padding-bottom: 10px;
	}
	.theme-title:after {
		content: '';
        display: block;
        width: 100%;
        left: 0;
        right: 0;
        height: 4px;
        position: absolute;
        bottom: 0;
        background: linear-gradient(140deg,var(--hcan1-color),var(--hcan2-color));
        z-index: 10;
        box-shadow: 0px -1px 7px -1px #13c07e;
        border-radius: 8px;
	}
	.theme-conntent {}
	.theme-conntent p {
		font-size: 16px;
		line-height: 28px;
		font-family: 'arial';
		margin: 0
	}
	.theme-item {
		float: left;
		margin-left: -1px;
		margin-bottom: -1px;
		transition: all .3s;
		cursor: pointer;
	}
	.theme-item:hover {
		background: #2c63ff;
		box-shadow: 0px -1px 7px -1px #2c63ff;
		transform: translateY(-5px);
	}
	.theme-item:hover p {
		color:#fff
	}
	.theme-item:hover span {
		color:#ddd!important
	}
	.theme-btn {
		padding: 10px 30px;
	}
	.theme-bottom {
		height: 280px;
		position: relative;
	}
	.theme-bottom a{
	    color:#fff!important
	}
	.theme-show {
		max-height: 450px;
	}
	.theme-color{
	    background: var(--primary-color);
        color: #fff!important;
	}
	@media screen and (max-width: 600px) {
		.theme-top {
			margin-top: 0px;
		    height: 230px;
		}
		.ceo-theme-img{
		    height: 290px;
		}
		.theme-top h1 {
            font-size: 1.625rem;
        }
        .theme-prototype {
            margin-top: -100px;
        }
        .theme-bottom img{
            height: 160px;
        }
        .theme-bottom .ceo-padding {
            padding: 10px;
        }
        .theme-btn {
            padding: 8px 18px;
        }
        .theme-conntent p {
            font-size: 14px;
        }
	}
	.ceo-footer-banner {
        margin-top: 0px;
    }
</style>
<main class="main ceo-background-default">
	<section class="theme-top b-b ceo-overflow-hidden ceo-background-cover" style="background-image: url(https://ceostyle.ceotheme.com/ceoedu/ceoedu_top.jpg);">
		<div class="theme-top-cover ceo-position-cover"></div>
		<div class="ceo-overlay ceo-position-top-center ceo-dark">
			<div class="ceo-container ceo-light">
				<h1 class="page-title ceo-margin-large-top">CeoEdu-Pro主题</h1>
			</div>	
		</div>
	</section>
	<section class="theme-prototype ceo-text-center ceo-position-relative ceo-position-z-index">
		<img src="https://ceostyle.ceotheme.com/ceoedu/ceoedu.png" alt="CeoEdu-Pro主题"/>
	</section>
	<section class="ceo-container ceo-text-center">
		<div class="ceo-text-center ceo-padding">
			<div class="theme-title ceo-h2 ceo-text-bolder ceo-display-inline-block ceo-position-relative">主题简介</div>
		</div>
		<div class="theme-conntent ceo-background-muted ceo-padding">
			<p>CeoEdu-Pro主题是一款轻量级、且简洁大气、教育专类型主题，定位于教育资源行业，当然也适用于各类资源站，同时也适用于企业站、企业产品展示等全方位覆盖，线上付费/免费产品下载全系列行业终端。</p>
			<p>CeoEdu-Pro主题后台有着丰富主题设置，无需修改代码，让WordPress新手也能得心应手得使用该主题。</p>
			<p>CeoEdu-Pro主题带来的不仅是惊艳，更是中小企业在互联网发展的重要跨越</p>
		</div>
	</section>
	
	<section class="theme-bottom ceo-overflow-hidden ceo-background-cover ceo-margin-large-top" style="background-image: url(https://ceostyle.ceotheme.com/ceoedu/ceoedu_top.jpg);">
		<div class="ceo-overlay-primary ceo-position-cover"></div>
		<div class="ceo-overlay ceo-position-top-center ceo-dark">
			<div class="ceo-container ceo-light ceo-text-center">
				<div class="ceo-padding">
					<p class="page-title ceo-h2 ceo-margin-large-bottom">CeoEdu-Pro主题演示站</p>
					<a href="http://ceoedu-pro.ceotheme.com" target="_blank" class="theme-btn b-r-4 ceo-margin-right">查看主题</a>
					<a href="<?php echo _ceo('ceo-theme');?>" target="_blank" class="theme-color theme-btn b-r-4" alt="CeoEdu-Pro主题">购买主题</a>
				</div>
			</div>	
		</div>
	</section>
	
	<section class="ceo-container ceo-margin-large-top">
		<div class="ceo-text-center ceo-padding ceo-padding-remove-top">
			<div class="theme-title ceo-h2 ceo-text-bolder ceo-display-inline-block ceo-position-relative">意见建议</div>
		</div>
		<div class="ceo-margin-large-bottom">
			<?php if ( comments_open() || get_comments_number() ) : ?>
			<?php comments_template( '', true ); ?>
			<?php endif; ?>
		</div>
	</section>
</main>
<?php get_footer(); ?>