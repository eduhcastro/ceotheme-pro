<?php
/*
Template Name: 用户列表
*/
get_header();
$text = _ceo('user-text');
$bg = _ceo('user-bg');
?>
<div class="ceo-tag-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);margin-bottom: 20px">
    <div class="ceo-container ceo-containertag">
        <div class="ceo-tag-bgleft">
            <h3 class="ceo-hs"><?php the_title(); ?></h3>
            <p class="ceo-visible@s"><?php echo $text; ?></p>
        </div>
    </div>
</div>

<div class="ceo-container">
    <div class="ceo-grid-ceosmls" ceo-grid>

        <?php
        $no=12;
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        if($paged==1){
            $offset=0;
        }else {
            $offset= ($paged-1)*$no;
        }
        $user_arrs=get_users();
        $user_query = new WP_User_Query( array( 'number' => $no, 'offset' => $offset ) );
        if(! empty( $user_query->results)){
        foreach ($user_query->results as $v){
        ?>
        <div class="userpages-box ceo-width-1-2 ceo-width-1-4@s">
            <div class="userpages-boxmk ceo-background-default b-a b-r-4 ceo-dongtai">
                <div class="userpages-boxmk-bg"></div>
                <div class="userpages-boxmk-item">
                    <div class="userpages-boxmk-item-icon">
                        <div class="ceo-author-imgs">
                            <?php echo get_avatar( $v->ID , 100 ); ?>
                            <?php if(user_can($v->ID,'author') || user_can($v->ID,'editor') || user_can($v->ID,'administrator')){ ?>
                                <i ceo-tooltip="认证作者"></i>
                            <?php }?>
                        </div>
                    </div>
                    <div class="userpages-boxmk-item-content">
                        <a href="/author/<?php echo the_author_meta( 'user_login',$v->ID ); ?>" target="_blank" class="ceo-text-truncate"><?php echo $v->display_name;?></a>
                        <p><?php

                            $description = $v->description;
                            if(empty($description)){
                                $description='这家伙很懒，只想把你留下。';
                            }
                            echo $description;
                            ?></p>
                    </div>
                    <div class="userpages-boxmk-item-ingress">
                        <a href="/author/<?php echo the_author_meta( 'user_login',$v->ID ); ?>" target="_blank">进入主页</a>
                    </div>
                    <div class="userpages-boxmk-item-count">
                        <?php
                        $query = new WP_Query( 'author='.$v->ID);
                        $postsNumberAll = $query->found_posts;

                        $today = getdate();
                        $query = new WP_Query( 'year=' . $today["year"] . '&monthnum=' . $today["mon"] . '&day=' . $today["mday"].'&author='.$v->ID);
                        $postsNumberToday = $query->found_posts;
                        ?>
                        <span>今日发布 <?php echo $postsNumberToday;?> 篇</span>
                        <em>·</em>
                        <span>全部文章 <?php echo $postsNumberAll;?> 篇</span>
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
    </div>
    <div class="fenye ceo-text-center ceo-text-small ceo-margin-medium-top">
        <?php
        $current = ! empty($_GET['pgae']) ? (int)$_GET['pgae'] : 1;
        $current = ! empty($_GET['pgae']) ? (int)$_GET['pgae'] : 2;
        $args = array(
            'prev_next'          => 0,
            'format'       => '?paged=%#%',
            'before_page_number' => '',
            'mid_size'           => 2,
            'current' => max( 1, $current ),
            'prev_next'    => True,
            'prev_text'    => __('上一页'),
            'next_text'    => __('下一页'),
        );

        $total_user = $user_query->total_users;
        $total_pages=ceil($total_user/$no);

        $args=array(
            'base' => get_pagenum_link(1) . '%_%',
            'format' => '?paged=%#%',
            'current' => $paged,
            'total' => $total_pages,
            'prev_text'    => __('上一页'),
            'next_text'    => __('下一页'),
        );
        $page_arr=paginate_links($args);
        if ($page_arr) {
            echo $page_arr;
        }else{

        } } ?>
    </div>
</div>
<?php get_footer(); ?>
