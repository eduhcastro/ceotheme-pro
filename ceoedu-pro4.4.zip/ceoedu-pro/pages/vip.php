<?php
/*
Template Name: VIP模板
*/
get_header(); 
$subtitle = _ceo('vip-subtitle');
$bg = _ceo('vip-bg');
$vd = _ceo('vip_desc_sz');
$vip = _ceo('ceo_shop_vip_info');
$vip_tq_sz= _ceo('vip_tq_sz');
$vip_qa_sz= _ceo('vip_qa_sz');
?>
<div class="ceo-tag-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);margin-bottom: 30px">
    <div class="ceo-container ceo-containertag">
        <div class="ceo-tag-bgleft ceo-pages-vip-title">
            <h3 class="ceo-hs"><?php the_title(); ?><em>·</em><span><?php echo $subtitle; ?></span></h3>
            <ul class="ceo-visible@s">
                <?php
        		if ($vd) {
        			foreach ( $vd as $key => $value) {
        		?>
                <li><i class="ceofont <?php echo $vd[$key]['icon']; ?>"></i><?php echo $vd[$key]['title']; ?></li>
                <?php } } ?>
            </ul>
        </div>
    </div>
</div>
<div class="ceo-container">
    <div class="ceo-grid-ceosmls" ceo-grid>
        <?php
		if ($vip) {
			foreach ( $vip as $key => $value) {
		?>
        <div class="vip-box-mk ceo-width-1-1 ceo-width-1-4@m ceo-width-1-4@l ceo-width-1-4@xl">
    	    <div class="vip-box-mk-zt ceo-background-default ceo-dongtai">
        	    <div class="vip-box-mk-zt-top">
        	        <h1><?php echo $vip[$key]['name']; ?></h1>
        	        <?php if ($vip[$key]['tags']): ?>
        	        <div class="tag"><?php echo $vip[$key]['tags']; ?></div>
        	        <?php endif; ?>
        	        <p class="time">会员有效期<?php echo $vip[$key]['validity']; ?>天</p>
	                <div class="vip-box-mk-zt-top-dj">
    	                <span>¥</span><strong><?php echo $vip[$key]['price']; ?></strong><span><?php echo _ceo('ceo_shop_currency_name'); ?></span>
        	        </div>
	                <p class="vip-box-mk-zt-top-pi">每天可下载<?php echo $vip[$key]['number']; ?>个VIP资源</p>
	                <?php if( is_user_logged_in() ){ ?>
                    <a href="javascript:void(0)" class="btn-ceo-svip" data-vip-id="<?php echo $vip[$key]['id'] ?>" data-style="slide-down">立即开通</a>
                    <?php }else{ ?>
    				<a href="#navbar-login" ceo-toggle>立即开通</a>
    				<?php } ?>
        	    </div>
        	    <div class="vip-box-mk-zt-mbox">
            	    <div class="vip-box-mk-zt-mbox-s">
            	        <div class="vip-box-title">套餐介绍：</div>
        	            <?php echo $vip[$key]['desc']; ?>
            	    </div>
        	    </div>
    	    </div>
        </div>
        <?php } } ?>
    </div>
</div>
<div class="ceo-pages-problem">
    <div class="ceo-container">
        <div class="problem-title">
            <h2><?php echo _ceo('vip_tq_title'); ?></h2>
            <p><?php echo _ceo('vip_tq_subtitle'); ?></p>
        </div>
        <div class="ceo-grid-ceosmls" ceo-grid>
            <?php
			if ($vip_tq_sz) {
				foreach ( $vip_tq_sz as $key => $value) {
			?>
            <div class="ceo-width-1-1 ceo-width-1-4@m ceo-width-1-4@l ceo-width-1-4@xl">
        	    <div class="vip-box-mk-zts ceo-background-default ceo-dongtai">
        	        <div class="vip-box-mk-zt-i"><i class="ceofont <?php echo $vip_tq_sz[$key]['ico']; ?>"></i></div>
        	        <span><?php echo $vip_tq_sz[$key]['title']; ?></span>
        	        <p><?php echo $vip_tq_sz[$key]['content']; ?></p>
            	</div>
    	    </div>
    	    <?php } } ?>
        </div>
    </div>
</div>
<div class="ceo-pages-problem">
    <div class="ceo-container">
        <div class="problem-title">
            <h2><?php echo _ceo('vip_qa_title'); ?></h2>
            <p><?php echo _ceo('vip_qa_subtitle'); ?></p>
        </div>
        
        <div class="problem-box" ceo-grid>
            <?php
			if ($vip_qa_sz) {
				foreach ( $vip_qa_sz as $key => $value) {
			?>
            <div class="problem-box-mk ceo-width-1-1 ceo-width-1-2@m ceo-width-1-2@l ceo-width-1-2@xl">
                <div class="problem-box-mk-w ceo-dongtai">
                    <h2><?php echo $vip_qa_sz[$key]['title']; ?></h2>
                    <p><?php echo $vip_qa_sz[$key]['content']; ?></p>
                </div>
            </div>
            <?php } } ?>
        </div>
    </div>
</div>
<?php get_footer(); ?>