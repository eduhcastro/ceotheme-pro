<?php get_header(); ?>
<section class="ceo-background-default">
	<div class="ceo-container ceo-flex ceo-flex-middle">
		<div class="ceo-flex-1">
			<div class="ceo-search-box">
				<?php
				$allsearch = new WP_Query("s=$s");
				$key = get_search_query(1);
				if(empty($key)){
				    $key = get_query_var( 'p' );
                }
				$count = $allsearch->post_count;
				echo '<h1 class="ceo-h3">「'. $key .'」</h1>';
				
				if(is_search()){
                    global $wp_query;
                    $count = $wp_query->found_posts;
                }
				echo '<p class="ceo-display-block ceo-text-muted ceo-margin-remove">共搜索到<strong class="ceo-text-warning ceo-text-bold"> ' . $count .' </strong>条「' . $key .'」的相关内容。</p>' ;
				wp_reset_query(); 
				?>

			</div>
		</div>
	</div>
</section>
<section class="ceo-container">
	<div class="crumbs ceo-text-small ceo-padding-small ceo-padding-remove-horizontal">
		<?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
	</div>	
	<div class="card ceo-grid-ceosmls" ceo-grid>
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

		<div class="ceo-width-1-2 ceo-width-1-4@s">
			<?php get_template_part( 'template-parts/loop/loop', 'card' ); ?>

		</div>
		<?php endwhile; else: ?>
			<div class="ceo-width-1-1">
    			<div class="ceo-alert-primary ceo-container" ceo-alert>
    				<a class="ceo-alert-close" ceo-close></a>
    				<p class="ceo-padding-small ceo-text-center">这是一个没有灵魂的搜索词...</p>
    			</div>
    		</div>
		<?php endif; ?>

	</div>
    <div class="fenye ceo-text-center ceo-text-small ceo-margin-medium-top">
    	<?php fenye(); ?>
    </div>
</section>
<?php get_footer(); ?>