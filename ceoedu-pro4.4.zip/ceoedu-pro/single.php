<?php



get_header();
$post_id =  get_the_ID();
$down_info_arr = get_post_meta(get_the_ID(), 'down_info', true);
$video = get_post_meta($post->ID, 'ceo_video', true);
$my_post_video_options = get_post_meta(get_the_ID(), 'my_post_video_options', 1);

$userId = get_current_user_id();
$productInfo = CeoShopCoreProduct::getInfo($post_id, $userId);
$productTypeKey = CeoShopCoreProduct::getTypeKey($post_id);

?>
<?php if (_ceo('single_zz_top') == true) : ?>
	<div class="ceo-container ceo-margin-top ceo-ad-single-top">
		<a href="<?php echo _ceo('single_zz_top_link'); ?>" target="_blank" class="ceo-display-block ceo-overflow-hidden">
			<img src="<?php echo _ceo('single_zz_top_img'); ?>" />
		</a>
	</div>
<?php endif ?>

<?php if ($productTypeKey == 'video') : ?>
	<!--课程-->
	<section class="ceo-single-shop-video">
		<div class="ceo-container">
			<section class="ceo-single-wz">
				<?php if (function_exists('cmp_breadcrumbs')) cmp_breadcrumbs(); ?>
			</section>
			<header class="ceo-single-shop-video-head">
				<div class="ceo-flex">
					<div class="title ceo-flex-1">
						<?php if (get_post_meta(get_the_ID(), 'ceo-tese-tag', true)) { ?>
							<div class="ceo-single-tese">
								<i class="ceofont ceoicon-hashtag"></i><?php echo get_post_meta(get_the_ID(), 'ceo-tese-tag', true); ?>
							</div>
						<?php } ?>
						<h1><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h1>
					</div>
					<?php if (_ceo('ceoshop_video_topan') == true) : ?>
						<div class="an ceo-visible@s">
							<a href="<?php if (_ceo('ceoshop_video_topan_sz')) echo _ceo('ceoshop_video_topan_sz')['topan_link']; ?>" target="_blank"><i class="ceofont <?php if (_ceo('ceoshop_video_topan_sz')) echo _ceo('ceoshop_video_topan_sz')['topan_icon']; ?>"></i><?php if (_ceo('ceoshop_video_topan_sz')) echo _ceo('ceoshop_video_topan_sz')['topan_title']; ?><em></em></a>
						</div>
					<?php endif; ?>
				</div>
			</header>
			<div class="ceo-grid-ceosmls" ceo-grid>
				<div class="ceo-width-1-1 ceo-width-3-4@s">
					<?php get_template_part('template-parts/single/single', 'video'); ?>
				</div>
				<div class="ceo-width-1-1 ceo-width-1-4@s">
					<?php get_template_part('template-parts/single/single', 'videolist'); ?>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>

<?php if ($productTypeKey != 'close' && $productTypeKey != '' ) : ?>
	<!--商城-->
	<?php while (have_posts()) : the_post(); ?>
		<section class="ceo-container ceo-margin-top-20">
			<?php if ($productTypeKey != 'video') : ?>
				<section class="ceo-single-wz">
					<?php if (function_exists('cmp_breadcrumbs')) cmp_breadcrumbs(); ?>
				</section>
			<?php endif; ?>
			<div class="ceo-grid-ceosmls" ceo-grid>
				<div class="ceo-width-1-1 ceo-width-auto@s">
					<div class="wp">
						<?php get_template_part('template-parts/single/single', 'icon'); ?>
						<div class="ceo-margin-bottom">
							<?php if ($productTypeKey != 'video') : ?>
								<?php get_template_part('template-parts/single/single', 'shop'); ?>
							<?php endif; ?>
							<div class="ceo-background-default ceo-margin-bottom b-a">
								<div class="ceo-padding-20">
									<div class="ceo_single_shop_comtitle b-b">
										<span><?php echo _ceo('ceo_shop_single_nertitle'); ?></span>
									</div>
									<article class="single-content">

										<?php if (_ceo('single_zz_top_content') == true) : ?>
											<div class="ceo-ad-single-content ceo-margin-bottom">
												<a href="<?php echo _ceo('single_zz_top_content_link'); ?>" target="_blank" class="ceo-display-block ceo-overflow-hidden">
													<img src="<?php echo _ceo('single_zz_top_content_img'); ?>" alt="广告" />
												</a>
											</div>
										<?php endif ?>

										<?php if ($productTypeKey != 'video') : ?>
											<?php if (_ceo('ceo_shop_single_xx') == true) : ?>
												<div class="ceo_single_shop_box_cos_mid">
													<div class="ceo-grid-ceosmls" ceo-grid>
														<?php if (_ceo('ceo_shop_single_xx_bh') == true) : ?>
															<div class="ceo-width-1-1 ceo-width-1-4@s ceo_single_shop_box_cos_mid_tim">
																<span>
																	<p><?php echo _ceo('ceo_shop_single_xx_bhbt'); ?></p>
																	<em><?php echo get_the_ID(); ?></em>
																</span>
															</div>
														<?php endif ?>
														<?php
														if (!empty($down_info_arr)) {
															foreach ($down_info_arr as $k => $v) {
																$number = $k + 1;
																echo '<div class="ceo-width-1-1 ceo-width-1-4@s ceo_single_shop_box_cos_mid_tim"><span><p>' . $v['title'] . '</p>' . '<em>' . $v['desc'] . '</em></span></div>';
															}
														}
														?>
														<?php if (_ceo('ceo_shop_single_xx_gx') == true) : ?>
															<div class="ceo-width-1-1 ceo-width-1-4@s ceo_single_shop_box_cos_mid_tim">
																<span>
																	<p><?php echo _ceo('ceo_shop_single_xx_gxbt'); ?></p>
																	<em><?php echo date("Y-m-d", strtotime($post->post_modified)); ?></em>
																</span>
															</div>
														<?php endif ?>
													</div>
												</div>
											<?php endif ?>
										<?php endif; ?>

										<?php if (_ceo('single_content_zy') == true) : ?>
											<div class="ceo-single-abstract">
												<strong><i class="ceofont ceoicon-file-text-line"></i>摘要 :</strong>
												<p><?php $tempContent = preg_replace("/<style.*?style>/s", '', apply_filters('the_content', $post->post_content)); echo mb_strimwidth(strip_tags($tempContent), 0, 160, '……'); ?></p>
											</div>
										<?php endif ?>

										<?php the_content(); ?>
										<div id="ceo-ceoshop-boxs" class="ceo-ceoshop-boxs"></div>
									</article>
								</div>
								<?php if (_ceo('single_commodity') == true) : ?>
									<!--商品关联-->
								<?php
									if (get_post_meta(get_the_ID(), "ceo_commodity_kg", 1)) {
										get_template_part('template-parts/single/single', 'commodity');
									}
								endif ?>
								<!--文章按钮-->
								<div class="ceo-single-szcan">
									<?php if (_ceo('single_foo_sc') == true) : ?>
										<div class="ceo-single-szcan-dz">
											<?php echo ceotheme_post_collection_button(get_the_ID()); ?>
										</div>
									<?php endif ?>
									<?php if (_ceo('single_foo_ds') == true) : ?>
										<div class="ceo-single-szcan-sc">
											<span>赏</span>
											<div class="ceo-single-dashang-img b-a">
												<p><img src="<?php echo _ceo('single_foo_ds_wximg'); ?>"> <?php echo _ceo('single_foo_ds_wxtext'); ?> </p>
												<p><img src="<?php echo _ceo('single_foo_ds_zfbimg'); ?>"> <?php echo _ceo('single_foo_ds_zfbtext'); ?> </p>
											</div>
										</div>
									<?php endif ?>
									<?php if (_ceo('single_foo_dz') == true) : ?>
										<div class="ceo-single-szcan-dz">
											<?php echo ceotheme_post_like_button(); ?>
										</div>
									<?php endif ?>
								</div>

								<?php if (_ceo('single_foo_bq') == true) : ?>
									<!--文章版权-->
									<div class="ceo-padding-20">
										<div class="ceo-text-small ceo-text-pu ceo-margin-remove ceo-cop-text ceo-hh-p b-r-4" ceo-alert>
											<?php if (get_post_meta(get_the_ID(), 'ceo-tese-source', true)) { ?>
												<div class="ceo-single-source">
													<i class="ceofont ceoicon-share-forward-box-line"></i> 来源：<?php echo get_post_meta(get_the_ID(), 'ceo-tese-source', true); ?>
												</div>
											<?php } ?>
											<p class="ceo-margin-remove-bottom"><i class="ceofont ceoicon-information-line"></i> 版权：<?php echo _ceo('single_foo_bq_text'); ?> 转载请注明出处：<?php the_permalink(); ?></p>
										</div>
									</div>
								<?php endif ?>

								<?php if (_ceo('single_foo_tag') == true) : ?>
									<!--文章标签-->
									<div class="ceo-single-tag-s">
										<div class="ceo-single-tag-s-tags ceo-flex-1">
											<?php the_tags('', '') ?>
										</div>
									</div>
								<?php endif ?>

								<!--文章作者-->
								<div class="ceo-padding-20 b-t ceo-flex">
									<div class="ceo-single-author-d ceo-flex-1">
										<?php echo get_avatar(get_the_author_meta('ID'), 20); ?>
										<span class="ceo-text-small ceo-display-block ceo-margin-small-left"><?php the_author_posts_link(); ?></span>
										<p class="ceo-single-author-dg ceo-background-default"><?php get_user_role() ?></p>
									</div>

									<div class="share">
										<a class="share-post meta-item mobile j-mobile-share" href="javascript:;" data-id="<?php echo get_the_ID(); ?>" data-qrcode="<?php echo get_the_permalink(); ?>">
											<i class="ceofont ceoicon-image-line"></i> 生成海报
										</a>
										<?php
										$qrcode = '' . get_bloginfo('template_directory') . '/inc/qrcode?data=' . get_the_permalink() . '';
										$post_url = esc_url(get_permalink());
										$post_title = esc_attr(get_the_title());
										$post_desc = wp_trim_words(get_the_content(), 30);
										?>
										<p class="ceo-visible@s ceo-display-inline-block">分享</p>
										<a class="weixin-share ceo-display-inline-block ceo-visible@s" href="<?php echo $qrcode; ?>" ceo-tooltip="分享到微信" data-image="<?php echo esc_attr($post_image); ?>" target="_blank"><i class="ceofont ceoicon-wechat-fill"></i>
										</a>
										<a class="ceo-display-inline-block ceo-visible@s" href="http://connect.qq.com/widget/shareqq/index.html?url=<?php echo $post_url; ?>&sharesource=qzone&title=<?php echo $post_title; ?>&pics=<?php echo post_thumbnail_src(); ?>&summary=<?php echo $post_desc; ?>" ceo-tooltip="分享到QQ好友/QQ空间" target="_blank" rel="noreferrer nofollow"><i class="ceofont ceoicon-qq-fill"></i>
										</a>
										<a class="ceo-display-inline-block ceo-visible@s" href="http://service.weibo.com/share/mobile.php?url=<?php echo $post_url; ?>&title=<?php echo $post_title ?> - <?php bloginfo('name'); ?>&appkey=3313789115" ceo-tooltip="分享到微博" target="_blank" rel="noreferrer nofollow"><i class="ceofont ceoicon-weibo-fill"></i>
										</a>
									</div>
								</div>
							</div>
						</div>

						<?php get_template_part('template-parts/single/single', 'page'); ?>

						<?php if (_ceo('single_zz_foo_content') == true) : ?>
							<div class="ceo-ad-single-content ceo-margin-bottom ceo-background-default ceo-zcgg-img b-a">
								<a href="<?php echo _ceo('single_zz_foo_content_link'); ?>" target="_blank" class="ceo-display-block ceo-overflow-hidden">
									<img src="<?php echo _ceo('single_zz_foo_content_img'); ?>" />
								</a>
							</div>
						<?php endif ?>

						<?php if (_ceo('single_qa') == true) : ?>
							<?php if (_ceo('single_qa_shop') == true) : ?>
								<?php get_template_part('template-parts/single/single', 'qa'); ?>
							<?php endif ?>
						<?php endif ?>

						<?php if (_ceo('xg_show') == true) : ?>
							<?php get_template_part('template-parts/single/single', 'bottom'); ?>
						<?php endif ?>

						<?php if (_ceo('comments_close') == false) : ?>
							<?php if (comments_open() || get_comments_number()) : ?>
								<?php comments_template('', true); ?>
							<?php endif; ?>
						<?php endif; ?>

					</div>
				</div>
				<?php get_sidebar(); ?>
			</div>
		</section>

	<?php endwhile; ?>
<?php else: ?>
	<!--文章-->
    <section class="ceo-container ceo-margin-top-20">
        <section class="ceo-single-wz">
        	<?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
        </section>
    	<div class="ceo-grid-ceosmls" ceo-grid>
    		<div class="ceo-width-1-1 ceo-width-auto@s">
    		    <div class="wp">
    		        <?php get_template_part( 'template-parts/single/single', 'icon' ); ?>
        			<?php while ( have_posts() ) : the_post(); ?>
                    <div class="ceo-background-default ceo-margin-bottom b-a">
                        <?php
                        if( $video!='' ){ ?>
                            <div class="ceo-single-video">
                                <iframe src="<?php echo get_post_meta( get_the_ID(), 'ceo_video', true );?>" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>
                            </div>
                        <?php } ?>
            			<header class="single-head b-b ceo-padding-20">
            			    <div class="ceo-single-title">
                			    <?php if(get_post_meta( get_the_ID(), 'ceo-tese-tag', true )){?>
                			    <div class="ceo-single-tese">
            				        <i class="iconfont icon-huatifuhao"></i><?php echo get_post_meta( get_the_ID(), 'ceo-tese-tag', true );?>
            				    </div>
            				    <?php }?>
            					<h1><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h1>
        					</div>
        					<?php get_template_part( 'template-parts/single/single', 'info' ); ?>
        				</header>
        				<div class="ceo-padding-20">
        					<article class="single-content">
        					    <?php if(_ceo('single_zz_top_content') == true ): ?>
        					    <div class="ceo-ad-single-content ceo-margin-bottom">
        					        <a href="<?php echo _ceo('single_zz_top_content_link'); ?>" target="_blank" class="ceo-display-block ceo-overflow-hidden">
                                		<img src="<?php echo _ceo('single_zz_top_content_img'); ?>"/>
                                	</a>
        					    </div>
        					    <?php endif ?>
    
        					    <?php if(_ceo('single_content_zy') == true ): ?>
        					    <div class="ceo-single-abstract">
        					        <strong><i class="iconfont icon-lights"></i>摘要 :</strong>
        					        <p><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 160,'……'); ?></p>
        					    </div>
        					    <?php endif ?>
    
        						<?php the_content(); ?>
        					</article>
        				</div>
        				<?php if(_ceo('single_commodity') == true ): ?>
    				    <!--商品关联-->
    				    <?php
                            if(get_post_meta(get_the_ID(),"ceo_commodity_kg",1)){
                                get_template_part( 'template-parts/single/single', 'commodity' );
        				} endif ?>
        				<!--文章按钮-->
        				<div class="ceo-single-szcan">
        				    <?php if(_ceo('single_foo_sc') == true ): ?>
        				    <div class="ceo-single-szcan-dz">
                    	        <?php echo ceotheme_post_collection_button( get_the_ID() );?>
                    	    </div>
                    	    <?php endif ?>
                    	    <?php if(_ceo('single_foo_ds') == true ): ?>
                    	    <div class="ceo-single-szcan-sc">
                    	        <span>赏</span>
                    	        <div class="ceo-single-dashang-img b-a">
                    	            <p><img src="<?php echo _ceo('single_foo_ds_wximg'); ?>"> <?php echo _ceo('single_foo_ds_wxtext'); ?> </p>
                	                <p><img src="<?php echo _ceo('single_foo_ds_zfbimg'); ?>"> <?php echo _ceo('single_foo_ds_zfbtext'); ?> </p>
            	                </div>
                    	    </div>
                    	    <?php endif ?>
                    	    <?php if(_ceo('single_foo_dz') == true ): ?>
                    	    <div class="ceo-single-szcan-dz">
                                <?php echo ceotheme_post_like_button();?>
                            </div>
                            <?php endif ?>
                        </div>
    
        				<?php if (_ceo('single_foo_bq') == true ): ?>
        				<!--文章版权-->
        				<div class="ceo-padding-20">
            				<div class="ceo-text-small ceo-text-pu ceo-margin-remove ceo-cop-text ceo-hh-p b-r-4" ceo-alert>
            				    <?php if(get_post_meta( get_the_ID(), 'ceo-tese-source', true )){?>
                			    <div class="ceo-single-source">
            				        <i class="iconfont icon-fenxiang"></i> 来源：<?php echo get_post_meta( get_the_ID(), 'ceo-tese-source', true );?>
            				    </div>
            				    <?php }?>
            					<p class="ceo-margin-remove-bottom"><i class="iconfont icon-tanhao"></i> 版权：<?php echo _ceo('single_foo_bq_text'); ?> 转载请注明出处：<?php the_permalink(); ?></p>
            				</div>
        				</div>
        				<?php endif ?>
    
        				<?php if (_ceo('single_foo_tag') == true ): ?>
        				<!--文章标签-->
        				<div class="ceo-single-tag-s">
        				    <div class="ceo-single-tag-s-tags ceo-flex-1">
        					<?php the_tags('', '') ?>
        					</div>
        				</div>
        				<?php endif ?>
    
        				<!--文章作者-->
        				<div class="ceo-padding-20 b-t ceo-flex">
        				    <div class="ceo-single-author-d ceo-flex-1">
            					<?php echo get_avatar(get_the_author_meta( 'ID' ), 20); ?>
            					<span class="ceo-text-small ceo-display-block ceo-margin-small-left"><?php the_author_posts_link(); ?></span>
            					<p class="ceo-single-author-dg ceo-background-default"><?php get_user_role() ?></p>
        					</div>
    
                    		<div class="share">
                                <a class="share-post meta-item mobile j-mobile-share" href="javascript:;" data-id="<?php echo get_the_ID(); ?>"
                                   data-qrcode="<?php echo get_the_permalink(); ?>">
                                    <i class="iconfont icon-tupian"></i> 生成海报
                                </a>
                                <?php
        							$qrcode = ''.get_bloginfo('template_directory').'/inc/qrcode?data='.get_the_permalink().'';
        							$post_url = esc_url(get_permalink());
        							$post_title = esc_attr(get_the_title());
        							$post_desc = wp_trim_words( get_the_content(), 30 );
        						?>
        						<p class="ceo-visible@s ceo-display-inline-block">分享</p>
        						<a class="weixin-share ceo-display-inline-block ceo-visible@s" href="<?php echo $qrcode; ?>" ceo-tooltip="分享到微信" data-image="<?php echo esc_attr($post_image); ?>" target="_blank"><i class="iconfont icon-wechat-fill"></i>
        						</a>
        						<a class="ceo-display-inline-block ceo-visible@s" href="http://connect.qq.com/widget/shareqq/index.html?url=<?php echo $post_url; ?>&sharesource=qzone&title=<?php echo $post_title; ?>&pics=<?php echo post_thumbnail_src(); ?>&summary=<?php echo $post_desc; ?>"  ceo-tooltip="分享到QQ好友/QQ空间" target="_blank" rel="noreferrer nofollow"><i class="iconfont icon-QQ"></i>
        						</a>
        						<a class="ceo-display-inline-block ceo-visible@s" href="http://service.weibo.com/share/mobile.php?url=<?php echo $post_url; ?>&title=<?php echo $post_title ?> - <?php bloginfo('name'); ?>&appkey=3313789115" ceo-tooltip="分享到微博" target="_blank" rel="noreferrer nofollow"><i class="iconfont icon-weibo1"></i>
        						</a>
                    		</div>
        				</div>
    				</div>
    
        			<?php get_template_part( 'template-parts/single/single', 'page' ); ?>
        			<?php endwhile; ?>
    
        			<?php if(_ceo('single_zz_foo_content') == true ): ?>
        		    <div class="ceo-ad-single-content ceo-margin-bottom ceo-background-default ceo-zcgg-img b-a">
        		        <a href="<?php echo _ceo('single_zz_foo_content_link'); ?>" target="_blank" class="ceo-display-block ceo-overflow-hidden">
                    		<img src="<?php echo _ceo('single_zz_foo_content_img'); ?>"/>
                    	</a>
        		    </div>
        		    <?php endif ?>
    
                    <?php if(_ceo('single_qa') == true ): ?>
                    <?php if(_ceo('single_qa_article') == true ): ?>
        			<?php get_template_part( 'template-parts/single/single', 'qa' ); ?>
        			<?php endif ?>
        			<?php endif ?>
    
                    <?php if(_ceo('xg_show') == true ): ?>
        			<?php get_template_part( 'template-parts/single/single', 'bottom' ); ?>
        			<?php endif ?>
    
        			<?php if(_ceo('comments_close') == false ): ?>
        			<?php if ( comments_open() || get_comments_number() ) : ?>
        			<?php comments_template( '', true ); ?>
        			<?php endif; ?>
        			<?php endif; ?>
    
    			</div>
    		</div>
    		<?php get_sidebar(); ?>
    	</div>
    </section>
<?php endif; ?>
<!--必备-->
<?php add_action('get_footer', function () {
	wp_enqueue_script('js2021', get_template_directory_uri() . '/static/js/js21.js', ['jquery']);
}); ?>
<?php get_footer(); ?>