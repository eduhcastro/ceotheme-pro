// 验证邮箱邮件 重新发送
var t = 60;
function showTime(item){

    item ? item : item = '#re_send_mail';

    t -= 1;
    $(item).text('重新发送（'+t+'）');
    $('#re_send_mail').css("pointer-events","none")
    var f = setTimeout("showTime('"+item+"')",1000);

    if(t==0){
       $(item).text('重新发送');
       $('#re_send_mail').css("pointer-events","auto")
       window.clearTimeout(f);
       t=60;
    }

}


(function($) {

// 重新发送邮件
$(document).on('click', '#re_send_mail', function(event) {
    event.preventDefault();
    $.ajax({
        url: ceotheme.ajaxurl,
        type: 'POST',
        dataType: 'json',
        data: {action: 're_send_mail'},
    })
    .done(function( data ) {
        if( data.state == 200 ){
            showTime('#re_send_mail');
        }else{
            alert(data.tips)
        }
    })
    .fail(function() {
        alert('网络错误，请稍候再试！');
    });


});

// 账号登录
$('#login-form,.login-form2,.login-form-sms').submit(function(event) {
    event.preventDefault();
    $.ajax({
        url: ceotheme.ajaxurl,
        type: 'POST',
        dataType: 'json',
        data: $(this).serializeArray(),
    })
    .done(function( data ) {
        if(data.success){
            $('.ceotheme-tips').removeClass('success').addClass('error').text('');
            // layer.msg(data.data.msg, {icon: 1})
            UIkit.notification(data.data.msg, { status: 'success' })
            if( data.data.url ){
                window.location.href = data.data.url
            }
        }else{
            // layer.msg(data.data, {icon: 2})
            UIkit.notification(data.data, { status: 'warning' })
            $('.ceotheme-tips').removeClass('success').addClass('error').text('登录失败');
        }
    })
    .fail(function() {
        // layer.msg('操作错误！', {icon: 2})
        UIkit.notification('操作错误！', { status: 'warning' })
    });

});


//注册账号
    $('#register-form').on("submit",function(event) {
        event.preventDefault();

        $.ajax({
            url: ceotheme.ajaxurl,
            type: 'POST',
            dataType: 'json',
            data: $('#register-form').serializeArray(),
            success: function( data ) {
                if (data.success) {
                    $('.ceotheme-tips').removeClass('success').addClass('error').text('');
                    setTimeout(function (){
                        if (data.data.url) {
                            window.location.href = data.data.url;
                        }
                    },1000)
                    // layer.msg(data.data.msg, {icon: 1})
                    UIkit.notification(data.data.msg, { status: 'success' })
                } else {
                    $('.ceotheme-tips').removeClass('success').addClass('error').text('请求错误！');
                    // layer.msg(data.data, {icon: 2})
                    UIkit.notification(data.data, { status: 'warning' })
                }
            },
            error:function() {
                // layer.msg('操作错误！', {icon: 2})
                UIkit.notification('操作错误！', { status: 'warning' })
            }
        });

    });


//收藏
jQuery(document).on("click", ".add-collection", function() {

    var post_id = $(this).data("id");
    var $this = $(this);

    jQuery.ajax({
        url: ceotheme.ajaxurl,
        data: {
            action:"do_collection",
            post_id:post_id
        },
        type: 'post',
        dataType: 'json',
        success:function(data){

            if(data.state == 1){
                $this.addClass("cancel-collection").removeClass("add-collection").html("<i class='ceofont ceoicon-star-fill'></i><span>"+data.num+"</span>");
            }else{

                if( data.state == 300 ){
                    alert(data.tips);
                    window.location.href = data.url;
                } else{
                    alert(data.tips);
                }

            }

        },

    });
    return false;
});

//取消收藏
jQuery(document).on("click", ".cancel-collection", function() {

    var post_id = $(this).data("id");
    var $this = $(this);

    jQuery.ajax({
        url: ceotheme.ajaxurl,
        data: {
            action:"cancel_collection",
            post_id:post_id
        },
        type: 'post',
        dataType: 'json',
        success:function(data){

            if(data.state == 1){
                $this.addClass("add-collection").removeClass("cancel-collection").html("<i class='ceofont ceoicon-star-line'></i><span>"+data.num+"</span>");
            }else{
                alert(data.tips);
            }

        },

    });
    return false;
});

//文章页面，刷新页面后取消收藏
$(document).on('click', '.single-del-collection', function() {

    var post_id = $(this).data('id');
    var $this = $(this);

    jQuery.ajax({
        url: ceotheme.ajaxurl,
        data: {
            action:"cancel_collection",
            post_id:post_id
        },
        type: 'post',
        dataType: 'json',
        success:function(data){

            if(data.state == 1){
                $this.addClass("add-collection").removeClass("single-del-collection").html("<i class='ceofont ceoicon-star-line'></i><span>"+data.num+"</span>");
            }else{
                alert(data.tips);
            }

        },

    });

});

//用户中心取消收藏文章
$(document).on('click', '.del-collection', function(event) {
    event.preventDefault();
    var id = $(this).data('id');

    jQuery.ajax({
        url: ceotheme.ajaxurl,
        data: {
            action:"cancel_collection",
            post_id:id
        },
        type: 'post',
        dataType: 'json',
        success:function(data){

            if(data.state == 1){
                $('.collection-post-'+id).remove();
            }else{
                alert(data.tips);
            }

        },
    });

});

//文章点赞
$.fn.postLike = function() {
	if ($(this).hasClass('done')) {
		UIkit.notification({
            message: '您已经赞过了！',
            status: 'success'
        });
		return false;
	} else {
		$(this).addClass('done');
		var id = $(this).data("id"),
			action = $(this).data('action'),
			rateHolder = $(this).children('.count');
		var ajax_data = {
			action: "ceotheme_post_like",
			um_id: id,
			um_action: action
		};
		$.post(ceotheme.ajaxurl, ajax_data, function(data) {
			$(rateHolder).html(data);
		});
		return false;
	}
};
$(".post-like").click(function() {
	$(this).postLike();
});

// 用户中心 我的收藏  移除收藏
(function($){
    var $dp_handle = $('.dropdown-handle');

    $dp_handle.on('click', toggleSettings);

    function toggleSettings() {
        var $this = $(this),
            $dp = $this.siblings('.dropdown');

        if($dp.hasClass('closed')) {
            $dp.removeClass('closed');
            $this.addClass('active');
        } else {
            $dp.addClass('closed');
            $this.removeClass('active');
        }
    }
})(jQuery);

// 修改资料
$('#updata_accounts').submit(function(event) {
    event.preventDefault();

    $.ajax({
        url: ceotheme.ajaxurl,
        type: 'POST',
        dataType: 'json',
        data: $('#updata_accounts').serializeArray(),
    })
    .done(function( data ) {
        alert(data.tips);
        location.reload();
    })
    .fail(function() {
        alert('网络错误！');
    });

});


//用户中心修改密码
$(document).on('click', '#change_password_button', function(event) {
    event.preventDefault();

    var oldpwd = $('#oldpassword').val();
    var pwd1 = $('#newpassword').val();
    var pwd2 = $('#newpassword2').val();

    var err = 0;

    if( oldpwd == '' ){
        $('.oldpassword').removeClass('success').addClass('error');
        $('.oldpassword .ceotheme-tips').text('请输入旧密码');
        $('.oldpassword .ceotheme-tips').show();
        err = 1;
    }else{
        $('.oldpassword .ceotheme-tips').hide();
    }

    if( pwd1 == '' ){
        $('.newpassword').removeClass('success').addClass('error');
        $('.newpassword .ceotheme-tips').text('请输入密码');
        $('.newpassword .ceotheme-tips').show();
        err = 1;
    }else{
        $('.newpassword .ceotheme-tips').hide();
    }

    if( pwd2 == '' ){
        $('.newpassword2').removeClass('success').addClass('error');
        $('.newpassword2 .ceotheme-tips').text('请输入密码');
        $('.newpassword2 .ceotheme-tips').show();
        err = 1;
    }else{
        $('.newpassword2 .ceotheme-tips').hide()
    }

    if( pwd1 && pwd2 ){

        if( pwd1 != pwd2 ){
            $('.newpassword2,.newpassword').removeClass('success').addClass('error');
            $('.newpassword2 .ceotheme-tips,.newpassword .ceotheme-tips').text('密码不一致');
            $('.newpassword2 .ceotheme-tips,.newpassword .ceotheme-tips').show();
            err = 1;
        }else if( pwd1.length < 6 ){
            $('.newpassword2,.newpassword').removeClass('success').addClass('error');
            $('.newpassword2 .ceotheme-tips,.newpassword .ceotheme-tips').text('密码不能少于六位');
            $('.newpassword2 .ceotheme-tips,.newpassword .ceotheme-tips').show();
            err = 1;
        }

    }

    if( err != 1 ){

        $.ajax({
            url: ceotheme.ajaxurl,
            type: 'POST',
            dataType: 'json',
            data: $('#change_password').serializeArray(),
        })
        .done(function(data) {

            if( data.state ){
                alert(data.tips);
                window.location.href =  window.location.href;
            }else{
                alert(data.tips);
            }

        })
        .fail(function() {
            alert('网络错误，请稍候再试！');
        });

    }

});

//QQ登录
jQuery(document).on("click", ".qq_login_button",
    function() {
        //var w = window.open("","QQ授权登录",["toolbar=0,status=0,resizable=1,width=640,height=560,left=", (screen.width - 640) / 2, ",top=", (screen.height - 560) / 2].join(""));
        jQuery.ajax({
            url: ceotheme.ajaxurl,
            type: "POST",
            data: {action:"ajax_qq",ref:window.location.href},
            success: function(data) {
                window.location = data;
            }
        });
    return false;
});

//第三方账号首次登录需绑定本站账号
$('#login_binding').submit(function(event) {
    /* Act on the event */
    event.preventDefault();

        $.ajax({
            url: ceotheme.ajaxurl,
            type: 'POST',
            dataType: 'json',
            data: $('#login_binding').serializeArray(),
        })
        .done(function( data ) {
            if( data != 0 ){
                if( data.state == 200 ){
                    if( data.url ){
                    	//alert(data.tips);
                        window.location.href = data.url;
                    }
                }else if( data.state == 201 ){
                    alert(data.tips);
                }
            }else{
                alert('请求错误！');
            }
        })
        .fail(function() {
            alert('网络错误！');
        });

});

//第三方账号首次登录，没有本站账号的情况下注册新账号并绑定
$('#reg_binding').submit(function(event) {
    event.preventDefault();

        $.ajax({
            url: ceotheme.ajaxurl,
            type: 'POST',
            dataType: 'json',
            data: $('#reg_binding').serializeArray(),
        })
        .done(function( data ) {
            if( data != 0 ){
                if( data.state == 200 ){
                    if( data.url ){
	                    //alert(data.tips);
	                    //window.location.href = data.url;
                        window.location.reload()
                    }
                }else if( data.state == 201 ){
                    alert(data.tips);
                }
            }else{
                alert('请求错误！');
            }
        })
        .fail(function() {
            alert('网络错误！');
        });

});



//ajax点击加载更多
$('#ajaxBtn a').click(function() {
	$this = $(this);
	$this.addClass('loading').text("正在努力加载..."); //给a标签加载一个loading的class属性，可以用来添加一些加载效果
	var href = $this.attr("href"); //获取下一页的链接地址
	if (href != undefined) { //如果地址存在
		$.ajax({ //发起ajax请求
			url: href, //请求的地址就是下一页的链接
			type: "get", //请求类型是get
			error: function(request) {
				//如果发生错误怎么处理
			},
			success: function(data) { //请求成功
				setTimeout(function(){
					$this.removeClass('loading').text("点击查看更多"); //移除loading属性
					var $res = $(data).find(".ajaxItem"); //从数据中挑出文章数据，请根据实际情况更改
					$('.ajaxMain').append($res.fadeIn(500)); //将数据加载加进posts-loop的标签中。
					var newhref = $(data).find("#ajaxBtn a").attr("href"); //找出新的下一页链接
					if (newhref != undefined) {
						$("#ajaxBtn a").attr("href", newhref);
					} else {
						$("#ajaxBtn").html('我是有底线的！'); //如果没有下一页了，隐藏
					}
				},500);
			}
		});
	}
	return false;
});


})(jQuery);

(function ($) {
    $(function () {

        // 发送验证码 注册
        $(document).on('click', ".go-captcha_mobile", function (event) {
            if(typeof vaptcha != 'undefined' && !window.vaptcha_pass){
                // layer.msg('请先人机验证', {icon: 2})
                UIkit.notification('请先人机验证', { status: 'warning' })
                return false
            }
            var _this =
                $(this)
            var deft = _this.text()
            var user_mobile = $("input[name='user_mobile']").val()
            if(!user_mobile){
                var user_mobile = $("input[name='user_mobile_reg']").val()
            }
            if(!user_mobile){
                var user_mobile = $("input[name='user_mobile_forget']").val()
            }
            // _this.html(iconspin+deft)
            _this.attr("disabled","true");
            //验证邮箱
            if( !is_check_mobile(user_mobile) ){
                // _this.html(iconwarning+'手机号错误')
                // layer.msg('手机号错误', {icon: 2})
                UIkit.notification('手机号错误', { status: 'warning' })
                setTimeout(function(){
                    _this.html(deft)
                    _this.removeAttr("disabled")
                },3000)
                return false;
            }
            let s60 = 60;
            let text=''

            $.ajax({
                "action": "captcha_mobile",
                "url": ceotheme.ajaxurl,
                "type": 'POST',
                "data": {
                    "action": "captcha_mobile",
                    "user_mobile": user_mobile,
                    "smstype": $(this).attr("data-smstype"),
                    "nonce": $(this).attr("data-nonce"),
                },
                success: function (data) {
                    if (data.success) {
                        // layer.msg(data.data.msg, {icon: 1})
                        UIkit.notification(data.data.msg, { status: 'success' })

                        const inval = setInterval(() => {
                            if (s60 === 0) {
                                clearInterval(inval)
                                _this.attr('disabled', false);
                                _this.text('发送验证码')
                                return
                            } else {

                            }
                            s60 = s60 - 1
                            text = s60 + 's'
                            _this.disabled = true
                            _this.attr('disabled', true);
                            _this.text('')
                            _this.text(text);
                        }, 1000)

                        // setTimeout(function () {
                        //     _this.html(data.data.btn_msg)
                        // }, 3000)
                    } else {
                        // layer.msg(data.data.msg, {icon: 2})
                        UIkit.notification(data.data, { status: 'warning' })
                        setTimeout(function () {
                            _this.html(deft)
                            _this.removeAttr("disabled")
                        }, 3000)
                    }
                },
                error: function () {
                    _this.removeAttr("disabled")

                }
            });
        });

        function is_check_mobile(str){
            // if((/^1[34578]\d{9}$/.test(str))){
            if((/^1[\d]\d{9}$/.test(str))){
                return true;
            }
            return false;//tmp
        }




    })
})(jQuery)
