(function ($) {
    $(function () {
        $(".question-money-v").on("click", function () {
            if ($(this).attr('data-v') > 0) {
                $(".ceo-question-money-input").val($(this).attr('data-v'))
            } else {
                UIkit.notification('请输入悬赏金额', { status: 'warning' })
                $(".ceo-question-money-input").val('')
                $(".ceo-question-money-input").focus()
            }

        })
    })

    $(".button-select-answer").on("click", function () {
        var that = this

        UIkit.modal('#ceo-dialog-public').show()

        $('#submit-ceo-question-confirm').off('click').click(function () {
            $.ajax({
                url: '/wp-admin/admin-ajax.php',
                data: { post_id: $(that).attr('data-post_id'), comment_id: $(that).attr('data-comment_id'), action: 'select_the_answer' },
                type: 'post',
                success: function (data) {
                    if (data && data.success) {
                        UIkit.notification(data.data.msg, { status: 'success' })
                        location.href = data.data.url
                    } else if (data.data) {
                        UIkit.notification(data.data, { status: 'warning' })
                    } else {
                        UIkit.notification('操作出错', { status: 'warning' })
                    }
                },
                error: function (e) {
                    UIkit.notification('操作出错', { status: 'warning' })
                }
            })
        })
    })

    jQuery(function () {
        'use strict';
        $('#j-form-question').on('submit', function (e) {
            e.preventDefault()

            let $btn = $(this).find('button[type=submit]');
            if ($btn.hasClass('loading')) return false;
            $btn.attr("disabled", "true");
            $btn.prepend('<div ceo-spinner id="q_spinner"></div>')

            var error = 0;
            $('#post-tags').remove();
            if (typeof tinyMCE != "undefined") {
                tinyMCE.triggerSave();
                var ed = tinyMCE.activeEditor;
                if (ed) {
                    ed.off('change').on('change', function (ed) {
                        $('.wp-editor-wrap').removeClass('error');
                    });
                }
            }
            var title = $.trim($('#question_title').val());
            var content = $.trim($('#question_content').val());
            var category = $('#question_cat').val();
            if (title == '') {
                $('#question_title').addClass('error');
                error = 1;
                UIkit.notification('请输入问题标题', { status: 'warning' })
            }
            if (content == '') {
                $('.wp-editor-wrap').addClass('error');
                error = 1;
                UIkit.notification('请输入问题内容', { status: 'warning' })
            }
            if (!category) {
                $('#question_cat').addClass('error');
                UIkit.notification('请选择分类', { status: 'warning' })
                error = 1;
            }
            if (error) {
                $btn.loading(0);
                $btn.removeAttr("disabled");
                $("#q_spinner").remove()
                return false;
            }

            var form_data = $('#j-form-question').serialize();
            console.log(form_data)
            $.ajax({
                url: '/wp-admin/admin-ajax.php',
                data: form_data,
                type: 'post',
                success: function (data) {
                    $btn.removeAttr("disabled")
                    $("#q_spinner").remove()
                    if (data && data.success) {
                        UIkit.notification(data.data.msg, { status: 'success' })
                        location.href = data.data.url
                    } else if (data.data) {
                        UIkit.notification(data.data, { status: 'warning' })
                    } else {
                        UIkit.notification('添加出错', { status: 'warning' })
                    }
                },
                error: function (e) {
                    $btn.removeAttr("disabled")
                    $("#q_spinner").remove()
                }
            });

            return false;
        }).on('input propertychange', '.form-control', function () {
            $(this).removeClass('error');
        });

    });
})(jQuery)
