<?php get_header(); ?>
<section class="ceo-background-default">
	<div class="ceo-container ceo-flex ceo-flex-middle">
		<div class="single-head ceo-flex-1">
			<div class="ceo-search-box">
				<h1 class="ceo-h3" style="display: block;">#<?php single_tag_title(); ?></h1>
				<p class="ceo-display-block ceo-text-muted">标签为 #<?php single_tag_title(); ?> 内容如下：</p>
			</div>
		</div>
	</div>
</section>
<section class="ceo-container">
	<div class="crumbs ceo-text-small ceo-padding-small ceo-padding-remove-horizontal">
		<?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
	</div>	
	<div class="card ceo-grid-ceosmls" ceo-grid>
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div class="ceo-width-1-2 ceo-width-1-4@s">
			<?php get_template_part( 'template-parts/loop/loop', 'card' ); ?>
		</div>
		<?php endwhile; else: ?>
		<div class="ceo-width-1-1">
			<div class="ceo-alert-primary ceo-container" ceo-alert>
				<a class="ceo-alert-close" ceo-close></a>
				<p class="ceo-padding-small ceo-text-center">这是一个没有灵魂的标签...</p>
			</div>
		</div>
		<?php endif; ?>
	</div>
    <div class="fenye ceo-text-center ceo-text-small ceo-margin-medium-top">
    	<?php fenye(); ?>
    </div>
</section>
<?php get_footer(); ?>