<?php
    get_header();
?>
<div class="ceo-special-category">
    <?php
    $backgroud_img = '';
    $cate_background_img_arrs = get_term_meta(get_queried_object_id(), 'catf_background_img', 1);
    if ($cate_background_img_arrs && ! empty($cate_background_img_arrs['url'])) {
        $backgroud_img = $cate_background_img_arrs['url'];
    }
    ?>
    <div class="special-category-banner ceo-display-block ceo-cover-container ceo-overflow-hidden ceo-inline ceo-flex ceo-flex-middle ceo-flex-center">
        <img src="<?php echo $backgroud_img; ?>" ceo-cover/>
        <?php if(!$backgroud_img){?>
		<img src="<?php echo _ceo('special-bg-db'); ?>" ceo-cover/>
        <?php }?>

        <div class="ceo-overlay-primary ceo-position-cover"></div>
	        <div class="special-category-title ceo-overlay ceo-position-center ceo-text-center ceo-light">
                <?php
                $term_current=get_term(get_queried_object_id());
                if($term_current){
                    echo "<h3>".$term_current->name."</h3>";
                    echo "<p>".$term_current->description."</p>";
                }
                ?>
            </div>
        </div>
    </div>
	<div class="ceo-container">
		<div class="blog special-category-box">
		    <?php
	        $category = get_the_category();
            $term_id = get_queried_object_id();
            global $wp_query;
            $current_page = !empty($paged) ? $paged: get_query_var('paged');

            $wp_query = new WP_Query(
                array(
                    'post_type'   => 'post',
                    'post_status' => 'publish',
                    'tax_query'   => array(
                        array(
                            'taxonomy' => 'special',
                            'field'    => 'term_id',
                            'terms'    => $term_id,
                        )
                    ),
                    'paged'=>$current_page
                )
            );
            if ( have_posts() ) :  while ( have_posts() ) : the_post();
		    ?>
			<?php get_template_part( 'template-parts/loop/loop', 'blog' ); ?>
			<?php endwhile;endif; ?>
		</div>
		<?php if( _ceo('cat_load' ) == 'num' ){?>
        <div class="fenye ceo-text-center ceo-text-small ceo-margin-medium-top">
        	<?php
            $args = array(
                'prev_next'          => 0,
                'format'       => '?paged=%#%',
                'before_page_number' => '',
                'mid_size'           => 2,
                'current' => max( 1, $current_page ),
                'prev_next'    => True,
                'prev_text'    => __('上一页'),
                'next_text'    => __('下一页'),
            );
            $page_arr=paginate_links($args);
            if ($page_arr) {
                echo $page_arr;
            }else{

            }
            ?>
        </div>
        <?php }else{ ?>
        <div id="ajaxBtn" class="ajax-btn ceo-text-center ceo-margin-medium">
        	<?php next_posts_link(__('点击加载更多')); ?>
        </div>
        <?php } ?>
	</div>
</div>
<?php get_footer();?>