<?php
if(!empty($author)){
    $user_id=$author;
}
?>
<div class="wp">
    <div class="ceo-cet-forum-box">
        <div class="forum-box-list">
        	<?php
            //我的发布
            global $wp_query;
            $page=!empty(get_query_var('paged')) ?get_query_var('paged') :1;
            $wp_query = new WP_Query(
                array(
                    'post_type'      => 'forum',
                    'posts_per_page' => 20,
                    'post_status'    => 'publish',
                    'author' => $user_id,
                    'paged' => $page
                )
            );
            if(have_posts()) : while (have_posts()) : the_post(); ?>
        	    <?php get_template_part( 'template-parts/loop/loop', 'forum' ); ?>
        	<?php endwhile;endif; ?>
    	</div>
	</div>
</div>
<div class="fenye ceo-text-center ceo-text-small ceo-margin-medium-top ceo-margin-medium-bottom">
	<?php fenye(); ?>
</div>