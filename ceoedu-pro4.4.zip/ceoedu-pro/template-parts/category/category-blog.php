<div class="ceo-category-box ceo-background-default">
    <div class="ceo-container">
        <div class="ceo-category-blog-box">
            <div class="ceo-category-blog-boxll">
        		<ul>
        			<?php wp_list_categories('child_of=' . get_category_root_id($cat) . '&depth=1&hide_empty=0&hierarchical=1&optioncount=1&title_li=');?>
        		</ul>
    		</div>
    	</div>
	</div>
</div>

<?php if(_ceo('cat_zz_show')  == true ): ?>
<section class="ceo-container ceo-margin-top ceo-cat-ad ceo-margin-bottom">
	<a href="<?php echo _ceo('cat_zz_link'); ?>" target="_blank" class="ceo-display-block ceo-overflow-hidden">
		<img src="<?php echo _ceo('cat_zz_img'); ?>"/>
	</a>
</section>
<?php endif ?>

<section class="ceo-container" id="category">
    <div class="ceo-grid-ceosmls" ceo-grid>
    	<div class="ceo-width-1-1 ceo-width-auto@s">
    		<div class="wp b-a b-r-4 ceo-background-default">
    			<div class="blog ajaxMain">
    				<?php if ( have_posts() ) :  while ( have_posts() ) : the_post(); ?>
    				<?php get_template_part( 'template-parts/loop/loop', 'blog' ); ?>
    				<?php endwhile;endif; ?>
    			</div>
    		</div>
            <div class="fenye ceo-text-center ceo-text-small ceo-margin-medium-top ceo-margin-medium-bottom">
            	<?php fenye(); ?>
            </div>
    	</div>
    	<?php get_sidebar(); ?>
    </div>
</section>