<?php
$term = get_category(get_query_var('cat'));
?>
<div class="ceo-shop-category-box ceo-category-box ceo-background-default">
	<div class="ceo-container">
		<div class="ceo-category-shop-box">
			<?php ceo_catnav_ji(); ?>
		</div>
		<?php if (_ceo('ceo_choice')  == true) : ?>
			<div class="ceo-category-shop-screen">
				<?php ceo_catnav_bar(); ?>
			</div>
		<?php endif; ?>
		<div class="ceo-grid-ceosmls" ceo-grid>
			<?php if (_ceo('ceo_cat_ss')  == true) : ?>
				<div class="ceo-catnav-ss ceo-width-1-1@s ceo-width-expand@m ceo-width-expand@l ceo-width-expand@xl">
					<ul>
						<li>
							<strong>价格筛选：</strong>
						</li>
						<li><a href="<?php echo get_category_link(get_queried_object_id()); ?>">全部</a></li>
						<li><a href="<?php echo get_category_link(get_queried_object_id()); ?>?filter_type_1=1">免费</a></li>
						<li><a href="<?php echo get_category_link(get_queried_object_id()); ?>?filter_type_2=1">收费</a></li>
						<li><a href="<?php echo get_category_link(get_queried_object_id()); ?>?filter_type_3=1">VIP专属</a></li>
						<li><a href="<?php echo get_category_link(get_queried_object_id()); ?>?filter_type_4=1">VIP免费</a></li>
					</ul>
				</div>
			<?php endif; ?>
			<div class="ceo-fl-icon ceo-width-1-1@s ceo-width-auto@m ceo-width-auto@l ceo-width-auto@xl">
				<?php if (_ceo('ceo-cat-tj') == true) : ?>
					<div class="ceo-display-inline-block ceo-visible@s">
						<i class="ceofont ceoicon-calendar-line"></i>共<span class="ceo-text-warning ceo-text-bold"> <?php echo get_cat_postcount($term->term_id); ?> </span>个资源
					</div>
				<?php endif; ?>
				<?php if (_ceo('ceo_cat_wss') == true) : ?>
					<a class="hot" href="<?php echo get_category_link($cat) ?>"> <i class="ceofont ceoicon-time-line"></i>最新 </a>
					<a class="hot" href="<?php echo get_category_link($cat) ?>?order=hot"> <i class="ceofont ceoicon-fire-line"></i>最热 </a>
					<a class="hot" href="<?php echo get_category_link($cat) ?>?order=rand"> <i class="ceofont ceoicon-refresh-line"></i>随机 </a>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>

<?php if (_ceo('cat_zz_show')  == true) : ?>
	<section class="ceo-container ceo-margin-top ceo-cat-ad ceo-margin-bottom">
		<a href="<?php echo _ceo('cat_zz_link'); ?>" target="_blank" class="ceo-display-block ceo-overflow-hidden">
			<img src="<?php echo _ceo('cat_zz_img'); ?>" />
		</a>
	</section>
<?php endif ?>

<section class="ceo-container" id="category">
	<div class="shop">
		<div class="ajaxMain ceo-grid-ceosmls" ceo-grid>
			<?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
					<div class="ajaxItem ceo-width-1-2 ceo-width-1-4@s">
						<?php get_template_part('template-parts/loop/loop', 'shop'); ?>
					</div>
			<?php endwhile;
			endif; ?>
		</div>
	</div>
	<div class="fenye ceo-text-center ceo-text-small ceo-margin-medium-top">
		<?php fenye(); ?>
	</div>
</section>