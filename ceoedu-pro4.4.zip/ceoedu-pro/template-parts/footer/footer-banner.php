<?php if(_ceo('ceo_foo_banner') == true ): ?>
<?php if (_ceo('ceo_footer_display')!='index' || (is_home() && _ceo('ceo_footer_display')=='index') ) { ?>
<?php if(_ceo('ceo_footer_style')=='1'){ ?>
<div class="ceo-footer-banner ceo-background-cover" style="background-image: url(<?php if(_ceo('ceo_footer_sz'))echo _ceo('ceo_footer_sz')['ceo_foo_bannerbg']; ?>);">
	<em></em>
	<i></i>
	<div class="ceo-container">
    	<div class="ceo-footer-banner-box">
        	<h5><?php if(_ceo('ceo_footer_sz'))echo _ceo('ceo_footer_sz')['ceo_foo_banner_title']; ?></h5>
            <a href="<?php if(_ceo('ceo_footer_sz'))echo _ceo('ceo_footer_sz')['ceo_foo_banner_anlink']; ?>" target="_blank"><?php if(_ceo('ceo_footer_sz'))echo _ceo('ceo_footer_sz')['ceo_foo_banner_antitle']; ?></a>
        </div>
        <div class="ceo-footer-banner-statistics ceo-visible@s">
            <ul class="ceo-grid-ceosmls" ceo-grid>
                <li class="ceo-width-1-6">
                    <div class="banner-statistics-box">
                        <span><?php echo all_view(); ?></span>
                        <v>+</v>
                        <p><?php if(_ceo('ceo_footer_count_sz'))echo _ceo('ceo_footer_count_sz')['all_view_count_title']; ?></p>
                    </div>
                </li>
                <li class="ceo-width-1-6">
                    <div class="banner-statistics-box">
                        <span><?php echo all_users_count(); ?></span>
                        <v>+</v>
                        <p><?php if(_ceo('ceo_footer_count_sz'))echo _ceo('ceo_footer_count_sz')['all_huiyuan_count_title']; ?></p>
                    </div>
                </li>
                <li class="ceo-width-1-6">
                    <div class="banner-statistics-box">
                        <span><?php echo all_posts_count();?></span>
                        <v>+</v>
                        <p><?php if(_ceo('ceo_footer_count_sz'))echo _ceo('ceo_footer_count_sz')['all_site_count_title']; ?></p>
                    </div>
                </li>
                <li class="ceo-width-1-6">
                    <div class="banner-statistics-box">
                        <span><?php echo DayUpdate()?></span>
                        <v>+</v>
                        <p><?php if(_ceo('ceo_footer_count_sz'))echo _ceo('ceo_footer_count_sz')['all_jinri_count_title']; ?></p>
                    </div>
                </li>
                <li class="ceo-width-1-6">
                    <div class="banner-statistics-box">
                        <span><?php echo get_week_post_count(); ?></span>
                        <v>+</v>
                        <p><?php if(_ceo('ceo_footer_count_sz'))echo _ceo('ceo_footer_count_sz')['all_benzhou_count_title']; ?></p>
                    </div>
                </li>
                <li class="ceo-width-1-6">
                    <div class="banner-statistics-box">
                        <span><?php echo floor((time()-strtotime(_ceo('all_yunxing_count',"2011-11-11")))/86400); ?></span>
                        <v>+</v>
                        <p><?php if(_ceo('ceo_footer_count_sz'))echo _ceo('ceo_footer_count_sz')['all_yunxing_count_title']; ?></p>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php }else { ?>
<div class="ceo-footerer-banner ceo-background-cover" style="background-image: url(<?php if(_ceo('ceo_footerer_sz'))echo _ceo('ceo_footerer_sz')['ceo_fooer_bannerbg']; ?>);">
	<em></em>
	<i></i>
	<div class="ceo-container">
    	<div class="ceo-footer-banner-box">
        	<h5><?php if(_ceo('ceo_footerer_sz'))echo _ceo('ceo_footerer_sz')['ceo_fooer_banner_title']; ?></h5>
            <a href="<?php if(_ceo('ceo_footerer_sz'))echo _ceo('ceo_footerer_sz')['ceo_fooer_banner_anlink']; ?>" target="_blank"><?php if(_ceo('ceo_footerer_sz'))echo _ceo('ceo_footerer_sz')['ceo_fooer_banner_antitle']; ?></a>
        </div>
    </div>
</div>
<?php }?>
<?php } ?>
<?php endif; ?>