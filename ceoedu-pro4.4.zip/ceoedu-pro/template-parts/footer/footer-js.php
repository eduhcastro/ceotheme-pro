<?php echo _ceo('head_js'); ?>
<script>
    console.log("\n %c \u603b\u88c1\u4e3b\u9898 V4.4 %c \u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0077\u0077\u0077\u002e\u0063\u0065\u006f\u0074\u0068\u0065\u006d\u0065\u002e\u0063\u006f\u006d \n\n", "color: #fff; background: #3371f5; padding:5px 0;", "background: #3371f5; padding:5px 0;");
</script>