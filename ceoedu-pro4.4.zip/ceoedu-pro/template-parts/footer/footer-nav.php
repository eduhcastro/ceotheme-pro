<div class="ceo-app-footer-fixed ceo-app-footer ceo-hidden@s">
    <a href="<?php if(_ceo('ceo_app_foo_sz'))echo _ceo('ceo_app_foo_sz')['ceo_app_foo_link1']; ?>">
        <span class="icon">
            <i class="ceofont <?php if(_ceo('ceo_app_foo_sz'))echo _ceo('ceo_app_foo_sz')['ceo_app_foo_ico1']; ?>"></i>
        </span>
        <span class="text"><?php if(_ceo('ceo_app_foo_sz'))echo _ceo('ceo_app_foo_sz')['ceo_app_foo_title1']; ?></span>
    </a>
    <a href="<?php if(_ceo('ceo_app_foo_sz'))echo _ceo('ceo_app_foo_sz')['ceo_app_foo_link2']; ?>">
        <span class="icon">
            <i class="ceofont <?php if(_ceo('ceo_app_foo_sz'))echo _ceo('ceo_app_foo_sz')['ceo_app_foo_ico2']; ?>"></i>
        </span>
        <span class="text"><?php if(_ceo('ceo_app_foo_sz'))echo _ceo('ceo_app_foo_sz')['ceo_app_foo_title2']; ?></span>
    </a>
    <a class="cat" ceo-toggle="target: #mobNav">
        <span class="icon">
            <i class="ceofont ceoicon-apps-2-line"></i>
        </span>
        <span class="text">菜单</span>
    </a>
    <a href="<?php if(_ceo('ceo_app_foo_sz'))echo _ceo('ceo_app_foo_sz')['ceo_app_foo_linky1']; ?>">
        <span class="icon">
            <i class="ceofont <?php if(_ceo('ceo_app_foo_sz'))echo _ceo('ceo_app_foo_sz')['ceo_app_foo_icoy1']; ?>"></i>
        </span>
        <span class="text"><?php if(_ceo('ceo_app_foo_sz'))echo _ceo('ceo_app_foo_sz')['ceo_app_foo_titley1']; ?></span>
    </a>
    <a href="<?php if(_ceo('ceo_app_foo_sz'))echo _ceo('ceo_app_foo_sz')['ceo_app_foo_linky2']; ?>">
        <span class="icon">
            <i class="ceofont <?php if(_ceo('ceo_app_foo_sz'))echo _ceo('ceo_app_foo_sz')['ceo_app_foo_icoy2']; ?>"></i>
        </span>
        <span class="text"><?php if(_ceo('ceo_app_foo_sz'))echo _ceo('ceo_app_foo_sz')['ceo_app_foo_titley2']; ?></span>
    </a>
</div>