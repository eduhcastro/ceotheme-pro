<?php if(_ceo('ceo_footer_vip') == true ): ?>
<div id="ceo-footer-vip" class="ceo-footer-vip ceo-visible@s" style="display: none">
    <div class="ceo-footer-vipmk">
        <button id="footer-vip-close" type="button" ceo-close></button>
        <div class="footer-vipmk-n">
            <div class="vipmk-nz" style="background: url(<?php if(_ceo('ceo_footer_vip_sz'))echo _ceo('ceo_footer_vip_sz')['footer_vip_img']; ?>) no-repeat;"></div>
            <div class="vipmk-btn">
                <a href="<?php if(_ceo('ceo_footer_vip_sz'))echo _ceo('ceo_footer_vip_sz')['footer_vip_1link']; ?>" target="_blank" class="vipmk-btn-vip"><?php if(_ceo('ceo_footer_vip_sz'))echo _ceo('ceo_footer_vip_sz')['footer_vip_1title']; ?></a>
                <a href="<?php if(_ceo('ceo_footer_vip_sz'))echo _ceo('ceo_footer_vip_sz')['footer_vip_2link']; ?>" class="vipmk-btn-fw" rel="noreferrer nofollow"><?php if(_ceo('ceo_footer_vip_sz'))echo _ceo('ceo_footer_vip_sz')['footer_vip_2title']; ?></a>
                <a href="<?php if(_ceo('ceo_footer_vip_sz'))echo _ceo('ceo_footer_vip_sz')['footer_vip_3link']; ?>" target="_blank" class="vipmk-btn-yw"><?php if(_ceo('ceo_footer_vip_sz'))echo _ceo('ceo_footer_vip_sz')['footer_vip_3title']; ?></a>
            </div>
        </div>
    </div>
	<div class="ceo-footer-vip-bottom"></div>
</div>
<script>
	$('#footer-vip-close').click(function(){
		UIkit.modal('#ceo-footer-vip').hide();
        var now = new Date();
        var time = now.getTime();
        time += 3600 * 1000*24;
        now.setTime(time);
        document.cookie =
            'footertips_close=' + '1' +
            '; expires=' + now.toUTCString() +
            '; path=/';
	});
    $(function (){
        if(document.cookie.indexOf('footertips_close=1') =='-1'){
            $("#ceo-footer-vip").show()
        }
    })
</script>
<?php endif; ?>