<?php
    $ceo_ads_sz = _ceo('ceo_ads_sz');
	$ceo_adsw_sz = _ceo('ceo_adsw_sz');
?>
<!--图文广告模块-->
<div class="ceo-home-ads ceo-background-default">
    <div class="ceo-container">
        <!--多图广告-->
        <?php if ( _ceo('ceo_ads') == true): ?>
        <div class="ceo_ads">
            <div class="ceo-grid-ceossss" ceo-grid>
                <?php
            		if ($ceo_ads_sz) {
            			foreach ( $ceo_ads_sz as $key => $value) {
            	?>
                <li class="ceo-width-1-1 ceo-width-1-3@s">
            	    <a href="<?php echo $ceo_ads_sz[$key]['link']; ?>" target="_blank">
            	        <img src="<?php echo $ceo_ads_sz[$key]['img']; ?>" alt="<?php echo $ceo_ads_sz[$key]['title']; ?> 到期时间：<?php echo $ceo_ads_sz[$key]['date']; ?>">
        	        </a>
            	</li>
            	<?php } } ?>
        	</div>
    	</div>
    	<?php endif;  ?>
    	
    	<!--文字广告-->
    	<?php if ( _ceo('ceo_adsw') == true): ?>
        <div class="ceo_adsw b-a">
            <div class="ceo-grid-ceossss" ceo-grid>
             <?php
        		if ($ceo_adsw_sz) {
        			foreach ( $ceo_adsw_sz as $k => $v) {
        	?>
            <li class="ceo-width-1-2 ceo-width-1-5@s">
                <a href="<?php echo $ceo_adsw_sz[$k]['link']; ?>" target="_blank" class="ceo-text-truncate" alt="<?php echo $ceo_adsw_sz[$k]['title']; ?> 到期时间：<?php echo $ceo_adsw_sz[$k]['date']; ?>" >
                    <span style="color:<?php echo $ceo_adsw_sz[$k]['color']; ?>;"><?php echo $ceo_adsw_sz[$k]['title']; ?></span>
                </a>
            </li>
            <?php } } ?>
            </div>
        </div>
        <?php endif;  ?>
    
        <?php if ( _ceo('ceo_ads_spp') == true): ?>
        <style>
        @media screen and (max-width: 800px) {
            .ceo_ads{
                display:none;
            }
        }
        </style>
        <?php endif;  ?>
        
        <?php if ( _ceo('ceo_adsw_app') == true): ?>
        <style>
        @media screen and (max-width: 800px) {
            .ceo_adsw{
                display:none;
            }
        }
        </style>
        <?php endif; ?>
    </div>
</div>