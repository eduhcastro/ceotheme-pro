<!--文章布局首页广告模块-->
<?php 
    $guanggao = _ceo('ceo_article_guanggao');
    if(!$guanggao) {
?>
<div class="ceo-container ceo-margin-bottom">
	<div class="ceo-alert-primary" ceo-alert>
		<a class="ceo-alert-close" ceo-close></a>
		<p class="ceo-text-small"><i class="ceofont ceoicon-alert-fill ceo-margin-small-right"></i>请前往后台<i class="ceofont ceoicon-arrow-right-s-line"></i>主题设置<i class="ceofont ceoicon-arrow-right-s-line"></i>首页设置<i class="ceofont ceoicon-arrow-right-s-line"></i>首页文章布局-<b>广告模块</b>，设置该模块内容！</p>
	</div>
</div>
<?php }else { ?>
<div class="ceo-article-guanggao ceo-background-default b-a ceo-margin-bottom">
    <?php
		if ($guanggao) {
			foreach ( $guanggao as $key => $value) {
	?>
    <li>
        <a href="<?php echo $value['url']; ?>" target="_blank" class="ceo-display-block">
        	<img src="<?php echo $value['img']; ?>" alt="<?php echo $value['title']; ?>"/>
        </a>
    </li>
    <?php } } ?>
</div>
<?php } ?>