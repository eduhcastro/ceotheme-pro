<!--文章布局首页切换模块-->
<div class="ceo-article-hot ceo-background-default b-a ceo-margin-bottom">
    <div class="ceo-grid-ceossss" ceo-grid>
        <div class="ceo-width-auto">
            <img src="<?php echo get_template_directory_uri(); ?>/static/images/ceo-article-hot-img.png">
        </div>
        <div class="ceo-width-expand" id="scrollDiv">
            <ul>
                <?php
                $wp_query_views = new WP_Query(
                    array(
                        'post_type'      => 'post',
                        'posts_per_page' => 10,
                        'post_status'    => 'publish',
                        'meta_key'       => 'views',
                        'orderby'        => 'meta_value_num',
                        'order'          => 'DESC',
                    )
                );
                while ($wp_query_views->have_posts()) : $wp_query_views->the_post();
                ?>
                <li class="ceo-flex">
                    <a href="<?php the_permalink(); ?>" target="_blank" class="ceo-flex-1"><?php the_title(); ?></a>
                    <span class="ceo-visible@s">日期：<?php echo get_the_date("Y-m-d"); ?></span>
                    <span>阅读：<?php echo get_post_meta(get_the_ID(),'views',1); ?></span>
                </li>
                <?php endwhile; wp_reset_query(); ?>
            </ul>
        </div>
    </div>
</div>