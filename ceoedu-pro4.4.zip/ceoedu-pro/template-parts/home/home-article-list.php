<!--文章布局首页切换模块-->
<div class="ceo-article-list ceo-margin-bottom">
    <div class="ceo-background-default b-a">
        <ul class="ceo-subnav-pill ultitle b-b" ceo-switcher="animation: ceo-animation-fade">
            <?php if(_ceo('article_switcher_new_enable') == true ): ?>
            <li><a href="#"><?php echo _ceo('article_switcher_new_title'); ?></a></li>
            <?php endif; ?>
            <?php
            $cat_arrs   = _ceo('article_title_cat');
            if(empty($cat_arrs)){
                $cat_arrs=[];
            }
            foreach ($cat_arrs as $v) {
            $term_v = get_term($v);
            ?>
            <li><a href="#"><?php echo $term_v->name; ?></a></li>
            <?php }?>
        </ul>
        <ul class="ceo-switcher">
            <?php if(_ceo('article_switcher_new_enable') == true ): ?>
            <li>
                <div class="blog">
                    <?php
                    global $wp_query;
                    $cat_arrs   = _ceo('article_content_cat');
                    if(empty($cat_arrs)){
                        $cat_arrs=[];
                    }
                    $wp_query = new WP_Query(
                        array(
                            'post_type' => 'post',
                            'post_status' => 'publish',
                            'order' => 'DESC',
                            'orderby' => 'date',
                            'posts_per_page' => 20,
                            'cat'=>(array) _ceo('article_content_cat')
                        )
                    );
                    if ( have_posts() ) :  while ( have_posts() ) : the_post(); ?>
                    <?php get_template_part( 'template-parts/loop/loop', 'blog' ); ?>
                    <?php endwhile;endif; ?>
                </div>
                <div class="more">
                    <a href="<?php echo _ceo('article_switcher_new_url'); ?>" target="_blank">查看更多</a>
                </div>
            </li>
            <?php endif; ?>

            <?php
            $cat_arrs   = _ceo('article_title_cat');
            if(empty($cat_arrs)){
                $cat_arrs=[];
            }
            foreach ($cat_arrs as $v) {
            $term_v = get_term($v);
            ?>
            <li>
                <div class="blog">
                    <?php
                    global $wp_query;
                    $wp_query = new WP_Query(
                        array(
                            'cat' => $term_v->term_id,
                            'post_type' => 'post',
                            'post_status' => 'publish',
                            'order' => 'DESC',
                            'orderby' => 'date',
                            'posts_per_page' => 20,
                        )
                    );
                    if ( have_posts() ) :  while ( have_posts() ) : the_post(); ?>
                    <?php get_template_part( 'template-parts/loop/loop', 'blog' ); ?>
                    <?php endwhile;endif; ?>
                </div>
                <div class="more">
                    <a href="<?php echo get_term_link($term_v->term_id) ?>" target="_blank">查看更多</a>
                </div>
            </li>
            <?php }?>
        </ul>
    </div>
</div>