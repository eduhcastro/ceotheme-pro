<?php 
    $article_slide_type = _ceo('article_slide_type');
?>
<?php if( $article_slide_type == 1 ) { ?>
	<?php 
        $article_slide1 = _ceo('article_slide1');
        if(!$article_slide1) {
    ?>
    <div class="ceo-container ceo-margin-bottom">
    	<div class="ceo-alert-primary" ceo-alert>
    		<a class="ceo-alert-close" ceo-close></a>
    		<p class="ceo-text-small"><i class="ceofont ceoicon-alert-fill ceo-margin-small-right"></i>请前往后台<i class="ceofont ceoicon-arrow-right-s-line"></i>主题设置<i class="ceofont ceoicon-arrow-right-s-line"></i>首页设置<i class="ceofont ceoicon-arrow-right-s-line"></i>首页文章布局-幻灯模块<i class="ceofont ceoicon-arrow-right-s-line"></i><b>幻灯样式1设置</b>，设置该模块内容！</p>
    	</div>
    </div>
    <?php }else { ?>
    <div class="ceo-article-slide1 b-a ceo-background-default ceo-margin-bottom">
        <div class="ceo-position-relative ceo-visible-toggle" tabindex="-1" ceo-slideshow="autoplay: true">
    	    <ul class="ceo-slideshow-items">
    	    	<?php
    				if ($article_slide1) {
    					foreach ( $article_slide1 as $key => $value) {
    			?>
    	        <li>
    	            <a href="<?php echo $value['link']; ?>" target="_blank" class="ceo-height-1-1 ceo-cover-container ceo-display-block">
    	            	<img src="<?php echo $value['img']; ?>" alt="<?php echo $value['title']; ?>" ceo-cover />
    	            </a>
    	        </li>
    	        <?php } } ?>
    	    </ul>
    	    <a class="ceo-position-center-left ceo-position-small ceo-hidden-hover" href="#" ceo-slidenav-previous ceo-slideshow-item="previous"></a>
    	    <a class="ceo-position-center-right ceo-position-small ceo-hidden-hover" href="#" ceo-slidenav-next ceo-slideshow-item="next"></a>
    	    <ul class="slide_dotnav ceo-position-bottom-center ceo-slideshow-nav ceo-dotnav"></ul>
    	</div>
    </div>
    <?php } ?>
<?php }else { ?>
	<?php 
        $article_slide2 = _ceo('article_slide2'); 
        if(!$article_slide2){ 
    ?>
    <div class="ceo-container ceo-margin-bottom">
    	<div class="ceo-alert-primary" ceo-alert>
    		<a class="ceo-alert-close" ceo-close></a>
    		<p class="ceo-text-small"><i class="ceofont ceoicon-alert-fill ceo-margin-small-right"></i>请前往后台<i class="ceofont ceoicon-arrow-right-s-line"></i>主题设置<i class="ceofont ceoicon-arrow-right-s-line"></i>首页设置<i class="ceofont ceoicon-arrow-right-s-line"></i>首页文章布局-幻灯模块<i class="ceofont ceoicon-arrow-right-s-line"></i><b>幻灯样式2设置</b>，设置该模块内容！</p>
    	</div>
    </div>
    <?php }else { ?>
    <div class="ceo-article-slide2 b-a ceo-background-default ceo-margin-bottom">
	    <div class="ceo-grid-small" ceo-grid>
	        <div class="ceo-width-1-1 ceo-width-3-4@s">
        		<div class="ceo-position-relative ceo-visible-toggle" tabindex="-1" ceo-slideshow="autoplay: true">
        		    <ul class="ceo-slideshow-items">
        		    	<?php 
        				if ($article_slide2) { 
        					foreach ( $article_slide2 as $key => $value) {
        				?>
        		        <li>
        		            <a href="<?php echo $value['link']; ?>" target="_blank" class="ceo-cover-container ceo-display-block ceo-height-1-1">
        		            	<img src="<?php echo $value['img']; ?>" alt="<?php echo $value['title']; ?>" ceo-cover>
        		            </a>
        		        </li>
        		        <?php } } ?>
        		    </ul>
        		    <a class="ceo-position-center-left ceo-position-small ceo-hidden-hover" href="#" ceo-slidenav-previous ceo-slideshow-item="previous"></a>
            	    <a class="ceo-position-center-right ceo-position-small ceo-hidden-hover" href="#" ceo-slidenav-next ceo-slideshow-item="next"></a>
            	    <ul class="slide_dotnav ceo-position-bottom-center ceo-slideshow-nav ceo-dotnav"></ul>
        		</div>
    		</div>
    		<div class="slide-02-img ceo-width-1-1 ceo-width-1-4@s">
    		    <div class="ceo-grid-small" ceo-grid>
    		        <div class="ceo-width-1-2 ceo-width-1-1@s">
            		    <a href="<?php if(_ceo('simg_01'))echo _ceo('simg_01')['simg_01_link']; ?>" target="_blank" class="ceo-display-block ceo-cover-container">
                    	    <img src="<?php if(_ceo('simg_01'))echo _ceo('simg_01')['simg_01_img']; ?>" alt="<?php if(_ceo('simg_01'))echo _ceo('simg_01')['simg_01_title']; ?>" ceo-cover>
                    	    <?php if(_ceo('simg_tia') == true ): ?>
                    	    <span class="overlay ceo-overlay-primary ceo-position-bottom">
                                <p class="ceo-text-truncate"><?php if(_ceo('simg_01'))echo _ceo('simg_01')['simg_01_title']; ?></p>
                            </span>
                            <?php endif; ?>
                    	</a>
                    </div>
                	<div class="ceo-width-1-2 ceo-width-1-1@s">
                    	<a href="<?php if(_ceo('simg_02'))echo _ceo('simg_02')['simg_02_link']; ?>" target="_blank" class="ceo-display-block ceo-cover-container">
                    	    <img src="<?php if(_ceo('simg_02'))echo _ceo('simg_02')['simg_02_img']; ?>" alt="<?php if(_ceo('simg_02'))echo _ceo('simg_02')['simg_02_title']; ?>" ceo-cover>
                    	    <?php if(_ceo('simg_tia') == true ): ?>
                    	    <span class="overlay ceo-overlay-primary ceo-position-bottom">
                                <p class="ceo-text-truncate"><?php if(_ceo('simg_02'))echo _ceo('simg_02')['simg_02_title']; ?></p>
                            </span>
                            <?php endif; ?>
                    	</a>
                    </div>
            	</div>
    		</div>
		</div>
    </div>
    <?php } ?>	
<?php } ?>