<!--文章布局首页专题模块-->
<div class="ceo-article-special ceo-background-default b-a ceo-margin-bottom">
    <?php if(_ceo('ceo_article_special_tia') == true ): ?>
    <div class="title ceo-flex">
    	<span class="ceo-flex-1"><?php echo _ceo('ceo_article_special_title') ?><em class="ceo-visible@s"><?php echo _ceo('ceo_article_special_subtitle') ?></em></span>
        <a href="<?php echo _ceo('ceo_article_special_url'); ?>" target="_blank"><i class="ceofont ceoicon-more-line"></i></a>
    </div>
    <?php endif; ?>
    <div class="ceo-article-special-box">
        <div class="ceo-grid-small" ceo-grid>
            <?php
        		$args=array(
        			'taxonomy' => 'special',
        			'hide_empty'=>'0',
        			'hierarchical'=>1,
        			'parent'=>'0',
        			'number'=>'4',
        		);
        		$categories=get_categories($args);
        		foreach($categories as $category){
        			$cat_id = $category->term_id;

                    $backgroud_img = '';
                    $cate_background_img_arrs = get_term_meta($cat_id, 'cate_background_img', 1);
                    if ($cate_background_img_arrs && ! empty($cate_background_img_arrs['url'])) {
                        $backgroud_img = $cate_background_img_arrs['url'];
                    }
        	?>
            <div class="ceo-width-1-2 ceo-width-1-4@s">
                <div class="boxmk">
                	<a href="<?php echo get_category_link( $category->term_id )?>" target="_blank" class="ceo-display-block ceo-cover-container">
                	    <img src="<?php echo $backgroud_img; ?>" alt="<?php echo get_category_link( $category->term_id )?>" ceo-cover>
                	    <?php if(!$backgroud_img){?>
                		<img src="<?php echo _ceo('special-bg-mk'); ?>" alt="<?php echo get_category_link( $category->term_id )?>" ceo-cover/>
                        <?php }?>
                        <?php if(_ceo('ceo_article_special_ati') == true ): ?>
                        <div class="overlay ceo-overlay-primary ceo-position-bottom">
                            <p class="ceo-text-truncate"><?php echo $category->name;?></p>
                        </div>
                        <?php endif; ?>
                	</a>
                </div>
            </div>
            <?php }?>
        </div>
    </div>
</div>