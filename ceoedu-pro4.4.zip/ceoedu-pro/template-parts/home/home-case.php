<?php
    $case = _ceo('ceo_case_sz');
    $cat = $case['cat_id'];
?>
<!--首页案例模块-->
<div class="ceo-home-case" style="background: #141414 url(<?php echo _ceo('ceo_case_img') ?>) no-repeat;">
    <div class="ceo-container">
        <div class="ceo-home-title">
        	<h5><?php echo _ceo('ceo_case_title') ?></h5>
            <div class="ceo-home-title-lines">
                <i></i>
            </div>
            <p><?php echo _ceo('ceo_case_subtitle') ?></p>
        </div>
        
        <div class="ceo-home-case-box">
            <div class="ceo-position-relative ceo-visible-toggle ceo-light" tabindex="-1" ceo-slider="autoplay: true;autoplay-interval: 3000" >
            	<ul class="ceo-slider-items ceo-child-width-1-2 ceo-child-width-1-4@m ceo-grid">
            	    <?php 
        		        query_posts('cat='.$cat.'&showposts='.$case['num']);
        		        while (have_posts()) : the_post(); 
        		    ?>
            	    <li>
                    	<div class="ceo-home-case-boxpic">
                        	<a href="<?php the_permalink() ?>" <?php echo _target_blank();?> class="thumb ceo-display-block ceo-cover-container<?php echo $video?' ceo_video':'';?>">
                        		<?php if( _ceo('thumbnail_cj' ) == 'timthumb_php' ){?>
                        		<img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=160&w=290&zc=1" alt="<?php the_title(); ?>"/>
                        		<?php }elseif( _ceo('thumbnail_cj' ) == 'timthumb_theme' ){ ?>
                        		<img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" ceo-cover/>
                        		<?php }elseif( _ceo('thumbnail_cj' ) == 'timthumb_yun' ){ ?>
                        		<img src="<?php echo post_thumbnail_src(); ?><?php echo _ceo('thumbnail_yun_custom'); ?>,h_160,w_290" alt="<?php the_title(); ?>"/>
                        		<?php } ?>
                            </a>
                            <?php if(_ceo('ceo_cat_fl') == true ): ?>
                            <?php
                            	$category = get_the_category();
                            	if($category[0]){
                            		echo '<a class="ceo-case-category" target="_blank" href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';
                            	}
                            ?>
                            <?php endif; ?>
                        </div>
                        <div class="ceo-home-case-boxnew ceo-background-default">
                        	<a href="<?php the_permalink() ?>" <?php echo _target_blank();?> class="title" title="<?php the_title(); ?>"><?php the_title(); ?></a>
                            <div class="ceo-card-info info ceo-flex ceo-flex-middle ceo-text-small ceo-text-muted ceo-flex-middle ceo-text-truncate">
                                <?php if(_ceo('ceo_cat_tx') == true ): ?>
                                <div class="avatar ceo-border-circle ceo-overflow-hidden ceo-user-adminimg">
                        		<?php echo get_avatar(get_the_author_meta( 'ID' ), 20); ?>
                        		</div>
                        		<?php endif; ?>
                        		<?php if(_ceo('ceo_cat_mc') == true ): ?>
                        		<span class="ceo-text-small ceo-display-block ceo-user-admin"><?php the_author_posts_link(); ?></span>
                        		<?php endif; ?>
                        		<?php if(_ceo('ceo_cat_rq') == true ): ?>
                            	<span class="ceo-margin-ymd ceo-visible@s"><i class="ceofont ceoicon-calendar-2-line"></i><?php the_time('Y-m-d') ?></span>
                            	<?php endif; ?>
                            </div>
                            <p class="ceo-visible@s"><?php $tempContent = preg_replace("/<style.*?style>/s", '', apply_filters('the_content', $post->post_content)); echo mb_strimwidth(strip_tags($tempContent), 0, 60, '…'); ?></p>
                            <div class="ceo-home-case-boxnewbot ceo-flex">
                            	<a href="<?php the_permalink() ?>" target="_blank" class="ceo-flex-1">查看详情<i class="ceofont ceoicon-arrow-right-s-line"></i></a>
                                <span><i class="ceofont ceoicon-eye-line"></i><?php post_views('', ''); ?></span>
                            </div>
                        </div>
                    </li>
                    <?php endwhile; wp_reset_query(); ?>
                </ul>
                <a class="ceo-position-center-left ceo-position-small" href="#" ceo-slidenav-previous ceo-slider-item="previous"></a>
                <a class="ceo-position-center-right ceo-position-small" href="#" ceo-slidenav-next ceo-slider-item="next"></a>
            </div>
        </div>
        <div class="ceo-home-more">
            <a href="<?php echo get_category_link( $cat ); ?>" target="_blank">查看更多</a>
        </div>
    </div>
</div>