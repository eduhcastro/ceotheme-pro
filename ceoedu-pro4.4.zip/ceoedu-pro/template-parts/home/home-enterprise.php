<?php
$qiye= _ceo('ceo_qiye_sz');
?>
<!--首页企业模块-->
<div class="ceo-home-qiye ceo-background-default">
    <div class="ceo-container">
        <div class="ceo-home-title">
        	<h5><?php echo _ceo('ceo_qiye_title') ?></h5>
            <div class="ceo-home-title-lines">
                <i></i>
            </div>
            <p><?php echo _ceo('ceo_qiye_subtitle') ?></p>
        </div>
        <div class="ceo-grid-ceosmls" ceo-grid>
            <?php
    		if ($qiye) {
    			foreach ( $qiye as $key => $value) {
    		?>
            <div class="ceo-width-1-2 ceo-width-1-6@s">
                <div class="ceo-dongtai ceo-qiye-img">
                    <a href="<?php echo $qiye[$key]['url']; ?>" rel="nofollow" target="_blank">
                        <img src="<?php echo $qiye[$key]['img']; ?>" alt="<?php echo $qiye[$key]['title']; ?>">
                    </a>
                </div>
            </div>
            <?php } } ?>
        </div>
    </div>
</div>