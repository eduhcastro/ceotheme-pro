<?php
    $forumbox = _ceo('ceo_forum_box');
?>
<!--首页社区模块-->
<div class="ceo-home-forum ceo-background-default">
    <div class="ceo-container">
        <div class="ceo-home-title">
        	<h5><?php echo _ceo('ceo_forum_title') ?></h5>
            <div class="ceo-home-title-lines">
                <i></i>
            </div>
            <p><?php echo _ceo('ceo_forum_subtitle') ?></p>
        </div>
        
        <?php if(_ceo('ceo_forum_boxmk') == true ): ?>
        <!--推荐模块-->
        <div class="ceo-home-forum-tjbox ceo-overflow-hidden">
            <div class="ceo-position-relative ceo-visible-toggle" tabindex="-1" ceo-slider>
                <ul class="ceo-grid-ceosmls ceo-slider-items ceo-child-width-1-2 ceo-child-width-1-5@s" ceo-grid>
                    <?php
        				if ($forumbox) {
        					foreach ( $forumbox as $key => $value) {
        			?>
                    <li>
                        <div class="ceo-home-forum-tjboxmk">
                            <a href="<?php echo $value['link']; ?>" target="_blank">
                                <div class="tjboxmk-top">
                                    <img src="<?php echo $value['img']; ?>" alt="<?php echo $value['title']; ?>">
                                </div>
                                <div class="tjboxmk-btm">
                                    <h2><?php echo $value['title']; ?></h2>
                                    <span><?php echo $value['desc']; ?></span>
                                </div>
                                <p><?php echo $value['antitle']; ?></p>
                            </a>
                        </div>
                    </li>
                    <?php } } ?>
                </ul>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="ceo-home-forum-box">
            <div class="ceo-grid-ceosmls" ceo-grid>
                <!--问答模块-->
                <div class="ceo-width-1-1 ceo-width-1-2@s">
                    <div class="ceo-home-forum-box-question b-a ceo-background-default">
                        <div class="forum-box-title b-b ceo-flex">
                        	<span class="ceo-flex-1" style="background: url(<?php if(_ceo('ceo_forum_q_sz'))echo _ceo('ceo_forum_q_sz')['forum_q_img']; ?>) left center no-repeat;"><?php if(_ceo('ceo_forum_q_sz'))echo _ceo('ceo_forum_q_sz')['forum_q_title']; ?></span>
                            <a href="<?php if(_ceo('ceo_forum_q_sz'))echo _ceo('ceo_forum_q_sz')['forum_q_link']; ?>" target="_blank">More..</a>
                        </div>
                        <div class="forum-box-question-new">
                            <ul>
                                <?php
                                $_args = array(
                                    'post_type' => 'question',
                                    'paged' => get_query_var('paged', 1),
                                    'posts_per_page' => 5,
                                );
                                $postlist = new WP_Query( $_args );
                                ?>

                                <?php if ( $postlist->have_posts() ) { ?>
                                <?php
                                while ( $postlist->have_posts() ) : $postlist->the_post();
                                    $post_id = get_the_ID();
                                    $comments_number = get_comments_number( $post_id );
                                    $question_comment_num = get_question_comment_num($post_id);
                                    $xz = (!empty($question_comment_num)) ? ' xz' : '' ;
                                ?>

                                <li>
                                	<div class="tops ceo-flex">
                                    	<div class="tx ceo-flex-1">
                                        	<a href="/author/<?php echo the_author_meta( 'user_login' ); ?>" target="_blank">
                                                <?php echo get_avatar(get_the_author_meta( 'ID' ), 20); ?>
                                                <em><?php the_author(); ?></em>
                                            </a>
                                        </div>
                                        <div class="rq"><?php the_time('Y-m-d') ?></div>
                                    </div>
                                    <div class="bots ceo-flex">
                                    	<div class="ceo-flex-1 ceo-text-truncate">
                                            <a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a>
                                        </div>
                                        <span><?php echo $question_comment_num;?>个回答</span>
                                    </div>
                                </li>
                                <?php endwhile; } ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <!--论坛模块-->
                <div class="ceo-width-1-1 ceo-width-1-2@s">
                    <div class="ceo-home-forum-box-question b-a ceo-background-default">
                        <div class="forum-box-title b-b ceo-flex">
                        	<span class="ceo-flex-1" style="background: url(<?php if(_ceo('ceo_forum_f_sz'))echo _ceo('ceo_forum_f_sz')['forum_f_img']; ?>) left center no-repeat;"><?php if(_ceo('ceo_forum_f_sz'))echo _ceo('ceo_forum_f_sz')['forum_f_title']; ?></span>
                            <a href="<?php if(_ceo('ceo_forum_f_sz'))echo _ceo('ceo_forum_f_sz')['forum_f_link']; ?>" target="_blank">More..</a>
                        </div>
                        <div class="forum-box-question-new">
                            <ul>
                                <?php
                                $_args = array(
                                    'post_type' => 'forum',
                                    'paged' => get_query_var('paged', 1),
                                    'posts_per_page' => 5,
                                );
                                $postlist = new WP_Query( $_args );
                                ?>

                                <?php if ( $postlist->have_posts() ) { ?>
                                <?php
                                while ( $postlist->have_posts() ) : $postlist->the_post();
                                $post_id = get_the_ID();
                                ?>

                                <li>
                                    <div class="tops ceo-flex">
                                        <div class="tx ceo-flex-1">
                                            <a href="/author/<?php echo the_author_meta( 'user_login' ); ?>" target="_blank">
                                                <?php echo get_avatar(get_the_author_meta( 'ID' ), 20); ?>
                                                <em><?php the_author(); ?></em>
                                            </a>
                                        </div>
                                        <div class="rq"><?php the_time('Y-m-d') ?></div>
                                    </div>
                                    <div class="bots ceo-flex">
                                        <div class="ceo-flex-1 ceo-text-truncate">
                                            <a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a>
                                        </div>
                                        <span><?php post_views('', ''); ?>次浏览</span>
                                    </div>
                                </li>
                                <?php endwhile; } ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>