<?php
	$infinite = _ceo('infinite');
?>
<?php
	if ($infinite) {
		foreach ( $infinite as $key => $value) {
?>
<!--首页分类切换模块-->
<div class="ceo-home-switch ceo-background-default">
    <div class="ceo-container">
        <div class="ceo-home-title">
        	<h5>
        	<?php
				if(!$value['title']){
					echo get_cat_name( $value['id'] );
				}else {
					echo $value['title'];
				}
			?>
			</h5>
            <div class="ceo-home-title-lines">
                <i></i>
            </div>
            <p><?php echo $infinite[$key]['subtitle']; ?></p>
        </div>
        
        <div class="shop">
            <div class="ajaxMain ceo-grid-ceosmls" ceo-grid>
                <?php query_posts('cat='.$value['id'] .'&showposts='.$value['num'] ); ?>
			    <?php while (have_posts()) : the_post(); ?>
            	<div class="ajaxItem ceo-width-1-2 ceo-width-1-4@s">
            	<?php get_template_part( 'template-parts/loop/loop', 'shop' ); ?>
            	</div>
            	<?php endwhile; wp_reset_query(); ?>
        	</div>
        </div>
        
        <div class="ceo-home-more">
            <a href="<?php echo get_category_link($value['id']); ?>" target="_blank">查看更多</a>
        </div>
    </div>
</div>
<?php } } ?>