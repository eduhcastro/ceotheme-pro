<?php
$only = _ceo('ceo_news_only');
if($only){
?>
<!--首页新闻资讯模块-->
<div class="ceo-home-news">
    <div class="ceo-container">
        <div class="ceo-home-title">
        	<h5><?php echo _ceo('ceo_news_title') ?></h5>
            <div class="ceo-home-title-lines">
                <i></i>
            </div>
            <p><?php echo _ceo('ceo_news_subtitle') ?></p>
        </div>
        
        <div class="ceo-home-news-box">
            <div class="ceo-grid-ceosmls" ceo-grid>
                <?php
                if ($only) {
                foreach ( $only as $key => $value) {
                    if(!$value['id']){
                        continue;
                    }
                ?>
            	<ul class="ceo-width-1-1 ceo-width-1-3@s">
            	    <div class="ceo-background-default b-r-4 b-a ceo-padding-small">
                	    <div class="ceo-home-news-boxtop" style="background-image: url(<?php echo esc_url( $value['img'] ); ?>)">
                        	<a href="<?php echo get_category_link( $value['id'] ); ?>" target="_blank"><?php echo get_cat_name($value['id']) ?></a>
                        </div>
                        <?php query_posts('cat='.$value['id'] .'&showposts='.$value['num'] ); ?>
                        <?php while (have_posts()) : the_post(); ?>
                        <li>
                            <div class="ceo-flex">
                            	<a href="<?php echo get_permalink();?>" title="<?php echo get_the_title();?>" target="_blank" class="ceo-flex-1 ceo-text-truncate"><i class="ceofont ceoicon-file-copy-2-line"></i><?php echo get_the_title();?></a>
                                <span><?php the_time('Y-m-d') ?></span>
                            </div>
                        </li>
                        <?php endwhile; wp_reset_query(); ?>
                    </div>
                </ul>
                <?php } } ?>
            </div>
        </div>
    </div>
</div>
<?php }?>