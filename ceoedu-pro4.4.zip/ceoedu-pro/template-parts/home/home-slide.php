<?php
    $slide = _ceo('slide');
    $slidecms = _ceo('slide_cms');
    $app_zcd = _ceo('ceo_app_zcd_sz');
    $app_cms = _ceo('ceo_app_cms_sz');
?>
<div class="ceo-home-slide slide_01">
    <div class="slide b-r-4 ceo-position-relative ceo-visible-toggle" tabindex="-1" ceo-slideshow="autoplay: true">
	    <ul class="ceo-slideshow-items">
	    	<?php
				if ($slide) {
					foreach ( $slide as $key => $value) {
			?>
	        <li>
	            <a href="<?php echo $value['url']; ?>" target="_blank" class="ceo-height-1-1 ceo-cover-container ceo-display-block">
	            	<img src="<?php echo $value['img']; ?>" alt="<?php echo $value['title']; ?>" ceo-cover />
	            </a>
	        </li>
	        <?php } } ?>
	    </ul>
	    <a class="ceo-position-center-left ceo-position-small" href="#" ceo-slidenav-previous ceo-slideshow-item="previous"></a>
	    <a class="ceo-position-center-right ceo-position-small" href="#" ceo-slidenav-next ceo-slideshow-item="next"></a>
	    <ul class="slide_dotnav ceo-position-bottom-center ceo-slideshow-nav ceo-dotnav"></ul>
	</div>
</div>

<?php if(_ceo('slide_cmsmk') == true ): ?>
<div class="ceo-home-cms ceo-background-default ceo-visible@s">
    <div class="ceo-home-cmsbox">
        <div class="ceo-container">
            <div class="ceo-grid-ceosmls" ceo-grid>
                <?php
    				if ($slidecms) {
    					foreach ( $slidecms as $key => $value) {
    			?>
                <div class="ceo-width-1-5">
                    <a href="<?php echo $value['link']; ?>" target="_blank" class="ceo-home-cms-boxa">
                        <div class="ceo-grid-ceosmls" ceo-grid>
                            <div class="ceo-width-auto">
                                <img src="<?php echo $value['img']; ?>"/>
                            </div>
                            <div class="ceo-width-expand">
                                <span><?php echo $value['title']; ?></span>
                                <p><?php echo $value['desc']; ?></p>
                            </div>
                        </div>
                    </a>
                </div>
                <?php } } ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if(_ceo('ceo_app_zcd') == true ): ?>
<div class="ceo-app-icobox ceo-background-default ceo-hidden@s">
    <div class="ceo-grid-ceosmls" ceo-grid>
        <?php
			if ($app_zcd) {
				foreach ( $app_zcd as $key => $value) {
		?>
        <div class="ceo-width-1-4">
            <a href="<?php echo $value['link']; ?>">
                <img src="<?php echo $value['img']; ?>"/>
                <p><?php echo $value['title']; ?></p>
            </a>
        </div>
        <?php } } ?>
    </div>
</div>
<?php endif; ?>

<?php if(_ceo('ceo_app_cms') == true ): ?>
<div class="ceo-app-mkbox ceo-background-default ceo-hidden@s">
    <div class="ceo-container">
        <div class="ceo-grid-small" ceo-grid>
            <?php
				if ($app_cms) {
					foreach ( $app_cms as $key => $value) {
			?>
            <div class="ceo-width-1-2">
                <div class="ceo-app-mkbox-z" style="background: <?php echo $value['style']; ?>;">
                    <a href="<?php echo $value['link']; ?>">
                        <div class="ceo-flex">
                            <span class="ceo-flex-1"><?php echo $value['title']; ?></span>
                            <i class="ceofont ceoicon-arrow-right-circle-line"></i>
                        </div>
                        <p><?php echo $value['subtitle']; ?></p>
                    </a>
                </div>
            </div>
            <?php } } ?>
        </div>
    </div>
</div>
<?php endif; ?>