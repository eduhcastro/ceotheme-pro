<!--首页专题模块-->
<div class="ceo-home-special ceo-background-default">
    <div class="ceo-container">
        <div class="ceo-home-title">
        	<h5><?php echo _ceo('ceo_special_title') ?></h5>
            <div class="ceo-home-title-lines">
                <i></i>
            </div>
            <p><?php echo _ceo('ceo_special_subtitle') ?></p>
        </div>

        <div class="ceo-home-special-box">
            <div class="ceo-grid-ceosmls" ceo-grid>
                <?php
            		$args=array(
            			'taxonomy' => 'special',
            			'hide_empty'=>'0',
            			'hierarchical'=>1,
            			'parent'=>'0',
            			'number'=>'4',
            		);
            		$categories=get_categories($args);
            		foreach($categories as $category){
            			$cat_id = $category->term_id;

                        $backgroud_img = '';
                        $cate_background_img_arrs = get_term_meta($cat_id, 'cate_background_img', 1);
                        if ($cate_background_img_arrs && ! empty($cate_background_img_arrs['url'])) {
                            $backgroud_img = $cate_background_img_arrs['url'];
                        }
            	?>
                <div class="ceo-width-1-2 ceo-width-1-4@s">
                    <div class="ceo-home-special-boxmk">
                        <div class="ceo-home-special-boxmkimg">
                        	<a href="<?php echo get_category_link( $category->term_id )?>" target="_blank" class="ceo-display-block ceo-cover-container">
                        	    <img src="<?php echo $backgroud_img; ?>" ceo-cover>
                        	    <?php if(!$backgroud_img){?>
                        		<img src="<?php echo _ceo('special-bg-mk'); ?>" ceo-cover/>
                                <?php }?>
                        	</a>
                    	</div>
                        <div class="ceo-home-special-boxmktext">
                            <div class="box">
                                <div class="title">
                                    <a href="<?php echo get_category_link( $category->term_id )?>" target="_blank"><?php echo $category->name;?></a>
                                </div>
                                <div class="desc">
                                    <p><?php echo $category->description;?></p>
                                </div>
                                <div class="btns">
                                    <div class="ceo-grid-ceosmls" ceo-grid>
                                        <div class="ceo-width-1-2@s ceo-visible@s">
                                            <a href="<?php echo _ceo('special-an-link'); ?>" target="_blank"><i class="ceofont ceoicon-add-line"></i><?php echo _ceo('special-an-text'); ?></a>
                                        </div>
                                        <div class="ceo-width-1-1 ceo-width-1-2@s">
                                            <a href="<?php echo get_category_link( $category->term_id )?>" target="_blank"><i class="ceofont ceoicon-eye-line"></i>查看专题</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php }?>
            </div>
        </div>
        <div class="ceo-home-more">
            <a href="<?php echo _ceo('ceo_special_url'); ?>" target="_blank">查看更多</a>
        </div>
    </div>
</div>