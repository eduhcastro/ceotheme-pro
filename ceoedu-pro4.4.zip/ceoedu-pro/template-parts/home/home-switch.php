<!--首页分类切换模块-->
<div class="ceo-home-switch ceo-background-default">
    <div class="ceo-container">
        <div class="ceo-home-title">
        	<h5><?php echo _ceo('switch_title'); ?></h5>
            <div class="ceo-home-title-lines">
                <i></i>
            </div>
            <p><?php echo _ceo('switch_subtitle'); ?></p>
        </div>
		<ul class="ceo-subnav-pill ceo-switch-title" ceo-switcher="animation: ceo-animation-fade">
		    <li><a href="#"><?php echo _ceo('switch_antitle'); ?></a></li>
		    <?php
            $cat_arrs   = _ceo('switch_title_cat');
            if(empty($cat_arrs)){
                $cat_arrs=[];
            }
            foreach ($cat_arrs as $v) {
                $term_v = get_term($v);
            ?>
            <li><a href="#"><?php echo $term_v->name; ?></a></li>
            <?php }?>
        </ul>

        <ul class="ceo-switcher ceo-margin">
            <li>
    		    <div class="shop">
    			    <div class="ceo-grid-ceosmls" ceo-grid>
                        <?php
                        global $wp_query;
                        $cat_arrs   = _ceo('switch_title_cat');
                        if(empty($cat_arrs)){
                            $cat_arrs=[];
                        }
                        $wp_query = new WP_Query(
                            array(
                                'post_type' => 'post',
                                'post_status' => 'publish',
                                'order' => 'DESC',
                                'orderby' => 'date',
                                'posts_per_page' => 8,
                                'cat'=>(array) _ceo('newest_content_cat')
                            )
                        );
                        if ( have_posts() ) :  while ( have_posts() ) : the_post(); ?>
                        <div class="ceo-width-1-2 ceo-width-1-4@s">
                            <?php get_template_part( 'template-parts/loop/loop', 'shop' ); ?>
                        </div>
                        <?php endwhile;endif; ?>
                    </div>
                </div>
                <div class="ceo-home-more">
                    <a href="<?php echo _ceo('switch_anlink'); ?>" target="_blank">查看更多</a>
                </div>
            </li>

            <?php
            $cat_arrs   = _ceo('switch_title_cat');
            if(empty($cat_arrs)){
                $cat_arrs=[];
            }
            foreach ($cat_arrs as $v) {
            $term_v = get_term($v);
            ?>
            <li>
                <div class="shop">
    			    <div class="ceo-grid-ceosmls" ceo-grid>
                        <?php
                        global $wp_query;
                        $wp_query = new WP_Query(
                            array(
                                'cat' => $term_v->term_id,
                                'post_type' => 'post',
                                'post_status' => 'publish',
                                'order' => 'DESC',
                                'orderby' => 'date',
                                'posts_per_page' => 8,
                            )
                        );
                        if ( have_posts() ) :  while ( have_posts() ) : the_post(); ?>
                        <div class="ceo-width-1-2 ceo-width-1-4@s">
                            <?php get_template_part( 'template-parts/loop/loop', 'shop' ); ?>
                        </div>
                        <?php endwhile;endif; ?>
                    </div>
                </div>
                <div class="ceo-home-more">
                    <a href="<?php echo get_term_link($term_v->term_id) ?>" target="_blank">查看更多</a>
                </div>
            </li>
            <?php }?>
        </ul>
    </div>
</div>