<!--首页用户模块-->
<div class="ceo-home-user">
    <div class="ceo-container">
        <div class="ceo-home-title">
        	<h5><?php echo _ceo('ceo_user_title') ?></h5>
            <div class="ceo-home-title-lines">
                <i></i>
            </div>
            <p><?php echo _ceo('ceo_user_subtitle') ?></p>
        </div>

        <div class="ceo-home-user-box">
            <div class="ceo-grid-ceosmls" ceo-grid>
                <?php
                $args_user = array("number" => 6);
                $user_list_sort_post_count = get_users_by_post_count(  );

                foreach ($user_list_sort_post_count  as $k=>$user_v){
                    $v=get_userdata($user_v->ID);
                    if($k>5){
                        break;
                    }
                ?>
                <div class="ceo-width-1-2 ceo-width-1-6@s">
                    <div class="b-a">
                        <div class="ceo-home-user-boxmk">
                            <div class="ceo-home-user-boxmkimg">
                            	<a href="/author/<?php echo the_author_meta( 'user_login',$v->ID ); ?>" target="_blank" class="ceo-display-block">
                                    <?php echo get_avatar( $v->ID , 185 ); ?>
                            	</a>
                        	</div>
                            <div class="ceo-home-user-boxmktext">
                                <div class="box">
                                    <div class="title">
                                        <a href="/author/<?php echo the_author_meta( 'user_login',$v->ID ); ?>" target="_blank"><?php echo $v->display_name;?></a>
                                        <p>
                                            <?php if(user_can($v->ID,'author') || user_can($v->ID,'editor') || user_can($v->ID,'administrator')){ ?>
                                                认证作者
                                            <?php }else{
                                                echo '普通用户';
                                            } ?>
                                        </p>
                                    </div>
                                    <div class="desc">
                                        <p>
                                            <?php
                                            $description = $v->description;
                                            if(empty($description)){
                                                $description='这家伙很懒，只想把你留下。';
                                            }
                                            echo $description;
                                            ?>
                                        </p>
                                    </div>
                                    <div class="btns">
                                        <a href="/author/<?php echo the_author_meta( 'user_login',$v->ID ); ?>" target="_blank"><i class="ceofont ceoicon-user-add-line"></i>Ta的主页</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php }?>
            </div>
        </div>
        <div class="ceo-home-more">
            <a href="<?php echo _ceo('ceo_user_url'); ?>" target="_blank">查看更多</a>
        </div>
    </div>
</div>