<?php
    $video = get_post_meta( $post->ID, 'ceo_video', true );
?>
<div class="item b-b ajaxItem ceo-background-default">
	<div class="ceo-grid-ceosmls" ceo-grid>
		<div class="ceo-width-auto ceo-blog-mks">
			<a href="<?php the_permalink(); ?>" <?php echo _target_blank();?> class="thumb ceo-display-block ceo-cover-container<?php echo $video?' ceo_video':'';?>">
			    <?php if( _ceo('thumbnail_cj' ) == 'timthumb_php' ){?>
        		<img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=130&w=210&zc=1" alt="<?php the_title(); ?>"/>
        		<?php }elseif( _ceo('thumbnail_cj' ) == 'timthumb_theme' ){ ?>
        		<img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" ceo-cover/>
        		<?php }elseif( _ceo('thumbnail_cj' ) == 'timthumb_yun' ){ ?>
        		<img src="<?php echo post_thumbnail_src(); ?><?php echo _ceo('thumbnail_yun_custom'); ?>,h_130,w_210" alt="<?php the_title(); ?>"/>
        		<?php } ?>
			</a>
		</div>
		<div class="ceo-overflow-hidden ceo-width-expand info-box">
			<a href="<?php the_permalink(); ?>" <?php echo _target_blank();?> class="title ceo-display-block" title="<?php the_title(); ?>">
    		    <?php if (is_sticky()): //置顶文章 ?>
    		    <div class="ceo-title-dd">顶</div>
                <?php endif; ?>
                <?php if(get_post_meta( get_the_ID(), 'ceo-tese-tag', true )){?>
    		    <div class="ceo-title-dd">
    		        <?php echo get_post_meta( get_the_ID(), 'ceo-tese-tag', true );?>
    		    </div>
    		    <?php }?>
                <?php the_title(); ?>
            </a>
			<div class="desc ceo-text-muted ceo-text-small ceo-visible@s"><?php $tempContent = preg_replace("/<style.*?style>/s", '', apply_filters('the_content', $post->post_content)); echo mb_strimwidth(strip_tags($tempContent), 0, 60, '…'); ?></div>
			<?php get_template_part( 'template-parts/module/item', 'info' ); ?>
		</div>
	</div>
</div>