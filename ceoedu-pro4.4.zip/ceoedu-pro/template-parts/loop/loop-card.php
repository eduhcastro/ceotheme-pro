<?php



$post_id =  get_the_ID();
$video = get_post_meta($post->ID, 'ceo_video', true);
?>
<div class="item b-a ceo-overflow-hidden ceo-background-default ceo-dongtai">
	<div class="card-boxpic">
		<?php if (_ceo('ceo_cat_fl') == true) : ?>
			<?php
			$category = get_the_category();
			if ($category[0]) {
				echo '<a class="card-category ceo-visible@s" target="_blank" href="' . get_category_link($category[0]->term_id) . '">' . $category[0]->cat_name . '</a>';
			}
			?>
		<?php endif; ?>
		<a href="<?php the_permalink() ?>" <?php echo _target_blank(); ?> class="thumb ceo-display-block ceo-cover-container<?php echo $video ? ' ceo_video' : ''; ?>">
			<?php if (_ceo('thumbnail_cj') == 'timthumb_php') { ?>
				<img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=160&w=288&zc=1" alt="<?php the_title(); ?>" />
			<?php } elseif (_ceo('thumbnail_cj') == 'timthumb_theme') { ?>
				<img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" ceo-cover />
			<?php } elseif (_ceo('thumbnail_cj') == 'timthumb_yun') { ?>
				<img src="<?php echo post_thumbnail_src(); ?><?php echo _ceo('thumbnail_yun_custom'); ?>,h_160,w_288" alt="<?php the_title(); ?>" />
			<?php } ?>
		</a>
	</div>
	<div class="card-boxnew ceo-background-default">
		<a href="<?php the_permalink() ?>" <?php echo _target_blank(); ?> class="title" title="<?php the_title(); ?>"><?php the_title(); ?></a>
		<div class="ceo-card-info info ceo-flex ceo-flex-middle ceo-text-small ceo-text-muted ceo-flex-middle ceo-text-truncate">
			<?php if (_ceo('ceo_cat_tx') == true) : ?>
				<div class="avatar ceo-border-circle ceo-overflow-hidden ceo-user-adminimg">
					<?php echo get_avatar(get_the_author_meta('ID'), 20); ?>
				</div>
			<?php endif; ?>
			<?php if (_ceo('ceo_cat_mc') == true) : ?>
				<span class="ceo-text-small ceo-display-block ceo-user-admin"><?php the_author_posts_link(); ?></span>
			<?php endif; ?>
			<?php if (_ceo('ceo_cat_rq') == true) : ?>
				<span class="ceo-margin-ymd ceo-visible@s"><i class="ceofont ceoicon-calendar-2-line"></i><?php the_time('Y-m-d') ?></span>
			<?php endif; ?>
		</div>
		<p class="ceo-visible@s"><?php $tempContent = preg_replace("/<style.*?style>/s", '', apply_filters('the_content', $post->post_content)); echo mb_strimwidth(strip_tags($tempContent), 0, 60, '…'); ?></p>
		<div class="card-boxnewbot ceo-flex">
			<a href="<?php the_permalink() ?>" target="_blank" class="ceo-flex-1">查看详情<i class="ceofont ceoicon-arrow-right-s-line"></i></a>
			<span><i class="ceofont ceoicon-eye-line"></i><?php post_views('', ''); ?></span>
			<?php if (_ceo('ceo_cat_jg') == true && _ceo('ceo_shop_whole')) : ?>
				<?php if (get_current_user_id() > 0 || _ceo('ceo_shop_tourist')) : ?>
					<span class="ceo_shop_loop_jg"><?php echo CeoShopCoreProduct::getPriceFormat($post_id, true, true) ?></span>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	</div>
</div>