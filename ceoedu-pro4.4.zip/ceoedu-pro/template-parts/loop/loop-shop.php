<?php



$post_id =  get_the_ID();
?>
<div class="item ceo-background-default ceo-overflow-hidden ceo-vip-icons">
    <?php if (is_sticky()) : //置顶文章 
    ?>
        <div class="ceo-title-dd" ceo-tooltip="置顶推荐"></div>
    <?php endif; ?>
    <div class="ceo-loop-shop">
        <div class="ceo_app_img">
            <a href="<?php the_permalink() ?>" <?php echo _target_blank(); ?> class="thumb ceo-display-block ceo-cover-container">
                <?php if (_ceo('thumbnail_cj') == 'timthumb_php') { ?>
                    <img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=180&w=290&zc=1" alt="<?php the_title(); ?>" />
                <?php } elseif (_ceo('thumbnail_cj') == 'timthumb_theme') { ?>
                    <img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" ceo-cover />
                <?php } elseif (_ceo('thumbnail_cj') == 'timthumb_yun') { ?>
                    <img src="<?php echo post_thumbnail_src(); ?><?php echo _ceo('thumbnail_yun_custom'); ?>,h_180,w_290" alt="<?php the_title(); ?>" />
                <?php } ?>
            </a>
            <?php if (_ceo('ceo_cat_viptb') == true && _ceo('ceo_shop_whole') && CeoShopCoreProduct::hasVipFree($post_id)) : ?>
                <?php if (get_current_user_id() > 0 || _ceo('ceo_shop_tourist')) : ?>
                    <span class="ceo_shop_vip"></span>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <div class="ceo-loop-shop-text">
            <div class="box">
                <div class="ceo-loop-shop-text-title">
                    <a href="<?php the_permalink() ?>" <?php echo _target_blank(); ?> class="title" title="<?php the_title(); ?>">
                        <?php if (get_post_meta(get_the_ID(), 'ceo-tese-tag', true)) { ?>
                            <div class="ceo-title-ts ceo-visible@s">
                                <?php echo get_post_meta(get_the_ID(), 'ceo-tese-tag', true); ?>
                            </div>
                        <?php } ?>
                        <?php the_title(); ?>
                    </a>
                </div>
                <div class="ceo-loop-shop-text-subtitle">
                    <div class="ceo-flex">
                        <div class="ceo-loop-shop-text-subtitle-author ceo-flex-1">
                            <?php if (_ceo('ceo_cat_fl') == true) : ?>
                                <?php
                                $category = get_the_category();
                                if ($category[0]) {
                                    echo '<a class="ceo_shop_category" target="_blank" href="' . get_category_link($category[0]->term_id) . '"><i class="ceofont ceoicon-apps-2-line"></i>' . $category[0]->cat_name . '</a>';
                                }
                                ?>
                            <?php endif; ?>
                        </div>
                        <?php if (_ceo('ceo_cat_rq') == true) : ?>
                            <div class="ceo-loop-shop-text-subtitle-keshi ceo-visible@s">
                                <?php the_time('Y-m-d') ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="ceo-loop-shop-text-desc">
                    <p><?php $tempContent = preg_replace("/<style.*?style>/s", '', apply_filters('the_content', $post->post_content)); echo mb_strimwidth(strip_tags($tempContent), 0, 94, '…'); ?></p>
                </div>
                <div class="info ceo-flex ceo-flex-middle ceo-text-small ceo-text-muted ceo-flex-middle ceo-text-truncate">
                    <?php if (_ceo('ceo_cat_tx') == true) : ?>
                        <div class="<?php if (wp_is_mobile()) { ?>ceo-flex-1<?php } ?>">
                            <div class="avatar ceo-border-circle ceo-overflow-hidden ceo-user-adminimg">
                                <?php echo get_avatar(get_the_author_meta('ID'), 20); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if (_ceo('ceo_cat_mc') == true) : ?>
                        <span class="ceo-text-small ceo-display-block ceo-flex-1 ceo-user-admin ceo-visible@s"><?php the_author_posts_link(); ?></span>
                    <?php endif; ?>
                    <?php if (_ceo('ceo_cat_ll') == true) : ?>
                        <span class="ceo-visible@s"><i class="ceofont ceoicon-eye-line"></i><?php post_views('', ''); ?></span>
                    <?php endif; ?>
                    <?php if (_ceo('ceo_cat_jg') == true && _ceo('ceo_shop_whole')) : ?>
                        <?php if (get_current_user_id() > 0 || _ceo('ceo_shop_tourist')) : ?>
                            <span class="ceo_shop_loop_jg"><?php echo CeoShopCoreProduct::getPriceFormat($post_id, true, true) ?></span>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>