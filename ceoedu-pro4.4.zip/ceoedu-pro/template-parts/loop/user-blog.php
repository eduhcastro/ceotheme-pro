<?php



$post_id =  get_the_ID();
$video = get_post_meta($post->ID, 'ceo_video', true);
?>
<div class="item b-b ajaxItem">
	<div class="ceo-grid-ceosmls" ceo-grid>
		<div class="ceo-width-auto ceo-blog-mks">
			<a href="<?php the_permalink(); ?>" <?php echo _target_blank(); ?> class="thumb ceo-display-block ceo-cover-container<?php echo $video ? ' ceo_video' : ''; ?>">
				<?php if (_ceo('thumbnail_cj') == 'timthumb_php') { ?>
					<img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=130&w=210&zc=1" alt="<?php the_title(); ?>" />
				<?php } elseif (_ceo('thumbnail_cj') == 'timthumb_theme') { ?>
					<img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" ceo-cover />
				<?php } elseif (_ceo('thumbnail_cj') == 'timthumb_yun') { ?>
					<img src="<?php echo post_thumbnail_src(); ?><?php echo _ceo('thumbnail_yun_custom'); ?>,h_130,w_210" alt="<?php the_title(); ?>" />
				<?php } ?>
			</a>
		</div>
		<div class="ceo-overflow-hidden ceo-width-expand info-box">
			<a href="<?php the_permalink(); ?>" <?php echo _target_blank(); ?> class="title ceo-display-block" title="<?php the_title(); ?>">
				<?php if (is_sticky()) : //置顶文章 
				?>
					<div class="ceo-title-dd">顶</div>
				<?php endif; ?>
				<?php if (get_post_meta(get_the_ID(), 'ceo-tese-tag', true)) { ?>
					<div class="ceo-title-dd">
						<i class="ceofont ceoicon-hashtag"></i><?php echo get_post_meta(get_the_ID(), 'ceo-tese-tag', true); ?>
					</div>
				<?php } ?>
				<?php the_title(); ?>
			</a>
			<div class="desc ceo-text-muted ceo-text-small ceo-visible@s"><?php echo wp_trim_words(get_the_content(), 70); ?></div>
			<div class="info-boxmk">
				<div class="info ceo-flex ceo-flex-middle ceo-text-small ceo-text-muted ceo-flex ceo-flex-middle ceo-text-truncate">
					<div class="ceo-flex-1 ceo-flex ceo-flex-middle">
						<?php if (_ceo('ceo_cat_tx') == true) : ?>
							<div class="avatar ceo-border-circle ceo-overflow-hidden ceo-user-adminimg">
								<?php echo get_avatar(get_the_author_meta('ID'), 20); ?>
							</div>
						<?php endif; ?>
						<?php if (_ceo('ceo_cat_mc') == true) : ?>
							<span class="ceo-text-small ceo-display-block ceo-user-admin"><?php the_author_posts_link(); ?></span>
						<?php endif; ?>
						<?php if (_ceo('ceo_cat_fl') == true) : ?>
							<?php
							$category = get_the_category();
							if ($category[0]) {
								echo '<a class="ceo_blog_category ceo-visible@s" target="_blank" href="' . get_category_link($category[0]->term_id) . '"><i class="ceofont ceoicon-apps-2-line"></i>' . $category[0]->cat_name . '</a>';
							}
							?>
						<?php endif; ?>
					</div>
					<div class="ceo-blog-info-y">
						<span class="ceo-visible@s"><a href="<?php echo home_url(user_trailingslashit('tougao')); ?>?post=<?php echo get_the_ID(); ?>&amp;action=edit"><i class="ceofont ceoicon-edit-2-line"></i> 编辑</a></span>

						<?php if (_ceo('ceo_cat_rq') == true) : ?>
							<span class="ceo-visible@s">日期：<?php the_time('Y-m-d') ?></span>
						<?php endif; ?>
						<?php if (_ceo('ceo_cat_dz') == true) : ?>
							<span class="ceo-visible@s">点赞：<?php echo ($dot_good = get_post_meta($post->ID, 'like', true)) ? $dot_good : '0'; ?></span>
						<?php endif; ?>
						<?php if (_ceo('ceo_cat_ll') == true) : ?>
							<span>阅读：<?php post_views('', ''); ?></span>
						<?php endif; ?>
						<?php if (_ceo('ceo_cat_jg') == true && _ceo('ceo_shop_whole')) : ?>
							<?php if (get_current_user_id() > 0 || _ceo('ceo_shop_tourist')) : ?>
								<span class="ceo_shop_loop_jg"><?php echo CeoShopCoreProduct::getPriceFormat($post_id, true, true) ?></span>
							<?php endif; ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>