<?php if(_ceo('navbar_top') == true): ?>
<?php get_template_part( 'template-parts/navbar/navbar', 'top' ); ?>
<?php endif; ?>
<header class="navBar_01 ceo-background-default ceo-sticky-fixed ceo-visible@s" <?php if(_ceo('navbar_sticky') == true): ?>ceo-sticky<?php endif; ?>>
	<div class="ceo-container ceo-flex ceo-flex-middle">
		<a href="<?php bloginfo('url'); ?>" class="ceo-logo-navBar_01 logo ceo-display-block">
			<img src="<?php echo _ceo('head_logo'); ?>" alt="<?php bloginfo('name'); ?>"/>
		</a>
		<div class="nav ceo-flex-1 ceo-visible@s">
		    <ul class="ceo-navbar-ul ceo-margin-remove ceo-padding-remove">
		        <?php ceo_menu('main-nav'); ?>
		    </ul>
		</div>
		
		<?php if(_ceo('navbar_search') == true): ?>
		<div class="search ceo-visible@s">
		    <form method="get" class="ceo-form ceo-flex ceo-overflow-hidden ceo-position-relative" action="<?php bloginfo('url'); ?>">
				<input type="search" placeholder="输入关键字搜索" autocomplete="off" value="" name="s" required="required" class="b-a b-r-4 ceo-input ceo-flex-1">
				<button type="submit" class="ceo-position-center-right"><i class="ceofont ceoicon-search-2-line"></i></button>
			</form>
		</div>
		<?php endif; ?>
		
		<?php if(_ceo('navbar_user') == true): ?>
		<div class="ceo-visible@s">
		    <?php get_template_part( 'template-parts/module/top', 'user' ); ?>
		</div>
		<?php endif; ?>
	</div>
</header>
<?php get_template_part( 'template-parts/navbar/navbar', 'app' ); ?>