<?php if ( wp_is_mobile() ){ ?>
<header class="ceo_app_navbar ceo-background-default ceo-hidden@s" <?php if(_ceo('navbar_sticky') == true): ?>ceo-sticky<?php endif; ?>>
	<div class="ceo-container ceo-flex ceo-flex-middle">
	    <a href="<?php bloginfo('url'); ?>" class="ceo-flex-1 logo ceo-display-block">
			<img src="<?php echo _ceo('head_logo'); ?>" alt="<?php bloginfo('name'); ?>"/>
		</a>
        <?php if(_ceo('navbar_search') == true): ?>
		<div class="search">
		    <a class="ceo-navbar-search-a" ceo-toggle="target: #mobSearch"><i class="ceofont ceoicon-search-2-line"></i></a>
		</div>
		<?php endif; ?>
		
		<?php if(_ceo('navbar_user') == true): ?>
        <?php get_template_part( 'template-parts/module/top', 'user' ); ?>
        <?php endif; ?>
	</div>
</header>
<!--导航弹窗-->
<div id="mobNav" ceo-offcanvas>
    <div class="ceo-offcanvas-bar ceo-background-default ceo-box-shadow-small ceo-mobNav-box">
        <div class="mobSide">
            <div class="ceo-text-center ceo-margin-small-bottom">
                <a href="<?php bloginfo('url'); ?>" class="logo ceo-display-inline-block ceo-margin-bottom">
                    <img src="<?php echo _ceo('head_logo'); ?>" alt="<?php bloginfo('name'); ?>"/>
                </a>
            </div>
            <div class="mobNav">
    		    <ul class="ceo-margin-remove ceo-padding-remove ceo-text-center">
    		        <?php ceo_menu('main-nav'); ?>
    		    </ul>
    		</div>
        </div>
    </div>
</div>
<?php } ?>