<div id="navbar-login" ceo-modal>
    <div class="ceo-modal-dialog ceo-modal-body ceo-navbar-login">
        <button class="ceo-modal-close-default ceo-modal-close" type="button" ceo-close></button>
        <div class="ceo-login-title">
            <a href="<?php bloginfo('url'); ?>">
                <img src="<?php echo _ceo('head_logo'); ?>" alt="<?php bloginfo('name'); ?>"/>
            </a>
            <p>Hi~欢迎登录 <?php bloginfo('name'); ?></p>
        </div>

		<?php if(_ceo('ceo_login_txt') == true): ?>
		<form action="" method="POST" id="login-form" class="login-weixin ceo-margin-medium-top ceo-margin-bottom">
		    <div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-user-line"></i></span>
			    <input type="text" id="username" class="b-r-4 ceo-input ceo-text-13px" name="username" placeholder="请输入您的用户名或邮箱账号" required="required">
			</div>
			<div class="ceo-inline ceo-width-1-1">
			    <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-keyhole-line"></i></span>
			    <input type="password" id="password" class="b-r-4 ceo-input ceo-text-13px" name="password" placeholder="请输入您的密码..." required="required">
			</div>

            <div class="ceotheme-tips ceo-margin ceo-text-danger"></div>
    		<div class="ceo-flex ceo-margin-bottom">
        		<p class="ceo-flex-1 ceo-text-muted ceo-text-13px">没有账号？<a href="#navbar-register" ceo-toggle>立即注册！</a></p>
                <p>
                </p>
        		<p class="ceo-text-muted ceo-text-13px"><a href="/wp-login.php?action=lostpassword">忘记密码？</a></p>
    		</div>
			<input type="hidden" name="action" value="zongcai_login">
			<button class="login-button b-r-4 ceo-width-1-1 button mid dark ceo-display-block">立即登录</button>
		</form>
		<?php endif; ?>
		<div class="ceo-login-social">
		    <div class="ceo-grid-ceosmls" ceo-grid>
		        <div class="ceo-width-1-1@s ceo-width-expand@m ceo-width-expand@l ceo-width-expand@xl">
		            <p class="ceo-flex-1 ceo-text-muted ceo-text-13px">社交账号登录</p>
	            </div>
	            <div class="ceo-width-1-1@s ceo-width-auto@m ceo-width-auto@l ceo-width-auto@xl bottom">
                    <?php if(_ceo('qq_login')){?>
                	<a href="javascript:;" class="button mid qq half qq_login_button ceo_qq_login" ceo-tooltip="QQ登录"><i class="ceofont ceoicon-qq-fill"></i>QQ</a>
                	<?php }?>

                	<?php if(_ceo('is_oauth_mpweixin')){?>
                	<a href="<?php echo esc_url(home_url('/oauth/mpweixin')); ?>" class="mpweixin_login_button btn change-color social-login ceo-margin-top button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="关注微信公众号登录"><i class="ceofont ceoicon-wechat-fill"></i>微信</a>
                    <?php }elseif(_ceo('weixin_login')){?>
                	<a href="<?php echo esc_url(home_url('/oauth/'.'weixin'.'?rurl='.home_url(add_query_arg(array())))); ?>" class="btn change-color social-login ceo-margin-top button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="微信登录"><i class="ceofont ceoicon-wechat-fill"></i>微信</a>
                    <?php }?>

                	<?php if(_ceo('weibo_login')){?>
                	<a href="<?php echo weibo_oauth_url();?>" class="ceo_weibo_login" ceo-tooltip="微博登录"><i class="ceofont ceoicon-weibo-fill"></i>微博</a>
                	<?php }?>
            	</div>
        	</div>
        </div>
	</div>
</div>

<div id="navbar-register" ceo-modal>
    <div class="ceo-modal-dialog ceo-modal-body ceo-navbar-login">
        <button class="ceo-modal-close-default ceo-modal-close" type="button" ceo-close></button>
        <div class="ceo-login-title">
            <a href="<?php bloginfo('url'); ?>">
                <img src="<?php echo _ceo('head_logo'); ?>" alt="<?php bloginfo('name'); ?>"/>
            </a>
            <p>Hi~欢迎注册 <?php bloginfo('name'); ?></p>
        </div>

		<?php if(_ceo('ceo_login_txt') == true): ?>
		<form action="" method="POST" id="register-form" class="login-weixin ceo-margin-medium-top ceo-margin-bottom">
            <?php if(_ceo('is_invitaion_code')):?>
            <div class="ceo-inline ceo-width-1-1 ceo-margin-bottom-10">
                <span class="ceo-form-icon"><i class="ceofont ceoicon-coupon-fill"></i></span>
                <input type="text" name="invitation_code" id="invitation_code" placeholder="请输入邀请码" class="b-r-4 ceo-input ceo-text-small" required="required">
            </div>
            <a href="<?php echo _ceo('is_invitaion_link'); ?>" target="_blank" rel="noreferrer nofollow" class="ceo-invitation-btn ceo-margin-bottom-10"><?php echo _ceo('is_invitaion_title'); ?></a>
            <?php endif;?>
		    <div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
		        <span class="ceo-form-icon"><i class="ceofont ceoicon-mail-line"></i></span>
    			<input type="email" id="email_address2" class="b-r-4 ceo-input ceo-text-13px" name="email_address2" placeholder="请输入您的邮箱" required="required">
			</div>
			<div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-user-line"></i></span>
			    <input type="text" id="username2" class="b-r-4 ceo-input ceo-text-13px" name="username2" placeholder="请输入您的用户名(英文/数字)" required="required">
			</div>
			<div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-keyhole-line"></i></span>
			    <input type="password" id="password2" class="b-r-4 ceo-input ceo-text-13px" name="password2" placeholder="请输入您的密码" required="required">
			</div>
			<div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-keyhole-line"></i></span>
			    <input type="password" id="repeat_password2" class="b-r-4 ceo-input ceo-text-13px" name="repeat_password2" placeholder="请再次输入密码..." required="required">
            </div>
            <div class="agreen ceo-text-13px">
                <input id="agreement" name="agreen" type="checkbox" class="agreen_btn" required>
                <label for="agreen"></label>
                我已阅读并同意<a href="<?php echo _ceo('ceo_login_zcxy_link'); ?>" target="_blank"><?php echo _ceo('ceo_login_zcxy'); ?></a>
            </div>
            <div class="ceotheme-tips ceo-margin ceo-text-danger"></div>
			<input type="hidden" name="action" value="zongcai_register">
            <input type="hidden" name="ref" value="<?php echo $_GET['ref'] ?>">
			<button class="login-button b-r-4 ceo-width-1-1 button mid dark">立即注册</button>
		</form>
		<?php endif; ?>
		<div class="ceo-login-social">
		    <div class="ceo-grid-ceosmls" ceo-grid>
		        <div class="ceo-width-1-1@s ceo-width-expand@m ceo-width-expand@l ceo-width-expand@xl">
		            <p class="ceo-flex-1 ceo-text-muted ceo-text-13px">社交账号登录</p>
	            </div>
	            <div class="ceo-width-1-1@s ceo-width-auto@m ceo-width-auto@l ceo-width-auto@xl bottom">
                    <?php if(_ceo('qq_login')){?>
                	<a href="javascript:;" class="button mid qq half qq_login_button ceo_qq_login" ceo-tooltip="QQ登录"><i class="ceofont ceoicon-qq-fill"></i>QQ</a>
                	<?php }?>

                    <?php if(_ceo('is_oauth_mpweixin')){?>
                    <a href="<?php echo esc_url(home_url('/oauth/mpweixin')); ?>" class="mpweixin_login_button btn change-color social-login ceo-margin-top button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="关注微信公众号登录"><i class="ceofont ceoicon-wechat-fill"></i>微信</a>
                    <?php }elseif(_ceo('weixin_login')){?>
                    <a href="<?php echo esc_url(home_url('/oauth/'.'weixin'.'?rurl='.home_url(add_query_arg(array())))); ?>" class="btn change-color social-login ceo-margin-top button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="微信登录"><i class="ceofont ceoicon-wechat-fill"></i>微信</a>
                    <?php }?>

                	<?php if(_ceo('weibo_login')){?>
                	<a href="<?php echo weibo_oauth_url();?>" class="ceo_weibo_login" ceo-tooltip="微博登录"><i class="ceofont ceoicon-weibo-fill"></i>微博</a>
                	<?php }?>
            	</div>
        	</div>
        </div>
        <div class="ceo-margin-top ceo-text-center">
            <p class="ceo-text-muted ceo-text-13px">已有账号？<a href="#navbar-login" ceo-toggle>立即登录！</a>
            </p>
            </p>

        </div>
	</div>
</div>

<script>
    function is_in_weixin() {
        return "micromessenger" == navigator.userAgent.toLowerCase().match(/MicroMessenger/i)
    }

    $(".login-form .mpweixin_login_button,.login-form .mpweixin_login_button").on("click", function(e) {
        setTimeout(function (){
            UIkit.modal('#navbar-login').show();
        },500)
    });
    $(document).on("click", ".mpweixin_login_button", function(e) {
        e.preventDefault();
        var t = $(this)
            , a = t.html();
        if (is_in_weixin())
            return window.location.href = t.attr("href"),
                !0;
        $.post(ceotheme.ajaxurl, {
            action: "get_mpweixin_qr"
        }, function(e) {
            if (1 == e.status) {
                $("#navbar-login").find('form').html('<img class="login-weixin-img" src="' + e.ticket_img + '"><p class="login-weixin-p">请使用微信扫码关注登录</p>');
                $("#navbar-register").find('form').html('<img class="login-weixin-img" src="' + e.ticket_img + '"><p class="login-weixin-p">请使用微信扫码关注登录</p>');
                var n = setInterval(function() {
                    $.post(ceotheme.ajaxurl, {
                        action: "check_mpweixin_qr",
                        scene_id: e.scene_id
                    }, function(e) {
                        1 == e.status && (clearInterval(n),
                            UIkit.notification('扫码成功，即将登录', { status: 'success' }),
                            window.location.reload())
                    })
                }, 5e3)
            } else
                alert(e.ticket_img);
            t.html(a)
        })
    });
</script>