<style>
    <?php echo _ceo('diy_css'); ?>
    :root {
    	--primary-color: <?php if(_ceo('ceo_color'))echo _ceo('ceo_color')['ceo_zcolor']; ?>;
    	--hcan1-color: <?php if(_ceo('ceo_color'))echo _ceo('ceo_color')['ceo_an1color']; ?>;
    	--hcan2-color: <?php if(_ceo('ceo_color'))echo _ceo('ceo_color')['ceo_an2color']; ?>;
    }
    .ceo-navbar-top {
        background-color: <?php echo _ceo('navbar_top_bg'); ?>;
    }
    .navbar-top-z .icon,.navbar-top-y a{
        color: <?php echo _ceo('navbar_top_color'); ?>;
    }
</style>