<?php
    $z = _ceo('navbar_top_z_sz');
    $t = _ceo('y_tc_sz');
    $y = _ceo('y_an_sz');
?>
<div class="ceo-navbar-top ceo-visible@s">
	<div class="ceo-container">
	    <div class="ceo-flex">
        	<div class="ceo-flex-1 navbar-top-z">
               	<ul>
               	    <?php
                	if ($z) {
                		foreach ( $z as $key => $value) {
                	?>
                	<li>
                    	<div class="navbar-top-zsj">
                            <div class="icon"><i class="ceofont <?php echo $z[$key]['icon']; ?>"></i><?php echo $z[$key]['title']; ?></div>
                            <div class="box">
                                <i></i>
                                <img src="<?php echo $z[$key]['img']; ?>" alt="<?php echo $z[$key]['title']; ?>">
                                <p><?php echo $z[$key]['tctitle']; ?></p>
                            </div>
                        </div>
                    </li>
                    <?php } } ?>
                </ul>
            </div>
            <div class="navbar-top-y">
            	<ul>
                	<li>
                	    <a href="<?php if(_ceo('navbar_top_y_tc'))echo _ceo('navbar_top_y_tc')['y_tc_anlink']; ?>" target="_blank" class="navbar-top-ytc">
                	        <i class="ceofont <?php if(_ceo('navbar_top_y_tc'))echo _ceo('navbar_top_y_tc')['y_tc_an_icon']; ?>"></i><?php if(_ceo('navbar_top_y_tc'))echo _ceo('navbar_top_y_tc')['y_tc_an_title']; ?>
                	        <div class="box">
                	            <div class="boxmk">
                                    <div class="boxmk-banner">
                                        <div class="boxmk-cut"><?php if(_ceo('navbar_top_y_tc'))echo _ceo('navbar_top_y_tc')['y_tc_bq']; ?></div>
                                        <p><?php if(_ceo('navbar_top_y_tc'))echo _ceo('navbar_top_y_tc')['y_tc_title']; ?></p>
                                    </div>
                                    <div class="boxmk-bottom">
                                        <?php
                                        $navbar_top_y_tc = _ceo('navbar_top_y_tc');
                                        $t = ! empty($navbar_top_y_tc['y_tc_sz']) ? $navbar_top_y_tc['y_tc_sz'] : [];
                                    	if ($t) {
                                    		foreach ( $t as $k => $v) {
                                    	?>
                                        <div class="ceo-grid-ceosmls" ceo-grid>
                                            <div class="ceo-width-auto">
                                                <i class="ceofont <?php echo $t[$k]['icon']; ?>"></i>
                                            </div>
                                            <div class="ceo-width-expand">
                                                <span><?php echo $t[$k]['title']; ?></span>
                                                <p><?php echo $t[$k]['describe']; ?></p>
                                            </div>
                                        </div>
        	                            <?php } } ?>
                                        <div class="boxmk-bottom-btn"><?php if(_ceo('navbar_top_y_tc'))echo _ceo('navbar_top_y_tc')['y_tc_antitle']; ?></div>
                                    </div>
                                </div>
                            </div>
            	        </a>
            	    </li>
            	    <?php
                	if ($y) {
                		foreach ( $y as $key => $value) {
                	?>
                    <li>
                        <a href="<?php echo $y[$key]['link']; ?>" target="_blank"><i class="ceofont <?php echo $y[$key]['icon']; ?>"></i><?php echo $y[$key]['title']; ?></a>
                    </li>
                    <?php } } ?>
                </ul>
            </div>
        </div>
    </div>
</div>