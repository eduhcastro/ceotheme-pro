<?php
    $post_id =  get_the_ID();
	$user_id  = get_the_author_ID();
	$author = get_the_author_meta( 'ID' );
	$args = array(
	    'post_author' => $user_id
	);
	$author_comments = get_comments($args);
	$productTypeKey = CeoShopCoreProduct::getTypeKey($post_id);
	if (is_single()):
	if ($productTypeKey != 'close' && $productTypeKey != '' ) :
?>
<!--作者模块-->
<div class="ceo-shop-sidebar-author b-a ceo-background-default ceo-margin-bottom">
    <div class="ceo-position-relative">
        <div class="ceo-profile-cover">
        </div>
        <div class="ceo-weixin-author">
            <div class="wximg">
                <img src="<?php echo get_user_meta( $user_id , 'weixinerweima' , true ); ?>" alt="微信扫码咨询">
                <span><i class="ceofont ceoicon-wechat-fill"></i>微信扫码咨询</span>
            </div>
        </div>
		<div class="ceo-text-center ceo-profile-adminimg">
		    <div class="ceo-author-imgs">
    			<?php echo get_avatar( get_the_author_meta( 'ID' ),'100' ); ?>
                <?php if(user_can(get_the_author_meta( 'ID' ),'author') || user_can(get_the_author_meta( 'ID' ),'editor') || user_can(get_the_author_meta( 'ID' ),'administrator')){ ?>
    			<i ceo-tooltip="认证作者"></i>
                <?php }?>
			</div>
		</div>
	    <div class="ceo-sidebar-author-text ceo-text-center">
		    <p class="ceo-text-normal ceo-h4 ceo-admin-author"><?php the_author_posts_link(); ?></p>
		    <p class="roles-admin ceo-display-inline-block ceo-admin-author-p2" style="margin-top: 1px;"><?php get_user_role() ?></p>
		    <p class="ceo-text-small ceo-text-muted ceo-sidebar-author-codes">
		    <?php
		    if(!get_the_author_description()){
		      echo '这家伙很懒，只想把你留下。';
		    	}else {
		    	   the_author_description();
 		    	}
		    ?>
		    </p>
	    </div>
	</div>
	<?php if ( _ceo('side_author_statistics') == true): ?>
	<div class="side-author author-count b-t">
		<div class="ceo-grid-collapse" ceo-grid>
			<div class="author-count-item ceo-position-relative ceo-text-center ceo-width-1-3">
				<span>资源</span>
				<div class="ceo-text-bold"><?php echo count_user_posts($user_id); ?></div>
			</div>
			<div class="author-count-item ceo-position-relative ceo-text-center ceo-width-1-3">
				<span>人气</span>
				<div class="ceo-text-bold ceo-margin-remove"><?php echo cx_posts_views($user_id); ?></div>
			</div>
            <div class="author-count-item ceo-position-relative ceo-text-center ceo-width-1-3">
				<span>粉丝</span>
				<div class="ceo-text-bold ceo-margin-remove"><?php echo get_user_meta($user_id, 'wp_followers_count', true); ?></div>
			</div>
		</div>
	</div>
	<?php endif; ?>
	<?php if ( _ceo('side_author_gzsx') == true): ?>
	<div class="ceo-gzsxbtn-box">
        <div class="ceo-grid-small btn-follow-div" ceo-grid>
            <?php do_action('ceo_profile_after_description', $author);?>
            <div class="ceo-width-1-3">
                <a href="<?php echo get_author_posts_url( $user_id, get_userdata($user_id)->user_nicename ); ?>" target="_blank" class="ceo-zybtn"><i class="ceofont ceoicon-user-add-line"></i>进主页</a>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php if( _ceo('shop_author_other') == true ): ?>
<div class="ceo-sidebar-shop-author ceo-background-default ceo-margin-bottom b-a">
    <div class="ceo-width-1-1 sidebar-shop-author-title ceo-flex">
        <div class="ceo-zx-title ceo-imgtext-ioc ceo-flex-1">
            <?php echo _ceo('shop_author_other_title') ?>
        </div>
        <a href="<?php echo get_author_posts_url( $user_id, get_userdata($user_id)->user_nicename ); ?>" target="_blank"><i class="ceofont ceoicon-more-line"></i></a>
    </div>

	<?php
	$shop_author_other_num = _ceo('shop_author_other_num');
    $wp_query  = new WP_Query(
		array(
			'author' => $post->post_author,
			'posts_per_page' => $shop_author_other_num,
			'post__not_in' => array($post->ID),
            'meta_key' => 'member_down',
            'meta_value' => '1',
            'meta_compare' => '!='
		)
	);
	?>
	<ul class="ceo-grid-small" ceo-grid>
		<?php while (have_posts()) : the_post(); $p=get_post(); ?>
		<li class="ceo-width-1-2">
		    <div class="sidebar-shop-author-box">
		        <a href="<?php echo get_permalink($p->ID); ?>" target="_blank" title="<?php echo $p->post_title ?>">
        			<?php if( _ceo('thumbnail_cj' ) == 'timthumb_php' ){?>
            		<img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=80&w=132&zc=1" alt="<?php the_title(); ?>"/>
            		<?php }elseif( _ceo('thumbnail_cj' ) == 'timthumb_theme' ){ ?>
            		<img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" ceo-cover/>
            		<?php }elseif( _ceo('thumbnail_cj' ) == 'timthumb_yun' ){ ?>
            		<img src="<?php echo post_thumbnail_src(); ?><?php echo _ceo('thumbnail_yun_custom'); ?>,h_80,w_132" alt="<?php the_title(); ?>"/>
            		<?php } ?>
        			<h3 class="ceo-text-truncate"><?php echo $p->post_title ?></h3>
    			</a>
			</div>
		</li>
		<?php endwhile; wp_reset_query(); ?>
	</ul>
</div>
<?php endif; ?>

<?php else: ?>

<!--作者模块-->
<div class="b-a ceo-background-default ceo-margin-bottom">
    <div class="ceo-position-relative">
        <div class="ceo-profile-cover">
            <img class="j-lazy" src="<?php
    		if(!get_user_meta( $user_id , 'userbg' , true )){
    		    echo  _ceo('side_author_img');
    		}else {
    		echo get_user_meta( $user_id , 'userbg' , true );
    		}
    		?>" alt="Lomu" style="display: block;">
        </div>
		<div class="ceo-text-center ceo-profile-adminimg">
		    <div class="ceo-author-imgs">
    			<?php echo get_avatar( get_the_author_meta( 'ID' ),'100' ); ?>
                <?php if(user_can(get_the_author_meta( 'ID' ),'author') || user_can(get_the_author_meta( 'ID' ),'editor') || user_can(get_the_author_meta( 'ID' ),'administrator')){ ?>
    			<i ceo-tooltip="认证作者"></i>
                <?php }?>
			</div>
		</div>
	    <div class="ceo-sidebar-author-text ceo-text-center">
		    <p class="ceo-text-normal ceo-h4 ceo-admin-author"><?php the_author_posts_link(); ?></p>
		    <p class="roles-admin ceo-display-inline-block ceo-admin-author-p2" style="margin-top: 1px;"><?php get_user_role() ?></p>
		    <p class="ceo-text-small ceo-text-muted ceo-sidebar-author-codes">
		    <?php
		    if(!get_the_author_description()){
		      echo '这家伙很懒，只想把你留下。';
		    	}else {
		    	   the_author_description();
 		    	}
		    ?>
		    </p>
	    </div>
	</div>
	<?php if ( _ceo('side_author_statistics') == true): ?>
	<div class="side-author author-count b-t">
		<div class="ceo-grid-collapse" ceo-grid>
			<div class="author-count-item ceo-position-relative ceo-text-center ceo-width-1-4">
				<span>文章</span>
				<div class="ceo-text-bold"><?php echo count_user_posts($user_id); ?></div>
			</div>
			<div class="author-count-item ceo-position-relative ceo-text-center ceo-width-1-4">
				<span>收藏</span>
				<div class="ceo-text-bold"><?php echo count($author_comments); ?></div>
			</div>
			<div class="author-count-item ceo-position-relative ceo-text-center ceo-width-1-4">
				<span>人气</span>
				<div class="ceo-text-bold ceo-margin-remove"><?php echo cx_posts_views($user_id); ?></div>
			</div>
            <div class="author-count-item ceo-position-relative ceo-text-center ceo-width-1-4">
				<span>粉丝</span>
				<div class="ceo-text-bold ceo-margin-remove"><?php echo get_user_meta($user_id, 'wp_followers_count', true); ?></div>
			</div>
		</div>
	</div>
	<?php endif; ?>
	<?php if ( _ceo('side_author_gzsx') == true): ?>
	<div class="ceo-gzsxbtn-box">
        <div class="ceo-grid-small btn-follow-div" ceo-grid>
            <?php do_action('ceo_profile_after_description', $author);?>
            <div class="ceo-width-1-3">
                <a href="<?php echo get_author_posts_url( $user_id, get_userdata($user_id)->user_nicename ); ?>" target="_blank" class="ceo-zybtn"><i class="ceofont ceoicon-user-add-line"></i>进主页</a>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php endif; ?>