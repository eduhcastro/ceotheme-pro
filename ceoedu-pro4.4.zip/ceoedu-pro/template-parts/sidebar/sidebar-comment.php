<!--评论列表-->
<div class="ceo-sidebar-tuwen ceo-background-default ceo-margin-bottom b-a">
    <div class="ceo-sidebar-tuwen-title ceo-flex">
        <div class="ceo-zx-title ceo-imgtext-ioc ceo-flex-1">
            <?php echo _ceo('comment-title') ?>
        </div>
    </div>
    <div class="new-comment ceo-overflow-auto" >
        <?php
        $side_comment_num =_ceo('comment-title-num');
        $new_comment_num = $new_comment_show = $side_comment_num;
        $comments = get_comments('status=approve&order=DESC&number='.$new_comment_num);
        foreach($comments as $comment) :
        $output = '<li class="b-b"><div class="avatar ceo-display-inline-block">'.get_avatar($comment, 24).'</div>' .get_comment_author().'：<p class="content b-r-4 ceo-background-muted"><a href="' . esc_url( get_comment_link($comment->comment_ID) ) . '" target="_blank">' . $comment->comment_content . '</a></p></li>';
        echo $output;
        endforeach;
        ?>
    </div>
</div>