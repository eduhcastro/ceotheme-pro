<!--社交模块-->
<div class="ceo_sidebar_focus ceo-background-default ceo-margin-bottom b-a">
    <div class="ceo_sidebar_focus_bg" style="background:url(<?php echo _ceo('side_focus_img'); ?>) center no-repeat; background-size:cover;"></div>
	<div class="ceo_sidebar_focus_box">
        <div class="ceo_sidebar_focus_mk">
            <div class="ceo-grid-ceosmls" ceo-grid>
            	<div class="ceo-width-auto">
            	    <div class="ceo_sidebar_focus_img">
                	    <img src="<?php echo _ceo('side_focus_ma'); ?>">
            	    </div>
        	    </div>
                <div class="ceo-width-expand">
                    <div class="ceo_sidebar_focus_title">
                        <span class="title"><?php echo _ceo('side_focus_title'); ?></span>
                        <span><?php echo _ceo('side_focus_subtitle'); ?></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="ceo_sidebar_focus_link">
        	<ul class="ceo-grid-ceosmls" ceo-grid>
            	<li class="qqq ceo-width-1-2">
            	    <a href="<?php echo _ceo('side_focus_an1link'); ?>" target="_blank" rel="noreferrer nofollow"><i class="ceofont ceoicon-group-line"></i><?php echo _ceo('side_focus_an1title'); ?></a>
        	    </li>
                <li class="wb ceo-width-1-2">
                    <a href="<?php echo _ceo('side_focus_an2link'); ?>" target="_blank" rel="noreferrer nofollow"><i class="ceofont ceoicon-weibo-fill"></i><?php echo _ceo('side_focus_an2title'); ?></a>
                </li>
            </ul>
        </div>
    </div>
</div>