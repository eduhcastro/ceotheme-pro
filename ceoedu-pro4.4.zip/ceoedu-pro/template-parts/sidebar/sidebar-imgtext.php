<?php
    $imgtext_on = 1;
    $args = array(
        'cat'            => _ceo('imgtext-cat'),
        'ignore_sticky_posts' => true,
        'post_status'         => 'publish',
        'posts_per_page'      => _ceo('imgtext-number'),
        'orderby'      => _ceo('imgtext-orderby'),
        'order' => 'DESC',
    );
    $data = new WP_Query($args);
?>
<!--图文模块-->
<div class="ceo-sidebar-tuwen ceo-background-default ceo-margin-bottom b-a">
    <?php while ( $data->have_posts() ) : $data->the_post();if($imgtext_on==1){ ?>
    <div class="ceo-width-1-1 ceo-sidebar-tuwen-title ceo-flex">
        <div class="ceo-zx-title ceo-imgtext-ioc ceo-flex-1">
            <?php echo _ceo('imgtext-title') ?>
        </div>
        <a href="<?php echo _ceo('imgtext-url') ?>" target="_blank"><i class="ceofont ceoicon-more-line"></i></a>
    </div>
    <div class="ceo-sidebar-tuwen-dimg">
        <a href="<?php echo get_permalink(); ?>" target="_blank" class="ceo-display-block ceo-cover-container">
            <?php if( _ceo('thumbnail_cj' ) == 'timthumb_php' ){?>
    		<img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=166&w=278&zc=1" alt="<?php the_title(); ?>"/>
    		<?php }elseif( _ceo('thumbnail_cj' ) == 'timthumb_theme' ){ ?>
    		<img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" ceo-cover/>
    		<?php }elseif( _ceo('thumbnail_cj' ) == 'timthumb_yun' ){ ?>
    		<img src="<?php echo post_thumbnail_src(); ?><?php echo _ceo('thumbnail_yun_custom'); ?>,h_166,w_278" alt="<?php the_title(); ?>"/>
    		<?php } ?>
            <div class="ceo-sidebar-tuwen-dimg-d">
                <div class="mk">
                    <span><?php the_time('Y-m-d') ?></span>
                    <p><?php echo get_the_title(); ?></p>
                </div>
            </div>
        </a>
    </div>
    
    <div class="ceo-sidebar-tuwen-wen">
        <?php $imgtext_on++;}else{ ?>
        <div class="ceo-width-1-1 ceo-width-1-1@s ceo-sidebar-tuwen-wen-mk">
            <div class="ceo-grid-small" ceo-grid>
                <div class="ceo-width-auto ceo-sidebar-tuwen-wen-img">
                    <a href="<?php echo get_permalink(); ?>" target="_blank" class="ceo-display-block ceo-cover-container">
                        <?php if( _ceo('thumbnail_cj' ) == 'timthumb_php' ){?>
                		<img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=63&w=100&zc=1" alt="<?php the_title(); ?>"/>
                		<?php }elseif( _ceo('thumbnail_cj' ) == 'timthumb_theme' ){ ?>
                		<img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" ceo-cover/>
                		<?php }elseif( _ceo('thumbnail_cj' ) == 'timthumb_yun' ){ ?>
                		<img src="<?php echo post_thumbnail_src(); ?><?php echo _ceo('thumbnail_yun_custom'); ?>,h_63,w_100" alt="<?php the_title(); ?>"/>
                		<?php } ?>
                    </a>
                </div>
                <div class="ceo-width-expand ceo-sidebar-tuwen-wen-a">
                    <a href="<?php echo get_permalink(); ?>" title="<?php echo get_the_title(); ?>" target="_blank"><?php echo get_the_title(); ?></a>
                    <div class="ceo-flex">
                        <p class="ceo-flex-1"><?php the_time('Y-m-d') ?></p>
                        <p><?php post_views('', ''); ?> 浏览</p>
                    </div>
                </div>
            </div>
        </div>
        <?php } endwhile; ?>
    </div>
</div>