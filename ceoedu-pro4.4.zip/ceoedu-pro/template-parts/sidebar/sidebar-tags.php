<!--标签模块-->
<div class="ceo-sidebar-tuwen ceo-background-default ceo-margin-bottom b-a">
    <div class="ceo-sidebar-tuwen-title ceo-flex">
        <div class="ceo-zx-title ceo-imgtext-ioc ceo-flex-1">
            <?php echo _ceo('side-tag-title') ?>
        </div>
        <a href="<?php echo _ceo('side-tag-url') ?>" target="_blank"><i class="ceofont ceoicon-more-line"></i></a>
    </div>
	<ul class="ceo-list ceo-margin-remove ceo-tag-left">
        <div class="ceo-sidebar-tag">
            <div class="ceo-sidebar-tagbox">
                <?php
                $side_tag_num =  _ceo('side-tag-num');
                $tags_list = get_tags( array('number' => $side_tag['num'], 'orderby' => '', 'order' => 'DESC', 'hide_empty' => false) );
                $count=0;
                if ($tags_list) {
                    foreach($tags_list as $tag) {
                        $count++;
                        echo '<span><a href="'.get_tag_link($tag->term_id).'" target="_blank">'.$tag->name.'</a></span>';
                        if( $count > $side_tag_num ) break;
                    }
                }
                ?>
            </div>
        </div>
	</ul>
</div>