<?php
    $cat_id = _ceo('text-cat');
    $args = array(
        'cat'            => $cat_id,
        'ignore_sticky_posts' => true,
        'post_status'         => 'publish',
        'posts_per_page'      => _ceo('text-number'),
        'orderby'      => _ceo('text-orderby'),
        'meta_key' => 'views',
        'order' => 'DESC',
    );
    $data = new WP_Query($args);
    $category = get_category( $cat_id);
?>
<!--文章展示-->
<div class="ceo-sidebar-tuwen ceo-background-default ceo-margin-bottom b-a">
    <div class="ceo-sidebar-text-title ceo-flex">
        <div class="ceo-zx-title ceo-imgtext-ioc ceo-flex-1">
            <?php echo _ceo('text-title') ?>
        </div>
        <a href="<?php echo _ceo('text-url') ?>" target="_blank"><i class="ceofont ceoicon-more-line"></i></a>
    </div>
    <div class="ceo-sidebar-text-wen">
        <?php while ( $data->have_posts() ) : $data->the_post(); ?>
        <li>
            <div class="ceo-grid-small" ceo-grid>
                <?php
        	    	$category = get_the_category();
        	    	if($category[0]){
        	    		echo '<a href="'.get_category_link($category[0]->term_id ).'" target="_blank" class="ceo-width-auto">[ '.$category[0]->cat_name.' ]</a>';
        	    	}
        	    ?>
                <a href="<?php echo get_permalink(); ?>" target="_blank" class="ceo-width-expand ceo-text-truncate" title="<?php echo get_the_title(); ?>"><?php echo get_the_title(); ?></a>
            </div>
        </li>
        <?php endwhile; ?>
    </div>
</div>