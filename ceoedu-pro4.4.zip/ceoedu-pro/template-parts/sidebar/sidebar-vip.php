<!--VIP模块-->
<div class="ceo_sidebar_vip ceo-background-default ceo-margin-bottom b-a">
    <div class="ceo_sidebar_vip_bg" style="background:url(<?php echo _ceo('side_vip_img'); ?>) center no-repeat; background-size:cover;"></div>
    <div class="ceo_sidebar_vip_box">
        <a href="<?php echo _ceo('side_vip_link'); ?>" target="_blank"><?php echo _ceo('side_vip_title'); ?><i></i></a>
    </div>
</div>