<?php
$commodity_info=get_post_meta( get_the_ID(), 'commodity_info', true );
?>
<div class="ceo-padding-20">
    <?php
    if(!empty($commodity_info)){
        foreach ($commodity_info as $k=>$v){
            $number=$k+1;
            echo '
            <div id="ceo-single-commodity" class="ceo-single-commodity">
                <div class="ceo-grid-ceosmls" ceo-grid>
                    <div class="ceo-width-1-1@s ceo-width-auto@m ceo-width-auto@l ceo-width-auto@xl commodity-img">
                        <a href="'.$v['link'].'" target="_blank" rel="noreferrer nofollow" class="thumb b-r-4 ceo-display-block ceo-cover-container">
            				<img src="'.$v['img'].'" ceo-cover />
            			</a>
                    </div>
                    <div class="ceo-overflow-hidden ceo-width-1-1@s ceo-width-expand@m ceo-width-expand@l ceo-width-expand@xl commodity-info">
            			<a href="'.$v['link'].'" target="_blank" rel="noreferrer nofollow" class="title ceo-display-block">
                			<em>'.$v['platform'].'</em>'.$v['title'].'
            			</a>
            			<div class="bottom ceo-flex">
                			<p class="ceo-flex-1">'.$v['price'].'<em>'.$v['desc'].'</em></p>
                			<a href="'.$v['link'].'" target="_blank" rel="noreferrer nofollow" class="ceo-display-block">直达链接</a>
            			</div>
            		</div>
        		</div>
    		</div>
            ';
        }
    }
    ?>
</div>