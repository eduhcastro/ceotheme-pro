<?php
    if(get_post_meta(get_the_ID(),"ceo_commodity_kg",1)){
?>
<div class="ceo-single-icon-commodity" ceo-sticky="animation: ceo-animation-slide-top;">
    <div class="ceo-single-icon-commoditybox">
        <a href="#ceo-single-commodity" ceo-tooltip="本文关联商品">
            <i class="ceofont ceoicon-shopping-cart-line"></i>
        </a>
    </div>
</div>
<?php } ?>