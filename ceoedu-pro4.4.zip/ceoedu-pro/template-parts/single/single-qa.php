<?php
    $qa = _ceo('single_qa_sz');
?>
<div class="ceo-background-default ceo-margin-bottom b-a">
	<div class="ceo-single-qa b-b ceo-flex ceo-flex-middle ceo-overflow-hidden">
		<span class="ceo-position-relative ceo-zx-title ceo-imgtext-ioc"><?php echo _ceo('single_qa_title'); ?></span>
	</div>
    <div class="ceo-single-qabox">
    	<div class="ceo-grid-ceosmls" ceo-grid>
    	    <?php
				if ($qa) {
					foreach ( $qa as $key => $value) {
			?>
    	    <div class="ceo-width-1-1 ceo-width-1-2@s">
                <a href="<?php echo $value['link']; ?>" target="_blank">
                    <div class="w1">
                        <span><?php echo $value['title']; ?></span>
                    </div>
                    <div class="w2">
                        <span><?php echo $value['content']; ?></span>
                    </div>
                    <p><?php echo $value['antitle']; ?></p>
                </a>
            </div>
            <?php } } ?>
        </div>
    </div>
</div>