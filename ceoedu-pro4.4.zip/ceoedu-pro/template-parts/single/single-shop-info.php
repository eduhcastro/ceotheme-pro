<?php 
	$post_id =  get_the_ID();
?>
<div class="info ceo-flex ceo-flex-middle ceo-text-small ceo-text-muted ceo-flex ceo-flex-middle ceo-text-truncate">
    <div class="ceo-flex-1 ceo-flex ceo-flex-middle">
		<?php if(_ceo('single_info_tx') == true ): ?>
        <div class="avatar ceo-border-circle ceo-overflow-hidden ceo-user-adminimg">
		<?php echo get_avatar(get_the_author_meta( 'ID' ), 20); ?>
		</div>
		<?php endif; ?>
		<?php if(_ceo('single_info_mc') == true ): ?>
		<span class="ceo-text-small ceo-display-block ceo-user-admin"><?php the_author_posts_link(); ?></span>
		<?php endif; ?>
        <?php if(_ceo('single_info_rq') == true ): ?>
    	<span class="ceo-margin-ymd"><i class="ceofont ceoicon-calendar-2-line"></i><?php echo the_time('Y年m月j日'); ?></span>
    	<?php endif; ?>
    	<span class="ceo-margin-ymd"><?php edit_post_link('<i class="ceofont ceoicon-edit-2-line"></i> 编辑'); ?></span>
	</div>
	<div class="ceo-info-y">
    	<?php if(_ceo('single_info_sc') == true ): ?>
    	<span class="ceo-visible@s"><?php echo count_collection_current_post( $post_id ) ?> 收藏</span>
    	<?php endif; ?>
    	<?php if(_ceo('single_info_dz') == true ): ?>
    	<span class="ceo-visible@s"><?php echo ($dot_good=get_post_meta($post->ID, 'like', true)) ? $dot_good : '0'; ?> 点赞</span>
    	<?php endif; ?>
    	<?php if(_ceo('single_info_ll') == true ): ?>
    	<span class=""><?php post_views('', ''); ?> 浏览</span>
    	<?php endif; ?>
	</div>
</div>