<?php



$zzfw = _ceo('ceo_shop_single_zzsz');
$post_id = get_the_ID();
?>
<div class="ceo-margin-bottom ceo-background-default b-a">
	<div class="ceo_single_shop_box">
		<div class="ceo-grid-ceosmls" ceo-grid>
			<div class="ceo-width-1-1@s ceo-width-auto@m ceo-width-auto@l ceo-width-auto@xl">
				<div class="ceo_single_shop_box_img ceo-display-block ceo-cover-container">
					<?php if (_ceo('thumbnail_cj') == 'timthumb_php') { ?>
						<img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=200&w=300&zc=1" alt="<?php the_title(); ?>" />
					<?php } elseif (_ceo('thumbnail_cj') == 'timthumb_theme') { ?>
						<img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" ceo-cover />
					<?php } elseif (_ceo('thumbnail_cj') == 'timthumb_yun') { ?>
						<img src="<?php echo post_thumbnail_src(); ?><?php echo _ceo('thumbnail_yun_custom'); ?>,h_200,w_300" alt="<?php the_title(); ?>" />
					<?php } ?>
					<?php if (_ceo('single_info_fl') == true) : ?>
						<span>
							<?php
							$category = get_the_category();
							if ($category[0]) {
								echo '<a href="' . get_category_link($category[0]->term_id) . '">' . $category[0]->cat_name . '</a>';
							}
							?>
						</span>
					<?php endif; ?>
				</div>
				<div class="risktips">
					<?php if (_ceo('ceo_shop_single_ts_link') == '1') { ?>
						<i class="ceofont ceoicon-volume-up-line"></i><a href="https://wpa.qq.com/msgrd?v=3&uin=<?php if (_ceo('goTop_service_sz')) echo _ceo('goTop_service_sz')['goTop_qq_qq']; ?>&site=qq&menu=yes" rel="nofollow" target="_blank"><?php echo _ceo('ceo_shop_single_ts'); ?></a>
					<?php } else { ?>
						<i class="ceofont ceoicon-volume-up-line"></i><a href="<?php echo _ceo('ceo_shop_single_ts_linkn'); ?>" rel="nofollow" target="_blank"><?php echo _ceo('ceo_shop_single_ts'); ?></a>
					<?php } ?>
				</div>
			</div>
			<div class="ceo-width-1-1@s ceo-width-expand@m ceo-width-expand@l ceo-width-expand@xl">
				<div class="ceo_single_shop_box_cos">
					<div class="shop_box_cos_title">
						<?php if (get_post_meta(get_the_ID(), 'ceo-tese-tag', true)) { ?>
							<div class="ceo-single-tese">
								<i class="ceofont ceoicon-hashtag"></i><?php echo get_post_meta(get_the_ID(), 'ceo-tese-tag', true); ?>
							</div>
						<?php } ?>
						<h1><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h1>
					</div>
					<?php get_template_part('template-parts/single/single-shop', 'info'); ?>
					<?php if (_ceo('ceo_shop_single_jianjie') == true) : ?>
						<div class="ceo-overflow-hidden main_info_price_r" style="background: url(<?php echo _ceo('ceo_shop_single_jianjie_img'); ?>);background-size: 100% 100%;">
							<b><?php echo _ceo('ceo_shop_single_jianjie_title'); ?></b>丨<?php echo _ceo('ceo_shop_single_jianjie_title2'); ?>
							<div class="collection">
								<a href="<?php echo _ceo('ceo_shop_single_jianjie_title_l'); ?>" target="_blank"><i class="ceofont <?php echo _ceo('ceo_shop_single_jianjie_title_i'); ?>"></i><?php echo _ceo('ceo_shop_single_jianjie_title_y'); ?></a>
							</div>
						</div>
					<?php endif ?>
					<div class="ceo_single_shop_box_cos_btn">
						<?php if (_ceo('ceo_shop_whole')) : ?>
							<?php if (get_current_user_id() > 0 || _ceo('ceo_shop_tourist')) : ?>
								<div class="cos_btn_price">
									<em class="price"><?php echo CeoShopCoreProduct::getPriceFormat($post_id) ?></em>
                                    <?php echo CeoShopCoreProduct::getVipDiscountInfoFormat($post_id, get_current_user_id()) ?>
								</div>
							<?php endif; ?>
						<?php endif; ?>
						<div class="cos_btn_price_an">
							<div class="ceo-grid-small" ceo-grid>
								<?php if (_ceo('ceo_shop_whole')) : ?>
									<?php if (get_current_user_id() > 0 || _ceo('ceo_shop_tourist')) : ?>
										<div class="ceo-width-1-2 ceo-width-1-4@s">
											<?php if (get_current_user_id() == 0 && (!_ceo('ceo_shop_tourist_buy') || CeoShopCoreProduct::getTypeId(get_the_ID()) == 2)) : ?>
												<a href="#navbar-login" data-product-id="<?php echo get_the_ID() ?>" class="z1" ceo-toggle>
													<i class="ceofont ceoicon-shopping-cart-line"></i>
													<span id="shop_single_an_id"><?php echo CeoShopCoreProduct::getPayButtonText(get_the_ID(), get_current_user_id()) ?></span>
												</a>
											<?php else : ?>
												<a href="javascript:void(0)" data-product-id="<?php echo get_the_ID() ?>" data-flush="<?php echo CeoShopCoreProduct::getTypeId(get_the_ID()) == 1 ? '1': '0' ?>" class="z1 btn-ceo-purchase-product" data-style="slide-down">
													<i class="ceofont ceoicon-shopping-cart-line"></i>
													<span id="shop_single_an_id"><?php echo CeoShopCoreProduct::getPayButtonText(get_the_ID(), get_current_user_id()) ?></span>
												</a>
											<?php endif; ?>
										</div>
									<?php endif; ?>
								<?php endif; ?>
								<div class="ceo-width-1-2 ceo-width-1-4@s">
									<a href="<?php if (_ceo('ceo_shop_single_an')) echo _ceo('ceo_shop_single_an')['ceo_shop_single_an_hyl']; ?>" target="_blank" class="v">
										<i class="ceofont ceoicon-vip-diamond-line"></i>
										<?php if (_ceo('ceo_shop_single_an')) echo _ceo('ceo_shop_single_an')['ceo_shop_single_an_hy']; ?>
									</a>
								</div>

								<?php if (_ceo('ceo_shop_single_an_zxb') == true) : ?>
									<div class="ceo-width-1-1 ceo-width-1-4@s">
										<a href="https://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo get_the_author_meta('qq', $user_id); ?>&amp;site=qq&amp;menu=yes" target="_blank" rel="nofollow" class="x">
											<i class="ceofont ceoicon-customer-service-2-line"></i>
											<?php echo _ceo('ceo_shop_single_an_zx'); ?>
										</a>
									</div>
								<?php endif ?>

								<?php if (_ceo('ceo_shop_single_an_zdyb') == true) : ?>
									<div class="ceo-width-1-1 ceo-width-1-4@s">
										<a href="<?php echo _ceo('ceo_shop_single_an_zdyl'); ?>" target="_blank" class="y1">
											<i class="ceofont ceoicon-vip-crown-line"></i>
											<?php echo _ceo('ceo_shop_single_an_zdy'); ?>
										</a>
									</div>
								<?php endif ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php if (_ceo('ceo_shop_single_zz') == true) : ?>
		<div class="ceo_single_shop_box_kj">
			<span><i class="ceofont ceoicon-shopping-cart-line"></i><?php echo _ceo('ceo_shop_single_zz_title'); ?></span>
			<?php
			if ($zzfw) {
				foreach ($zzfw as $key => $value) {
			?>
					<span><?php echo $value['content']; ?></span>
			<?php }
			} ?>
		</div>
	<?php endif ?>
</div>