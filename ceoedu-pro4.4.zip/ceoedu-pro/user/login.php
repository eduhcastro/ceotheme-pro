<?php
// 登录页面背景图片
add_filter('body_class',function ($classes) {
	$classes[]	= 'joy-login';
	return $classes;
});
get_header();
?>
<section class="page-login ceo-animation-slide-bottom-small">
<?php include get_template_directory().'/user/login/'.$action.'.php'; ?>
</section>
<?php get_footer(); ?>