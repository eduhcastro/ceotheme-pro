<!--头像上传-->
<script src="<?php echo get_bloginfo('template_url');?>/static/js/jquery.form.js"></script>
<script>
	jQuery(function($){
		$("#addPic").change(function(){
			$("#AvatarForm").ajaxSubmit({
				dataType:  'json',
				beforeSend: function() {
					//return tips('上传中...');
				},
				uploadProgress: function(event, position, total, percentComplete) {

				},
				success: function(data) {
					if (data == "1") {
						//tips('头像修改成功');
						location.reload();
					}else if(data == "2"){
						alert('图片大小请不要超过1M');
					}else if(data == "3"){
						alert('图片格式只支持.jpg .png .gif');
					}else{
						alert('上传失败');
					}
				},
				error:function(xhr){
					alert('上传失败.');
				}
			});

		});
	});
</script>

<!--图片上传-->
<script>
   //个人主页背景图
    $(".upload-userhomebg-button").on("click", function () {
        $("#upload-userhomebg").trigger("click");
    });
    $("#upload-userhomebg").on("change",function () {
        var file_data = $('#upload-userhomebg').prop('files')[0];
        var form_data = new FormData();
        form_data.append('file', file_data);
        form_data.append('action', 'upload_image_userhomebg');
        form_data.append('upload_nonce', '<?php echo wp_create_nonce('upload_nonce') ?>');
        // alert(form_data);
        $.ajax({
            url: '/wp-admin/admin-ajax.php', // point to server-side PHP script
            dataType: 'json',  // what to expect back from the PHP script, if anything
            cache: false,
            contentType: false,
            processData: false,
            data: form_data,
            type: 'post',
            success: function (data) {
                if (data.code == 1) {
                    // $("#userbg").attr("src", data.data.url);
                    $("#userhomebg").val(data.data.url);
                }
                if(data.msg){
                    alert(data.msg)
                }
            }
        });
    })
    
    //用户模块背景图
    $(".upload-userbg-button").on("click", function () {
        $("#upload-userbg").trigger("click");
    });
    $("#upload-userbg").on("change",function () {
        var file_data = $('#upload-userbg').prop('files')[0];
        var form_data = new FormData();
        form_data.append('file', file_data);
        form_data.append('action', 'upload_image_userbg');
        form_data.append('upload_nonce', '<?php echo wp_create_nonce('upload_nonce') ?>');
        // alert(form_data);
        $.ajax({
            url: '/wp-admin/admin-ajax.php', // point to server-side PHP script
            dataType: 'json',  // what to expect back from the PHP script, if anything
            cache: false,
            contentType: false,
            processData: false,
            data: form_data,
            type: 'post',
            success: function (data) {
                if (data.code == 1) {
                    // $("#userbg").attr("src", data.data.url);
                    $("#userbg").val(data.data.url);
                }
                if(data.msg){
                    alert(data.msg)
                }
            }
        });
    })
    
    //微信二维码
    $(".upload-weixinerweima-button").on("click", function () {
        $("#upload-weixinerweima").trigger("click");
    });
    $("#upload-weixinerweima").on("change",function () {
        var file_data = $('#upload-weixinerweima').prop('files')[0];
        var form_data = new FormData();
        form_data.append('file', file_data);
        form_data.append('action', 'upload_image_weixinerweima');
        form_data.append('upload_nonce', '<?php echo wp_create_nonce('upload_nonce') ?>');
        // alert(form_data);
        $.ajax({
            url: '/wp-admin/admin-ajax.php', // point to server-side PHP script
            dataType: 'json',  // what to expect back from the PHP script, if anything
            cache: false,
            contentType: false,
            processData: false,
            data: form_data,
            type: 'post',
            success: function (data) {
                if (data.code == 1) {
                    // $("#weixinerweima").attr("src", data.data.url);
                    $("#weixinerweima").val(data.data.url);
                }
                if(data.msg){
                    alert(data.msg)
                }
            }
        });
    })
</script>