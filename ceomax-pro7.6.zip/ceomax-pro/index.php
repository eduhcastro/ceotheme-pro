<?php get_header();?>
<main>
	<?php ceo_index_home(); ?>
</main>
<?php get_footer();?>