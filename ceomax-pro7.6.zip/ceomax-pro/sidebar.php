<div class="sidebar">
    <?php ceo_sidebar_gn(); ?>
</div>