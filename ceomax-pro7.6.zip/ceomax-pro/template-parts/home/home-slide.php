<?php ceo_home_slide_gn(); ?>
<?php get_template_part( 'template-parts/app/app', 'home_middle' ); ?>