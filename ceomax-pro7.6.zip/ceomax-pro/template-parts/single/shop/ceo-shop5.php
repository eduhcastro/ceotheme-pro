<div class="ceo-side-lie ceo-margin-top-20" ceo-grid>
	<div class="ceo-side-lie-z ceo-width-auto">
        <?php get_template_part( 'template-parts/single/shop/ceo-shop5', 'video' ); ?>
    </div>
    <div class="ceo-shop5-list ceo-width-expand">
        <?php get_template_part( 'template-parts/single/shop/sidebar/sidebar', 'video' ); ?>
    </div>
</div>