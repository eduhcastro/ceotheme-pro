<div class="single-contact-box b-r-4 ceo-margin-bottom" style="background: url(<?php if(_ceo('single_article_contact_sz'))echo _ceo('single_article_contact_sz')['single_article_contact_sz_img']; ?>) no-repeat center;">
    <div class="single-contact-box-head">
        <div class="ceo-flex">
            <div class="single-contact-box-head-z ceo-flex-1">
                <span><?php if(_ceo('single_article_contact_sz'))echo _ceo('single_article_contact_sz')['single_article_contact_sz_title']; ?></span>
                <p><?php if(_ceo('single_article_contact_sz'))echo _ceo('single_article_contact_sz')['single_article_contact_sz_desc']; ?></p>
            </div>
            <div class="single-contact-box-head-y">
                <a href="<?php if(_ceo('single_article_contact_sz'))echo _ceo('single_article_contact_sz')['single_article_contact_sz_an1q']; ?>" target="_blank"><i class="ceofont <?php if(_ceo('single_article_contact_sz'))echo _ceo('single_article_contact_sz')['single_article_contact_sz_an1b']; ?>"></i><?php if(_ceo('single_article_contact_sz'))echo _ceo('single_article_contact_sz')['single_article_contact_sz_an1t']; ?></a>
                <a href="<?php if(_ceo('single_article_contact_sz'))echo _ceo('single_article_contact_sz')['single_article_contact_sz_an2q']; ?>" class="single-contact-box-head-y-mobile" target="_blank"><i class="ceofont <?php if(_ceo('single_article_contact_sz'))echo _ceo('single_article_contact_sz')['single_article_contact_sz_an2b']; ?>"></i><?php if(_ceo('single_article_contact_sz'))echo _ceo('single_article_contact_sz')['single_article_contact_sz_an2t']; ?></a>
            </div>
        </div>
    </div>
</div>