<div class="login-r ceo-overflow-hidden ceo-flex ceo-flex-middle" style="background: #fff url(<?php echo _ceo('login_bg'); ?>) no-repeat;">
	<div class="s-res ceo-background-default ceo-padding">
		<h4 class="b-b ceo-text-uppercase ceo-text-center">注册方式</h4>
		<a href="<?php echo home_url(user_trailingslashit('/user/register')); ?>" class="change-color ceo-display-block b-r-4 ceo-button-small ceo-margin-bottom ceo-text-center"><i class="ceofont ceoicon-mail-line"></i>邮箱注册</a>
		<a href="<?php echo home_url(user_trailingslashit('/user/login')); ?>" class="change-color ceo-display-block b-r-4 ceo-button-small ceo-margin-bottom ceo-text-center"><i class="ceofont ceoicon-share-forward-line"></i>返回登录</a>
	</div>
</div>