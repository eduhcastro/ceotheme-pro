<?php get_header();?>
<section class="ceo-404page">
    <div class="ceo-flex ceo-flex-middle">
    	<div class="ceo-container ceo-padding-large">
    		<div class="page404 ceo-text-center ceo-padding-large">
    		    <i></i>
    		    <img src="<?php echo _ceo('404-bg'); ?>" alt="404">
    			<p><?php echo _ceo('404-text'); ?></p>
				<a href="<?php bloginfo('url'); ?>"  class="btn b-r-4 change-color ceo-display-inline-block"> 返回首页<i class="ceofont ceoicon-share-forward-line-fill"></i></a>
    		</div>
    	</div>
    </div>
</section>
<?php get_footer(); ?>