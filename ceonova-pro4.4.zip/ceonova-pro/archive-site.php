<?php 
$bg = _ceo('site-bg');
get_header();
?>
<div class="ceo-pages-site">
    <div class="ceo-tag-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);">
        <div class="ceo-container ceo-containertag">
            <div class="ceo-tag-bgleft">
                <h3 class="ceo-hs ceo-hidden@s">网址导航</h3>
                <?php include TEMPLATEPATH.'/inc/sitenav/template-parts/top.php'; ?>
            </div>
        </div>
    </div>
    <?php include TEMPLATEPATH.'/inc/sitenav/template-parts/nav.php'; ?>
    <?php include TEMPLATEPATH.'/inc/sitenav/template-parts/hot.php'; ?>
    <?php include TEMPLATEPATH.'/inc/sitenav/index.php' ;?>
</div>
<style>.ceo-tag-bgleft{margin-top: 150px;}</style>
<?php get_footer(); ?>