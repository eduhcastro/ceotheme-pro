<?php
get_header();

global $wpdb;
$wpdb->collection = $wpdb->prefix.'collection';
$user_id        = get_the_author_ID();
if(!empty($author)){
    $user_id=$author;
}

$args['user_id'] = $user_id;

$author_comments = get_comments($args);
$all_collections = $wpdb->get_results( $wpdb->prepare("select post_id from $wpdb->collection where user_id = %d LIMIT 0,10", $user_id ) );

if( $all_collections ){
	foreach ($all_collections as $key => $value) {
		$collections_posts[] = $value->post_id;
	}

	$args = array(
		'post_type' => 'post',
		'post__in' => $collections_posts,
		'ignore_sticky_posts' => 1,
	);
	$collection_posts = new WP_Query($args);
}

?>
<section class="ceo-author-bg ceo-background-default ceo-position-relative">
	<div class="bg ceo-background-cover" style="background-image: url(<?php
                    		if(!get_user_meta( $user_id , 'userhomebg' , true )){
                    		    echo  _ceo('side_author_homeimg');
                    		}else {
                    		echo get_user_meta( $user_id , 'userhomebg' , true );
                    		}
                    		?>);">
	    <div class="ceo-container">
	        <div class="ceo-action-userzx ceo-align-lefts ceo-tag-bgleft">
    	        <div class="ceo-author-top ceo-position-relative">
    	            <div class="ceo-grid-ceosmls" ceo-grid>
    	                <div class="ceo-width-auto">
                        	<div class="ceo-text-center ceo-author-adminimg">
                        	    <div class="ceo-author-imgs">
                        		    <?php echo get_avatar( $user_id , 80 ); ?>
                        			<?php if(user_can(get_the_author_meta( 'ID' ),'author') || user_can(get_the_author_meta( 'ID' ),'editor') || user_can(get_the_author_meta( 'ID' ),'administrator')){ ?>
                        			<i ceo-tooltip="认证作者"></i>
                                    <?php }?>
                    			</div>
                        	</div>
                	    </div>
                    	<div class="ceo-width-expand">
                    	    <div class="mc ceo-text-left">
                    		    <h3 class="ceo-hs"><?php the_author_nickname(); ?></h3>
                        	    <p class="ceo-text-truncate">
                        	        <?php
                                        if(!get_the_author_meta('user_description', $user_id)){
                                            echo '这家伙很懒，只想把你留下。';
                                        }else {
                                            echo the_author_meta('user_description', $user_id);
                                        }
                                	?>
                        	    </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
	    </div>
	</div>
</section>

<section class="ceo-author-countbox ceo-background-default">
    <div class="ceo-container">
        <div class="ceo-grid-collapse" ceo-grid>
            <div class="item ceo-position-relative ceo-text-center ceo-width-1-4">
    			<span>文章 <?php echo count_user_posts($user_id); ?></span>
    		</div>
    		<div class="item ceo-position-relative ceo-text-center ceo-width-1-4">
    			<span>人气 <?php echo cx_posts_views($user_id); ?></span>
    		</div>
    		<div class="item ceo-position-relative ceo-text-center ceo-width-1-4">
    			<span>收藏 <?php echo count_collection_posts($user_id) ?></span>
    		</div>
    		<div class="item ceo-position-relative ceo-text-center ceo-width-1-4">
    			<span>评论 <?php echo count($author_comments); ?></span>
    		</div>
    	</div>
	</div>
</section>

<section class="ceo-category-blog">
    <div class="ceo-container" id="category">
        <div class="ceo-grid-ceosmls" ceo-grid>
        	<div class="ceo-width-1-1 ceo-width-auto@s">
        	    <div class="ceo-author-mkbox b-a ceo-background-default">
            	    <ul class="ceo-author-mkboxnav ceo-subnav ceo-subnav-pill" ceo-switcher>
                        <li><a href="#">文章</a></li>
                        <li><a href="#">问题</a></li>
                        <li><a href="#">帖子</a></li>
                    </ul>
                    
                    <ul class="ceo-switcher">
                        <li><?php get_template_part( 'template-parts/author/author', 'post' ); ?></li>
                        <li><?php get_template_part( 'template-parts/author/author', 'question' ); ?></li>
                        <li><?php get_template_part( 'template-parts/author/author', 'forum' ); ?></li>
                    </ul>
                </div>
            </div>
        	<?php get_sidebar(); ?>
        </div>
    </div>
</section>

<?php get_footer(); ?>