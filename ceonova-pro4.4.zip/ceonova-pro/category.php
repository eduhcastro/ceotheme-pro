<?php get_header(); ?>

<?php ceo_category_tpl_part(); ?>

<?php get_footer(); ?>