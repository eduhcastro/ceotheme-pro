<?php
    $y = _ceo('ceo_foot_y');
?>
		</main>
		    <!--底部宣传模块-->
		    <?php get_template_part( 'template-parts/footer/footer', 'new' ); ?>
		    <!--底部banner模块-->
		    <?php get_template_part( 'template-parts/footer/footer', 'banner' ); ?>
			<!--右下角跟随模块-->
			<?php get_template_part( 'template-parts/footer/footer', 'follow' ); ?>
			<!--底部主模块-->
			<footer class="ceo_footer">
                <?php if (is_home()) { ?>
                <?php if(_ceo('link_show') == true ): ?>
                <div class="ceo-container">
            		<div class="foot-link link">
            			<ul class="ceo-margin-remove ceo-text-small">
            				<li style="margin-right: 15px;"><i class="ceofont ceoicon-user-star-line"></i> 友情链接：</li><?php $wp_list_bookmarks=wp_list_bookmarks('title_li=&echo=0');
                            echo preg_replace('#<img src="(.*?)"  alt="(.*?)".*?/>#', "$2", $wp_list_bookmarks);
    						?>
    						<li>
    						    <a href="tencent://Message/?Uin=<?php if(_ceo('goTop_service_sz'))echo _ceo('goTop_service_sz')['goTop_qq_qq']; ?>&amp;websiteName=#=&amp;Menu=yes" rel="noreferrer nofollow">
    						        <i class="ceofont ceoicon-qq-fill"></i> 友链申请+
    					        </a>
    				        </li>
            			</ul>
            		</div>
                </div>
                <?php endif; ?>
                <?php } ?>
                <div class="foot-cop">
                    <div class="ceo-flex ceo-flex-middle ceo-container">
                        <div class="ceo-flex-1">
                            <div class="foot-cop-zt">
                                <span class="ceo-visible@s"><?php echo _ceo('cop_text'); ?></span>
                                <?php if(_ceo('theme_cop') == true): ?>
                                <span>Theme By <a href="https://www.ceotheme.com/" target="_blank" rel="noreferrer nofollow">CeoTheme</a></span>
                                <?php endif; ?>
                            </div>
                            <div class="foot-cop-zb">
                                <?php if(_ceo('foot_xml-y') == true): ?>
                                <span class="ceo-visible@s"><a href="<?php echo _ceo('foot_xml'); ?>" target="_blank"><i class="ceofont ceoicon-map-pin-fill" aria-hidden="true"></i> 网站地图</a></span>
                                <?php endif; ?>
                                <?php if(_ceo('foot_gongan') == true): ?>
        						<span class="ceo-margin-small-right ceo-gongan"><a href="http://www.beian.gov.cn/" target="_blank" rel="noreferrer nofollow"><img src="<?php bloginfo('template_url'); ?>/static//images/ceo-110.png" height="6"><?php echo _ceo('foot_gongan_beianhao'); ?></a></span>
        						<?php endif; ?>
                                <?php if(_ceo('show_beian') == true): ?>
                                <span class="ceo-display-inline-block"><a href="https://beian.miit.gov.cn/" target="_blank" rel="noreferrer nofollow"><?php echo _ceo('beian'); ?></a></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="foot-cop-y">
                            <?php 
                			if ($y) { 
                				foreach ( $y as $key => $value) {
                			?>
                            <li>
                                <a href="<?php echo $value['link']; ?>" target="_blank" rel="noreferrer nofollow">
                                    <img src="<?php echo $value['img']; ?>" alt="<?php echo $value['title']; ?>">
                                </a>
                            </li>
                            <?php } } ?>
    			        </div>
                    </div>
                </div>
                <?php if( is_user_logged_in() ){ ?>
                <?php }else{ ?>
	            <?php get_template_part( 'template-parts/navbar/navbar', 'login' ); ?>
		        <?php } ?>
			    <?php wp_footer(); ?>
		    </footer>
		</div>
		<?php get_template_part( 'template-parts/footer/footer', 'js' ); ?>
		<?php if(_ceo('ceo_app_foo') == true): ?>
		<?php get_template_part( 'template-parts/footer/footer', 'nav' ); ?>
		<?php endif; ?>
        <!-- CeoNova-Pro主题 -->
        <div id="ceoshop-member-box"></div>
</body>
</html>