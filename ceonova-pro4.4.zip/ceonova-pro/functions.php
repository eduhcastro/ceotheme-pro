<?php

/**
 * CeoNova-Pro主题是一款极致美观强大的WordPress付费产品官网主题。
 * 正版唯一购买地址：https://www.ceotheme.com/
 * CeoNova-Pro主题官方演示站点：http://ceonova-pro.ceotheme.com/
 * 作者总裁QQ：110300260 （总裁）
 * CeoNova-Pro主题是一款轻量级、且简洁大气、产品官网类主题，定位于高端产品官网、同时包含了知识付费、定制服务、问答社区、论坛交流、网址导航、以及付费产品下载等全方位覆盖。
 * 能理解使用盗版的人，但是不能接受传播盗版。
 * CeoTheme总裁主题制作的CeoNova-Pro主题正版用户可享受该主题不限制域名，不限制数量，无限授权，仅限本人享有此特权，外泄主题包将取消授权资格！
 * 开发者不易，感谢支持，全天候在线客户服务+技术支持为您服务。
 */

/*
 * ------------------------------------------------------------------------------
 * PHP多版本兼容
 * ------------------------------------------------------------------------------
 */
error_reporting(0);

if (file_exists(TEMPLATEPATH.'/inc/functions/functions.php')) {
    require_once TEMPLATEPATH.'/inc/functions/functions.php';
}else{
    if (extension_loaded('swoole_loader') && function_exists('swoole_loader_version') && w_parse_version_float(swoole_loader_version())>=3.1) {
        $php_v = substr(PHP_VERSION,0,3);
        require_once TEMPLATEPATH.'/inc/functions/functions.'.$php_v.'.php';
    }else{
        $_theme = get_template_directory_uri();
        wp_safe_redirect($_theme.'/help/swoole-compiler-loader.php');die;
    }
}

function w_parse_version_float($version) {
    $versionList = [];
    if (is_string($version)) {
        $rawVersionList = explode('.', $version);
        if (isset($rawVersionList[0])) {
            $versionList[] = $rawVersionList[0];
        }
        if (isset($rawVersionList[1])) {
            $versionList[] = $rawVersionList[1];
        }
    }
    return (float) implode('.',$versionList);
}

/*
==================（重要）请勿修改上方代码==================
************************************************************
==================二次开发功能请添加在下面==================
*/

