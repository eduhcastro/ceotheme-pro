<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="applicable-device"content="pc,mobile">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php include_once("inc/functions/seo.php"); ?>
<?php wp_head();?>
<link rel="stylesheet" href="https://at.alicdn.com/t/c/font_4073586_5fq4g109min.css"/>
<link rel="stylesheet" href="https://lf6-cdn-tos.bytecdntp.com/cdn/expire-1-M/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="shortcut icon" href="<?php echo _ceo('favicon'); ?>"/>
</head>
	<body>
	    <style>
		<?php echo _ceo('diy_css'); ?>
		</style>
		<div id="ceotheme">
			<?php get_template_part( 'template-parts/navbar/navbar', '1' ); ?>
			<main>