<?php if (! defined('ABSPATH')) {
	die;
}
/**
 * CeoNova-Pro主题是一款极致美观强大的WordPress付费产品官网主题。
 * 正版唯一购买地址：https://www.ceotheme.com/
 * CeoNova-Pro主题官方演示站点：http://ceonova-pro.ceotheme.com/
 * 作者总裁QQ：110300260 （总裁）
 * CeoNova-Pro主题是一款轻量级、且简洁大气、产品官网类主题，定位于高端产品官网、同时包含了知识付费、定制服务、问答社区、论坛交流、网址导航、以及付费产品下载等全方位覆盖。
 * 能理解使用盗版的人，但是不能接受传播盗版。
 * CeoTheme总裁主题制作的CeoNova-Pro主题正版用户可享受该主题不限制域名，不限制数量，无限授权，仅限本人享有此特权，外泄主题包将取消授权资格！
 * 开发者不易，感谢支持，全天候在线客户服务+技术支持为您服务。
 */


if (class_exists('CSF')) {
    $prefix = 'ceonova';
    CSF::createOptions($prefix, array(
        'menu_title'      => 'CeoNova-Pro主题',
        'menu_slug'       => 'my-framework',
        'framework_title' => '<i class="fa fa-laptop"></i> CeoNova-Pro主题  │ <small><a href="https://www.ceotheme.com" target="_blank" style="text-decoration:none;color:#fff;">Theme By 总裁主题 CeoTheme.com</a></small>',
    ));

    /*
     * ------------------------------------------------------------------------------
     * 基本设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($prefix, array(
        'id'      => 'ceotheme_basic',
        'icon'    => 'fa fa-cog',
        'title'   => '基本设置',
        'fields'  => array(
            array(
                'id'           => 'head_logo',
                'type'         => 'upload',
                'title'        => '网站基础LOGO图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'desc'         => '网站亮色LOGO图片',
                'default'      => get_template_directory_uri() . '/static/images/ceotheme-logo.png',
            ),
            array(
                'id'           => 'head_logo_n',
                'type'         => 'upload',
                'title'        => '网站顶部透明LOGO图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'desc'         => '网站顶部导航透明LOGO图片',
                'default'      => get_template_directory_uri() . '/static/images/ceotheme-logo-n.png',
            ),
            array(
                'id'           => 'favicon',
                'type'         => 'upload',
                'title'        => '网站favicon.ico图标',
                'desc'         => '浏览器/收藏夹图标 <a href="https://ico.ceotheme.com/" target="_blank" style="color: #0a8eff;">点击这里立即生成</a> 网站favicon.ico图标',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
            ),
        ),

    ));

    /*
     * ------------------------------------------------------------------------------
     * SEO设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($prefix, array(
        'id'     => 'ceotheme_seo',
        'icon'   => 'fa fa-desktop',
        'title'  => 'SEO设置',
        'fields' => array(
            array(
                'id'    => 'website_title',
                'type'  => 'text',
                'title' => '网站标题',
            ),
            array(
                'id'    => 'website_keywords',
                'type'  => 'text',
                'title' => '网站关键词',
            ),
            array(
                'id'    => 'website_description',
                'type'  => 'textarea',
                'title' => '网站描述',
            ),
            array(
                'id'       => 'category',
                'type'     => 'switcher',
                'title'    => '去掉分类目录中的category',
                'default'  => true,
                'subtitle' => '去掉分类目录中的category，精简URL，有利于SEO，推荐去掉',
            ),
        )
    ));

    /*
     * ------------------------------------------------------------------------------
     * 顶部设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($prefix, array(
        'id'     => 'ceotheme_top',
        'icon'   => 'fa fa-paper-plane',
        'title'  => '顶部设置',
    ));
    CSF::createSection($prefix, array(
        'parent'     => 'ceotheme_top',
        'title'  => '导航按钮设置',
        'fields' => array(
            array(
                'id'      => 'navbar_search',
                'type'    => 'switcher',
                'title'   => '顶部导航搜索按钮',
                'desc'    => '开启或关闭顶部导航搜索按钮（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            array(
                'id'         => 'navbar_search_h',
                'type'       => 'switcher',
                'dependency' => array( 'navbar_search', '==', true ),
                'title'      => '搜索框热门标签',
                'desc'       => '开启或关闭弹出搜索框热门标签（开启则显示，关闭则隐藏）',
                'default'    => true
            ),
            array(
                'id'      => 'navbar_user',
                'type'    => 'switcher',
                'title'   => '顶部导航登录注册按钮',
                'desc'    => '开启或关闭顶部导航登录注册按钮（开启则显示，关闭则隐藏）',
                'default' => true
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent'     => 'ceotheme_top',
        'title'  => '顶部用户弹窗',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '以下默认参数正常情况下无需修改！',
            ),
            array(
                'id'      => 'ceo_user_t_yexf',
                'type'    => 'switcher',
                'title'   => '余额/消费模块',
                'desc'    => '开启或关闭余额/消费模块（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_user_t_vip',
                'type'    => 'switcher',
                'title'   => 'VIP级别/升级VIP',
                'desc'    => '开启或关闭VIP级别/升级VIP模块（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'         => 'ceo_user_t_vip_sz',
                'type'       => 'fieldset',
                'dependency' => array('ceo_user_t_vip', '==', true),
                'title'      => 'VIP模块设置',
                'fields'     => array(
                    array(
                        'id'      => 'ceo_user_t_vip_title',
                        'type'    => 'text',
                        'title'   => 'VIP标题',
                        'default' => '升级VIP',
                    ),
                    array(
                        'id'      => 'ceo_user_t_vip_link',
                        'type'    => 'text',
                        'title'   => '升级链接',
                        'default' => '/member/center/',
                    ),
                    array(
                        'id'      => 'ceo_user_t_vip_desc',
                        'type'    => 'text',
                        'title'   => 'VIP描述',
                        'default' => '升级VIP尊享全站海量下载！',
                    ),
                ),
            ),
            array(
                'id'         => 'ceo_user_gr_sz',
                'type'       => 'fieldset',
                'title'      => '个人中心按钮设置',
                'fields'     => array(
                    array(
                        'id'      => 'ceo_user_gr_title',
                        'type'    => 'text',
                        'title'   => '按钮标题',
                        'default' => '个人中心',
                    ),
                    array(
                        'id'      => 'ceo_user_gr_icon',
                        'type'    => 'text',
                        'title'   => '按钮图标',
                        'default' => 'ceoicon-user-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'ceo_user_gr_link',
                        'type'    => 'text',
                        'title'   => '按钮链接',
                        'default' => '/user',
                    ),
                ),
            ),
            array(
                'id'         => 'ceo_user_sc_sz',
                'type'       => 'fieldset',
                'title'      => '商城中心按钮设置',
                'fields'     => array(
                    array(
                        'id'      => 'ceo_user_sc_title',
                        'type'    => 'text',
                        'title'   => '按钮标题',
                        'default' => '商城中心',
                    ),
                    array(
                        'id'      => 'ceo_user_sc_icon',
                        'type'    => 'text',
                        'title'   => '按钮图标',
                        'default' => 'ceoicon-shopping-cart-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'ceo_user_sc_link',
                        'type'    => 'text',
                        'title'   => '按钮链接',
                        'default' => '/member/center/',
                    ),
                ),
            ),
        )
    ));

    /*
     * ------------------------------------------------------------------------------
     * 用户中心
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($prefix, array(
        'id'    => 'ceotheme_user',
        'icon'  => 'fa fa-user',
        'title' => '用户中心',
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_user',
        'title'  => '基本设置 ',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线（用户中心背景图）',
            ),
            array(
                'id'      => 'user-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （用户中心设置）',
            ),
            array(
                'id'           => 'side_author_homeimg',
                'type'         => 'upload',
                'title'        => '用户个人主页背景图片',
                'desc'         => '用户个人主页默认背景图，用户也可以在个人中心独立设置用户个人主页背景图~未独立设置则自动调用该设置中默认背景图',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （用户中心菜单设置，以下功能开启则显示，关闭则隐藏）',
            ),
            array(
                'id'      => 'ceo_author_cdshop',
                'type'    => 'switcher',
                'title'   => '商城中心',
                'default' => true,
            ),
            array(
                'id'       => 'ceo_author_cdshopt',
                'type'     => 'text',
                'dependency' => array('ceo_author_cdshop', '==', true),
                'title'    => '商城中心按钮标题',
                'default'  => '商城中心',
            ),
            array(
                'id'       => 'ceo_author_cdshopl',
                'type'     => 'text',
                'dependency' => array('ceo_author_cdshop', '==', true),
                'title'    => '商城中心按钮链接',
                'default'  => '/member/center/',
            ),
            array(
                'id'      => 'ceo_author_cd1',
                'type'    => 'switcher',
                'title'   => '我的收藏',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_author_cd2',
                'type'    => 'switcher',
                'title'   => '我的关注',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_author_cd3',
                'type'    => 'switcher',
                'title'   => '我的私信',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_author_cd4',
                'type'    => 'switcher',
                'title'   => '我的提问',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_author_cd5',
                'type'    => 'switcher',
                'title'   => '我的帖子',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_author_cd6',
                'type'    => 'switcher',
                'title'   => '我的评论',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_author_cd7',
                'type'    => 'switcher',
                'title'   => '我的网站',
                'default' => true,
            ),
            array(
                'id'       => 'ceo_author_cd7x',
                'type'     => 'textarea',
                'dependency' => array('ceo_author_cd7', '==', true),
                'title'    => '网站收录提示信息',
                'desc'     => '请务必按照以上格式修改或添加',
                'default'  => '<p>欢迎优质网站提交收录，本站免费收录，提交后需后台审核，请勿重复提交。</p>
<p>申请网站收录前请先加上本站链接；</p>
<p>本站不收录违法违规站点；</p>
<p>禁止一切产品营销、广告联盟类型的站点，优先通过原创、内容相近的网站；</p>',
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_user',
        'title'  => '登录注册 ',
        'fields' => array(
            array(
                'id'      => 'navbar_login',
                'type'    => 'button_set',
                'title'   => '登录注册模式',
                'options' => array(
                    '1' => '弹窗模式',
                    '2' => '页面模式',
                ),
                'default' => '1',
                'desc'    => '（默认弹窗模式）选择弹窗模式时可在任意界面弹出登录注册框，页面模式则跳转登录注册页面。',
            ),
            array(
                'id'           => 'tlogin_bg',
                'type'         => 'upload',
                'title'        => '登录注册弹窗背景图片',
                'dependency' => array('navbar_login', '==', '1'),
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
            ),
            array(
                'id'      => 'tlogin_notice',
                'type'    => 'textarea',
                'dependency' => array('navbar_login', '==', '1'),
                'title'   => '登录注册弹窗文字',
                'default' => '总裁主题 - 为创业者及创业公司提供有用的、实用的线上产品。',
            ),
            array(
                'id'           => 'login_bg',
                'type'         => 'upload',
                'title'        => '登录注册背景图片',
                'dependency' => array('navbar_login', '==', '2'),
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
            ),
            array(
                'id'      => 'login_notice',
                'type'    => 'textarea',
                'dependency' => array('navbar_login', '==', '2'),
                'title'   => '登录注册页面通知文字',
                'default' => '好久不见甚是想念。',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （邀请码注册设置）',
            ),
            array(
                'id'      => 'is_invitaion_code',
                'type'    => 'switcher',
                'title'   => '邀请码注册',
                'desc'    => '开启或关闭邀请码注册功能（开启则需要填写正确邀请码才能注册，关闭则无需）提示：在后台菜单左侧的 <a href="/wp-admin/admin.php?page=invitation_code_add" style="color: #0a8eff;">“邀请码”</a> 中生成邀请码',
                'default' => false,
            ),
            array(
                'id'      => 'is_invitaion_title',
                'type'    => 'text',
                'title'   => '按钮标题',
                'default' => '获取邀请码',
                'dependency' => array('is_invitaion_code', '==', true),
            ),
            array(
                'id'      => 'is_invitaion_link',
                'type'    => 'text',
                'title'   => '按钮链接',
                'dependency' => array('is_invitaion_code', '==', true),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （表单登录/注册设置）',
            ),
            array(
                'id'      => 'ceo_login_txt',
                'type'    => 'switcher',
                'title'   => '表单登录/注册',
                'desc'    => '开启或关闭表单账号密码登录/注册（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_login_zcxy',
                'type'    => 'text',
                'title'   => '注册协议标题',
                'default' => '《注册协议》',
                'dependency' => array('ceo_login_txt', '==', true),
            ),
            array(
                'id'      => 'ceo_login_zcxy_link',
                'type'    => 'text',
                'title'   => '注册协议链接',
                'dependency' => array('ceo_login_txt', '==', true),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （QQ登录设置）',
            ),
            array(
                'id'      => 'qq_login',
                'type'    => 'switcher',
                'title'   => 'QQ登录',
                'default' => false,
            ),
            array(
                'type'       => 'content',
                'content'    => 'QQ登录申请：<a href="https://connect.qq.com" target="_blank">点击去申请</a>',
                'dependency' => array('qq_login', '==', true),
            ),
            array(
                'type'       => 'content',
                'content'    => 'QQ回调地址：'. get_stylesheet_directory_uri() . '/qq.php',
                'dependency' => array( 'qq_login', '==', true ),
            ),
            array(
                'id'         => 'qq_app_id',
                'type'       => 'text',
                'title'      => 'QQ-APP ID',
                'attributes' => array('style'=> 'width: 100%;'),
                'dependency' => array( 'qq_login', '==', true ),
            ),
            array(
                'id'         => 'qq_app_key',
                'type'       => 'text',
                'title'      => 'QQ-APP KEY',
                'attributes' => array('style'=> 'width: 100%;'),
                'dependency' => array( 'qq_login', '==', true ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （微信登录设置）',
            ),
            // 微信登录
            array(
                'id'      => 'weixin_login',
                'type'    => 'switcher',
                'title'   => '微信登录（开放平台模式）',
                'default' => false,
            ),
            array(
                'type'       => 'content',
                'content'    => '微信登录申请：<a href="https://open.weixin.qq.com/" target="_blank">点击去申请</a>',
                'dependency' => array('weixin_login', '==', true),
            ),
            array(
                'id'         => 'oauth_weixin',
                'type'       => 'fieldset',
                'title'      => '微信登录配情',
                'fields'     => array(
                    array(
                        'id'         => 'backurl',
                        'type'       => 'text',
                        'title'      => '开放平台 回调地址',
                        'attributes' => array(
                            'readonly' => 'readonly',
                        ),
                        'default' => esc_url(home_url('')).'/oauth/weixin/callback',
                        'desc'    => '更换域名时请重置当前分区即可刷新为最新回调地址，操作前注意备份appid参数<br />注意：回调地址只需填写网站域名，无需填写http://或https://<br />例：www.ceotheme.com',
                    ),
                    array(
                        'id'      => 'appid',
                        'type'    => 'text',
                        'title'   => '开放平台 Appid',
                        'default' => '',
                    ),
                    array(
                        'id'      => 'appkey',
                        'type'    => 'text',
                        'title'   => '开放平台 AppSecret',
                        'default' => '',
                        'attributes'  => array(
                            'type'      => 'password',
                            'autocomplete' => 'off',
                        ),
                    ),
                ),
                'dependency' => array('weixin_login', '==', 'true'),
            ),

            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （微信公众号登录设置）',
            ),
            // 微信公众号登录
            array(
                'id'      => 'is_oauth_mpweixin',
                'type'    => 'switcher',
                'title'   => '微信公众号登录（公众号模式）',
                'desc'   => '总裁主题提示您：需要认证微信服务号，配置以下信息后，用户首次使用微信注册登录需要在你的网站扫码关注公众号后自动注册并登录，第二次登录直接扫码即可登录，同时可以直接在公众号内登录',
                'default' => false,
            ),
            array(
                'type'       => 'content',
                'content'    => '微信公众号登录申请：<a href="https://mp.weixin.qq.com/" target="_blank">点击去申请</a>',
                'dependency' => array('is_oauth_mpweixin', '==', true),
            ),
            array(
                'id'         => 'oauth_mpweixin',
                'type'       => 'fieldset',
                'title'      => '配置详情',
                'fields'     => array(
                    array(
                        'id'      => 'mp_appid',
                        'type'    => 'text',
                        'title'   => '公众号Appid',
                        'default' => '',
                    ),
                    array(
                        'id'      => 'mp_appsecret',
                        'type'    => 'text',
                        'title'   => '公众号appsecret',
                        'default' => '',
                        'attributes'  => array(
                            'type'      => 'password',
                            'autocomplete' => 'off',
                        ),
                    ),
                    array(
                        'id'      => 'mp_token',
                        'type'    => 'text',
                        'title'   => '公众号Token',
                        'default' => '',
                        'attributes'  => array(
                            'type'      => 'password',
                            'autocomplete' => 'off',
                        ),
                    ),

                    array(
                        'id'         => 'mp_backurl',
                        'type'       => 'text',
                        'title'      => '授权回调页面域名',
                        'attributes' => array(
                            'readonly' => 'readonly',
                        ),
                        'default'    => esc_url(home_url('/oauth/mpweixin/callback')),
                        'desc'    => '更换域名时请重置当前分区即可刷新为最新回调地址，操作前注意备份appid参数',
                    ),
                    array(
                        'id'      => 'mp_msg',
                        'type'    => 'textarea',
                        'title'   => '关注后自动回复的消息',
                        'default' => '您好，感谢关注我们！发送“签到”可获得奖励，发生关键词可搜索站内相关文章~',
                    ),

                ),
                'dependency' => array('is_oauth_mpweixin', '==', 'true'),
            ),
            array(
                'id'     => 'mpweixin_menu',
                'type'   => 'repeater',
                'title'  => '自定义公众号菜单',
                'desc'  => '总裁主题提示您：<br>
自定义公众号菜单可创建3个一级菜单，每个一级菜单可创建5个二级菜单。<br>
一级菜单不超过4个汉字，二级菜单不超过8个汉字，超过的文字会被以“...”代替。<br>',
                'dependency' => array('is_oauth_mpweixin', '==', 'true'),
                'fields' => array(
                    array(
                        'id'      => 'menu_name',
                        'type'    => 'text',
                        'title'   => '菜单名称',
                        'default' => '',
                    ),
                    array(
                        'id'      => 'menu_url',
                        'type'    => 'text',
                        'title'   => '菜单链接',
                        'default' => '',
                        'desc'    => '如果设置了二级菜单，那么一级菜单的菜单链接将会失效，这是公众号的规则。',
                    ),
                    array(
                        'id'     => 'mpweixin_menu_sub',
                        'type'   => 'repeater',
                        'title'  => '二级菜单',
                        'fields' => array(
                            array(
                                'id'      => 'menu_name',
                                'type'    => 'text',
                                'title'   => '菜单名称',
                                'default' => '',
                            ),
                            array(
                                'id'      => 'menu_url',
                                'type'    => 'text',
                                'title'   => '菜单链接',
                                'validate' => 'csf_validate_url',
                                'default' => '',
                            ),
                            array(
                                'type'    => 'notice',
                                'style'   => 'warning',
                                'content' => '分割线',
                            ),
                        ),
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
            array(
                'id'    => 'mpweixin_menu_update',
                'type'  => 'subheading',
                'title' => '刷新公众号菜单',
                'dependency' => array('is_oauth_mpweixin', '==', 'true'),
                'content'       => '<a href="admin-ajax.php?action=mpweixin_menu_update" target="_blank"><input type="button" value="点击刷新公众号菜单"></a> <br /><br />一：创建好公众号菜单，二：点击右上角保存，三：在点击刷新公众号菜单按钮',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （微博登录设置）',
            ),
            array(
                'id'      => 'weibo_login',
                'type'    => 'switcher',
                'title'   => '微博登录',
                'default' => false,
            ),
            array(
                'type'       => 'content',
                'content'    => '微博登录申请：<a href="https://open.weibo.com/authentication/" target="_blank">点击去申请</a>',
                'dependency' => array('weibo_login', '==', true),
            ),
            array(
                'type'       => 'content',
                'content'    => '微博回调地址：'. get_page_link( get_option('joy_framework')['login_page'] ) .'/?type=sina',
                'dependency' => array( 'weibo_login', '==', true ),
            ),
            array(
                'id'         => 'weibo_app_key',
                'type'       => 'text',
                'title'      => '微博 App Key',
                'attributes' => array('style'=> 'width: 100%;'),
                'dependency' => array( 'weibo_login', '==', true ),
            ),
            array(
                'id'         => 'weibo_app_id',
                'type'       => 'text',
                'title'      => '微博 App Secret',
                'attributes' => array('style'=> 'width: 100%;'),
                'dependency' => array( 'weibo_login', '==', true ),
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent'     => 'ceotheme_user',
        'title'  => '商城中心',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线（商城中心背景图）',
            ),
            array(
                'id'      => 'shop-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'id'      => 'ceo_user_member_btn',
                'type'    => 'switcher',
                'title'   => '商城快捷按钮',
                'desc'    => '开启或关闭商城快捷按钮（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'         => 'ceo_user_member_btn_set',
                'type'       => 'fieldset',
                'title'      => '商城快捷按钮设置',
                'dependency' => array('ceo_user_member_btn', '==', true),
                'fields'     => array(
                    array(
                        'id'      => 'title1',
                        'type'    => 'text',
                        'title'   => '按钮1标题',
                        'default' => '创作中心',
                    ),
                    array(
                        'id'      => 'icon1',
                        'type'    => 'text',
                        'title'   => '按钮1图标',
                        'default' => 'ceoicon-edit-box-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'link1',
                        'type'    => 'text',
                        'title'   => '按钮1链接',
                        'default' => '/tougao',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                    array(
                        'id'      => 'title2',
                        'type'    => 'text',
                        'title'   => '按钮2标题',
                        'default' => '个人中心',
                    ),
                    array(
                        'id'      => 'icon2',
                        'type'    => 'text',
                        'title'   => '按钮2图标',
                        'default' => 'ceoicon-user-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'link2',
                        'type'    => 'text',
                        'title'   => '按钮2链接',
                        'default' => '/user',
                    ),
                ),
            ),
        )
    ));
    
    require __DIR__ .'/../../ceoshop/inc/options/ceotheme-admin.php';
    
    /*
     * ------------------------------------------------------------------------------
     * 首页设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($prefix, array(
        'id'    => 'ceotheme_home',
        'icon'  => 'fa fa-home',
        'title' => '首页设置',
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_home',
        'title'  => '首页布局',
        'fields' => array(
            array(
                'id'        => 'layout',
                'type'      => 'sorter',
                'title'     => '首页模块布局拖拽设置',
                'default'   => array(
                    'enabled'  => array(
                        'slide'     => '幻灯模块',
                        'card'      => '卡片模块',
                        'vip'       => '会员模块',
                        'spread'    => '宣传模块',
                        'file'      => '文档模块',
                        'community' => '社区模块',
                        'news'      => '资讯模块',
                    ),
                    'disabled' => array(
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_home',
        'title'  => '幻灯模块设置',
        'fields' => array(
            //幻灯样式
            array(
                'id'         => 'slide2',
                'type'       => 'repeater',
                'title'      => '幻灯样式图片设置',
                'desc'       => '幻灯片尺寸1920px*630px',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'url',
                        'type'    => 'text',
                        'title'   => '图片链接',
                        'default' =>'/',
                    ),
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '幻灯片图片',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
            //幻灯CMS设置
            array(
                'id'         => 'slide_cms',
                'type'       => 'repeater',
                'title'      => '幻灯CMS设置',
                'fields'     => array(
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '链接',
                    ),
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '图片',
                        'desc'    => '建议尺寸高33px宽33px',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'subtitle',
                        'type'    => 'text',
                        'title'   => '副标题',
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => '描述',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_home',
        'title'  => '卡片模块设置',
        'fields' => array(
            array(
                'id'          => 'card_title',
                'type'        => 'text',
                'title'       => '模块标题',
                'default'     => '总裁智慧行业解决方案',
            ),
            array(
                'id'          => 'card_subtitle',
                'type'        => 'text',
                'title'       => '模块标题',
                'default'     => '满足付费资源、企业官网、课程门户及图片素材等不同场景业务需求',
            ),
            array(
                'id'          => 'card_more',
                'type'        => 'text',
                'title'       => '查看更多标题',
                'default'     => '查看更多作品',
            ),
            array(
                'id'        => 'card_sz',
                'type'      => 'fieldset',
                'title'     => '模块内容设置',
                'fields'    => array(
                    array(
                        'id'          => 'cat_id',
                        'type'        => 'select',
                        'title'       => '分类选择',
                        'placeholder' => '选择分类',
                        'options'     => 'categories',
                    ),
                    array(
                        'id'          => 'num',
                        'type'        => 'text',
                        'title'       => '显示数量',
                        'default'     => '6',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_home',
        'title'  => '会员模块设置',
        'fields' => array(
            array(
                'id'           => 'homevip_img',
                'type'         => 'upload',
                'title'        => '模块背景图',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo-home-vip-bg.png',
            ),
            array(
                'id'          => 'homevip_title',
                'type'        => 'text',
                'title'       => '模块标题',
                'default'     => '总裁会员尊享权益',
            ),
            array(
                'id'          => 'homevip_subtitle',
                'type'        => 'text',
                'title'       => '模块标题',
                'default'     => '成为我们的VIP会员，尊享无限免费下载使用，更享受全面的服务与福利。',
            ),
            array(
                'id'      => 'homevip_type',
                'type'    => 'image_select',
                'title'   => '<h3>选择会员模块样式</h3>',
                'options' => array(
                    '1' => get_template_directory_uri() . '/static/images/ceo-htvip-1.png',
                    '2' => get_template_directory_uri() . '/static/images/ceo-htvip-2.png',
                ),
                'desc'    => '样式1：4个模块，调用会员页面的设置内容，样式2：2个模块，自定义模块信息',
                'default' => '1'
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_home',
        'title'  => '宣传模块设置',
        'fields' => array(
            array(
                'id'          => 'spread_title',
                'type'        => 'text',
                'title'       => '模块标题',
                'default'     => '您有充足的理由选择我们',
            ),
            array(
                'id'          => 'spread_subtitle',
                'type'        => 'text',
                'title'       => '模块标题',
                'default'     => '世界上超过40%的网站是由WordPress搭建，而我们是国内最懂你的WordPress主题开发商',
            ),
            array(
                'id'         => 'spread_sz',
                'type'       => 'repeater',
                'title'      => '模块设置',
                'fields'     => array(
                    array(
                        'id'    => 'img',
                        'type'  => 'upload',
                        'title' => '图片',
                        'desc'  => '建议尺寸高40px宽40px',
                    ),
                    array(
                        'id'    => 'title',
                        'type'  => 'text',
                        'title' => '标题',
                    ),
                    array(
                        'id'    => 'desc',
                        'type'  => 'textarea',
                        'title' => '描述',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_home',
        'title'  => '文档模块设置',
        'fields' => array(
            array(
                'id'      => 'ceo_file_title',
                'type'    => 'text',
                'title'   => '模块标题',
                'default' => '总裁产品使用文档中心'
            ),
            array(
                'id'      => 'ceo_file_subtitle',
                'type'    => 'text',
                'title'   => '副标题',
                'default' => '总裁为您准备了各种产品使用教程及常见问题解决方案'
            ),
            array(
                'id'     => 'ceo_file_only',
                'type'   => 'repeater',
                'title'  => '分类标题模块设置',
                'fields' => array(
                    array(
                        'id'          => 'id',
                        'type'        => 'select',
                        'title'       => '选择分类栏目',
                        'placeholder' => '选择分类栏目',
                        'options'     => 'categories',
                    ),
                    array(
                        'id'           => 'img',
                        'type'         => 'upload',
                        'title'        => '封面图片',
                        'library'      => 'image',
                        'placeholder'  => 'http://',
                        'button_title' => '上传',
                        'remove_title' => '删除',
                    ),
                    array(
                        'id'      => 'num',
                        'type'    => 'text',
                        'title'   => '显示数量',
                        'default' => '5',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_home',
        'title'  => '社区模块设置',
        'fields' => array(
            array(
                'id'           => 'community_img',
                'type'         => 'upload',
                'title'        => '模块背景图',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo-home-community-bg.png',
            ),
            array(
                'id'          => 'community_title',
                'type'        => 'text',
                'title'       => '模块标题',
                'default'     => '总裁社区，行业大牛疑难解答',
            ),
            array(
                'id'          => 'community_subtitle',
                'type'        => 'text',
                'title'       => '模块标题',
                'default'     => '汇聚技术领域名师大咖，共同学习讨论，知识问答、讲师学员交流，知识点分享等。',
            ),
            //快捷模块设置
            array(
                'id'         => 'community_cms',
                'type'       => 'repeater',
                'title'      => '快捷模块设置',
                'fields'     => array(
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '图片',
                        'desc'    => '建议尺寸高47px宽自定',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '链接',
                    ),
                ),
            ),
            //问答模块设置
            array(
                'id'           => 'community_q_sz',
                'type'         => 'fieldset',
                'title'        => '问答模块设置',
                'fields'       => array(
                    array(
                        'id'           => 'community_q_img',
                        'type'         => 'upload',
                        'title'        => '模块背景',
                        'placeholder'  => 'http://',
                        'button_title' => '上传',
                        'remove_title' => '删除',
                    ),
                    array(
                        'id'           => 'community_q_title',
                        'type'         => 'text',
                        'title'        => '模块标题',
                        'default'      => '问答中心',
                    ),
                    array(
                        'id'           => 'community_q_link',
                        'type'         => 'text',
                        'title'        => '模块连接',
                        'default'      => '/question',
                    ),
                ),
            ),
            //论坛模块设置
            array(
                'id'           => 'community_f_sz',
                'type'         => 'fieldset',
                'title'        => '问答模块设置',
                'fields'       => array(
                    array(
                        'id'           => 'community_f_img',
                        'type'         => 'upload',
                        'title'        => '模块背景',
                        'placeholder'  => 'http://',
                        'button_title' => '上传',
                        'remove_title' => '删除',
                    ),
                    array(
                        'id'           => 'community_f_title',
                        'type'         => 'text',
                        'title'        => '模块标题',
                        'default'      => '论坛社区',
                    ),
                    array(
                        'id'           => 'community_f_link',
                        'type'         => 'text',
                        'title'        => '模块连接',
                        'default'      => '/forum',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_home',
        'title'  => '资讯模块设置',
        'fields' => array(
            array(
                'id'          => 'news_title',
                'type'        => 'text',
                'title'       => '模块标题',
                'default'     => '官方最新动态',
            ),
            array(
                'id'          => 'news_subtitle',
                'type'        => 'text',
                'title'       => '模块标题',
                'default'     => '时刻掌握官方最新动态，全面了解平台讯息',
            ),
            array(
                'id'        => 'news_sz',
                'type'      => 'fieldset',
                'title'     => '模块内容设置',
                'fields'    => array(
                    array(
                        'id'          => 'cat_id',
                        'type'        => 'select',
                        'title'       => '分类选择',
                        'placeholder' => '选择分类',
                        'options'     => 'categories',
                    ),
                    array(
                        'id'          => 'num',
                        'type'        => 'text',
                        'title'       => '显示数量',
                        'default'     => '8',
                    ),
                ),
            ),
        )
    ));

    /*
 * ------------------------------------------------------------------------------
 * 侧边栏设置
 * ------------------------------------------------------------------------------
 */
    CSF::createSection($prefix, array(
        'id'    => 'ceotheme_side',
        'icon'  => 'fa fa-th-list',
        'title' => '右侧边栏',
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_side',
        'title'  => '侧边栏布局',
        'fields' => array(
            array(
                'id'           => 'sidebar_layout',
                'type'         => 'sorter',
                'title'        => '侧边栏布局拖拽设置',
                'default'      => array(
                    'enabled'      => array(
                        'author'   => '作者模块',
                        'slide'    => '幻灯模块',
                        'text'     => '文章展示',
                        'zz'       => '广告模块',
                        'tags'     => '随机标签',
                    ),
                    'disabled'     => array(
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_side',
        'title'  => '作者模块',
        'fields' => array(
            array(
                'id'           => 'side_author_img',
                'type'         => 'upload',
                'title'        => '作者模块背景图片',
                'desc'         => '作者模块默认背景图，用户也可以在个人中心独立设置作者模块背景图~未独立设置则自动调用该设置中默认背景图',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo-author-bg.png',
            ),
            array(
                'id'      => 'side_author_statistics',
                'type'    => 'switcher',
                'title'   => '作者数据统计',
                'desc'    => '隐藏/显示作者数据统计（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'      => 'side_author_gzsx',
                'type'    => 'switcher',
                'title'   => '关注/私信功能',
                'desc'    => '隐藏/显示关注/私信功能按钮（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_side',
        'title'  => '幻灯模块',
        'fields' => array(
            array(
                'id'           => 'sidebar_slide_bg',
                'type'         => 'upload',
                'title'        => '幻灯模块背景图',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
            ),
            array(
                'id'         => 'sidebar_slide',
                'type'       => 'repeater',
                'title'      => '幻灯图片设置',
                'desc'       => '幻灯片尺寸1920px*630px',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'url',
                        'type'    => 'text',
                        'title'   => '链接',
                        'default' =>'/',
                    ),
                    array(
                        'id'           => 'img',
                        'type'         => 'upload',
                        'title'        => '图片',
                        'placeholder'  => 'http://',
                        'button_title' => '上传',
                        'remove_title' => '删除',
                        'default'      => get_template_directory_uri() . '/static/images/ceo-text-title-img.png',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_side',
        'title'  => '文章展示',
        'fields' => array(
            array(
                'id'      => 'text-title',
                'type'    => 'text',
                'title'   => '标题',
                'default' => '文章展示'
            ),
            array(
                'id'           => 'text-title-img',
                'type'         => 'upload',
                'title'        => '标题图标',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo-text-title-img.png',
            ),
            array(
                'id'      => 'text-url',
                'type'    => 'text',
                'title'   => '右侧链接',
                'default' => '/'
            ),
            array(
                'id'          => 'text-cat',
                'type'        => 'select',
                'title'       => '选择展示分类',
                'placeholder' => '请选择分类',
                'options'     => 'categories',
            ),
            array(
                'id'      => 'text-orderby',
                'type'    => 'radio',
                'title'   => '排序',
                'inline'  => true,
                'options' => array(
                    'date'          => esc_html__('日期'),
                    'rand'          => esc_html__('随机'),
                    'comment_count' => esc_html__('评论数量'),
                    'id'            => esc_html__('文章ID'),
                ),
                'default' => 'date',
            ),
            array(
                'id'      => 'text-number',
                'type'    => 'text',
                'title'   => '显示数量',
                'default' => '6'
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_side',
        'title'  => '随机标签',
        'fields' => array(
            array(
                'id'      => 'side-tag-title',
                'type'    => 'text',
                'title'   => '标题',
                'default' => '随机标签'
            ),
            array(
                'id'           => 'side-tag-img',
                'type'         => 'upload',
                'title'        => '标题图标',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo-side-tag-img.png',
            ),
            array(
                'id'      => 'side-tag-num',
                'type'    => 'text',
                'title'   => '标签数量',
                'default' => 20
            ),
            array(
                'id'      => 'side-tag-url',
                'type'    => 'text',
                'title'   => '查看更多',
                'default' => '/tags',
            ),

        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_side',
        'title'  => '广告模块',
        'fields' => array(
            array(
                'id'     => 'side_zz',
                'type'   => 'repeater',
                'title'  => '广告模块设置',
                'fields' => array(
                    array(
                        'id'           => 'img',
                        'type'         => 'upload',
                        'title'        => '广告图片',
                        'library'      => 'image',
                        'placeholder'  => 'http://',
                        'button_title' => '上传',
                        'remove_title' => '删除',
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '广告连接',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
        )
    ));
    /*
 * ------------------------------------------------------------------------------
 * 分类页设置
 * ------------------------------------------------------------------------------
 */
    CSF::createSection($prefix, array(
        'id'    => 'ceotheme_cat',
        'icon'   => 'fa fa-folder-open',
        'title' => '分类设置',
    ));
    CSF::createSection($prefix, array(
        'parent'     => 'ceotheme_cat',
        'title'  => '分类基础设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （缩略图裁剪设置）',
            ),
            array(
                'id'      => 'thumbnail_cj',
                'type'    => 'radio',
                'title'   => '缩略图裁剪模式',
                'options' => array(
                    'timthumb_php' => 'timthumb.php裁剪（默认推荐，可保留高清晰度，图片规范）',
                    'timthumb_theme'  => '主题框架裁剪（原图压缩裁剪，可保留高清晰度，图片规范，服务器带宽太低会影响图片加载速度）',
                    'timthumb_yun'  => '自定义参数裁剪（例如OSS云储存裁剪模式）',
                ),
                'default' => 'timthumb_php',
                'subtitle' => '总裁主题提供的3种模式都可以将缩略图以最完美的标准展示，您可以根据自己的需求选择',
            ),
            array(
                'id'         => 'thumbnail_yun_custom',
                'type'       => 'text',
                'title'      => '自定义参数裁剪设置',
                'dependency' => array('thumbnail_cj', '==', 'timthumb_yun'),
                'default'    => '?x-oss-process=image/resize,m_fill',
                'desc'       => "如阿里云OSS在图片地址后加（?x-oss-process=image/resize,m_fill）<br>
                原理说明，例如本身图片地址是：https://本站域名.com/wp-content/uploads/2019/08/a.jpg<br>
                使用云储存插件接入oss后是https://oss云储存域名.com/wp-content/uploads/2021/01/01.png<br>
                加入自定义参数后是，https://oss域名.com/wp-content/uploads/2021/01/01.png?x-oss-process=image/resize,m_fill，即可实现oss裁剪<br>
                注意：主题已经在对应位置添加了图片宽高，因此无需添加h_xxx,w_xxx,h_高度，w_宽度",
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （分类基础信息设置）',
            ),
            array(
                'id'      => 'ceo_cat_nav_title2',
                'type'    => 'text',
                'title'   => '自定义二级分类标题',
                'default' => '栏目',
            ),
            array(
                'id'      => 'ceo_cat_nav_title3',
                'type'    => 'text',
                'title'   => '自定义三级分类标题',
                'default' => '子栏',
            ),
            array(
                'id'          => 'cat_load',
                'type'        => 'select',
                'title'       => '文章加载方式',
                'placeholder' => '选择文章加载方式',
                'options'     => array(
                    'num'        => '上一页下一页数字加载',
                    'ajax'       => 'AJAX无刷新加载',
                ),
                'default'     => 'num'
            ),
            array(
                'id'         => 'default_thumb',
                'type'       => 'switcher',
                'title'      => '开启/关闭默认缩略图',
                'desc'       => '开启/关闭显示默认缩略图，已设置的文章缩略图依旧显示！',
                'default'    =>  true
            ),
            array(
                'id'           => 'default_thum',
                'type'         => 'upload',
                'title'        => '设置文章默认缩略图',
                'desc'         => '文章没有设置独立特色图时则调用该图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceotheme_no.jpg',
            ),
            array(
                'id'           => 'category_default_bg',
                'type'         => 'upload',
                'title'        => '栏目默认背景图片',
                'desc'         => '分类列表默认背景图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'id'      => 'ceo-cat-tj',
                'type'    => 'switcher',
                'title'   => '分类文章数量统计',
                'desc'    => '隐藏/显示分类文章数量统计（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'      => 'target_blank',
                'type'    => 'switcher',
                'title'   => '新窗口打开文章',
                'desc'    => '点击列表文章跳转新窗口（开启则跳转新窗口，关闭则当前窗口跳转）',
                'label'   => '',
                'default' => false,
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '列表文章设置（以下功能开启则显示，关闭则隐藏）',
            ),
            array(
                'id'      => 'ceo_cat_jg',
                'type'    => 'switcher',
                'title'   => '资源价格',
                'desc'    => '隐藏/显示列表资源价格',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_fl',
                'type'    => 'switcher',
                'title'   => '文章所属分类',
                'desc'    => '隐藏/显示列表文章所属分类',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_tx',
                'type'    => 'switcher',
                'title'   => '作者头像',
                'desc'    => '隐藏/显示列表文章作者头像',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_mc',
                'type'    => 'switcher',
                'title'   => '作者名称',
                'desc'    => '隐藏/显示列表文章作者名称',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_rq',
                'type'    => 'switcher',
                'title'   => '发布日期',
                'desc'    => '隐藏/显示列表发布日期',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_cat_ll',
                'type'    => 'switcher',
                'title'   => '文章浏览量',
                'desc'    => '隐藏/显示列表文章浏览量',
                'default' => true,
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent'     => 'ceotheme_cat',
        'title'  => '商城分类设置',
        'fields' => array(
            array(
                'id'      => 'ceo_shop_cat',
                'type'    => 'switcher',
                'title'   => '商城列表分类菜单总开关',
                'desc'    => '关闭后以下菜单将全部隐藏',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_shop_cat_nav',
                'type'    => 'switcher',
                'title'   => '商城列表分类菜单',
                'desc'    => '隐藏/显示商城列表分类菜单',
                'dependency' => array('ceo_shop_cat', '==', 'true'),
                'default' => true,
            ),
            array(
                'id'      => 'ceo_shop_cat_price',
                'type'    => 'switcher',
                'title'   => '商城列表分类价格筛选',
                'desc'    => '隐藏/显示商城列表分类价格筛选',
                'dependency' => array('ceo_shop_cat', '==', 'true'),
                'default' => true,
            ),
            array(
                'id'      => 'ceo_shop_cat_tj',
                'type'    => 'switcher',
                'title'   => '商城列表分类资源数量统计',
                'desc'    => '隐藏/显示商城列表分类资源数量统计',
                'dependency' => array('ceo_shop_cat', '==', 'true'),
                'default' => true,
            ),
            array(
                'id'      => 'ceo_shop_cat_sort',
                'type'    => 'switcher',
                'title'   => '商城列表分类资源排序',
                'desc'    => '隐藏/显示商城列表分类资源排序',
                'dependency' => array('ceo_shop_cat', '==', 'true'),
                'default' => true,
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '列表资源设置',
            ),
            array(
                'id'      => 'ceo_cat_viptb',
                'type'    => 'switcher',
                'title'   => 'VIP图标',
                'desc'    => '隐藏/显示列表VIP图标',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_shop_cat_antitle',
                'type'    => 'text',
                'title'   => '商城列表按钮标题',
                'default' => '主题介绍',
            ),
        )
    ));
    /*
 * ------------------------------------------------------------------------------
 * 文章页设置
 * ------------------------------------------------------------------------------
 */
    CSF::createSection($prefix, array(
        'id'    => 'ceotheme_single',
        'icon'  => 'fa fa-window-maximize',
        'title' => '内页设置',
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_single',
        'title'  => '内页基础设置',
        'fields' => array(
            array(
                'id'      => 'single-post-bg',
                'type'    => 'upload',
                'title'   => '文章内页顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （内页信息设置，以下开关开启则显示功能，关闭则隐藏功能）',
            ),
            array(
                'id'      => 'single_info_tx',
                'type'    => 'switcher',
                'title'   => '文章作者头像',
                'default' => true,
            ),
            array(
                'id'      => 'single_info_mc',
                'type'    => 'switcher',
                'title'   => '文章作者名称',
                'default' => true,
            ),
            array(
                'id'      => 'single_info_fl',
                'type'    => 'switcher',
                'title'   => '文章所属分类',
                'default' => true,
            ),
            array(
                'id'      => 'single_info_rq',
                'type'    => 'switcher',
                'title'   => '文章发布日期',
                'default' => true,
            ),
            array(
                'id'      => 'single_info_ll',
                'type'    => 'switcher',
                'title'   => '文章浏览数量',
                'default' => true,
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （以下开关开启则显示功能，关闭则隐藏功能）',
            ),
            array(
                'id'      => 'single_foo_sc',
                'type'    => 'switcher',
                'title'   => '文章收藏按钮',
                'default' => true,
            ),
            array(
                'id'      => 'single_foo_ds',
                'type'    => 'switcher',
                'title'   => '文章打赏按钮',
                'default' => true,
            ),
            array(
                'id'         => 'single_foo_ds_wxtext',
                'dependency' => array('single_foo_ds', '==', 'true'),
                'type'       => 'text',
                'title'      => '微信扫码标题',
                'default'    => '微信扫一扫',
            ),
            array(
                'id'           => 'single_foo_ds_wximg',
                'type'         => 'upload',
                'title'        => '微信二维码图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'dependency'   => array('single_foo_ds', '==', 'true'),
                'default'      => get_template_directory_uri() . '/static/images/ceo-ma.png',
            ),
            array(
                'id'         => 'single_foo_ds_zfbtext',
                'dependency' => array('single_foo_ds', '==', 'true'),
                'type'       => 'text',
                'title'      => '支付宝扫码标题',
                'default'    => '支付宝扫一扫',
            ),
            array(
                'id'           => 'single_foo_ds_zfbimg',
                'type'         => 'upload',
                'title'        => '支付宝二维码图片',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'dependency'   => array('single_foo_ds', '==', 'true'),
                'default'      => get_template_directory_uri() . '/static/images/ceo-ma.png',
            ),
            array(
                'id'      => 'single_foo_dz',
                'type'    => 'switcher',
                'title'   => '文章点赞按钮',
                'default' => true,
            ),
            array(
                'id'      => 'single_foo_bq',
                'type'    => 'switcher',
                'title'   => '文章底部版权',
                'default' => true,
            ),
            array(
                'id'         => 'single_foo_bq_text',
                'dependency' => array('single_foo_bq', '==', 'true'),
                'type'       => 'textarea',
                'title'      => '版权文字',
            ),
            array(
                'id'         => 'single_foo_bq_link',
                'type'       => 'switcher',
                'title'      => '版权链接',
                'default'    => true,
                'dependency' => array('single_foo_bq', '==', 'true'),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （以下开关开启则显示功能，关闭则隐藏功能）',
            ),
            array(
                'id'      => 'single_foo_fy',
                'type'    => 'switcher',
                'title'   => '底部文章分页',
                'default' => true,
            ),
            //相关文章模块
            array(
                'id'      => 'xg_show',
                'type'    => 'switcher',
                'title'   => '底部相关文章',
                'default' => true,
            ),
            array(
                'id'         => 'xg_title',
                'type'       => 'text',
                'title'      => '相关文章标题',
                'dependency' => array('xg_show', '==', 'true'),
                'default'    => '相关推荐'
            ),
            array(
                'id'           => 'xg_title_img',
                'type'         => 'upload',
                'title'        => '标题图标',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'dependency'   => array('xg_show', '==', 'true'),
                'default'      => get_template_directory_uri() . '/static/images/ceo-xg-title-img.png',
            ),
            array(
                'id'         => 'xg_num',
                'type'       => 'text',
                'title'      => '相关文章数量',
                'dependency' => array('xg_show', '==', 'true'),
                'default'    => '6'
            ),
            //发表评论模块
            array(
                'id'      => 'comments_close',
                'type'    => 'switcher',
                'title'   => '整站评论',
                'desc'    =>'开启或关闭整站评论功能，不需要评论可以关闭（按钮开启既关闭整站评论）',
                'default' => false
            ),
            array(
                'id'         => 'comments_title',
                'type'       => 'text',
                'title'      => '发表评论标题',
                'dependency' => array('comments_close', '==', 'false'),
                'default'    => '发表评论'
            ),
            array(
                'id'           => 'comments_title_img',
                'type'         => 'upload',
                'title'        => '标题图标',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'dependency'   => array('comments_close', '==', 'false'),
                'default'      => get_template_directory_uri() . '/static/images/ceo-comment-title-img.png',
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_single',
        'title'  => '商城内页设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '商城模块 - 商城默认按钮设置',
            ),
            array(
                'id'         => 'ceo_shop_single_an',
                'type'       => 'fieldset',
                'title'      => '商城默认按钮',
                'fields'     => array(
                    array(
                        'id'      => 'ceo_shop_single_an_xz',
                        'type'    => 'text',
                        'title'   => '购买按钮标题',
                        'default' => '立即购买',
                    ),
                    array(
                        'id'      => 'ceo_shop_single_an_cxz',
                        'type'    => 'text',
                        'title'   => '已购买按钮标题',
                        'title'   => '仅限虚拟商品单套餐时有效',
                        'default' => '立即下载',
                    ),
                    array(
                        'id'      => 'ceo_shop_single_an_ys',
                        'type'    => 'text',
                        'title'   => '查看演示按钮标题',
                        'default' => '查看演示',
                    ),
                    array(
                        'id'      => 'ceo_shop_single_an_hy',
                        'type'    => 'text',
                        'title'   => '升级会员按钮标题',
                        'default' => '升级会员',
                    ),
                    array(
                        'id'      => 'ceo_shop_single_an_hyl',
                        'type'    => 'text',
                        'title'   => '升级会员按钮链接',
                        'default' => '/vip',
                    ),
                    array(
                        'id'         => 'ceo_shop_download_hide_text_l',
                        'type'       => 'text',
                        'title'      => '隐藏信息自定义1',
                        'default'    => '隐藏信息',
                    ),
                    array(
                        'id'         => 'ceo_shop_download_hide_text_2',
                        'type'       => 'text',
                        'title'      => '隐藏信息自定义2',
                        'default'    => '隐藏信息',
                    ),
                    array(
                        'id'      => 'ceo_shop_single_an_zz',
                        'type'    => 'text',
                        'title'   => '联系作者按钮标题',
                        'default' => '联系作者',
                        'desc'    => '作者QQ调用资源发布者个人中心设置的QQ号码'
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '商城模块 - 信息属性框设置',
            ),
            array(
                'id'      => 'ceo_shop_single_xx_bh',
                'type'    => 'switcher',
                'title'   => '资源编号',
                'desc'    => '是否显示资源编号（默认编号是文章的ID）',
                'default' => true,
            ),
            array(
                'id'      => 'ceo_shop_single_xx_bhbt',
                'dependency' => array('ceo_shop_single_xx_bh', '==', true),
                'type'    => 'text',
                'title'   => '资源编号标题',
                'default' => '资源编号',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '商城模块 - 商城帮助中心设置',
            ),
            array(
                'id'       => 'ceo_shop_help',
                'type'     => 'switcher',
                'title'    => '帮助中心模块 ',
                'desc'     => '开启或关闭帮助中心模块（开启则显示关闭则隐藏）',
                'default'  => true,
            ),
            array(
                'id'      => 'shop_help_title',
                'dependency' => array('ceo_shop_help', '==', true),
                'type'    => 'text',
                'title'   => '帮助中心模块标题',
                'default' => '帮助中心',
            ),
            array(
                'id'      => 'shop_help_subtitle',
                'dependency' => array('ceo_shop_help', '==', true),
                'type'    => 'text',
                'title'   => '帮助中心模块副标题',
                'default' => '常见的问题，也是您需要知道的',
            ),
            array(
                'id'         => 'shop_help_sz',
                'type'       => 'repeater',
                'title'      => '常见问题内容设置',
                'dependency' => array('ceo_shop_help', '==', true),
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'content',
                        'type'    => 'textarea',
                        'title'   => '内容',
                        'desc'    => '请根据以上示例添加，注意每一行都需要一个p标签开头及结尾，同时b标签可加粗显示',
                        'default' => '<p><b>永久技术支持</b>：主题购买后可提供<b>永久使用技术支持</b>，使用过程中有任何问题均可联系我们获取技术支持。</p>
<p><b>永久免费使用</b>：购买任意WP主题都可获得<b>永久免费使用权</b>，即一次付费后可以一直使用。</p>
<p><b>售后服务渠道</b>：可通过在线客服（限工作时间）联系我们，也可通过提交服务单的方式获取技术支持。</p>',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_single',
        'title'  => '内页优化设置',
        'fields' => array(
            array(
                'id'       => 'auto_add_tags',
                'type'     => 'switcher',
                'title'    => '自动添加已有关键词 ',
                'default'  => false,
            ),
            array(
                'id'       => 'single_tag_link',
                'type'     => 'switcher',
                'title'    => 'Tag标签自动内链 ',
                'default'  => false,
            ),
            array(
                'id'       => 'single_nofollow',
                'type'     => 'switcher',
                'title'    => '文章外链自动添加nofollow',
                'default'  => true,
                'subtitle' => '防止导出权重',
            ),
            array(
                'id'       => 'single_img_alt',
                'type'     => 'switcher',
                'title'    => '图片自动添加alt',
                'default'  => true,
            ),
            array(
                'id'       => 'single_upload_filter',
                'type'     => 'switcher',
                'title'    => '上传文件重命名',
                'default'  => true,
            ),
            array(
                'id'       => 'single_delete_post_and_img',
                'type'     => 'switcher',
                'title'    => '删除文章时删除图片附件',
                'default'  => true,
            ),

        )
    ));
    CSF::createSection($prefix, array(
        'id'    => 'ceotheme_danye',
        'title' => '单页设置',
        'icon'  => 'fa fa-window-restore',
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_danye',
        'title'  => '单页基本设置',
        'fields' => array(
            //默认页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '默认页设置',
            ),
            array(
                'id'      => 'page-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'page-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            //友链页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '友链页设置',
            ),
            array(
                'id'      => 'links-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'links-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            //标签页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '标签页设置',
            ),
            array(
                'id'      => 'tag-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'tag-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            //存档页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '存档页设置',
            ),
            array(
                'id'      => 'archives-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'archives-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            //合集页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '单页合集设置',
            ),
            array(
                'id'      => 'onepage-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'onepage-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            //错误页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '404错误页设置',
            ),
            array(
                'id'      => '404-bg',
                'type'    => 'upload',
                'title'   => '顶部图片',
                'default' => get_template_directory_uri() . '/static/images/ceo-404.png',
            ),
            array(
                'id'      => '404-text',
                'type'    => 'text',
                'title'   => '错误提示',
                'default' => 'Sorry，页面丢失了，要不返回首页吧？',
            ),
            //网址导航页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '网址导航页设置',
            ),
            array(
                'id'      => 'site-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_danye',
        'title'  => '定制服务设置',
        'fields' => array(
            //定制服务页设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '定制服务页顶部设置',
            ),
            array(
                'id'      => 'apply-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-apply-bg.png',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '定制内容设置',
            ),
            array(
                'id'      => 'apply_mktitle',
                'type'    => 'text',
                'title'   => '定制模块标题',
                'default' => '强大的资深技术团队',
            ),
            array(
                'id'         => 'apply_sz',
                'type'       => 'repeater',
                'title'      => '模块内容设置',
                'fields'     => array(
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '图片',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'price',
                        'type'    => 'text',
                        'title'   => '价格',
                        'default' => '￥<i>999</i>起',
                        'desc'    => '注意按以上格式填写，注意i标签'
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => '描述',
                    ),
                    array(
                        'id'      => 'default',
                        'type'    => 'textarea',
                        'title'   => '内容',
                        'default' => '<li>根据网站设计需求和产品方案</li>
<li>全新的设计网站视觉风格</li>
<li>100%保证和网站效果图一致</li>',
                        'desc'    => '注意按以上格式填写，注意li标'
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '常见问题设置',
            ),
            array(
                'id'      => 'apply_qatitle',
                'type'    => 'text',
                'title'   => '常见问题标题',
                'default' => '服务定制常见问题',
            ),
            array(
                'id'         => 'apply_qasz',
                'type'       => 'repeater',
                'title'      => '常见问题内容设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => '描述',
                    ),
                    array(
                        'id'      => 'antitle',
                        'type'    => 'text',
                        'title'   => '按钮标题',
                        'default' => '还有问题？向官方提问',
                    ),
                    array(
                        'id'      => 'anlink',
                        'type'    => 'text',
                        'title'   => '按钮链接',
                        'default' => '/question',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_danye',
        'title'  => '问答页面设置',
        'fields' => array(
            //问答页面设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '问答中心顶部设置',
            ),
            array(
                'id'      => 'is_enable_question',
                'type'    => 'switcher',
                'title'   => '开启问答功能',
                'default' => true,
                'desc'    => '此按钮关闭后将关闭问答全部功能',
            ),
            array(
                'id'      => 'question-title',
                'type'    => 'text',
                'title'   => '问答中心标题',
                'default' => '问答中心',
            ),
            array(
                'id'      => 'question-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '有问必答！同时学习技能、解决问题。',
            ),
            array(
                'id'      => 'question-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '问答审核设置',
            ),
            array(
                'id'      => 'question_check',
                'type'    => 'switcher',
                'title'   => '提问审核',
                'desc'    => '开启按钮则无需审核直接显示，关闭按钮则需要审核后显示',
                'default' => true
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '友情提示设置',
            ),
            array(
                'id'      => 'question_ts_title',
                'type'    => 'text',
                'title'   => '友情提示标题',
                'default' => '友情提示：',
            ),
            array(
                'id'      => 'question_ts_text',
                'type'    => 'textarea',
                'title'   => '友情提示内容',
                'default' => '<li>①：请勿重复提交内容</li><li>②：请勿提交违法违规内容</li><li>③：提交违法违规内容者将给予永久封号</li>',
                'desc'    => '请根据以上示例添加',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '问答内页设置',
            ),
            array(
                'id'      => 'question_single_bg',
                'type'    => 'upload',
                'title'   => '问答内页顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'id'      => 'question_single_bq',
                'type'    => 'textarea',
                'title'   => '版权声明',
                'default' => '版权：言论仅代表个人观点，不代表官方立场。',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '问答侧边栏设置',
            ),
            array(
                'id'      => 'question_sidebar_ad',
                'type'    => 'upload',
                'title'   => '广告图片',
                'default' => get_template_directory_uri() . '/static/images/ceo-question-ad.png',
            ),
            array(
                'id'      => 'question_sidebar_ad_title',
                'type'    => 'text',
                'title'   => '广告标题',
                'default' => '总裁主题',
            ),
            array(
                'id'      => 'question_sidebar_ad_link',
                'type'    => 'text',
                'title'   => '广告链接',
                'default' => 'https://www.ceotheme.com',
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_danye',
        'title'  => '论坛页面设置',
        'fields' => array(
            //论坛页面设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '论坛社区顶部设置',
            ),
            array(
                'id'      => 'is_enable_forum',
                'type'    => 'switcher',
                'title'   => '是否开启论坛',
                'default' => true,
                'desc'    => '此按钮关闭后将关闭论坛全部功能',
            ),
            array(
                'id'      => 'forum-title',
                'type'    => 'text',
                'title'   => '论坛社区标题',
                'default' => '论坛社区',
            ),
            array(
                'id'      => 'forum-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '汇聚技术领域名师大咖，畅所欲言无畏无惧。',
            ),
            array(
                'id'      => 'forum-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '论坛审核设置',
            ),
            array(
                'id'      => 'forum_check',
                'type'    => 'switcher',
                'title'   => '发帖审核',
                'desc'    => '开启按钮则无需审核直接显示，关闭按钮则需要审核后显示',
                'default' => true
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '友情提示设置',
            ),
            array(
                'id'      => 'forum_ts_title',
                'type'    => 'text',
                'title'   => '友情提示标题',
                'default' => '友情提示：',
            ),
            array(
                'id'      => 'forum_ts_text',
                'type'    => 'textarea',
                'title'   => '友情提示内容',
                'default' => '<li>①：请勿重复提交内容</li><li>②：请勿提交违法违规内容</li><li>③：提交违法违规内容者将给予永久封号</li>',
                'desc'    => '请根据以上示例添加',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '论坛内页设置',
            ),
            array(
                'id'      => 'forum_single_bg',
                'type'    => 'upload',
                'title'   => '论坛内页顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'id'      => 'forum_single_bq',
                'type'    => 'textarea',
                'title'   => '版权声明',
                'default' => '版权：言论仅代表个人观点，不代表官方立场。',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '论坛侧边栏设置',
            ),
            array(
                'id'      => 'forum_sidebar_ad',
                'type'    => 'upload',
                'title'   => '广告图片',
                'default' => get_template_directory_uri() . '/static/images/ceo-question-ad.png',
            ),
            array(
                'id'      => 'forum_sidebar_ad_title',
                'type'    => 'text',
                'title'   => '广告标题',
                'default' => '总裁主题',
            ),
            array(
                'id'      => 'forum_sidebar_ad_link',
                'type'    => 'text',
                'title'   => '广告链接',
                'default' => 'https://www.ceotheme.com',
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_danye',
        'title'  => '会员页面设置',
        'fields' => array(
            //会员页面设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '会员页面顶部设置',
            ),
            array(
                'id'      => 'vip-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'vip-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-cat-bg.jpg',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '会员特权设置',
            ),
            array(
                'id'      => 'vip_tq_title',
                'type'    => 'text',
                'title'   => '会员特权标题',
                'default' => '尊享特权',
            ),
            array(
                'id'      => 'vip_tq_subtitle',
                'type'    => 'text',
                'title'   => '会员特权副标题',
                'default' => '加入VIP，精品学习课程随心学！',
            ),
            array(
                'id'         => 'vip_tq_sz',
                'type'       => 'repeater',
                'title'      => '会员特权内容设置',
                'fields'     => array(
                    array(
                        'id'         => 'ico',
                        'type'       => 'text',
                        'title'      => '图标',
                        'default'    => 'ceoicon-gift-2-line',
                        'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'content',
                        'type'    => 'textarea',
                        'title'   => '副标题',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '常见问题设置',
            ),
            array(
                'id'      => 'vip_qa_title',
                'type'    => 'text',
                'title'   => '常见问题标题',
                'default' => '常见问题',
            ),
            array(
                'id'      => 'vip_qa_subtitle',
                'type'    => 'text',
                'title'   => '常见问题副标题',
                'default' => '为您解决烦忧，总裁主题势在必行！',
            ),
            array(
                'id'         => 'vip_qa_sz',
                'type'       => 'repeater',
                'title'      => '常见问题内容设置',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'content',
                        'type'    => 'textarea',
                        'title'   => '内容',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_danye',
        'title'  => '会员页面2设置',
        'fields' => array(
            //会员页面设置
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '会员页面2顶部设置',
            ),
            array(
                'id'      => 'vip2-text',
                'type'    => 'text',
                'title'   => '短语介绍',
                'default' => '生活不止眼前的苟且，还有诗和远方',
            ),
            array(
                'id'      => 'vip2-bg',
                'type'    => 'upload',
                'title'   => '顶部背景',
                'default' => get_template_directory_uri() . '/static/images/ceo-vip2-bg.svg',
            ),
            array(
                'id'         => 'vip2_js',
                'type'       => 'repeater',
                'title'      => '页面顶部介绍设置',
                'fields'     => array(
                    array(
                        'id'      => 'icon',
                        'type'    => 'text',
                        'title'   => '图标',
                        'default' => 'ceoicon-star-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                        'default' => '商用授权，版权无忧',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线（会员特权设置）',
            ),
            array(
                'id'      => 'vip2_tq_text',
                'type'    => 'text',
                'title'   => '模块标题',
                'default' => '会员尊享特权',
            ),
            array(
                'id'      => 'vip2_tq_desc',
                'type'    => 'text',
                'title'   => '模块简介',
                'default' => '加入VIP，尊享特权，助力创业，让创业更高效',
            ),
            array(
                'id'         => 'vip2_tq',
                'type'       => 'repeater',
                'title'      => '会员特权设置',
                'fields'     => array(
                    array(
                        'id'      => 'img',
                        'type'    => 'upload',
                        'title'   => '图片',
                        'desc'    => '建议尺寸高52px宽52px',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => '描述',
                    ),
                ),
            ),
        )
    ));
    /*
     * ------------------------------------------------------------------------------
     * 广告设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($prefix, array(
        'id'     => 'ceotheme_ad',
        'icon'   => 'fa fa-bell',
        'title'  => '广告设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （内页内容顶部广告设置）',
            ),
            //内页内容顶部广告
            array(
                'id'      => 'single_zz_top_content',
                'type'    => 'switcher',
                'title'   => '内页内容顶部广告',
                'desc'    => '内页内容顶部广告（开启则显示，关闭则隐藏）',
                'default' => false,
            ),
            array(
                'id'         => 'single_zz_top_content_link',
                'type'       => 'text',
                'title'      => '图片链接',
                'dependency' => array('single_zz_top_content', '==', 'true'),
                'default'    => '/'
            ),
            array(
                'id'           => 'single_zz_top_content_img',
                'type'         => 'upload',
                'title'        => '上传图片',
                'dependency'   => array('single_zz_top_content', '==', 'true'),
                'library'      => 'image',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （内页底部广告设置）',
            ),
            //内页底部广告
            array(
                'id'      => 'single_zz_foo_content',
                'type'    => 'switcher',
                'title'   => '内页底部广告',
                'desc'    => '内页底部广告（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'         => 'single_zz_foo_content_link',
                'type'       => 'text',
                'title'      => '图片链接',
                'dependency' => array('single_zz_foo_content', '==', 'true'),
                'default'    => 'https://www.ceotheme.com'
            ),
            array(
                'id'           => 'single_zz_foo_content_img',
                'type'         => 'upload',
                'title'        => '上传图片',
                'dependency'   => array('single_zz_foo_content', '==', 'true'),
                'library'      => 'image',
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'    => get_template_directory_uri() . '/static/images/ceo-ad-single-bottom.png',
            ),
        )
    ));
    /*
     * ------------------------------------------------------------------------------
     * 底部设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($prefix, array(
        'id'     => 'ceotheme_boo',
        'icon'   => 'fa fa-gears',
        'title'  => '底部设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （底部Banner模块设置）',
            ),
            array(
                'id'      => 'ceo_foo_banner',
                'type'    => 'switcher',
                'title'   => '底部Banner模块',
                'desc'    =>'隐藏/显示底部Banner模块（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            array(
                'id'           => 'ceo_foo_banner_bg',
                'type'         => 'upload',
                'title'        => '底部Banner模块背景图',
                'dependency'   => array('ceo_foo_banner', '==', 'true'),
                'placeholder'  => 'http://',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => get_template_directory_uri() . '/static/images/ceo-footer-banner-bg.jpg',
            ),
            array(
                'id'         => 'ceo_foo_banner_title',
                'dependency' => array('ceo_foo_banner', '==', 'true'),
                'type'       => 'text',
                'title'      => '主标题',
                'default'    => '你的前景，远超我们想象',
            ),
            array(
                'id'         => 'ceo_foo_banner_subtitle',
                'dependency' => array('ceo_foo_banner', '==', 'true'),
                'type'       => 'text',
                'title'      => '副标题',
                'default'    => '与百万创作者共同创造',
            ),
            array(
                'id'         => 'ceo_foo_banner_antitle',
                'dependency' => array('ceo_foo_banner', '==', 'true'),
                'type'       => 'text',
                'title'      => '按钮标题',
                'default'    => '申请入驻',
            ),
            array(
                'id'         => 'ceo_foo_banner_anlink',
                'dependency' => array('ceo_foo_banner', '==', 'true'),
                'type'       => 'text',
                'title'      => '按钮链接',
                'default'    => '/',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （底部友情链接设置）',
            ),
            array(
                'id'      => 'link_show',
                'type'    => 'switcher',
                'title'   => '友情链接',
                'desc'    =>'隐藏/显示底部友情链接（开启则显示，关闭则隐藏）<a href="/wp-admin/link-manager.php" style="color: #0a8eff;">前往添加友链</a>',
                'default' => true
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （底部基本设置）',
            ),
            array(
                'id'      => 'cop_text',
                'type'    => 'textarea',
                'title'   => '网站底部版权文字',
                'desc'    => '可以使用html编辑',
                'default' => '© 2021 总裁主题 - CEOTHEME.COM & WordPress Theme. All rights reserved'
            ),
            array(
                'id'      => 'foot_xml-y',
                'type'    => 'switcher',
                'title'   => '网站地图',
                'label'   => '隐藏/显示底部网站地图（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'         => 'foot_xml',
                'type'       => 'text',
                'title'      => '地图地址',
                'desc'       => '<p>网站地图链接地址<h5 class="csf-text-desc" style="color: #0a8eff;">（推荐使用：Google XML Sitemaps 插件）</h5>后台-插件-搜索Google XML Sitemaps-安装谷歌 XML 站点地图-启用',
                'default'    => '/sitemap.xml',
                'dependency' => array('foot_xml-y', '==', 'true'),
            ),
            array(
                'id'      => 'show_beian',
                'type'    => 'switcher',
                'title'   => '网站底部备案号',
                'desc'    =>'隐藏/显示网站备案号（开启则显示，关闭则隐藏）',
                'default' => true
            ),
            array(
                'id'         => 'beian',
                'type'       => 'text',
                'dependency' => array('show_beian', '==', true),
                'title'      => '网站备案号',
                'default'    => '闽ICP备888888888号'
            ),
            array(
                'id'      => 'foot_gongan',
                'type'    => 'switcher',
                'title'   => '是否显示公安备案',
                'desc'    => '隐藏/显示底部公安备案号（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'         => 'foot_gongan_beianhao',
                'dependency' => array('foot_gongan', '==', 'true'),
                'type'       => 'text',
                'title'      => '公安备案号',
                'default'    => '闽公安网备888888888号'
            ),
            array(
                'id'      => 'theme_cop',
                'type'    => 'switcher',
                'title'   => '隐藏/显示主题版权',
                'desc'    => '隐藏版权希望可以在底部友情链接中添加作者网站链接（版权展示已经添加了nofollow标签，搜索引擎不会对作者网站进行追踪，所以如果可以请显示，感谢支持！）',
                'default' => true
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （底部右侧图片设置）',
            ),
            array(
                'id'         => 'ceo_foot_y',
                'type'       => 'repeater',
                'title'      => '底部右侧图片设置',
                'fields'     => array(
                    array(
                        'id'           => 'img',
                        'type'         => 'upload',
                        'title'        => '图片',
                        'desc'         => '高36px宽自定',
                        'placeholder'  => 'http://',
                        'button_title' => '上传',
                        'remove_title' => '删除',
                        'default'      => get_template_directory_uri() . '/static/images/ceo-mx.png',
                    ),
                    array(
                        'id'    => 'title',
                        'type'  => 'text',
                        'title' => '标题',
                    ),
                    array(
                        'id'    => 'link',
                        'type'  => 'text',
                        'title' => '连接',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
        )
    ));
    /*
     * ------------------------------------------------------------------------------
     * 手机设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($prefix, array(
        'id'     => 'ceotheme_boo',
        'icon'   => 'fa fa-tablet',
        'title'  => '手机设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （手机中部菜单设置）',
            ),
            array(
                'id'      => 'ceo_app_zcd',
                'type'    => 'switcher',
                'title'   => '手机中部菜单',
                'desc'    => '开启或关闭手机中部菜单（开启则显示，关闭则隐藏）',
                'default' => false,
            ),
            array(
                'id'         => 'ceo_app_zcd_sz',
                'type'       => 'repeater',
                'title'      => '手机中部菜单设置',
                'dependency' => array('ceo_app_zcd', '==', true),
                'fields'     => array(
                    array(
                        'id'      => 'img',
                        'type'    => 'text',
                        'title'   => '图标',
                        'type'    => 'upload',
                    ),
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                    ),
                    array(
                        'id'      => 'link',
                        'type'    => 'text',
                        'title'   => '链接',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （手机底部菜单设置）',
            ),
            array(
                'id'      => 'ceo_app_foo',
                'type'    => 'switcher',
                'title'   => '手机底部菜单',
                'desc'    => '开启或关闭手机底部菜单（开启则显示，关闭则隐藏）',
                'default' => true,
            ),
            array(
                'id'         => 'ceo_app_foo_sz',
                'type'       => 'fieldset',
                'title'      => '手机底部菜单设置',
                'dependency' => array('ceo_app_foo', '==', true),
                'fields'     => array(
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线 （手机底部左侧菜单设置）',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_ico1',
                        'type'    => 'text',
                        'title'   => '左侧菜单1图标',
                        'default' => 'ceoicon-home-3-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_title1',
                        'type'    => 'text',
                        'title'   => '左侧菜单1标题',
                        'default' => '首页',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_link1',
                        'type'    => 'text',
                        'title'   => '左侧菜单1链接',
                        'default' => '/',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_ico2',
                        'type'    => 'text',
                        'title'   => '左侧菜单2图标',
                        'default' => 'ceoicon-home-3-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_title2',
                        'type'    => 'text',
                        'title'   => '左侧菜单2标题',
                        'default' => '首页',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_link2',
                        'type'    => 'text',
                        'title'   => '左侧菜单2链接',
                        'default' => '/',
                    ),
                    array(
                        'type'    => 'notice',
                        'style'   => 'warning',
                        'content' => '分割线 （手机底部右侧菜单设置）',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_icoy1',
                        'type'    => 'text',
                        'title'   => '右侧菜单1图标',
                        'default' => 'ceoicon-home-3-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_titley1',
                        'type'    => 'text',
                        'title'   => '右侧菜单1标题',
                        'default' => '首页',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_linky1',
                        'type'    => 'text',
                        'title'   => '右侧菜单1链接',
                        'default' => '/',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_icoy2',
                        'type'    => 'text',
                        'title'   => '右侧菜单2图标',
                        'default' => 'ceoicon-home-3-line',
                        'desc'    => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_titley2',
                        'type'    => 'text',
                        'title'   => '右侧菜单2标题',
                        'default' => '首页',
                    ),
                    array(
                        'id'      => 'ceo_app_foo_linky2',
                        'type'    => 'text',
                        'title'   => '右侧菜单2链接',
                        'default' => '/',
                    ),
                ),
            ),
        )
    ));
    //扩展功能设置
    CSF::createSection($prefix, array(
        'id'    => 'ceotheme_function',
        'icon'  => 'fa fa-laptop',
        'title' => '扩展功能',
    ));
    CSF::createSection($prefix, array(
        'parent'     => 'ceotheme_function',
        'title'  => '扩展功能设置',
        'fields' => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （文章随机阅读量）',
            ),
            array(
                'id'      => 'is_rand_views',
                'type'    => 'switcher',
                'title'   => '文章随机阅读量',
                'desc'    => '开启或关闭自动文章阅读量功能（开启则发布文章自动生成，关闭则无）',
                'default' => true,
            ),
            array(
              'id'      => 'is_rand_views_sz_q',
              'dependency' => array('is_rand_views', '==', true),
              'type'    => 'number',
              'title'   => '自定义随机阅读量（起）',
              'default' => 100,
            ),
            array(
              'id'      => 'is_rand_views_sz_z',
              'dependency' => array('is_rand_views', '==', true),
              'type'    => 'number',
              'title'   => '自定义随机阅读量（止）',
              'default' => 1000,
            ),
            array(
              'type'    => 'submessage',
              'style'   => 'info',
              'content' => '自定义随机阅读量（起）与自定义随机阅读量（止）表示如：从100起1000止，100-1000内数值随机，可以自定义自由设置随机值',
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent'     => 'ceotheme_function',
        'title'       => '邮箱功能设置',
        'fields'      => array(
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '总裁主题推荐使用163邮箱发信，更稳定、更高效~',
            ),
            array(
                'id'      => 'mail_smtps',
                'type'    => 'switcher',
                'title'   => 'SMTP邮箱功能',
                'desc'    => '开启或关闭SMTP邮箱功能（注意：开启时请关闭相关功能插件）',
                'default' => false,
            ),
            array(
                'id'       => 'mail_name',
                'type'     => 'text',
                'title'    => '发信邮箱',
                'desc'     => '请填写发信人邮箱帐号',
                'default'  => '88888888@163.com',
                'validate' => 'csf_validate_email',
            ),
            array(
                'id'       => 'mail_nicname',
                'type'     => 'text',
                'title'    => '发信人昵称',
                'desc'     => '请填写发信人昵称',
                'default'  => 'CeoNova-Pro主题',
            ),
            array(
                'id'       => 'mail_host',
                'type'     => 'text',
                'title'    => '邮箱服务器',
                'desc'     => '请填写SMTP邮箱服务器地址',
                'default'  => 'smtp.163.com',
            ),
            array(
                'id'       => 'mail_port',
                'type'     => 'text',
                'title'    => '服务器端口',
                'desc'     => '请填写SMTP邮箱服务器端口',
                'default'  => '465',
            ),
            array(
                'id'       => 'mail_passwd',
                'type'     => 'text',
                'title'    => '邮箱独立密码',
                'desc'     => '请填写SMTP服务器邮箱独立密码（注意：非账号密码）',
                'default'  => '88888888',
                'attributes'  => array(
                    'type'      => 'password',
                    'autocomplete' => 'off',
                ),
            ),
            array(
                'id'      => 'mail_smtpauth',
                'type'    => 'switcher',
                'title'   => '启用SMTPAuth服务',
                'desc'    => '是否启用SMTPAuth服务',
                'default' => true,
            ),
            array(
                'id'       => 'mail_smtpsecure',
                'type'     => 'text',
                'title'    => 'SMTPSecure设置',
                'desc'     => '若启用SMTPAuth服务则填写ssl，若不启用则留空',
                'default'  => 'ssl',
            ),

        ),
    ));
    /*
     * ------------------------------------------------------------------------------
     * 美化设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($prefix, array(
        'id'     => 'ceotheme_qita',
        'icon'   => 'fa fa-paper-plane',
        'title'  => '美化设置',
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_qita',
        'title'  => '右侧跟随设置',
        'fields' => array(
            array(
                'id'      => 'goTop',
                'type'    => 'switcher',
                'title'   => '网站右下角跟随总开关',
                'default' => true
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （活动按钮设置）',
            ),
            array(
                'id'         => 'goTop_hd',
                'type'       => 'switcher',
                'title'      => '活动图标按钮',
                'desc'       =>'开启或关闭活动图标按钮（开启则显示，关闭则隐藏）',
                'dependency' => array('goTop', '==', true),
                'default'    => true
            ),
            array(
                'id'         => 'goTop_hd_link',
                'type'       => 'text',
                'title'      => '活动链接',
                'dependency' => array('goTop_hd', '==', true),
            ),
            array(
                'id'         => 'goTop_hd_img',
                'type'       => 'upload',
                'title'      => '活动图片',
                'dependency' => array('goTop_hd', '==', true),
                'default'    => get_template_directory_uri() . '/static/images/ceo_follow_img.png',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （签到按钮设置）',
            ),
            array(
                'id'         => 'goTop_qd',
                'type'       => 'switcher',
                'title'      => '签到按钮',
                'desc'       =>'开启或关闭签到按钮（开启则显示，关闭则隐藏）',
                'dependency' => array('goTop', '==', true),
                'default'    => true
            ),
            array(
                'id'         => 'goTop_qd_title',
                'type'       => 'text',
                'title'      => '签到按钮标题',
                'dependency' => array('goTop_qd', '==', true),
                'default'    => '今日签到'
            ),
            array(
                'id'         => 'goTop_qd_icon',
                'type'       => 'text',
                'title'      => '按钮图标',
                'dependency' => array('goTop_qd', '==', true),
                'default'    => 'ceoicon-calendar-2-line',
                'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （抽奖活动按钮设置）',
            ),
            array(
                'id'         => 'goTop_encourage',
                'type'       => 'switcher',
                'title'      => '抽奖按钮',
                'desc'       =>'开启或关闭抽奖活动按钮（开启则显示，关闭则隐藏）',
                'dependency' => array('goTop', '==', true),
                'default'    => true
            ),
            array(
                'id'         => 'goTop_encourage_title',
                'type'       => 'text',
                'title'      => '抽奖按钮标题',
                'dependency' => array('goTop_encourage', '==', true),
                'default'    => '抽奖活动'
            ),
            array(
                'id'         => 'goTop_encourage_icon',
                'type'       => 'text',
                'title'      => '按钮图标',
                'dependency' => array('goTop_encourage', '==', true),
                'default'    => 'ceoicon-gift-2-line',
                'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （客服按钮设置）',
            ),
            array(
                'id'         => 'goTop_service',
                'type'       => 'switcher',
                'title'      => '客服按钮',
                'desc'       =>'开启或关闭跟随客服按钮（开启则显示，关闭则隐藏）',
                'dependency' => array('goTop', '==', true),
                'default'    => true
            ),
            array(
                'id'         => 'goTop_service_sz',
                'type'       => 'fieldset',
                'title'      => '客服按钮设置',
                'dependency' => array('goTop_service', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'goTop_service_icon',
                        'type'       => 'text',
                        'title'      => '按钮图标',
                        'default'    => 'ceoicon-customer-service-2-line',
                        'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'      => 'goTop_service_img',
                        'type'    => 'upload',
                        'title'   => '客服图片',
                        'default' => get_template_directory_uri() . '/static/images/ceo-gotop-qq.png',
                    ),
                    array(
                        'id'      => 'goTop_service_bt',
                        'type'    => 'text',
                        'title'   => '客服标题',
                        'default' => '点击联系客服',
                    ),
                    array(
                        'id'         => 'goTop_qq_qq',
                        'type'       => 'text',
                        'title'      => '客服QQ',
                        'default'    => '88888888'
                    ),
                    array(
                        'id'      => 'goTop_service_sj',
                        'type'    => 'text',
                        'title'   => '工作时间',
                        'default' => '在线时间：8:00-16:00',
                    ),
                    array(
                        'id'      => 'goTop_service_dhbt',
                        'type'    => 'text',
                        'title'   => '客服电话标题',
                        'default' => '客服电话',
                    ),
                    array(
                        'id'      => 'goTop_service_dhhm',
                        'type'    => 'text',
                        'title'   => '客服电话号码',
                        'default' => '400-888-8888',
                    ),
                    array(
                        'id'      => 'goTop_service_yxbt',
                        'type'    => 'text',
                        'title'   => '客服邮箱标题',
                        'default' => '客服邮箱',
                    ),
                    array(
                        'id'      => 'goTop_service_yxhm',
                        'type'    => 'text',
                        'title'   => '客服邮箱账号',
                        'default' => 'ceotheme@ceo.com',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （微信按钮设置）',
            ),
            array(
                'id'         => 'goTop_wx',
                'type'       => 'switcher',
                'title'      => '微信按钮',
                'desc'       =>'开启或关闭跟随微信按钮（开启则显示，关闭则隐藏）',
                'dependency' => array('goTop', '==', true),
                'default'    => true
            ),
            array(
                'id'         => 'goTop_wx_sz',
                'type'       => 'fieldset',
                'title'      => '微信按钮设置',
                'dependency' => array('goTop_wx', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'goTop_wx_icon',
                        'type'       => 'text',
                        'title'      => '按钮图标',
                        'default'    => 'ceoicon-qr-code-line',
                        'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'         => 'goTop_wx_title',
                        'type'       => 'text',
                        'title'      => '主标题',
                        'default'    => '扫描二维码',
                    ),
                    array(
                        'id'         => 'goTop_wx_subtitle',
                        'type'       => 'text',
                        'title'      => '副标题',
                        'default'    => '关注微信公众号',
                    ),
                    array(
                        'id'         => 'goTop_wx_img',
                        'type'       => 'upload',
                        'title'      => '微信二维码',
                        'default' => get_template_directory_uri() . '/static/images/ceo-ma.png',
                    ),
                ),
            ),
            array(
                'type'    => 'notice',
                'style'   => 'warning',
                'content' => '分割线 （手机按钮设置）',
            ),
            array(
                'id'         => 'goTop_sj',
                'type'       => 'switcher',
                'title'      => '手机按钮',
                'desc'       =>'开启或关闭跟随手机按钮（开启则显示，关闭则隐藏）',
                'dependency' => array('goTop', '==', true),
                'default'    => true
            ),
            array(
                'id'         => 'goTop_sj_sz',
                'type'       => 'fieldset',
                'title'      => '手机按钮设置',
                'dependency' => array('goTop_sj', '==', true),
                'fields'     => array(
                    array(
                        'id'         => 'goTop_sj_icon',
                        'type'       => 'text',
                        'title'      => '按钮图标',
                        'default'    => 'ceoicon-smartphone-line',
                        'desc'       => '<a href="https://www.ceotheme.com/ceoicon/" target="_blank">更换图标代码请点我</a>',
                    ),
                    array(
                        'id'         => 'goTop_sj_title',
                        'type'       => 'text',
                        'title'      => '主标题',
                        'default'    => '扫描二维码',
                    ),
                    array(
                        'id'         => 'goTop_sj_subtitle',
                        'type'       => 'text',
                        'title'      => '副标题',
                        'default'    => '手机访问本站',
                    ),
                    array(
                        'id'         => 'goTop_sj_img',
                        'type'       => 'upload',
                        'title'      => '二维码',
                        'default' => get_template_directory_uri() . '/static/images/ceo-ma.png',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_qita',
        'title'  => '底部跟随设置',
        'fields' => array(
            array(
                'id'      => 'footer_new',
                'type'    => 'switcher',
                'title'   => '网站底部跟随',
                'default' => true
            ),
            array(
                'id'     => 'footer_new_mk',
                'type'   => 'fieldset',
                'title'  => '网站底部跟随设置',
                'dependency'   => array('footer_new', '==', 'true'),
                'fields' => array(
                    array(
                        'id'      => 'footer_new_title',
                        'type'    => 'text',
                        'title'   => '标题',
                        'default' => '总裁主题新款上线，限时1个月优惠活动开始啦~',
                    ),
                    array(
                        'id'      => 'footer_new_tag',
                        'type'    => 'text',
                        'title'   => '标签',
                        'default' => 'NEW',
                    ),
                    array(
                        'id'      => 'footer_new_link',
                        'type'    => 'text',
                        'title'   => '链接',
                        'default' => 'https://www.ceotheme.com/',
                    ),
                    array(
                        'id'      => 'footer_new_antitle',
                        'type'    => 'text',
                        'title'   => '按钮标题',
                        'default' => '查看优惠',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_qita',
        'title'  => '主题美化设置',
        'fields' => array(
            array(
                'id'       => 'head_js',
                'type'     => 'textarea',
                'title'    => '网站底部自定义JS代码',
                'desc'     => '可用于添加第三方网站流量数据统计代码，如：百度统计或美化效果',
                'sanitize' => false,
                'default'  => '',
            ),
            array(
                'id'        => 'diy_css',
                'type'      => 'code_editor',
                'title'     => '自定义css样式',
                'desc'      => '少量css可以直接写在这里,注意：不需要添加《style》《/style》',
                'settings'  => array(
                    'theme' => 'mbo',
                    'mode'  => 'css',
                ),
            ),
        )
    ));

    /*
     * ------------------------------------------------------------------------------
     * 优化设置
     * ------------------------------------------------------------------------------
     */
    CSF::createSection($prefix, array(
        'id'    => 'ceotheme_optimization',
        'icon'  => 'fa fa-rocket',
        'title' => '优化设置',
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_optimization',
        'title'  => '优化加速',
        'fields' => array(
            array(
                'id'       => 'gtb_editor',
                'type'     => 'switcher',
                'title'    => '禁用古腾堡编辑器',
                'default'  => true,
                'subtitle' => '古腾堡用不习惯吗？那就关闭吧！(默认关闭)',
            ),
            array(
                'id'       => 'googleapis',
                'type'     => 'switcher',
                'title'    => '后台禁止加载谷歌字体',
                'default'  => true,
                'subtitle' => '后台禁止加载谷歌字体，加快后台访问速度',
            ),
            array(
                'id'       => 'emoji',
                'type'     => 'switcher',
                'title'    => '禁用emoji表情',
                'default'  => true,
                'subtitle' => '禁用WordPress的Emoji功能和禁止head区域Emoji css加载',
            ),
            array(
                'id'       => 'article_revision',
                'type'     => 'switcher',
                'title'    => '屏蔽文章修订功能',
                'default'  => true,
                'subtitle' => '文章多，修订次数的用户建议关闭此功能',
            ),
        )
    ));
    CSF::createSection($prefix, array(
        'parent' => 'ceotheme_optimization',
        'title'  => '精简头部',
        'fields' => array(
            array(
                'id'       => 'toolbar',
                'type'     => 'switcher',
                'title'    => '移除顶部工具条',
                'default'  => true,
                'subtitle' => '这个大家应该都懂',
            ),
            array(
                'id'       => 'rest_api',
                'type'     => 'switcher',
                'title'    => '禁用REST API',
                'default'  => false,
                'subtitle' => '不准备打通WordPress小程序的用户建议关闭',
            ),
            array(
                'id'       => 'wpjson',
                'type'     => 'switcher',
                'title'    => '移除wp-json链接代码',
                'default'  => true,
                'subtitle' => '移除头部区域wp-json链接代码，精简头部区域代码',
            ),
            array(
                'id'       => 'emoji_script',
                'type'     => 'switcher',
                'title'    => '移除头部多余Emoji JavaScript代码',
                'default'  => true,
                'subtitle' => '移除头部多余Emoji JavaScript代码，精简头部区域代码',
            ),
            array(
                'id'       => 'wp_generator',
                'type'     => 'switcher',
                'title'    => '移除头部WordPress版本',
                'default'  => true,
                'subtitle' => '移除头部WordPress版本，精简头部区域代码',
            ),
            array(
                'id'       => 'wp_headcssjs',
                'type'     => 'switcher',
                'title'    => '移除头部JS和CSS链接中的Wordpress版本号',
                'default'  => true,
                'subtitle' => '移除头部JS和CSS链接中的Wordpress版本号，精简头部区域代码',
            ),
            array(
                'id'       => 'rsd_link',
                'type'     => 'switcher',
                'title'    => '移除离线编辑器开放接口',
                'default'  => true,
                'subtitle' => '移除WordPress自动添加两行离线编辑器的开放接口，精简头部区域代码',
            ),
            array(
                'id'       => 'index_rel_link',
                'type'     => 'switcher',
                'title'    => '清除前后文、第一篇文章、主页meta信息',
                'default'  => true,
                'subtitle' => 'WordPress把前后文、第一篇文章和主页链接全放在meta中。我认为于SEO帮助不大，反使得头部信息巨大，建议移出。',
            ),
            array(
                'id'       => 'feed',
                'type'     => 'switcher',
                'title'    => '移除文章、分类和评论feed',
                'default'  => true,
                'subtitle' => '移除文章、分类和评论feed，精简头部区域代码。',
            ),
            array(
                'id'       => 'dns_prefetch',
                'type'     => 'switcher',
                'title'    => '移除头部加载DNS预获取',
                'default'  => true,
                'subtitle' => '移出head区域dns-prefetch代码，精简头部区域代码。',
            ),

        )
    ));
}
