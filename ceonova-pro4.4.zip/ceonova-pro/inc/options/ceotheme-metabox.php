<?php if ( ! defined( 'ABSPATH' )  ) { die; }

if( class_exists( 'CSF' ) ) {
	$prefix_info = 'ceo_post_info';
	CSF::createMetabox( $prefix_info, array(
		'title'     => '<span class="ceotheme_com"><i class="fa fa-laptop"></i> CeoNova-Pro主题 - 文章信息配置</span>',
		'nav'       => 'inline',
		'post_type' => 'post',
		'data_type' => 'unserialize',
		'context'   => 'normal',

	) );
	CSF::createSection($prefix_info, array(
	    'title'  => '文章信息',
        'fields' => array(
            array(
                'id'      => 'ceo-tese-tag',
                'type'    => 'text',
                'title'   => '文章标签',
                'desc'    => '文章标题前显示特色标签（例：热门、原创、转载等，填写后会显示在文章列表和文章内页标题前）',
            ),
            array(
                'id'      => 'ceo-tese-source',
                'type'    => 'text',
                'title'   => '文章来源',
                'desc'    => '填写后将显示在文章内容页底部，不填则不显示',
            ),
        )

	) );
	CSF::createSection($prefix_info, array(
	    'title'  => '自定义SEO',
        'fields' => array(
            array(
                'id'      => 'ceo-seo-title',
                'type'    => 'text',
                'title'   => '自定义SEO标题',
                'desc'    => '填写自定义SEO标题，未填写则调用默认文章标题',
            ),
            array(
                'id'      => 'ceo-seo-keywords',
                'type'    => 'text',
                'title'   => '自定义SEO关键词',
                'desc'    => '填写自定义SEO关键词，未填写则调用默认文章标签',
            ),
            array(
                'id'      => 'ceo-seo-description',
                'type'    => 'textarea',
                'title'   => '自定义SEO描述',
                'desc'    => '填写自定义SEO描述，未填写则调用默认文章内容前段',
            ),
        )

	) );
}
if( class_exists( 'CSF' ) ) {
    $prefix_theme = 'my_post_theme';
    CSF::createMetabox( $prefix_theme, array(
        'title'        => '<span class="ceotheme_com"><i class="fa fa-laptop"></i> CeoNova-Pro主题 - 产品信息设置</span>',
        'post_type'    => 'post',
        'data_type'    => 'unserialize',
        'show_restore' => true,
    ) );
    CSF::createSection( $prefix_theme, array(
        'fields' => array(
            array(
				'type'       => 'submessage',
				'style'      => 'success',
				'content'    => '分割线（顶部产品设置）',
			),
            array(
              'id'         => 'theme_color',
              'type'       => 'text',
              'title'      => '产品内页顶部颜色',
              'default'    => '#006fff',
              'desc'       => '自定义产品内页顶部颜色，给用户对每个产品体验不一样的视觉效果，默认#006fff',
            ),
            array(
              'id'         => 'theme_desc',
              'type'       => 'text',
              'title'      => '产品描述',
              'default'    => '',
            ),
            array(
              'id'         => 'theme_original',
              'type'       => 'text',
              'title'      => '产品原价',
              'default'    => '',
            ),
            array(
              'id'         => 'theme_discount',
              'type'       => 'text',
              'title'      => '产品优惠标签',
              'desc'       => '如：限时优惠，活动优惠等标签，建议不超过4个字',
              'default'    => '',
            ),
            array(
              'id'         => 'theme_demo',
              'type'       => 'text',
              'title'      => '演示地址',
              'default'    => '',
            ),
            array(
              'id'         => 'theme_zdy1_title',
              'type'       => 'text',
              'title'      => '自定义按钮1标题',
              'default'    => '产品问答',
            ),
            array(
              'id'         => 'theme_zdy1_link',
              'type'       => 'text',
              'title'      => '自定义按钮1链接',
              'default'    => '',
            ),
            array(
              'id'         => 'theme_zdy2_title',
              'type'       => 'text',
              'title'      => '自定义按钮2标题',
              'default'    => '产品社区',
            ),
            array(
              'id'         => 'theme_zdy2_link',
              'type'       => 'text',
              'title'      => '自定义按钮2链接',
              'default'    => '',
            ),
            array(
              'id'         => 'theme_update',
              'type'       => 'text',
              'title'      => '最后更新',
              'default'    => '',
            ),
            //信息属性
            array(
                'id'         => 'down_info',
                'type'       => 'repeater',
                'title'      => '资源信息属性',
                'desc'       => '付费资源内页显示资源信息属性',
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '标题',
                        'default' => '标题',
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => '描述内容',
                        'default' => '这里是描述内容',
                    ),
                ),
                /*'default' => array(
                    array(
                        'title' => '模板类型',
                        'desc'  => '',
                    ),
                ),*/
            ),
            array(
				'id'         => 'theme_slide',
				'type'       => 'repeater',
				'title'      => '产品幻灯',
				'fields'     => array(
					array(
						'id'           => 'img_s',
						'type'         => 'upload',
						'title'        => '幻灯图片',
                        'placeholder'  => 'http://',
						'button_title' => '上传',
						'remove_title' => '删除',
					),

				),
			),
			array(
				'type'       => 'submessage',
				'style'      => 'success',
				'content'    => '分割线（产品介绍设置）',
			),
            array(
              'id'      => 'theme_introduce_title',
              'type'    => 'text',
              'title'   => '模块标题',
              'default' => '产品介绍',
            ),
            array(
              'id'         => 'theme_introduce_desc',
              'type'       => 'text',
              'title'      => '模块描述',
              'default'    => '',
            ),
            array(
				'type'       => 'submessage',
				'style'      => 'success',
				'content'    => '分割线（特色功能设置）',
			),
			array(
                'id'         => 'theme_characteristic_switcher',
                'type'       => 'switcher',
                'title'      => '启用特色功能',
                'default'    => true,
            ),
            array(
              'id'      => 'theme_characteristic_title',
              'dependency' => array( 'theme_characteristic_switcher', '==', true ),
              'type'       => 'text',
              'title'      => '模块标题',
              'default'    => '特色功能',
            ),
            array(
              'id'      => 'theme_characteristic_desc',
              'dependency' => array( 'theme_characteristic_switcher', '==', true ),
              'type'    => 'text',
              'title'   => '模块描述',
              'default' => ''
            ),
            array(
				'id'         => 'characteristic_sz',
                'dependency' => array( 'theme_characteristic_switcher', '==', true ),
				'type'       => 'repeater',
				'title'      => '添加内容',
				'fields'     => array(
					array(
						'id'           => 'img',
						'type'         => 'upload',
						'title'        => '模块图片',
						'desc'         => '建议尺寸：高80px宽80px',
                        'placeholder'  => 'http://',
						'button_title' => '上传',
						'remove_title' => '删除',
					),
                    array(
                        'id'           => 'title',
                        'type'         => 'text',
                        'title'        => '标题',
                        'default'      => ''
                    ),
                    array(
                        'id'           => 'desc',
                        'type'         => 'text',
                        'title'        => '描述',
                        'default'      => ''
                    ),

				),
			),
			array(
				'type'    => 'submessage',
				'style'   => 'success',
				'content' => '分割线（更多功能设置）',
			),
			array(
                'id'    => 'theme_more_switcher',
                'type'  => 'switcher',
                'title' => '启用更多功能',
                'default'  => true,
            ),
			array(
              'id'      => 'theme_more_title',
              'dependency' => array( 'theme_more_switcher', '==', true ),
              'type'    => 'text',
              'title'   => '模块标题',
              'default' => '更多功能'
            ),
            array(
              'id'      => 'theme_more_desc',
              'dependency' => array( 'theme_more_switcher', '==', true ),
              'type'    => 'text',
              'title'   => '模块描述',
              'default' => ''
            ),
            array(
				'id'         => 'more_sz',
                'dependency' => array( 'theme_more_switcher', '==', true ),
				'type'       => 'repeater',
				'title'      => '添加内容',
			    'desc'       => '内容添加em标签可高亮显示',
				'fields'     => array(
                    array(
                        'id'           => 'desc',
                        'type'         => 'text',
                        'title'        => '内容',
                        'default'      => '',
                    ),

				),
			),
			array(
				'type'    => 'submessage',
				'style'   => 'success',
				'content' => '分割线（附赠服务设置）',
			),
			array(
                'id'    => 'theme_service_switcher',
                'type'  => 'switcher',
                'title' => '启用附赠服务',
                'default'  => true,
            ),
			array(
              'id'      => 'theme_service_title',
              'dependency' => array( 'theme_service_switcher', '==', true ),
              'type'    => 'text',
              'title'   => '模块标题',
              'default' => '附赠服务'
            ),
            array(
              'id'      => 'theme_service_desc',
              'dependency' => array( 'theme_service_switcher', '==', true ),
              'type'    => 'text',
              'title'   => '模块描述',
              'default' => ''
            ),
            array(
				'id'         => 'service_sz',
                'dependency' => array( 'theme_service_switcher', '==', true ),
				'type'       => 'repeater',
				'title'      => '添加内容',
				'fields'     => array(
					array(
						'id'           => 'img',
						'type'         => 'upload',
						'title'        => '模块图片',
						'desc'         => '建议尺寸：高60px宽60px',
                        'placeholder'  => 'http://',
						'button_title' => '上传',
						'remove_title' => '删除',
					),
                    array(
                        'id'           => 'title',
                        'type'         => 'text',
                        'title'        => '标题',
                        'default'      => '',
                    ),
                    array(
                        'id'           => 'desc',
                        'type'         => 'text',
                        'title'        => '内容',
                        'default'      => '',
                    ),

				),
			),
			array(
				'type'    => 'submessage',
				'style'   => 'success',
				'content' => '分割线（更新记录设置）',
			),
			array(
                'id'    => 'theme_update_switcher',
                'type'  => 'switcher',
                'title' => '启用更新记录',
                'default'  => true,
            ),
			array(
              'id'      => 'theme_update_title',
              'dependency' => array( 'theme_update_switcher', '==', true ),
              'type'    => 'text',
              'title'   => '模块标题',
              'default' => '更新记录'
            ),
            array(
              'id'      => 'theme_update_desc',
              'dependency' => array( 'theme_update_switcher', '==', true ),
              'type'    => 'text',
              'title'   => '模块描述',
              'default' => ''
            ),
            array(
				'id'         => 'update_sz',
                'dependency' => array( 'theme_update_switcher', '==', true ),
				'type'       => 'repeater',
				'title'      => '添加内容',
			    'desc'       => '添加新版本的时候将最新的更新记录拖拽到最上面',
				'fields'     => array(
                    array(
                        'id'           => 'title',
                        'type'         => 'text',
                        'title'        => '标题（更新时间）',
                        'default'      => '2021-11-19<em>V3.9.9</em>',
                    ),
                    array(
                        'id'           => 'desc',
                        'type'         => 'textarea',
                        'title'        => '内容',
		                'desc'         => '每行一个p标签',
                        'default'      => '<p>更新了XXXXXX</p>',
                    ),

				),
			),
        )
    ) );
}