<?php if (! defined('ABSPATH')) {
    die;
}
if (class_exists('CSF')) {
    $prefix = 'my_taxonomy_options';
    CSF::createTaxonomyOptions($prefix, array(
        'taxonomy' => 'category',
        'data_type' => 'unserialize ',
    ));

    CSF::createSection($prefix, array(
        'fields' => array(
            array(
                'id'           => 'cate_background_img',
                'type'         => 'media',
                'title'        => '分类列表背景图片',
                'desc'         => '自定义分类列表背景图片~未独立设置则自动调用主题设置-分类设置中默认背景图片',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => '',
            ),
            array(
                'id'        => 'cat_theme',
                'type'      => 'image_select',
                'title'     => '<h3>选择分类布局样式</h3>',
                'help'    => '[样式1：博客布局]  [样式2：卡片布局]  [样式3：极简布局]',
                'options' => array(
                    '1'  => get_template_directory_uri() . '/static/images/ceo-fenlei-boke.jpg',
                    '2'  => get_template_directory_uri() . '/static/images/ceo-fenlei-kapian.jpg',
                    '3'  => get_template_directory_uri() . '/static/images/ceo-fenlei-simple.jpg',
                ),
                'default'   => '1'
            ),
        )
    ));

    //自定义SEO标题
    if (true) {
        $fields_arr = [
            array(
                'id'    => 'seo-title',
                'type'  => 'text',
                'title' => '自定义SEO标题',
                'help'  => '不设置则遵循WP标题规则',
            ),
            array(
                'id'    => 'seo-keywords',
                'type'  => 'textarea',
                'title' => '自定义SEO关键词',
                'help'  => '自定义SEO关键词,用英文逗号隔开',
            ),
            array(
                'id'    => 'seo-description',
                'type'  => 'textarea',
                'title' => '自定义SEO描述',
                'help'  => '自定义SEO描述',
            )
        ];
    }
    CSF::createSection($prefix, array(
        'fields' => $fields_arr
    ));
}
//论坛
if (class_exists('CSF')) {
    $prefix = 'forum_options';
    CSF::createTaxonomyOptions($prefix, array(
        'taxonomy' => 'forum_cat',
        'data_type' => 'unserialize ',
    ));

    CSF::createSection($prefix, array(
        'fields' => array(
            array(
                'id'           => 'cate_forum_img',
                'type'         => 'media',
                'title'        => '论坛板块图标',
                'button_title' => '上传',
                'remove_title' => '删除',
                'default'      => '',
            ),
        )
    ));
}