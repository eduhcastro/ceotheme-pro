<div class="site-item b-a b-r-4 ceo-background-default ceo-dongtai">
	<div class="site-box-s">
	    <div class="site-box-img">
    	    <a href="<?php the_permalink(); ?>" <?php echo _target_blank();?> class="b-r-4 ceo-display-block ceo-cover-container">
    			<img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" ceo-cover/>
    		</a>
		</div>
		<div class="site-desc">
			<a href="<?php the_permalink(); ?>" <?php echo _target_blank();?> class="ceo-flex-1"><?php the_title(); ?></a>
			<em></em>
			<p>
				<?php 
				if (has_excerpt()) {
					echo $description = get_the_excerpt();
				}else {
					echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 100,"…");
				} 
				?>
			</p>
		</div>
	</div>
</div>