<?php 
/* Template Name: 单页合集 */ 
get_header();
$text = _ceo('onepage-text');
$bg = _ceo('onepage-bg');
?>
<div class="ceo-tag-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);">
    <div class="ceo-container ceo-containertag">
        <div class="ceo-tag-bgleft">
            <h3 class="ceo-hs"><?php the_title(); ?></h3>
            <p class="ceo-visible@s"><?php echo $text; ?></p>
        </div>
    </div>
</div>
<div class="ceo-catnav-wz ceo-background-default ceo-visible@s">
    <div class="ceo-container">
	    <?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
	</div>
</div>
<div class="ceo-container">
	<div class="page-about" ceo-grid>
		<div class="ceo-width-1-1 ceo-width-1-6@s">
			<div class="page-menu b-a ceo-background-default">
				<ul class="ceo-margin-remove">
					<?php ceo_menu('page-nav'); ?>	
				</ul>
			</div>
		</div>
		<div class="ceo-width-1-1@s ceo-width-5-6@m ceo-width-5-6@l ceo-width-5-6@xl">
			<div class="page-main single-content b-r-4 b-a ceo-padding ceo-background-default ceo-margin-bottom">
				<?php while(have_posts()) : the_post(); ?>
				<?php the_content(); ?>
				<?php endwhile; ?>
			</div>
			<?php if(_ceo('comments_close') == false ): ?>	
			<?php if ( comments_open() || get_comments_number() ) : ?>
			<?php comments_template( '', true ); ?>
			<?php endif; ?>
			<?php endif; ?>
		</div>
	</div>
</div>
<?php get_footer(); ?>
