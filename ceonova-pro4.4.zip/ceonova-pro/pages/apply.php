<?php
/*
Template Name: 定制服务
*/
get_header(); 
$bg = _ceo('apply-bg');
$apply_sz = _ceo('apply_sz');
$apply_qasz = _ceo('apply_qasz');
?>
<div class="ceo-pages-apply-top ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);"></div>
<div class="web-top">
    <div class="ceo-container">
        <div class="web-top-title"><?php echo _ceo('apply_mktitle'); ?></div>
        <div class="ceo-grid-medium" ceo-grid>
            <?php 
			if ($apply_sz) { 
				foreach ( $apply_sz as $key => $value) {
			?>
            <div class="ceo-width-1-1 ceo-width-1-3@s">
                <div class="web-topbox ceo-background-default ceo-dongtai">
                    <img src="<?php echo $value['img']; ?>" alt="<?php echo $value['title']; ?>">
                    <span><?php echo $value['title']; ?></span>
                    <div class="price"><?php echo $value['price']; ?></div>
                    <em></em>
                    <p class="b-b"><?php echo $value['desc']; ?></p>
                    <div class="tc">
                        <?php echo $value['default']; ?>
                    </div>
                    <div class="an">
                        <a href="tencent://Message/?Uin=<?php if(_ceo('goTop_service_sz'))echo _ceo('goTop_service_sz')['goTop_qq_qq']; ?>&amp;websiteName=#=&amp;Menu=yes" rel="noreferrer nofollow">定制咨询<i class="anim"></i></a>
                    </div>
                </div>
            </div>
            <?php } } ?>
        </div>
    </div>
</div>

<div class="ceo-pages-apply ceo-background-cover">
    <div class="ceo-container">
        <div class="web-apply-title">线上提交需求定制</div>
        <div class="ceo-pages-apply-box">
            <form class="loginForm" id="custom_loginForm">
                <div class="ceo-apply-txt ceo-width-1-1">
                    需求描述：<input type="text" name="username" lay-verify="required|userName" placeholder="* 请重点描述您的需求"/></input>
                </div>
                <div class="ceo-grid-ceosmls" ceo-grid>
                    <div class="ceo-apply-txt ceo-width-1-1 ceo-width-1-2@s">
                        预算金额：<input type="text" name="hyid" placeholder="* 请填写需求预算金额，例：10000元" lay-verify="required"/>
                    </div>
                    <div class="ceo-apply-txt ceo-width-1-1 ceo-width-1-2@s">
                        联系方式：<input type="text" name="price" placeholder="* 请填写您的联系方式"  lay-verify="required"/>
                    </div>
                </div>
                <div class="ceo_apple_is">
                    <div class="ceo-apply-txt">
                        图片上传：
                    </div>
                    <div class="ceo-apply-sfz" ceo-grid>
                        <div class="ceo-apply-sfzimg ceo-width-1-1 ceo-width-1-2@s">
                            <input type="text" name="yfz1" id="yfz1" placeholder="上传需求相关图片1（选填）"/>
                            <input type="button" class="applybat codeBtn filebtn" data-id="fileyfz1" value="上传" />
                            <img style="display: none;margin-bottom: 30px;border-radius: 4px;" class="previewyfz1">
                            <input type="file" class="fileyfz" data-id="yfz1" id="fileyfz1" name="fileyfz1" placeholder="图片" />
                        </div>
                        <div class="ceo-apply-sfzimg ceo-width-1-1 ceo-width-1-2@s">
                            <input type="text" name="yfz2" id="yfz2" placeholder="上传需求相关图片2（选填）"/>
                            <input type="button" class="applybat codeBtn filebtn" data-id="fileyfz2" value="上传" />
                            <img style="display: none;margin-bottom: 30px;border-radius: 4px;" class="previewyfz2">
                            <input type="file" class="fileyfz" data-id="yfz2" id="fileyfz2" name="fileyfz2" placeholder="图片" />
                        </div>
                    </div>
                </div>
                <?php if( is_user_logged_in() ){ ?>
                <div class="">
                    <input type="button" value="提交需求" id="regBtn" />
                </div>
                <?php }else{ ?>
                <div class="apply-login">
                    <a href="#navbar-login" ceo-toggle>登录后提交</a>
                </div>
                <?php } ?>
            </form>
        </div>
    </div>
</div>
<div class="web-qa ceo-background-default">
    <div class="ceo-container">
        <div class="web-qa-title"><?php echo _ceo('apply_qatitle'); ?></div>
        <div class="ceo-grid-medium" ceo-grid>
            <?php 
			if ($apply_qasz) { 
				foreach ( $apply_qasz as $key => $value) {
			?>
            <div class="ceo-width-1-1 ceo-width-1-2@s">
                <div class="web-qabox b-a">
                    <span><?php echo $value['title']; ?></span>
                    <p class="b-t"><?php echo $value['desc']; ?></p>
                    <a href="<?php echo $value['anlink']; ?>" target="_blank"><?php echo $value['antitle']; ?><i class="ceofont ceoicon-arrow-right-s-line"></i></a>
                </div>
            </div>
            <?php } } ?>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri().'/static';?>/js/base.js"></script>
<?php get_footer(); ?>