<?php
/* Template Name: 友情链接 */
get_header();
$text = _ceo('links-text');
$bg = _ceo('links-bg');
?>
<div class="ceo-tag-bg ceo-app-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);">
    <div class="ceo-container ceo-containertag">
        <div class="ceo-tag-bgleft">
            <h3 class="ceo-hs"><?php the_title(); ?></h3>
            <p class="ceo-visible@s"><?php echo $text; ?></p>
        </div>
    </div>
</div>
<div class="ceo-catnav-wz ceo-background-default ceo-visible@s">
    <div class="ceo-container">
	    <?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
	</div>
</div>
<section class="ceo-container">
    <div class="ceo-pages-links">
    <?php
	wp_list_bookmarks(array(
	    'show_description' => true,
	    'show_name'        => true,
	    'orderby'          => 'rating',
	    'title_before'     => '<h2><span>',
	    'title_after'      => '</span></h2>',
	    'order'            => 'DESC',
	    'show_description' => '0',
	));
	?>
	</div>
	<div class="ceo-pages-links-box single-content b-r-4 b-a ceo-padding ceo-background-default ceo-margin-bottom">
		<?php while(have_posts()) : the_post(); ?>
		<?php the_content(); ?>
		<?php endwhile; ?>
    </div>
</section>
<?php get_footer();?>