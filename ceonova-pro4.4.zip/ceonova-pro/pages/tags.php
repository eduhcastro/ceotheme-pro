<?php 
/* Template Name: 热门标签 */ 
get_header(); 
$text = _ceo('tag-text');
$bg = _ceo('tag-bg');
?>
<div class="ceo-tag-bg ceo-app-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);">
    <div class="ceo-container ceo-containertag">
        <div class="ceo-tag-bgleft">
            <h3 class="ceo-hs"><?php the_title(); ?></h3>
            <p class="ceo-visible@s"><?php echo $text; ?></p>
        </div>
    </div>
</div>
<div class="ceo-catnav-wz ceo-background-default ceo-visible@s">
    <div class="ceo-container">
	    <?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
	</div>
</div>
<section class="ceo-container">
	<div class="ceo-margin-large-bottom ceo-grid-ceosmls" ceo-grid>
		<?php
		$tags_list = get_tags('orderby=count&order=DESC&number=100');
		if($tags_list) {
			foreach($tags_list as $tag) {
				echo '<div class="ceo-width-1-1@s ceo-width-1-4@m ceo-width-1-4@l ceo-width-1-4@xl">
				      <div class="page-tags-item ceo-background-default b-a b-r-4">
				          <a class="" href="'.get_tag_link($tag).'">
				          <h2><span class="ceo-tagsj">#</span>'. $tag->name .'</h2>
				          <div class="ceo-flex">
				          <small class="ceo-text-muted ceo-flex-1">共 <span class="ceo-text-warning ceo-text-bold">'. $tag->count .'</span> 篇相关文章</small>
				          <small class="ceo-page-tags-a">查看详情<i class="ceofont ceoicon-arrow-right-s-line"></i></small>
				          </div>';
				echo '</a></div></div>';
			}
		}
		?>

	</div>
</section>
<?php get_footer(); ?>