<?php
/*
Template Name: VIP模板
*/
get_header(); 
$text = _ceo('vip-text');
$bg = _ceo('vip-bg');
$vip = _ceo('ceo_shop_vip_info');
$vip_tq_sz= _ceo('vip_tq_sz');
$vip_qa_sz= _ceo('vip_qa_sz');
?>
<div class="ceo-tag-bg ceo-app-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);">
    <div class="ceo-container ceo-containertag">
        <div class="ceo-align-lefts ceo-tag-bgleft">
            <h3 class="ceo-hs"><?php the_title(); ?></h3>
            <p class="ceo-visible@s"><?php echo $text; ?></p>
        </div>
    </div>
</div>
<div class="ceo-catnav-wz ceo-background-default ceo-visible@s">
    <div class="ceo-container">
	    <?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
	</div>
</div>
<div class="ceo-pages-vipbox">
    <div class="ceo-container">
        <div class="ceo-grid-ceosmls" ceo-grid>
            <?php
    		if ($vip) {
    			foreach ( $vip as $key => $value) {
    		?>
            <div class="vip-box-mk ceo-width-1-1 ceo-width-1-4@m ceo-width-1-4@l ceo-width-1-4@xl">
        	    <div class="vip-box-mk-zt ceo-background-default ceo-dongtai">
        	        <div class="top b-b">
            	        <div class="name"><?php echo $vip[$key]['name']; ?></div>
            	        <?php if ($vip[$key]['tags']): ?>
            	        <div class="tag"><?php echo $vip[$key]['tags']; ?></div>
            	        <?php endif; ?>
                	    <div class="vip-box-mk-zt-top">
        	                <div class="vip-box-mk-zt-top-dj">
            	                <span>¥</span><strong><?php echo $vip[$key]['price']; ?></strong><span><?php echo _ceo('ceo_shop_currency_name'); ?></span>
                	        </div>
        	                <p class="vip-box-mk-zt-top-pi">每天可下载<?php echo $vip[$key]['number']; ?>个VIP资源</p>
                	    </div>
            	    </div>
            	    <div class="vip-box-mk-zt-mbox">
                	    <div class="vip-box-mk-zt-mbox-s">
                	        <div class="vip-box-title">套餐介绍：</div>
                	        <p>会员有效期<em><?php echo $vip[$key]['validity']; ?>天</em><br/>
            	            <?php echo $vip[$key]['desc']; ?>
            	            </p>
                	    </div>
                        <?php if( is_user_logged_in() ){ ?>
                        <a href="javascript:void(0)" class="btn-ceo-svip" data-vip-id="<?php echo $vip[$key]['id'] ?>" data-style="slide-down">立即开通</a>
            			<?php }else{ ?>
            			<a href="#navbar-login" ceo-toggle>立即开通</a>
            			<?php } ?>
            	    </div>
        	    </div>
            </div>
            <?php } } ?>
        </div>
    </div>
</div>
<div class="ceo-pages-problem">
    <div class="ceo-container">
        <div class="problem-title">
            <h2><?php echo _ceo('vip_tq_title'); ?></h2>
            <p><?php echo _ceo('vip_tq_subtitle'); ?></p>
        </div>
        <div class="ceo-grid-ceosmls" ceo-grid>
            <?php
			if ($vip_tq_sz) {
				foreach ( $vip_tq_sz as $key => $value) {
			?>
            <div class="ceo-width-1-1 ceo-width-1-4@m ceo-width-1-4@l ceo-width-1-4@xl">
        	    <div class="vip-box-mk-zts ceo-background-default ceo-dongtai">
        	        <div class="vip-box-mk-zt-i"><i class="ceofont <?php echo $vip_tq_sz[$key]['ico']; ?>"></i></div>
        	        <span><?php echo $vip_tq_sz[$key]['title']; ?></span>
        	        <p><?php echo $vip_tq_sz[$key]['content']; ?></p>
            	</div>
    	    </div>
    	    <?php } } ?>
        </div>
    </div>
</div>
<div class="ceo-pages-problem">
    <div class="ceo-container">
        <div class="problem-title">
            <h2><?php echo _ceo('vip_qa_title'); ?></h2>
            <p><?php echo _ceo('vip_qa_subtitle'); ?></p>
        </div>
        
        <div class="problem-box" ceo-grid>
            <?php
			if ($vip_qa_sz) {
				foreach ( $vip_qa_sz as $key => $value) {
			?>
            <div class="problem-box-mk ceo-width-1-1 ceo-width-1-2@m ceo-width-1-2@l ceo-width-1-2@xl">
                <div class="problem-box-mk-w ceo-dongtai">
                    <h2><?php echo $vip_qa_sz[$key]['title']; ?></h2>
                    <p><?php echo $vip_qa_sz[$key]['content']; ?></p>
                </div>
            </div>
            <?php } } ?>
        </div>
    </div>
</div>
<?php get_footer(); ?>