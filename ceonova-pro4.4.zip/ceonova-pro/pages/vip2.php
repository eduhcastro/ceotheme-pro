<?php
/*
Template Name: VIP模板2
*/
get_header(); 
$bg = _ceo('vip2-bg');
$vip2_js = _ceo('vip2_js');
$vip2_tq = _ceo('vip2_tq');
$vip = _ceo('ceo_shop_vip_info');
?>
<div class="ceo-vip2-bg ceo-tag-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);">
    <div class="ceo-container ceo-containertag">
        <div class="vip2-bg-title">
            <h3 class="ceo-hs"><?php the_title(); ?></h3>
            <ul>
                <?php
        		if ($vip2_js) {
        			foreach ( $vip2_js as $key => $value) {
        		?>
                <li><i class="ceofont <?php echo $vip2_js[$key]['icon']; ?>"></i><?php echo $vip2_js[$key]['title']; ?></li>
                <?php } } ?>
            </ul>
        </div>
    </div>
</div>

<div class="ceo-vip2-tc">
    <div class="ceo-container">
        <div class="ceo-grid-medium" ceo-grid>
            <?php
    		if ($vip) {
    			foreach ( $vip as $key => $value) {
    		?>
    		<?php if ($vip[$key]['switch']): ?>
            <div class="vip2-tc-boxmk ceo-width-1-1 ceo-width-1-2@s">
        	    <div class="vip2-tc-box ceo-background-default ceo-dongtai">
            	    <div class="vip2-tc-box-top b-b">
        	            <i class="i"></i>
            	        <div class="title"><?php echo $vip[$key]['name']; ?></div>
            	        <span>¥<strong><?php echo $vip[$key]['price']; ?></strong>
            	        <p><?php echo _ceo('ceo_shop_currency_name'); ?><?php if ($vip[$key]['tags']): ?><em><?php echo $vip[$key]['tags']; ?></em><?php endif; ?></p></span>
            	        <p class="p">会员有效期<?php echo $vip[$key]['validity']; ?>天</p>
            	        <?php if( is_user_logged_in() ){ ?>
                        <a href="javascript:void(0)" class="btn-ceo-svip" data-vip-id="<?php echo $vip[$key]['id'] ?>" data-style="slide-down">立即开通</a>
            			<?php }else{ ?>
            			<a href="#navbar-login" ceo-toggle>立即开通</a>
            			<?php } ?>
            	    </div>
            	    <div class="vip2-tc-box-boo">
            	        <span>会员权益：</span>
            	        <p><?php echo $vip[$key]['desc']; ?></p>
            	    </div>
        	    </div>
            </div>
            <?php endif; ?>
            <?php } } ?>
        </div>
    </div>
</div>

<div class="ceo-vip2-qy">
    <div class="ceo-container">
        <div class="vip2-qy-title">
            <h2><?php echo _ceo('vip2_tq_text'); ?></h2>
            <p><?php echo _ceo('vip2_tq_desc'); ?></p>
        </div>
        <div class="ceo-grid-medium" ceo-grid>
            <?php
    		if ($vip2_tq) {
    			foreach ( $vip2_tq as $key => $value) {
    		?>
            <div class="ceo-width-1-2 ceo-width-1-4@s">
        	    <div class="vip2-tqyc-box ceo-background-default ceo-dongtai">
        	        <img src="<?php echo $vip2_tq[$key]['img']; ?>" alt="<?php echo $vip2_tq[$key]['title']; ?>">
        	        <span><?php echo $vip2_tq[$key]['title']; ?></span>
        	        <p><?php echo $vip2_tq[$key]['desc']; ?></p>
        	    </div>
            </div>
            <?php } } ?>
        </div>
    </div>
</div>

<?php get_template_part( 'template-parts/home/home', 'spread' ); ?>
<?php get_footer(); ?>