<?php
get_header();
$bg = _ceo('page-bg');
?>
<div class="ceo-tag-bg ceo-app-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);">
    <div class="ceo-container ceo-containertag">
        <div class="ceo-align-lefts ceo-tag-bgleft">
            <?php
				$allsearch = new WP_Query("s=$s");
				$key = get_search_query(1);
				if(empty($key)){
				    $key = get_query_var( 'p' );
                }
				$count = $allsearch->post_count;
				echo '<h3 class="ceo-hs">'. $key .'</h3>';
				
				if(is_search()){
                    global $wp_query;
                    $count = $wp_query->found_posts;
                }
				echo '<p class="ceo-visible@s">共搜索到<em class="ceo-text-warning"> ' . $count .' </em>条「' . $key .'」的相关内容。</p>' ;
				wp_reset_query(); 
				?>
        </div>
    </div>
</div>
<div class="ceo-catnav-wz ceo-background-default ceo-visible@s">
    <div class="ceo-container">
	    <?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
	</div>
</div>
<section class="ceo-category-blog">
    <div class="ceo-container" id="category">
        <div class="ceo-grid-ceosmls" ceo-grid>
        	<div class="ceo-width-1-1 ceo-width-auto@s">
        		<div class="wp">
        			<div class="blog ajaxMain b-a ceo-background-default">
        				<?php if ( have_posts() ) :  while ( have_posts() ) : the_post(); ?>
        				<?php get_template_part( 'template-parts/loop/loop', 'blog' ); ?>
        			    <?php endwhile; else: ?>
            			<div class="ceo-alert-primary ceo-container" ceo-alert>
            				<a class="ceo-alert-close" ceo-close></a>
            				<p class="ceo-padding-small ceo-text-center">这是一个没有灵魂的搜索词...</p>
            			</div>
                		<?php endif; ?>
        			</div>
            		
                    <?php if( _ceo('cat_load' ) == 'num' ){?>
                    <div class="fenye ceo-text-center ceo-text-small ceo-margin-medium-top ceo-margin-medium-bottom">
                    	<?php fenye(); ?>
                    </div>
                    <? }else{ ?>
                    <div id="ajaxBtn" class="ajax-btn ceo-text-center ceo-margin-medium">
                    	<?php next_posts_link(__('点击加载更多')); ?>
                    </div>
                    <?php } ?>
        		</div>
        	</div>
    	    <?php get_sidebar(); ?>
        </div>
    </div>
</section>
<?php get_footer(); ?>