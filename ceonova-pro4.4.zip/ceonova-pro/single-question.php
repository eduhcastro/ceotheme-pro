<?php
    $post_id = get_the_ID();
    $author_id = (int)get_post_field( 'post_author', $post_id );
    $question_comment_num = get_question_comment_num($post_id);
    $bg = _ceo('question_single_bg');
    get_header();
?>
<?php while ( have_posts() ) : the_post(); ?>

<div class="ceo-tag-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);">
    <div class="ceo-container ceo-containertag">
        <div class="ceo-tag-bgleft">
            <header class="single-question-head">
                <h1 class="ceo-hs"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h1>
                <div class="info ceo-flex ceo-flex-middle ceo-text-small ceo-text-muted ceo-flex ceo-flex-middle ceo-text-truncate ceo-margin-top">
                    <div class="ceo-flex-1 ceo-flex ceo-flex-middle">
                		<?php if(_ceo('single_info_tx') == true ): ?>
                        <div class="avatar ceo-border-circle ceo-overflow-hidden ceo-user-adminimg">
                		<?php echo get_avatar(get_the_author_meta( 'ID' ), 20); ?>
                		</div>
                		<?php endif; ?>
                		<?php if(_ceo('single_info_mc') == true ): ?>
                		<span class="ceo-text-small ceo-display-block ceo-user-admin"><?php the_author_posts_link(); ?></span>
                		<?php endif; ?>
                		<?php if(_ceo('single_info_rq') == true ): ?>
                    	<span class="ceo-margin-ymd"><i class="ceofont ceoicon-time-line"></i><?php echo the_time('Y年m月j日'); ?></span>
                    	<?php endif; ?>
                    	<?php if(_ceo('single_info_ll') == true ): ?>
                    	<span class="ceo-margin-ymd"><i class="ceofont ceoicon-eye-line"></i><?php post_views('', ''); ?> 浏览</span>
                    	<?php endif; ?>
                	    <span class="ceo-margin-ymd"><?php ceo_single_question_ts(); ?></span>
                	    <span class="ceo-margin-ymd"><?php edit_post_link('<i class="ceofont ceoicon-edit-2-line"></i> 编辑'); ?></span>
                	</div>
                </div>
            </header>
        </div>
    </div>
</div>
<div class="ceo-catnav-wz ceo-background-default ceo-visible@s">
    <div class="ceo-container">
	    <?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
	</div>
</div>

<div class="ceo-container ceo-margin-top-20">
	<div class="ceo-grid-ceosmls" ceo-grid>
		<div class="ceo-width-1-1 ceo-width-auto@s">
	        <div class="wp">
			    <article class="ceo-background-default ceo-padding-20 b-a ceo-margin-bottom">
			        <div class="single-question-xq">
			            <span>问题详情</span>
		            </div>
                    <div class="single-question-content single-content">
                        <?php the_content(); ?>
                    </div>
                    
                	<div class="single-question-an">
                	    <?php echo ceotheme_question_like_button();?>
            	    </div>

                    <!--文章版权-->
    				<div class="ceo-text-small ceo-text-pu ceo-margin-remove ceo-cop-text ceo-hh-p b-r-4" ceo-alert>
    					<p class="ceo-margin-remove-bottom"><i class="ceofont ceoicon-information-line"></i> <?php echo _ceo('question_single_bq'); ?>转载请注明出处：<?php the_permalink(); ?></p>
    				</div>

                	<!--文章标签-->
                    <?php
                    $tags_arrs = get_the_terms(get_the_ID(), 'question_tag');
                    if($tags_arrs){
                    ?>
                    <div class="ceo-single-tag-s-tags ceo-margin-top">
                        <?php foreach ($tags_arrs as $v) {

                         ?>
                        <a href="<?php echo get_term_link($v->term_id);?>" rel="tag" title="<?php echo $v->name;?>"># <?php echo $v->name;?></a>
                        <?php }?>
                    </div>
                    <?php }?>
                </article>
    			<?php if(_ceo('comments_close') == false ): ?>
    			<?php if ( comments_open() || get_comments_number() ) : ?>
    			<?php comments_template( '', true ); ?>
    			<?php endif; ?>
    			<?php endif; ?>
			</div>
		</div>
		<?php get_template_part( 'sidebar', 'question' ); ?>
	</div>
</div>
<?php endwhile;
wp_reset_query();
?>
<?php get_footer(); ?>