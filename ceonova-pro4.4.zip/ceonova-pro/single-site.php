<?php
$bg = _ceo('site-bg');
get_header();
?>
<div class="ceo-tag-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);">
    <div class="ceo-container ceo-containertag">
        <div class="ceo-tag-bgleft">
            <h3 class="ceo-hs"><?php the_title(); ?></h3>
        </div>
    </div>
</div>
<main class="ceo-site-single">
    <div class="ceo-container">
    	<?php while ( have_posts() ) : the_post(); ?>
    	<div class="ceo-margin-bottom" ceo-grid>
    		<div class="ceo-width-1-1@s ceo-width-2-3@m ceo-width-2-3@l ceo-width-2-3@xl">
    			<div class="site-box b-a ceo-background-default ceo-overflow-hidden">
    				<div class="ceo-margin-top" ceo-grid>
    					<div class="ceo-text-center ceo-width-1-1@s ceo-width-auto@m ceo-width-auto@l ceo-width-auto@xl">
    						<div class="site-box-cover b-r-4 ceo-inline ceo-overflow-hidden">
    							<img src="<?php echo post_thumbnail_src(); ?>" style="filter: blur(5px);">
    							<div class="ceo-overlay-primary ceo-position-cover ceo-flex ceo-flex-middle ceo-flex-center ceo-overflow-hidden ">
    								<div class="site-box-cover-small b-r-4 ceo-display-inline-block ceo-background-default ceo-overflow-hidden">
    								    <img src="<?php echo post_thumbnail_src(); ?>">
    							    </div>
    							</div>
    						</div>
    					</div>
    					<div class="site-content b-r-4 ceo-overflow-hidden ceo-width-1-1@s ceo-width-expand@m ceo-width-expand@l ceo-width-expand@xl">
    						<ul class="ceo-background-muted ceo-height-1-1 ceo-overflow-hidden">
    							<li><span>名称：</span><?php the_title(); ?></li>
    							<li><span>类型：</span><?php echo custom_taxonomies_terms_links(); ?></li>
    							<li><span>访问：</span><a href="<?php echo get_post_meta( get_the_ID(), '_site_director', true ); ?>" target="_blank" rel="nofollow" class="btn change-color b-r-4">访问网站 <i class="ceofont ceoicon-share-forward-line"></i></a></li>
    						</ul>
    					</div>
    				</div>
    			</div>
    			
    			<div class="ceo-margin-top site-content-sp b-a ceo-background-default ceo-margin-bottom">
    			    <div class="site-title b-b">
    					<span class="ceo-display-inline-block">简介</span>
    				</div>
    				<div class="ceo-margin-top">
    			    <?php the_content(); ?>
    			    </div>
    		    </div>
    		    
    		    <div class="ceo-margin-top">
            	<?php if(_ceo('comments_close') == false ): ?>	
            	<?php if ( comments_open() || get_comments_number() ) : ?>
            	<?php comments_template( '', true ); ?>
            	<?php endif; ?>
            	<?php endif; ?>
            	</div>
    		</div>
    		<div class="sidebar ceo-width-1-1@s ceo-width-1-3@m ceo-width-1-3@l ceo-width-1-3@xl">
    		    <div class="theiaStickySidebar">
        			<div class="site-box b-a ceo-background-default ceo-overflow-hidden ceo-margin-bottom">
        				<div class="site-title b-b">
        					<span class="ceo-display-inline-block">相关导航</span>
        				</div>
        				<div class="site-side ceo-grid-ceosmls ceo-margin-top" ceo-grid>
                            <?php
                            $args_relate=        						array(
                                'numberposts' => '10', //输出的文章数量
                                'post_type' => 'site',	//自定义文章类型名称
                            );
                            $current_cat = get_the_terms(get_the_ID(), 'sitecat');
                            if(!empty($current_cat[0])){
                                $args_relate['tax_query']=array(
                                    'taxonomy' => 'sitecat', //自定义分类法名称
                                    'terms'    => $current_cat[0]->term_id,
                                );
                            }
        					$posts = get_posts($args_relate);
        					?>
        					<?php if($posts): foreach($posts as $post): ?>	
        					<div class="ceo-width-1-2">
        						<a href="<?php the_permalink(); ?>" target="_blank" class="b-r-4 ceo-display-inline-block ceo-overflow-hidden" ceo-tooltip="<?php the_title(); ?>">
        						    <img src="<?php echo post_thumbnail_src(); ?>">
    						    </a>
        					</div>
        					<?php wp_reset_postdata(); endforeach; endif;?>
        				</div>
        			</div>
        			<div class="site-box b-a ceo-background-default ceo-margin-bottom">
        			    <a href="/user/site" target="_blank" class="site-box-tj">提交我的网站</a>
    			    </div>
    			</div>
    
    		</div>	
    	</div>
    	
    	<?php endwhile; ?>
    	
    </div>
</main>
<?php get_footer(); ?>