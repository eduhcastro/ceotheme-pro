<?php
get_header();
$post_id =  get_the_ID();
$userId = get_current_user_id();
$productInfo = CeoShopCoreProduct::getInfo($post_id, $userId);
$productTypeKey = CeoShopCoreProduct::getTypeKey($post_id);

$bg      = _ceo('single-post-bg');
$help_sz = _ceo('shop_help_sz');
/*产品顶部*/
$theme_color                 = get_post_meta( get_the_ID(), 'theme_color', true );
$theme_desc                  = get_post_meta( get_the_ID(), 'theme_desc', true );
$theme_original              = get_post_meta( get_the_ID(), 'theme_original', true );
$theme_discount              = get_post_meta( get_the_ID(), 'theme_discount', true );
$theme_demo                  = get_post_meta( get_the_ID(), 'theme_demo', true );
$theme_zdy1_title            = get_post_meta( get_the_ID(), 'theme_zdy1_title', true );
$theme_zdy1_link             = get_post_meta( get_the_ID(), 'theme_zdy1_link', true );
$theme_zdy2_title            = get_post_meta( get_the_ID(), 'theme_zdy2_title', true );
$theme_zdy2_link             = get_post_meta( get_the_ID(), 'theme_zdy2_link', true );
$theme_update                = get_post_meta( get_the_ID(), 'theme_update', true );
$down_info_arr               = get_post_meta( get_the_ID(), 'down_info', true );
$theme_slide                 = get_post_meta( get_the_ID(), 'theme_slide', true );
/*产品介绍*/
$theme_introduce_title       = get_post_meta( get_the_ID(), 'theme_introduce_title', true );
$theme_introduce_desc        = get_post_meta( get_the_ID(), 'theme_introduce_desc', true );
/*特色功能*/
$theme_characteristic_title  = get_post_meta( get_the_ID(), 'theme_characteristic_title', true );
$theme_characteristic_desc   = get_post_meta( get_the_ID(), 'theme_characteristic_desc', true );
$characteristic_sz           = get_post_meta( get_the_ID(), 'characteristic_sz', true );
/*附赠服务*/
$theme_service_title         = get_post_meta( get_the_ID(), 'theme_service_title', true );
$theme_service_desc          = get_post_meta( get_the_ID(), 'theme_service_desc', true );
$service_sz                  = get_post_meta( get_the_ID(), 'service_sz', true );
/*更多功能*/
$theme_more_title            = get_post_meta( get_the_ID(), 'theme_more_title', true );
$theme_more_desc             = get_post_meta( get_the_ID(), 'theme_more_desc', true );
$more_sz                     = get_post_meta( get_the_ID(), 'more_sz', true );
/*更新记录*/
$theme_update_title          = get_post_meta( get_the_ID(), 'theme_update_title', true );
$theme_update_desc           = get_post_meta( get_the_ID(), 'theme_update_desc', true );
$update_sz                   = get_post_meta( get_the_ID(), 'update_sz', true );
?>
<?php if ($productTypeKey != 'close' && $productTypeKey != '' ) : ?>
<?php while ( have_posts() ) : the_post(); ?>
<section class="ceo-shop-single" style="background-color: <?php echo $theme_color; ?>;">
    <div class="background-shape">
        <div class="circle1 wow fadeInRightBig" data-wow-duration="4000ms" style="visibility: visible; animation-duration: 4000ms; animation-name: fadeInRightBig;"></div>
        <div class="circle2 wow fadeInRightBig" data-wow-duration="4000ms" style="visibility: visible; animation-duration: 4000ms; animation-name: fadeInRightBig;"></div>
        <div class="circle3 wow fadeInRightBig" data-wow-duration="4000ms" style="visibility: visible; animation-duration: 4000ms; animation-name: fadeInRightBig;"></div>
        <div class="circle4 wow fadeInRightBig" data-wow-duration="4000ms" style="visibility: visible; animation-duration: 4000ms; animation-name: fadeInRightBig;"></div>
    </div>
    <div class="background-animation">
        <div class="star-ani"></div>
        <div class="cloud-ani"></div>
        <div class="triangle-ani"></div>
        <div class="circle-ani"></div>
        <div class="box-ani"></div>
    </div>
	<div class="ceo-container">
	    <div class="ceo-shop-single-box">
    		<div class="ceo-grid-ceosmls" ceo-grid>
    		    <div class="ceo-width-1-1 ceo-width-1-2@s">
    		        <div class="ceo-shop-single-z">
    		            <div class="shop-single-z-title">
                            <h1><?php the_title(); ?></h1>
                            <p><?php echo $theme_desc; ?></p>
                        </div>
                        <?php if (_ceo('ceo_shop_whole')) : ?>
						<?php if (get_current_user_id() > 0 || _ceo('ceo_shop_tourist')) : ?>
                        <div class="shop-single-z-price">
                            价格：<span><em><?php echo CeoShopCoreProduct::getPriceFormat($post_id, false) ?></em> <?php echo _ceo('ceo_shop_currency_name'); ?></span> <s>原价：<?php echo $theme_original; ?> <?php echo _ceo('ceo_shop_currency_name'); ?><i><?php echo $theme_discount; ?></i></s>
                        </div>
						<?php endif; ?>
						<?php endif; ?>
                        <div class="shop-single-z-btn">
                            <div class="ceo-grid-ceosmls" ceo-grid>
                                <?php if (_ceo('ceo_shop_whole')) : ?>
								<?php if (get_current_user_id() > 0 || _ceo('ceo_shop_tourist')) : ?>
								<div class="ceo-width-1-2">
									<?php if (get_current_user_id() == 0 && (!_ceo('ceo_shop_tourist_buy') || CeoShopCoreProduct::getTypeId(get_the_ID()) == 2)) : ?>
										<a href="#navbar-login" data-product-id="<?php echo get_the_ID() ?>" class="btn1" ceo-toggle>
											<span id="shop_single_an_id"><?php echo CeoShopCoreProduct::getPayButtonText(get_the_ID(), get_current_user_id()) ?></span>
										</a>
									<?php else : ?>
										<a href="javascript:void(0)" data-product-id="<?php echo get_the_ID() ?>" data-flush="<?php echo CeoShopCoreProduct::getTypeId(get_the_ID()) == 1 ? '1': '0' ?>" class="btn1 btn-ceo-purchase-product" data-style="slide-down">
											<span id="shop_single_an_id"><?php echo CeoShopCoreProduct::getPayButtonText(get_the_ID(), get_current_user_id()) ?></span>
										</a>
									<?php endif; ?>
								</div>
								<?php endif; ?>
								<?php endif; ?>
                                <div class="ceo-width-1-2">
                                    <a class="btn2" href="<?php echo $theme_demo; ?>" target="_blank"><?php if(_ceo('ceo_shop_single_an'))echo _ceo('ceo_shop_single_an')['ceo_shop_single_an_ys']; ?></a>
                                </div>
                            </div>
                            <div class="ceo-grid-ceosmls" ceo-grid>
                                <div class="ceo-width-1-4">
                                    <a class="btn3" href="<?php if(_ceo('ceo_shop_single_an'))echo _ceo('ceo_shop_single_an')['ceo_shop_single_an_hyl']; ?>" target="_blank"><?php if(_ceo('ceo_shop_single_an'))echo _ceo('ceo_shop_single_an')['ceo_shop_single_an_hy']; ?></a>
                                </div>
                                <div class="ceo-width-1-4">
                                    <a class="btn4" href="https://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo get_the_author_meta('qq',$user_id); ?>&amp;site=qq&amp;menu=yes" target="_blank" rel="noreferrer nofollow"><?php if(_ceo('ceo_shop_single_an'))echo _ceo('ceo_shop_single_an')['ceo_shop_single_an_zz']; ?></a>
                                </div>
                                <div class="ceo-width-1-4">
                                    <a class="btn4" href="<?php echo $theme_zdy1_link; ?>" target="_blank"><?php echo $theme_zdy1_title; ?></a>
                                </div>
                                <div class="ceo-width-1-4">
                                    <a class="btn4" href="<?php echo $theme_zdy2_link; ?>" target="_blank"><?php echo $theme_zdy2_title; ?></a>
                                </div>
                            </div>
                        </div>

    	                <div class="shop-single-z-meta">
    	                    <ul class="ul">
    	                        <?php if (_ceo('ceo_shop_whole')) : ?>
								<?php if (get_current_user_id() > 0 || _ceo('ceo_shop_tourist')) : ?>
    	                        <li class="li">
        	                        <span>会员权益：</span><?php echo CeoShopCoreProduct::getVipDiscountInfoFormat($post_id, get_current_user_id()) ?>
    	                        </li>
								<?php endif; ?>
								<?php endif; ?>
                                <?php if(_ceo('ceo_shop_single_xx_bh') == true ): ?>
    	                        <li class="li">
        	                        <span><?php echo _ceo('ceo_shop_single_xx_bhbt'); ?>：</span><p><?php echo get_the_ID(); ?></p>
    	                        </li>
    	                        <?php endif ?>
    	                        <li class="li">
        	                        <span>最后更新：</span><p><?php echo $theme_update; ?><a class="ceo_meta_go" href="#gxjl"><i class="ceofont ceoicon-question-fill"></i> 更新了什么</a></p>
    	                        </li>
    	                        <?php
                                if(!empty($down_info_arr)){
                                    foreach ($down_info_arr as $k=>$v){
                                        $number=$k+1;
                                        echo '<li class="li"><span>'.$v['title'].'：</span>'.'<p>'.$v['desc'].'</p></li>';
                                    }
                                }
                                ?>
                            </ul>
    	                </div>
                    </div>
    	        </div>
    	        <div class="ceo-width-1-1 ceo-width-1-2@s">
    	            <div class="ceo-shop-single-y">
    	                <div class="ceo-position-relative" ceo-slideshow="animation: fade">
                            <ul class="ceo-slideshow-items" style="box-shadow: 0 45px 80px -24px <?php echo $theme_color; ?>7a;">
                                <?php
                				if( is_array($theme_slide) ){
                					foreach ( $theme_slide as $value ): $i++; ?>
                                <li>
                                    <img src="<?php echo $value['img_s'];?>" alt="<?php the_title(); ?>">
                                </li>
                                <?php endforeach; }?>
                            </ul>
                            <div class="ceo-shop-single-ybo ceo-position-relative ceo-visible-toggle ceo-light" tabindex="-1" ceo-slider>
                                <ul class="ceo-thumbnav ceo-slider-items ceo-child-width-1-2 ceo-child-width-1-4@m ceo-grid">
                                    <?php
                                    $i=-1;
                    				if( is_array($theme_slide) ){
                    					foreach ( $theme_slide as $value ): $i++; ?>
                                    <li ceo-slideshow-item="<?php echo $i;?>">
                                        <a href="#"><img src="<?php echo $value['img_s'];?>" alt="<?php the_title(); ?>"></a>
                                    </li>
                                    <?php endforeach; }?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</div>
</section>

<div class="ceo-background-default">
    <!--快捷导航-->
    <div class="ceo-shop1-quick ceo-background-default ceo-visible@s" ceo-sticky="offset: 81; bottom: #top;" >
        <div class="ceo-container">
            <div class="ceo-shop1-quickbox">
                <a href="#ztjj"><?php echo $theme_introduce_title; ?></a>
                <?php if(get_post_meta(get_the_ID(), 'theme_characteristic_switcher', 1)){ ?>
                <a href="#tsgn"><?php echo $theme_characteristic_title; ?></a>
                <?php }?>
                <?php if(get_post_meta(get_the_ID(), 'theme_more_switcher', 1)){ ?>
                <a href="#gdgn"><?php echo $theme_more_title; ?></a>
                <?php }?>
                <?php if(get_post_meta(get_the_ID(), 'theme_service_switcher', 1)){ ?>
                <a href="#fzfw"><?php echo $theme_service_title; ?></a>
                <?php }?>
                <?php if(get_post_meta(get_the_ID(), 'theme_update_switcher', 1)){ ?>
                <a href="#gxjl"><?php echo $theme_update_title; ?></a>
                <?php }?>
                <?php if(_ceo('ceo_shop_help') == true): ?>
                <a href="#cjwt"><?php echo _ceo('shop_help_title'); ?></a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!--介绍模块-->
    <div id="ztjj" class="ceo-shop1-introduce">
        <div class="ceo-container">
            <div class="ceo-shop1-mktitle">
                <span><?php echo $theme_introduce_title; ?></span>
                <p><?php echo $theme_introduce_desc; ?></p>
            </div>
            <div class="ceo-shop1-content single-content">
				<?php the_content(); ?>
			</div>
        </div>
    </div>

    <?php if(get_post_meta(get_the_ID(), 'theme_characteristic_switcher', 1)){ ?>
    <!--特色功能-->
    <div id="tsgn" class="ceo-shop1-characteristic">
        <div class="ceo-container">
            <div class="ceo-shop1-mktitle">
                <span><?php echo $theme_characteristic_title; ?></span>
                <p><?php echo $theme_characteristic_desc; ?></p>
            </div>
            <div class="ceo-grid-medium" ceo-grid>
                <?php
				if( is_array($characteristic_sz) ){
					foreach ( $characteristic_sz as $value ): $i++; ?>
                <div class="ceo-width-1-1 ceo-width-1-4@s">
                    <div class="box ceo-dongtai">
    					<img src="<?php echo $value['img'];?>" alt="<?php echo $value['title'];?>">
    					<span><?php echo $value['title'];?></span>
    					<p><?php echo $value['desc'];?></p>
    				</div>
                </div>
                <?php endforeach; }?>
            </div>
        </div>
    </div>
    <?php } ?>

    <?php if(get_post_meta(get_the_ID(), 'theme_more_switcher', 1)){ ?>
    <!--更多功能-->
    <div id="gdgn" class="ceo-shop1-more">
        <div class="ceo-container">
            <div class="ceo-shop1-mktitle">
                <span><?php echo $theme_more_title; ?></span>
                <p><?php echo $theme_more_desc; ?></p>
            </div>
            <div class="ceo-shop1-morebox">
                <ul class="ceo-grid-medium" ceo-grid>
                    <?php
    				if( is_array($more_sz) ){
    					foreach ( $more_sz as $value ): $i++; ?>
                    <li class="ceo-width-1-1 ceo-width-1-2@s">
                        <i class="fa fa-check-circle-o"></i><?php echo $value['desc'];?>
                    </li>
                    <?php endforeach; }?>
                </ul>
            </div>
        </div>
    </div>
    <?php } ?>

    <?php if(get_post_meta(get_the_ID(), 'theme_service_switcher', 1)){ ?>
    <!--附赠服务-->
    <div id="fzfw" class="ceo-shop1-service ceo-background-cover ceo-background-muted ceo-panel">
        <div class="ceo-container">
            <div class="ceo-shop1-mktitle">
                <span><?php echo $theme_service_title; ?></span>
                <p><?php echo $theme_service_desc; ?></p>
            </div>
            <div class="ceo-shop1-servicebox">
                <div class="ceo-position-relative ceo-visible-toggle ceo-light" tabindex="-1" ceo-slider>
                    <ul class="ceo-slider-items ceo-child-width-1-2 ceo-child-width-1-6@m ceo-grid">
                        <?php
        				if( is_array($service_sz) ){
        					foreach ( $service_sz as $value ): $i++; ?>
                        <li>
                            <div class="box ceo-background-default">
            					<img src="<?php echo $value['img'];?>" alt="<?php echo $value['title'];?>">
            					<span><?php echo $value['title'];?></span>
            					<p><?php echo $value['desc'];?></p>
        					</div>
        				</li>
                        <?php endforeach; }?>
                    </ul>
                    <a class="ceo-position-center-left ceo-position-small" href="#" ceo-slidenav-previous ceo-slider-item="previous"></a>
                    <a class="ceo-position-center-right ceo-position-small" href="#" ceo-slidenav-next ceo-slider-item="next"></a>
                </div>
                <a href="https://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo get_the_author_meta('qq',$user_id); ?>&amp;site=qq&amp;menu=yes" target="_blank" class="btnsq" rel="noreferrer nofollow">点击领取<i class="anim"></i></a>
            </div>
        </div>
    </div>
    <?php } ?>
    
    <?php if(get_post_meta(get_the_ID(), 'theme_update_switcher', 1)){ ?>
    <!--更新记录-->
    <div id="gxjl" class="ceo-shop1-update">
        <div class="ceo-container">
            <div class="ceo-shop1-mktitle">
                <span><?php echo $theme_update_title; ?></span>
                <p><?php echo $theme_update_desc; ?></p>
            </div>
            <div class="ceo-shop1-updatebox ceo-panel b-a">
               <ul ceo-accordion="multiple: true;active: 0">
                   <?php
    				if( is_array($update_sz) ){
    					foreach ( $update_sz as $value ): $i++; ?>
                    <li>
                        <a class="ceo-accordion-title" href="#"><?php echo $value['title'];?></a>
                        <div class="ceo-accordion-content">
                            <?php echo $value['desc'];?>
                        </div>
                    </li>
                    <?php endforeach; }?>
                </ul>
            </div>
        </div>
    </div>
    <?php } ?>

    <?php if(_ceo('ceo_shop_help') == true): ?>
    <!--常见问题-->
    <div id="cjwt" class="ceo-shop1-qa">
        <div class="ceo-container">
            <div class="ceo-shop1-mktitle">
                <span><?php echo _ceo('shop_help_title'); ?></span>
                <p><?php echo _ceo('shop_help_subtitle'); ?></p>
            </div>
            <?php
			if ($help_sz) {
				foreach ( $help_sz as $key => $value) {
			?>
            <div class="ceo-shop1-qabox b-a">
                <div class="ceo-grid-collapse" ceo-grid>
                    <div class="ceo-width-1-1 ceo-width-1-5@s">
                        <div class="zs ceo-background-cover ceo-height-medium ceo-panel ceo-flex ceo-flex-center ceo-flex-middle">
                            <?php echo $value['title']; ?>
                        </div>
                    </div>
                    <div class="ceo-width-1-1 ceo-width-4-5@s">
                        <div class="ys">
                            <?php echo $value['content']; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php } } ?>
        </div>
    </div>
    <?php endif; ?>

</div>

<?php endwhile; ?>
<?php else: ?>

<!--文章-->

<div class="ceo-tag-bg ceo-app-bg ceo-single-post-bg ceo-background-cover" style="background-image: url(<?php echo $bg; ?>);">
    <div class="ceo-container ceo-containertag">
        <div class="ceo-tag-bgleft">
            <header class="single-post-wen">
            <h1 class="ceo-hs"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h1>
            <?php get_template_part( 'template-parts/single/single', 'info' ); ?>
            </header>
        </div>
    </div>
</div>
<div class="ceo-catnav-wz ceo-background-default ceo-visible@s">
    <div class="ceo-container">
	    <?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
	</div>
</div>
<section class="ceo-container">
	<div class="ceo-grid-ceosmls" ceo-grid>
		<div class="ceo-width-1-1 ceo-width-auto@s">
		    <div class="wp">
    			<div class="ceo-margin-bottom ceo-background-default">
					<div class="single-content">
        			    <div class="single-content-xq">
    			            <span>文章详情</span>
    		            </div>
					    <?php if(_ceo('single_zz_top_content') == true ): ?>
					    <div class="ceo-ad-single-content ceo-margin-bottom">
					        <a href="<?php echo _ceo('single_zz_top_content_link'); ?>" target="_blank" rel="noreferrer nofollow" class="ceo-display-block ceo-overflow-hidden">
                        		<img src="<?php echo _ceo('single_zz_top_content_img'); ?>"/>
                        	</a>
					    </div>
					    <?php endif ?>

						<?php the_content(); ?>
					</div>
    				<!--文章按钮-->
    				<div class="ceo-single-szcan">
    				    <?php if(_ceo('single_foo_sc') == true ): ?>
    				    <div class="ceo-single-szcan-dz">
                	        <?php echo ceotheme_post_collection_button( get_the_ID() );?>
                	    </div>
                	    <?php endif ?>
                	    <?php if(_ceo('single_foo_ds') == true ): ?>
                	    <div class="ceo-single-szcan-sc">
                	        <span>赏</span>
                	        <div class="ceo-single-dashang-img b-a">
                	            <p><img src="<?php echo _ceo('single_foo_ds_wximg'); ?>"> <?php echo _ceo('single_foo_ds_wxtext'); ?> </p>
            	                <p><img src="<?php echo _ceo('single_foo_ds_zfbimg'); ?>"> <?php echo _ceo('single_foo_ds_zfbtext'); ?> </p>
        	                </div>
                	    </div>
                	    <?php endif ?>
                	    <?php if(_ceo('single_foo_dz') == true ): ?>
                	    <div class="ceo-single-szcan-dz">
                            <?php echo ceotheme_post_like_button();?>
                        </div>
                        <?php endif ?>
                    </div>

    				<!--文章版权-->
    				<?php if (_ceo('single_foo_bq') == true ): ?>
    				<div class="ceo-padding-20">
        				<div class="ceo-text-small ceo-text-pu ceo-margin-remove ceo-cop-text ceo-hh-p b-r-4" ceo-alert>
        				    <?php if(get_post_meta( get_the_ID(), 'ceo-tese-source', true )){?>
            			    <div class="ceo-single-source">
        				        <i class="ceofont ceoicon-share-box-line"></i> 来源：<?php echo get_post_meta( get_the_ID(), 'ceo-tese-source', true );?>
        				    </div>
        				    <?php }?>
        					<p><i class="ceofont ceoicon-information-line"></i> 版权：<?php echo _ceo('single_foo_bq_text'); ?> </p>
        					<?php if (_ceo('single_foo_bq_link') == true ): ?>
        					<p>转载请注明出处：<?php the_permalink(); ?></p>
    				        <?php endif ?>
        				</div>
    				</div>
    				<?php endif ?>

    				<!--文章标签-->
    				<div class="ceo-single-tag-s">
    				    <div class="ceo-single-tag-s-tags ceo-flex-1">
    					<?php the_tags('', '') ?>
    					</div>
    				</div>

    				<!--文章作者-->
    				<div class="ceo-padding-20 b-t ceo-flex post-author-info">
    				    <div class="ceo-single-author-d ceo-flex-1">
        					<?php echo get_avatar(get_the_author_meta( 'ID' ), 25); ?>
        					<span class="ceo-text-small ceo-display-block ceo-margin-small-left"><?php the_author_posts_link(); ?></span>
    					</div>

                		<div class="share">
                            <a class="share-post meta-item mobile j-mobile-share" href="javascript:;" data-id="<?php echo get_the_ID(); ?>"
                               data-qrcode="<?php echo get_the_permalink(); ?>">
                                <i class="ceofont ceoicon-image-line"></i> 生成海报
                            </a>
                            <?php
    							$qrcode = ''.get_bloginfo('template_directory').'/inc/qrcode?data='.get_the_permalink().'';
    							$post_url = esc_url(get_permalink());
    							$post_title = esc_attr(get_the_title());
    							$post_desc = wp_trim_words( get_the_content(), 30 );
    						?>
    						<p class="ceo-visible@s ceo-display-inline-block">分享</p>
    						<a class="weixin-share ceo-display-inline-block ceo-visible@s" href="<?php echo $qrcode; ?>" ceo-tooltip="分享到微信" data-image="<?php echo esc_attr($post_image); ?>" target="_blank"><i class="ceofont ceoicon-wechat-fill"></i>
    						</a>
    						<a class="ceo-display-inline-block ceo-visible@s" href="http://connect.qq.com/widget/shareqq/index.html?url=<?php echo $post_url; ?>&sharesource=qzone&title=<?php echo $post_title; ?>&pics=<?php echo post_thumbnail_src(); ?>&summary=<?php echo $post_desc; ?>"  ceo-tooltip="分享到QQ好友/QQ空间" target="_blank" rel="noreferrer nofollow"><i class="ceofont ceoicon-qq-fill"></i>
    						</a>
    						<a class="ceo-display-inline-block ceo-visible@s" href="http://service.weibo.com/share/mobile.php?url=<?php echo $post_url; ?>&title=<?php echo $post_title ?> - <?php bloginfo('name'); ?>&appkey=3313789115" ceo-tooltip="分享到微博" target="_blank" rel="noreferrer nofollow"><i class="ceofont ceoicon-weibo-fill"></i>
    						</a>
                		</div>
    				</div>
    			</div>
    			<?php get_template_part( 'template-parts/single/single', 'page' ); ?>

    			<?php if(_ceo('single_zz_foo_content') == true ): ?>
    		    <div class="ceo-ad-single-bottom ceo-margin-bottom ceo-background-default">
    		        <a href="<?php echo _ceo('single_zz_foo_content_link'); ?>" target="_blank" rel="noreferrer nofollow" class="ceo-display-block ceo-overflow-hidden">
                		<img src="<?php echo _ceo('single_zz_foo_content_img'); ?>"/>
                	</a>
    		    </div>
    		    <?php endif ?>

                <?php if(_ceo('xg_show') == true ): ?>
    			<?php get_template_part( 'template-parts/single/single', 'bottom' ); ?>
    			<?php endif ?>

    			<?php if(_ceo('comments_close') == false ): ?>
    			<?php if ( comments_open() || get_comments_number() ) : ?>
    			<?php comments_template( '', true ); ?>
    			<?php endif; ?>
    			<?php endif; ?>

			</div>
		</div>
		<?php get_sidebar(); ?>
	</div>
</section>
<?php endif; ?>
<!--必备-->
<?php add_action('get_footer', function () { wp_enqueue_script('js2021', get_template_directory_uri() . '/static/js/js21.js', ['jquery']); }); ?>
<?php get_footer(); ?>