<?php
if(!empty($author)){
    $user_id=$author;
}
?>
<div class="wp">
    <div class="blog ajaxMain">
    	<?php
        //我的发布
        global $wp_query;
        $page=!empty(get_query_var('paged')) ?get_query_var('paged') :1;
        $wp_query = new WP_Query(
            array(
                'post_type'      => 'post',
                'posts_per_page' => 12,
                'post_status'    => 'publish',
                'author' => $user_id,
                'paged' => $page
            )
        );
        if(have_posts()) : while (have_posts()) : the_post(); ?>
    	    <?php get_template_part( 'template-parts/loop/loop', 'blog' ); ?>
    	<?php endwhile;endif; ?>
	</div>
</div>
<?php if( _ceo('cat_load' ) == 'num' ){?>
<div class="fenye ceo-text-center ceo-text-small ceo-margin-medium-top ceo-margin-medium-bottom">
	<?php fenye(); ?>
</div>
<? }else{ ?>
<div id="ajaxBtn" class="ajax-btn ceo-text-center ceo-margin-medium">
	<?php next_posts_link(__('点击加载更多')); ?>
</div>
<?php } ?>