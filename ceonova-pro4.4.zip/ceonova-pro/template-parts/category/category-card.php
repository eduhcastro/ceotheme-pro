<?php
	$term = get_category(get_query_var('cat'));
?>
<?php
$cate_background_img=get_term_meta($term->term_id,'cate_background_img',1);
if(!empty($cate_background_img['url'])) {
?>
<div class="ceo-tag-bg ceo-background-cover" style="background-image: url(<?php echo $cate_background_img['url'];?>);">
<?php }elseif(_ceo('category_default_bg')){ ?>
<div class="ceo-tag-bg ceo-background-cover" style="background-image: url(<?php echo _ceo('category_default_bg'); ?>);">
<?php }?>
    <div class="ceo-container ceo-containertag">
        <div class="ceo-tag-bgleft">
            <h3 class="ceo-hs"><?php single_cat_title(); ?></h3>
            <p class="ceo-visible@s"><?php echo category_description();?></p>
        </div>
    </div>
</div>

<?php if ( _ceo('ceo_shop_cat') == true): ?>
<div class="ceo-card-category-box ceo-background-default">
    <div class="ceo-container">
        <?php if(_ceo('ceo_shop_cat_nav') == true): ?>
        <div class="ceo-category-card-box">
    		<?php ceo_catnav_ji(); ?>
    	</div>
    	<?php endif; ?>
    	<div class="ceo-grid-ceosmls" ceo-grid>
    	    <?php if(_ceo('ceo_shop_cat_price') == true): ?>
            <div class="ceo-catnav-ss ceo-width-1-1@s ceo-width-expand@m ceo-width-expand@l ceo-width-expand@xl">
                <ul>
                    <li>
        				<strong>价格：</strong>
        			</li>
                    <li><a href="<?php echo get_category_link(get_queried_object_id()); ?>">全部</a></li>
					<li><a href="<?php echo get_category_link(get_queried_object_id()); ?>?filter_type_1=1">免费</a></li>
					<li><a href="<?php echo get_category_link(get_queried_object_id()); ?>?filter_type_2=1">收费</a></li>
					<li><a href="<?php echo get_category_link(get_queried_object_id()); ?>?filter_type_3=1">VIP专属</a></li>
					<li><a href="<?php echo get_category_link(get_queried_object_id()); ?>?filter_type_4=1">VIP免费</a></li>
                </ul>
    		</div>
    		<?php endif; ?>
    		<div class="ceo-fl-icon ceo-width-1-1@s ceo-width-auto@m ceo-width-auto@l ceo-width-auto@xl">
                <?php if ( _ceo('ceo_shop_cat_tj') == true): ?>
    		    <div class="ceo-card-rili ceo-visible@s">
        		    <i class="ceofont ceoicon-pie-chart-line"></i>共<span class="ceo-text-warning ceo-text-bold"> <?php echo get_cat_postcount($term->term_id); ?> </span>个作品
                </div>
                <?php endif; ?>
                <?php if(_ceo('ceo_shop_cat_sort') == true): ?>
                <a class="hot" href="<?php echo get_category_link($cat) ?>"> <i class="ceofont ceoicon-time-line"></i>最新 </a>
                <a class="hot" href="<?php echo get_category_link($cat) ?>?order=hot"> <i class="ceofont ceoicon-fire-line"></i>最热 </a>
                <a class="hot" href="<?php echo get_category_link($cat) ?>?order=rand"> <i class="ceofont ceoicon-refresh-line"></i>随机 </a>
                <?php endif; ?>
    		</div>
    	</div>
	</div>
</div>
<?php endif; ?>
<?php if ( _ceo('ceo_shop_cat') == false): ?>
<div class="ceo-margin-medium"></div>
<?php endif; ?>

<section class="ceo-container" id="category">
    <div class="card">
        <div class="ajaxMain ceo-grid-medium" ceo-grid>
        	<?php if ( have_posts() ) :  while ( have_posts() ) : the_post(); ?>
        	<div class="ajaxItem ceo-width-1-1@s ceo-width-1-3@m ceo-width-1-3@l ceo-width-1-3@xl">
        	<?php get_template_part( 'template-parts/loop/loop', 'card' ); ?>
        	</div>
        	<?php endwhile;endif; ?>
    	</div>
    </div>
    <?php if( _ceo('cat_load' ) != 'num' ){?>
    <div id="ajaxBtn" class="ajax-btn ceo-text-center ceo-margin-medium">
    	<?php next_posts_link(__('点击加载更多')); ?>
    </div>
    <? }else{ ?>
    <div class="fenye ceo-text-center ceo-text-small ceo-margin-medium-top ceo-margin-medium-bottom">
    	<?php fenye(); ?>
    </div>
    <?php } ?>
</section>