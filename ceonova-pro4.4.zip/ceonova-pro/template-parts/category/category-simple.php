<?php
	$term = get_category(get_query_var('cat'));
?>
<?php
$cate_background_img=get_term_meta($term->term_id,'cate_background_img',1);
if(!empty($cate_background_img['url'])) {
?>
<div class="ceo-tag-bg ceo-app-bg ceo-background-cover" style="background-image: url(<?php echo $cate_background_img['url'];?>);">
<?php }elseif(_ceo('category_default_bg')){ ?>
<div class="ceo-tag-bg ceo-app-bg ceo-background-cover" style="background-image: url(<?php echo _ceo('category_default_bg'); ?>);">
<?php }?>
    <div class="ceo-container ceo-containertag">
        <div class="ceo-tag-bgleft">
            <h3 class="ceo-hs"><?php single_cat_title(); ?></h3>
            <p class="ceo-visible@s"><?php echo category_description();?></p>
        </div>
    </div>
</div>
<div class="ceo-catnav-wz ceo-background-default ceo-visible@s">
    <div class="ceo-container">
        <div class="ceo-flex">
            <div class="ceo-flex-1">
    	    <?php if(function_exists('cmp_breadcrumbs')) cmp_breadcrumbs();?>
    	    </div>
    	    <?php if ( _ceo('ceo-cat-tj') == true): ?>
    		<div class="ceo-visible@s">
        		<div class="ceo-fl-icon">
                    <i class="ceofont ceoicon-pie-chart-line"></i>共<span> <?php echo get_cat_postcount($term->term_id); ?> </span>篇文章
                </div>
            </div>
            <?php endif; ?>
        </div>
	</div>
</div>

<section class="ceo-category-simple">
    <div class="ceo-container" id="category">
        <div class="ceo-grid-ceosmls" ceo-grid>
        	<div class="ceo-width-1-1 ceo-width-auto@s">
        		<div class="wp">
                    <div class="ceo-category-box ceo-background-default b-a">
                        <div class="ceo-container">
                            <div class="ceo-category-blog-box">
                        		<?php ceo_catnav_wenji(); ?>
                        	</div>
                    	</div>
                    </div>
        			<div class="simple ajaxMain b-a ceo-background-default">
        				<?php if ( have_posts() ) :  while ( have_posts() ) : the_post(); ?>
        				<?php get_template_part( 'template-parts/loop/loop', 'simple' ); ?>
        				<?php endwhile;endif; ?>
        			</div>
        		</div>
                <?php if( _ceo('cat_load' ) == 'num' ){?>
                <div class="fenye ceo-text-center ceo-text-small ceo-margin-medium-top ceo-margin-medium-bottom">
                	<?php fenye(); ?>
                </div>
                <? }else{ ?>
                <div id="ajaxBtn" class="ajax-btn ceo-text-center ceo-margin-medium">
                	<?php next_posts_link(__('点击加载更多')); ?>
                </div>
                <?php } ?>
        	</div>
        	<?php get_sidebar(); ?>
        </div>
    </div>
</section>