<?php if(_ceo('ceo_foo_banner') == true ): ?>
<div class="ceo-footer-banner ceo-background-cover" style="background-image: url(<?php echo _ceo('ceo_foo_banner_bg'); ?>);">
    <div class="ceo-container">
        <div class="ceo-footer-banner-box">
            <h2><?php echo _ceo('ceo_foo_banner_title'); ?></h2>
            <p><?php echo _ceo('ceo_foo_banner_subtitle'); ?></p>
            <a href="<?php echo _ceo('ceo_foo_banner_anlink'); ?>" target="_blank"><?php echo _ceo('ceo_foo_banner_antitle'); ?></a>
        </div>
    </div>
</div>
<?php endif; ?>