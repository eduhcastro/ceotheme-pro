<?php if(_ceo('goTop') == true): ?>
<div class="gotop ceo-animation-slide-bottom-small">
    <div class="gotop-box">
        <?php if(_ceo('goTop_hd') == true): ?>
        <div class="ceo_follow_img">
            <a href="<?php echo _ceo('goTop_hd_link'); ?>" class="ceo_follow_img_a" target="_blank" style="background: url(<?php echo _ceo('goTop_hd_img'); ?>) center no-repeat;"></a>
        </div>
        <?php endif; ?>
        
        <div class="gotop-boxan">
            <?php if(_ceo('goTop_qd') == true): ?>
            <div class="gotop-item ceo-background-default">
                <a href="javascript:void(0)" class="btn-ceo-sign ceo-sign member-sign ceo-display-block">
                    <i class="ceofont <?php echo _ceo('goTop_qd_icon'); ?>"></i>
                    <span class="gotop-span"><?php echo _ceo('goTop_qd_title'); ?></span>
                </a>
            </div>
            <?php endif; ?>
            
            <?php if(_ceo('goTop_encourage') == true): ?>
            <div class="gotop-item ceo-background-default">
                <a href="javascript:void(0)" class="btn-ceo-lottery ceo-display-block">
                    <i class="ceofont <?php echo _ceo('goTop_encourage_icon'); ?>"></i>
                    <span class="gotop-span"><?php echo _ceo('goTop_encourage_title'); ?></span>
                </a>
            </div>
            <?php endif; ?>
        
            <?php if(_ceo('goTop_service') == true): ?>
        	<div class="gotop-item ceo-background-default gotop-service">
        	    <i class="ceofont <?php if(_ceo('goTop_service_sz'))echo _ceo('goTop_service_sz')['goTop_service_icon']; ?>"></i>
        	    <div class="gotop-service-box ceo-background-default b-a">
        	        <span class="you"></span>
                    <div class="tops">
                        <img src="<?php if(_ceo('goTop_service_sz'))echo _ceo('goTop_service_sz')['goTop_service_img']; ?>">
                        <a href="tencent://Message/?Uin=<?php if(_ceo('goTop_service_sz'))echo _ceo('goTop_service_sz')['goTop_qq_qq']; ?>&amp;websiteName=#=&amp;Menu=yes" class="topsqq"><?php if(_ceo('goTop_service_sz'))echo _ceo('goTop_service_sz')['goTop_service_bt']; ?></a>
                        <p><?php if(_ceo('goTop_service_sz'))echo _ceo('goTop_service_sz')['goTop_service_sj']; ?></p>
                    </div>
                    <div class="btms">
                        <h5><?php if(_ceo('goTop_service_sz'))echo _ceo('goTop_service_sz')['goTop_service_dhbt']; ?></h5>
                        <p><?php if(_ceo('goTop_service_sz'))echo _ceo('goTop_service_sz')['goTop_service_dhhm']; ?></p>
                        <h4><?php if(_ceo('goTop_service_sz'))echo _ceo('goTop_service_sz')['goTop_service_yxbt']; ?></h4>
                        <span><?php if(_ceo('goTop_service_sz'))echo _ceo('goTop_service_sz')['goTop_service_yxhm']; ?></span>
                    </div>
                </div>
            </div>
        	<?php endif; ?>
        	
        	<?php if(_ceo('goTop_wx') == true): ?>
        	<div class="gotop-item ceo-background-default gotop-wx">
        	    <i class="ceofont <?php if(_ceo('goTop_wx_sz'))echo _ceo('goTop_wx_sz')['goTop_wx_icon']; ?>"></i>
        	    <div class="gotop-wx-box ceo-background-default b-a">
        	        <span class="you"></span>
                    <div class="tops">
                        <p><?php if(_ceo('goTop_wx_sz'))echo _ceo('goTop_wx_sz')['goTop_wx_title']; ?></p>
                        <p><?php if(_ceo('goTop_wx_sz'))echo _ceo('goTop_wx_sz')['goTop_wx_subtitle']; ?></p>
                        <img src="<?php if(_ceo('goTop_wx_sz'))echo _ceo('goTop_wx_sz')['goTop_wx_img']; ?>">
                    </div>
                </div>
            </div>
        	<?php endif; ?>
        	
        	<?php if(_ceo('goTop_sj') == true): ?>
        	<div class="gotop-item ceo-background-default gotop-ma">
        	    <i class="ceofont <?php if(_ceo('goTop_sj_sz'))echo _ceo('goTop_sj_sz')['goTop_sj_icon']; ?>"></i>
        	    <div class="gotop-ma-box">
        	        <i></i>
                    <div class="tops">
                        <p><?php if(_ceo('goTop_sj_sz'))echo _ceo('goTop_sj_sz')['goTop_sj_title']; ?></p>
                        <p><?php if(_ceo('goTop_sj_sz'))echo _ceo('goTop_sj_sz')['goTop_sj_subtitle']; ?></p>
                        <img src="<?php if(_ceo('goTop_sj_sz'))echo _ceo('goTop_sj_sz')['goTop_sj_img']; ?>"/>
                    </div>
                    <em></em>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="gotop-item gotops ceo-background-default" id="gotops">
                <a href="#header" class="ceo-display-block" ceo-scroll>
                    <i class="ceofont ceoicon-arrow-up-s-line"></i>
                    <span class="gotop-span">返回顶部</span>
                </a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<div class="ceo-app-gotop gotops ceo-hidden@s" id="gotops">
    <a href="#header" class="ceo-display-block" ceo-scroll>
        <i class="ceofont ceoicon-arrow-up-s-line"></i>
    </a>
</div>