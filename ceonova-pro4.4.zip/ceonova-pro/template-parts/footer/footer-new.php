<?php if(_ceo('footer_new') == true ): ?>
<?php if (is_single() == false ) { ?>
<div class="ceo-container ceo-visible@s">
    <div class="ceo-footer-new">
        <div class="ceo-footer-newbox ceo-flex">
            <div class="ceo-flex-1">
                <a href="<?php if(_ceo('footer_new_mk'))echo _ceo('footer_new_mk')['footer_new_link']; ?>" class="newwen"><em class="my-face"><?php if(_ceo('footer_new_mk'))echo _ceo('footer_new_mk')['footer_new_tag']; ?></em><?php if(_ceo('footer_new_mk'))echo _ceo('footer_new_mk')['footer_new_title']; ?></a>
            </div>
            <a href="<?php if(_ceo('footer_new_mk'))echo _ceo('footer_new_mk')['footer_new_link']; ?>" class="newbtn"><?php if(_ceo('footer_new_mk'))echo _ceo('footer_new_mk')['footer_new_antitle']; ?></a>
        </div>
    </div>
</div>
<?php } ?>
<?php endif; ?>