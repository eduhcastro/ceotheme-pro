<?php
	$card = _ceo('card_sz');
    $cat = $card['cat_id'];
	if(!$card){
?>
<div class="ceo-container ceo-margin-bottom">
	<div class="ceo-alert-primary" ceo-alert>
		<a class="ceo-alert-close" ceo-close></a>
		<p class="ceo-text-small"><i class="ceofont ceoicon-information-fill ceo-margin-small-right"></i>请前往后台<i class="ceofont ceoicon-arrow-right-s-line"></i>主题设置<i class="ceofont ceoicon-arrow-right-s-line"></i>首页设置<i class="ceofont ceoicon-arrow-right-s-line"></i><b>卡片模块</b>，设置该模块内容！</p>
	</div>
</div>
<?php }else { ?>
<div class="ceo-home-card ceo-background-default">
    <div class="ceo-container">
        <div class="ceo-home-title">
            <span><?php echo _ceo('card_title'); ?></span>
            <p><?php echo _ceo('card_subtitle'); ?></p>
        </div>
        <div class="card">
            <div class="ceo-grid-medium" ceo-grid>
                <?php 
    		        query_posts('cat='.$cat.'&showposts='.$card['num']);
    		        while (have_posts()) : the_post(); 
    		    ?>
    		    <div class="ceo-width-1-1 ceo-width-1-3@s">
    		    <?php get_template_part( 'template-parts/loop/loop', 'card' ); ?>
    		    </div>
                <?php endwhile; wp_reset_query(); ?>
            </div>
            <div class="ceo-card-more">
                <a href="<?php echo get_category_link( $cat ); ?>"><?php echo _ceo('card_more'); ?></a>
            </div>
        </div>
    </div>
</div>
<?php } ?>