<?php
	$community     = _ceo('community_title');
	$community_cms = _ceo('community_cms');
	if(!$community){
?>
<div class="ceo-container ceo-margin-bottom">
	<div class="ceo-alert-primary" ceo-alert>
		<a class="ceo-alert-close" ceo-close></a>
		<p class="ceo-text-small"><i class="ceofont ceoicon-information-fill ceo-margin-small-right"></i>请前往后台<i class="ceofont ceoicon-arrow-right-s-line"></i>主题设置<i class="ceofont ceoicon-arrow-right-s-line"></i>首页设置<i class="ceofont ceoicon-arrow-right-s-line"></i><b>社区模块</b>，设置该模块内容！</p>
	</div>
</div>
<?php }else { ?>
<div class="ceo-home-community ceo-background-default">
    <div class="home-community-bg ceo-background-cover ceo-panel ceo-flex-center ceo-flex-middle" style="background-image: url(<?php echo _ceo('community_img'); ?>)">
        <span><?php echo _ceo('community_title'); ?></span>
        <p><?php echo _ceo('community_subtitle'); ?></p>
    </div>
    <div class="ceo-container">
        <div class="home-community-box">
            <div class="ceo-grid-ceosmls" ceo-grid>
                <?php 
    			if ($community_cms) { 
    				foreach ( $community_cms as $key => $value) {
    			?>
    			<div class="ceo-width-1-2 ceo-width-1-4@s">
    			    <a href="<?php echo $value['link']; ?>" target="_blank" class="home-community-boxitem">
        				<img src="<?php echo $value['img']; ?>" alt="<?php echo $value['title']; ?>">
        				<span><?php echo $value['title']; ?></span>
        				<p></p>
    				</a>
    			</div>
    			<?php } } ?>
			</div>
		</div>
		<div class="home-community-list">
            <div class="ceo-grid-ceosmls" ceo-grid>
                <!--问答模块-->
                <div class="ceo-width-1-1 ceo-width-1-2@s">
                    <div class="home-community-list-box">
                    	<div class="home-community-list-boxtop ceo-background-cover ceo-panel ceo-flex ceo-flex-center ceo-flex-middle" style="background-image: url(<?php if(_ceo('community_q_sz'))echo _ceo('community_q_sz')['community_q_img']; ?>)">
                        	<a href="<?php if(_ceo('community_q_sz'))echo _ceo('community_q_sz')['community_q_link']; ?>" target="_blank"><?php if(_ceo('community_q_sz'))echo _ceo('community_q_sz')['community_q_title']; ?></a>
                        </div>
                        <div class="home-community-list-box-new">
                            <ul>
                                <?php
                                $_args = array(
                                    'post_type' => 'question',
                                    'paged' => get_query_var('paged', 1),
                                    'posts_per_page' => 5,
                                );
                                $PostData = new WP_Query( $_args );
                                ?>

                                <?php if ( $PostData->have_posts() ) { ?>
                                <?php
                                while ( $PostData->have_posts() ) : $PostData->the_post();
                                    $post_id = get_the_ID();
                                    $comments_number = get_comments_number( $post_id );
                                    $question_comment_num = get_question_comment_num($post_id);
                                    $xz = (!empty($question_comment_num)) ? ' xz' : '' ;
                                ?>
                                <li>
                                    <div class="bots ceo-flex">
                                        <a href="/author/<?php echo the_author_meta( 'user_login' ); ?>" target="_blank" class="avatar">
                                            <?php echo get_avatar(get_the_author_meta( 'ID' ), 20); ?>
                                            <em><?php the_author(); ?></em>
                                        </a>
                                    	<div class="ceo-flex-1 ceo-text-truncate">
                                            <a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a>
                                        </div>
                                        <span><em><?php echo $question_comment_num;?></em>个回答</span>
                                    </div>
                                </li>
                                <?php endwhile; } ?>
                            </ul>
                            <div class="home-community-list-box-btn">
                                <a href="<?php if(_ceo('community_q_sz'))echo _ceo('community_q_sz')['community_q_link']; ?>" target="_blank" class="z">查看更多</a>
                                <?php if( is_user_logged_in() ){ ?>
                                <a href="/question?type=ask" target="_blank" class="y">快速提问</a>
                                <?php }else{ ?>
                                <a href="#navbar-login" ceo-toggle class="y">快速提问</a>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!--论坛模块-->
                <div class="ceo-width-1-1 ceo-width-1-2@s">
                    <div class="home-community-list-box">
                        <div class="home-community-list-boxtop ceo-background-cover ceo-panel ceo-flex ceo-flex-center ceo-flex-middle" style="background-image: url(<?php if(_ceo('community_f_sz'))echo _ceo('community_f_sz')['community_f_img']; ?>)">
                        	<a href="<?php if(_ceo('community_f_sz'))echo _ceo('community_f_sz')['community_f_link']; ?>" target="_blank"><?php if(_ceo('community_f_sz'))echo _ceo('community_f_sz')['community_f_title']; ?></a>
                        </div>
                        <div class="home-community-list-box-new">
                            <ul>
                                <?php
                                $_args = array(
                                    'post_type' => 'forum',
                                    'paged' => get_query_var('paged', 1),
                                    'posts_per_page' => 5,
                                );
                                $PostData = new WP_Query( $_args );
                                ?>

                                <?php if ( $PostData->have_posts() ) { ?>
                                    <?php
                                    while ( $PostData->have_posts() ) : $PostData->the_post();
                                    $post_id = get_the_ID();
                                    $comments_number = get_comments_number( $post_id );
                                    ?>
                                    <li>
                                        <div class="ceo-flex">
                                            <a href="/author/<?php echo the_author_meta( 'user_login' ); ?>" target="_blank" class="avatar">
                                                <?php echo get_avatar(get_the_author_meta( 'ID' ), 20); ?>
                                                <em><?php the_author(); ?></em>
                                            </a>
                                            <div class="ceo-flex-1 ceo-text-truncate bots">
                                                <a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a>
                                            </div>
                                            <span><em><?php post_views('', ''); ?></em>次浏览</span>
                                        </div>
                                    </li>
                                <?php endwhile; } ?>
                            </ul>
                            <div class="home-community-list-box-btn">
                                <a href="<?php if(_ceo('community_f_sz'))echo _ceo('community_f_sz')['community_f_link']; ?>" target="_blank" class="z">查看更多</a>
                                <?php if( is_user_logged_in() ){ ?>
                                <a href="/forum?type=ask" target="_blank" class="y">快速发帖</a>
                                <?php }else{ ?>
                                <a href="#navbar-login" ceo-toggle class="y">快速发帖</a>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php } ?>