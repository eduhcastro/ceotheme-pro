<?php
	$file = _ceo('ceo_file_only');
	if(!$file){
?>
<div class="ceo-container ceo-margin-bottom">
	<div class="ceo-alert-primary" ceo-alert>
		<a class="ceo-alert-close" ceo-close></a>
		<p class="ceo-text-small"><i class="ceofont ceoicon-information-fill ceo-margin-small-right"></i>请前往后台<i class="ceofont ceoicon-arrow-right-s-line"></i>主题设置<i class="ceofont ceoicon-arrow-right-s-line"></i>首页设置<i class="ceofont ceoicon-arrow-right-s-line"></i><b>文档模块</b>，设置该模块内容！</p>
	</div>
</div>
<?php }else { ?>
<div class="ceo-home-file">
    <div class="ceo-container">
        <div class="ceo-home-title">
            <span><?php echo _ceo('ceo_file_title'); ?></span>
            <p><?php echo _ceo('ceo_file_subtitle'); ?></p>
        </div>
        <div class="ceo-home-file-box">
            <div class="ceo-grid-ceosmls" ceo-grid>
                <?php
                if ($file) {
                foreach ( $file as $key => $value) {
                    if(!$value['id']){
                        continue;
                    }
                ?>
            	<ul class="ceo-width-1-1 ceo-width-1-3@s">
            	    <div class="ceo-home-file-boxmk ceo-background-default">
                	    <div class="ceo-home-file-boxtop ceo-background-cover ceo-panel ceo-flex ceo-flex-center ceo-flex-middle" style="background-image: url(<?php echo esc_url( $value['img'] ); ?>)">
                        	<a href="<?php echo get_category_link( $value['id'] ); ?>" target="_blank"><?php echo get_cat_name($value['id']) ?></a>
                        </div>
                        <?php query_posts('cat='.$value['id'] .'&showposts='.$value['num'] ); ?>
                        <?php while (have_posts()) : the_post(); ?>
                        <li>
                            <div class="ceo-flex">
                            	<a href="<?php echo get_permalink();?>" title="<?php echo get_the_title();?>" target="_blank" class="ceo-flex-1 ceo-text-truncate"><?php echo get_the_title();?></a>
                                <span><?php the_time('Y-m-d') ?></span>
                            </div>
                        </li>
                        <?php endwhile; wp_reset_query(); ?>
                        <div class="ceo-home-file-boxbottom">
                            <a href="<?php echo get_category_link( $value['id'] ); ?>" target="_blank">更多<i class="ceofont ceoicon-arrow-right-s-line"></i></a>
                        </div>
                    </div>
                </ul>
                <?php } } ?>
            </div>
        </div>
    </div>
</div>
<?php } ?>