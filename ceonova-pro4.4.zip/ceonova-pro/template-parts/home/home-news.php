<?php
	$news = _ceo('news_sz');
    $cat = $news['cat_id'];
	if(!$news){
?>
<div class="ceo-container ceo-margin-bottom">
	<div class="ceo-alert-primary" ceo-alert>
		<a class="ceo-alert-close" ceo-close></a>
		<p class="ceo-text-small"><i class="ceofont ceoicon-information-fill ceo-margin-small-right"></i>请前往后台<i class="ceofont ceoicon-arrow-right-s-line"></i>主题设置<i class="ceofont ceoicon-arrow-right-s-line"></i>首页设置<i class="ceofont ceoicon-arrow-right-s-line"></i><b>资讯模块</b>，设置该模块内容！</p>
	</div>
</div>
<?php }else { ?>
<div class="ceo-home-news">
    <div class="ceo-container">
        <div class="ceo-home-title">
            <span><?php echo _ceo('news_title'); ?></span>
            <p><?php echo _ceo('news_subtitle'); ?></p>
        </div>
        <div class="ceo-home-news-box">
            <div class="ceo-grid-ceosmls" ceo-grid>
                <?php 
    		        query_posts('cat='.$cat.'&showposts='.$news['num']);
    		        while (have_posts()) : the_post(); 
    		    ?>
    		    <div class="ceo-width-1-1 ceo-width-1-2@s">
        		    <div class="home-news-boxmk">
        		        <div class="ceo-grid-ceosmls" ceo-grid>
        					<div class="ceo-width-auto">
        						<span class="md"><?php the_time('m-d') ?></span>
        						<p class="y"><?php the_time('Y') ?></p>
        					</div>
        					<div class="ceo-width-expand">
        						<div class="title ceo-text-truncate">
        						    <a href="<?php the_permalink(); ?>" target="_blank" title="<?php the_title(); ?>"><?php the_title(); ?></a>
    						    </div>
        						<p class="content ceo-text-truncate"><?php echo wp_trim_words( get_the_content(), 30 ); ?></p>
        					</div>
        					<div class="ceo-width-auto">
        					    <a href="<?php the_permalink(); ?>" target="_blank" class="btn">查看详情</a>
        					</div>
    					</div>
    				</div>
				</div>
                <?php endwhile; wp_reset_query(); ?>
            </div>
            <div class="btns">
			    <a href="<?php echo get_category_link( $cat ); ?>" target="_blank"><i class="ceofont ceoicon-share-forward-line"></i></a>
			</div>
        </div>
    </div>
</div>
<?php } ?>