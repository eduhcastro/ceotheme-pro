<?php
    $app_zcd   = _ceo('ceo_app_zcd_sz');
    $slide_cms = _ceo('slide_cms');
    $slide2    = _ceo('slide2'); 
    if(!$slide2){ 
?>
<div class="ceo-container ceo-margin-bottom">
	<div class="ceo-alert-primary" ceo-alert>
		<a class="ceo-alert-close" ceo-close></a>
		<p class="ceo-text-small"><i class="ceofont ceoicon-information-fill ceo-margin-small-right"></i>请前往后台<i class="ceofont ceoicon-arrow-right-s-line"></i>主题设置<i class="ceofont ceoicon-arrow-right-s-line"></i>首页设置<i class="ceofont ceoicon-arrow-right-s-line"></i><b>幻灯模块</b>，设置该模块内容！</p>
	</div>
</div>
<?php }else { ?>
<div class="slide_02 ceo-background-default">
	<div class="slide_2 ceo-position-relative ceo-visible-toggle" tabindex="-1" ceo-slideshow="autoplay: true">
	    <ul class="ceo-slideshow-items">
	    	<?php 
			if ($slide2) { 
				foreach ( $slide2 as $key => $value) {
			?>
	        <li>
	            <a href="<?php echo $value['url']; ?>" target="_blank" class="ceo-cover-container ceo-display-block ceo-height-1-1">
	            	<img src="<?php echo $value['img']; ?>" alt="<?php echo $value['title']; ?>" ceo-cover>
	            </a>
	        </li>
	        <?php } } ?>
	    </ul>
	    <a class="ceo-position-center-left ceo-position-small ceo-hidden-hover" href="#" ceo-slidenav-previous ceo-slideshow-item="previous"></a>
	    <a class="ceo-position-center-right ceo-position-small ceo-hidden-hover" href="#" ceo-slidenav-next ceo-slideshow-item="next"></a>
	    <ul class="slide_dotnav ceo-position-bottom-center ceo-slideshow-nav ceo-dotnav"></ul>
	</div>
	<div class="slide_2_mk ceo-visible@s">
	    <div class="ceo-container">
	        <div class="slide_2_mkbox ceo-background-default">
        		<div class="ceo-grid-ceosmls" ceo-grid>
        		    <?php 
        			if ($slide_cms) { 
        				foreach ( $slide_cms as $key => $value) {
        			?>
        			<div class="ceo-width-1-5">
        			    <a href="<?php echo $value['link']; ?>" target="_blank" class="item">
        			        <div class="ceo-grid-ceosmls" ceo-grid>
        			            <div class="ceo-width-auto">
                				    <img src="<?php echo $value['img']; ?>" alt="<?php echo $value['title']; ?><?php echo $value['subtitle']; ?>">
                				</div>
                				<div class="ceo-width-expand">
                					<span><?php echo $value['title']; ?><em><?php echo $value['subtitle']; ?></em></span>
                					<p><?php echo $value['desc']; ?></p>
                				</div>
            				</div>
        				</a>
        			</div>
        			<?php } } ?>
        		</div>
    		</div>
		</div>
	</div>
</div>
<?php } ?>

<?php if(_ceo('ceo_app_zcd') == true ): ?>
<div class="ceo-app-icobox ceo-background-default ceo-hidden@s">
    <div class="ceo-container">
        <div class="ceo-grid-ceosmls" ceo-grid>
            <?php
				if ($app_zcd) {
					foreach ( $app_zcd as $key => $value) {
			?>
            <div class="ceo-width-1-4">
                <a href="<?php echo $value['link']; ?>">
                    <img src="<?php echo $value['img']; ?>"/>
                    <p><?php echo $value['title']; ?></p>
                </a>
            </div>
            <?php } } ?>
        </div>
    </div>
</div>
<?php endif; ?>