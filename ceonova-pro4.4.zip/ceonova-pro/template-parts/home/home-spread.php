<?php
	$spread = _ceo('spread_sz');
	if(!$spread){
?>
<div class="ceo-container ceo-margin-bottom">
	<div class="ceo-alert-primary" ceo-alert>
		<a class="ceo-alert-close" ceo-close></a>
		<p class="ceo-text-small"><i class="ceofont ceoicon-information-fill ceo-margin-small-right"></i>请前往后台<i class="ceofont ceoicon-arrow-right-s-line"></i>主题设置<i class="ceofont ceoicon-arrow-right-s-line"></i>首页设置<i class="ceofont ceoicon-arrow-right-s-line"></i><b>宣传模块</b>，设置该模块内容！</p>
	</div>
</div>
<?php }else { ?>
<div class="ceo-home-spread ceo-background-default">
    <div class="ceo-container">
        <div class="ceo-home-title">
            <span><?php echo _ceo('spread_title'); ?></span>
            <p><?php echo _ceo('spread_subtitle'); ?></p>
        </div>
        <div class="ceo-home-spread-box ceo-position-relative ceo-visible-toggle ceo-light" tabindex="-1" ceo-slider>
            <ul class="ceo-slider-items ceo-child-width-1-1 ceo-child-width-1-5@s ceo-grid">
                <?php 
    			if ($spread) { 
    				foreach ( $spread as $key => $value) {
    			?>
                <li>
                    <div class="home-spread-boxmk ceo-dongtai">
                        <img src="<?php echo $value['img']; ?>" alt="<?php echo $value['title']; ?>">
                        <span><?php echo $value['title']; ?></span>
                        <p><?php echo $value['desc']; ?></p>
                    </div>
                </li>
                <?php } } ?>
            </ul>
            <a class="ceo-position-center-left ceo-position-small" href="#" ceo-slidenav-previous ceo-slider-item="previous"></a>
            <a class="ceo-position-center-right ceo-position-small" href="#" ceo-slidenav-next ceo-slider-item="next"></a>
        </div>
    </div>
</div>
<?php } ?>