<?php
	$homevip = _ceo('homevip_title');
	$vip_tc_sz = _ceo('vip_tc_sz');
	if(!$homevip){
?>
<div class="ceo-container ceo-margin-bottom">
	<div class="ceo-alert-primary" ceo-alert>
		<a class="ceo-alert-close" ceo-close></a>
		<p class="ceo-text-small"><i class="ceofont ceoicon-information-fill ceo-margin-small-right"></i>请前往后台<i class="ceofont ceoicon-arrow-right-s-line"></i>主题设置<i class="ceofont ceoicon-arrow-right-s-line"></i>首页设置<i class="ceofont ceoicon-arrow-right-s-line"></i><b>会员模块</b>，设置该模块内容！</p>
	</div>
</div>
<?php }else { ?>
<div class="ceo-home-homevip" style="background-image: url(<?php echo _ceo('homevip_img'); ?>);">
    <div class="ceo-container">
        <div class="ceo-home-title">
            <span><?php echo _ceo('homevip_title'); ?></span>
            <p><?php echo _ceo('homevip_subtitle'); ?></p>
        </div>
        <?php ceo_home_homevip_gn(); ?>
    </div>
</div>
<?php } ?>