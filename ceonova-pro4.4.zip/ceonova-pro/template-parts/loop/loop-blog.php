<?php
    $video = get_post_meta( $post->ID, 'ceo_video', true );
?>
<div class="item b-b ajaxItem ceo-background-default">
	<div class="ceo-grid-ceoblog" ceo-grid>
		<div class="ceo-width-auto ceo-blog-mks">
			<a href="<?php the_permalink(); ?>" <?php echo _target_blank();?> class="thumb ceo-display-block ceo-cover-container<?php echo $video?' ceo_video':'';?>">
				<?php if( _ceo('thumbnail_cj' ) == 'timthumb_php' ){?>
        		<img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=130&w=200&zc=1" alt="<?php the_title(); ?>"/>
        		<? }elseif( _ceo('thumbnail_cj' ) == 'timthumb_theme' ){ ?>
        		<img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" ceo-cover/>
        		<? }elseif( _ceo('thumbnail_cj' ) == 'timthumb_yun' ){ ?>
        		<img src="<?php echo post_thumbnail_src(); ?><?php echo _ceo('thumbnail_yun_custom'); ?>,h_130,w_200" alt="<?php the_title(); ?>"/>
        		<?php } ?>
    		    <?php if (is_sticky()): //置顶文章 ?>
    		    <div class="ceo-title-zd" ceo-tooltip="置顶推荐"></div>
                <?php endif; ?>
			</a>
		</div>
		<div class="ceo-overflow-hidden ceo-width-expand info-box">
			<a href="<?php the_permalink(); ?>" <?php echo _target_blank();?> class="title ceo-display-block" title="<?php the_title(); ?>">
                <?php if(get_post_meta( get_the_ID(), 'ceo-tese-tag', true )){?>
    		    <div class="ceo-title-dd">
    		        <i class="ceofont ceoicon-hashtag"></i><?php echo get_post_meta( get_the_ID(), 'ceo-tese-tag', true );?>
    		    </div>
    		    <?php }?>
                <?php the_title(); ?>
            </a>
			<div class="desc ceo-text-small ceo-visible@s"><?php echo wp_trim_words( get_the_content(), 70 ); ?></div>
			<?php get_template_part( 'template-parts/module/item', 'info' ); ?>
		</div>
	</div>
</div>