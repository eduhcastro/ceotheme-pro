<?php 
	$post_id     =  get_the_ID();
	$theme_desc  = get_post_meta( get_the_ID(), 'theme_desc', true );
?>
<div class="item ceo-overflow-hidden ceo-background-default">
    <div class="ceo-card-mk">
    	<a href="<?php the_permalink() ?>" <?php echo _target_blank();?> class="thumb ceo-display-block ceo-cover-container">
    		<?php if( _ceo('thumbnail_cj' ) == 'timthumb_php' ){?>
    		<img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=280&w=380&zc=1" alt="<?php the_title(); ?>"/>
    		<? }elseif( _ceo('thumbnail_cj' ) == 'timthumb_theme' ){ ?>
    		<img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" ceo-cover/>
    		<? }elseif( _ceo('thumbnail_cj' ) == 'timthumb_yun' ){ ?>
    		<img src="<?php echo post_thumbnail_src(); ?><?php echo _ceo('thumbnail_yun_custom'); ?>,h_280,w_380" alt="<?php the_title(); ?>"/>
    		<?php } ?>
    	</a>
    	<?php if (_ceo('ceo_cat_viptb') == true && _ceo('ceo_shop_whole') && CeoShopCoreProduct::hasVipFree($post_id)) : ?>
        <?php if (get_current_user_id() > 0 || _ceo('ceo_shop_tourist')) : ?>
        <span class="ceo_shop_vip"></span>
        <?php endif; ?>
        <?php endif; ?>
    </div>
	<div class="content">
	    <div class="titlebox ceo-text-truncate">
    		<a href="<?php the_permalink() ?>" <?php echo _target_blank();?> class="title" title="<?php the_title(); ?>">
                <?php the_title(); ?>
            </a>
            <p class="ceo-text-truncate" title="<?php echo $theme_desc; ?>"><?php echo $theme_desc; ?></p>
            <div class="contentan">
                <a href="<?php the_permalink() ?>" <?php echo _target_blank();?> class="x"><?php echo _ceo('ceo_shop_cat_antitle'); ?><i class="ceofont ceoicon-arrow-right-s-line"></i></a>
            </div>
        </div>
	</div>
</div>