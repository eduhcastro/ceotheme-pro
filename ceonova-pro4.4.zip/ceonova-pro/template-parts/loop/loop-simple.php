<?php 
	$post_id =  get_the_ID();
?>
<div class="item b-b ajaxItem ceo-background-default">
	<div class="info-box">
		<a href="<?php the_permalink(); ?>" <?php echo _target_blank();?> class="title ceo-display-block" title="<?php the_title(); ?>">
            <?php if(get_post_meta( get_the_ID(), 'ceo-tese-tag', true )){?>
		    <div class="ceo-title-dd">
		        <i class="ceofont ceoicon-hashtag"></i><?php echo get_post_meta( get_the_ID(), 'ceo-tese-tag', true );?>
		    </div>
		    <?php }?>
            <?php the_title(); ?>
        </a>
		<div class="info-boxmk">
            <div class="info ceo-flex ceo-flex-middle ceo-text-small ceo-flex ceo-flex-middle ceo-text-truncate">
                <div class="ceo-flex-1 ceo-flex ceo-flex-middle">
            		<?php if(_ceo('ceo_cat_mc') == true ): ?>
            		<span class="ceo-text-small ceo-display-block ceo-user-admin ceo-visible@s"><i class="ceofont ceoicon-user-follow-line"></i><?php the_author_posts_link(); ?></span>
            		<?php endif; ?>
                	<?php if(_ceo('ceo_cat_fl') == true ): ?>
                    <?php
                    	$category = get_the_category();
                    	if($category[0]){
                    		echo '<a class="ceo-margin-ymd ceo_blog_category ceo-visible@s" target="_blank" href="'.get_category_link($category[0]->term_id ).'"><i class="ceofont ceoicon-subtract-line"></i>'.$category[0]->cat_name.'</a>';
                    	}
                    ?>
                    <?php endif; ?>
                    <?php if(_ceo('ceo_cat_rq') == true ): ?>
                	<span class="ceo-margin-ymd ceo-margin-ymds"><i class="ceofont ceoicon-time-line"></i><?php the_time('Y-m-d') ?></span>
                	<?php endif; ?>
            	</div>
            	<div class="ceo-blog-info-y">
                	<?php if(_ceo('ceo_cat_ll') == true ): ?>
                	<span><i class="ceofont ceoicon-eye-line"></i><?php post_views('', ''); ?></span>
                	<?php endif; ?>
                	<?php if (_ceo('ceo_cat_jg') == true && _ceo('ceo_shop_whole')) : ?>
    				<?php if (get_current_user_id() > 0 || _ceo('ceo_shop_tourist')) : ?>
    					<span class="ceo_shop_loop_jg ceo-visible@s"><?php echo CeoShopCoreProduct::getPriceFormat($post_id, true, true) ?></span>
    				<?php endif; ?>
        			<?php endif; ?>
            	</div>
            </div>
        </div>
	</div>
</div>