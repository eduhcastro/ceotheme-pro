<?php
	$vip = _ceo('ceo_shop_vip_info');
?>
<div class="ceo-home-homevip-box ceo-grid-ceosmls" ceo-grid>
    <?php
	if ($vip) {
		foreach ( $vip as $key => $value) {
	?>
    <div class="ceo-width-1-1 ceo-width-1-4@s">
        <div class="home-homevip-boxmk ceo-dongtai ceo-background-default">
            <div class="top b-b">
                <div class="name"><?php echo $vip[$key]['name']; ?></div>
                <?php if ($vip[$key]['tags']): ?>
    	        <div class="tag"><?php echo $vip[$key]['tags']; ?></div>
    	        <?php endif; ?>
                <div class="home-homevip-boxmktitle">
                    <div class="price">¥<strong><?php echo $vip[$key]['price']; ?></strong><?php echo _ceo('ceo_shop_currency_name'); ?></div>
                    <p>每天可下载<?php echo $vip[$key]['number']; ?>个VIP资源</p>
                </div>
            </div>
            <div class="home-homevip-boxmks">
                <span>套餐介绍：</span>
                <p>会员有效期<em><?php echo $vip[$key]['validity']; ?>天</em><br/>
	            <?php echo $vip[$key]['desc']; ?>
	            </p>
            </div>
            <?php if( is_user_logged_in() ){ ?>
            <a href="javascript:void(0)" class="btn-ceo-svip" data-vip-id="<?php echo $vip[$key]['id'] ?>" data-style="slide-down">立即开通</a>
			<?php }else{ ?>
			<a href="#navbar-login" ceo-toggle>立即开通</a>
			<?php } ?>
        </div>
    </div>
    <?php } } ?>
</div>