<?php
    $vip = _ceo('ceo_shop_vip_info');
?>
<div class="ceo-home-homevip2-box ceo-grid-medium" ceo-grid>
    <?php
	if ($vip) {
		foreach ( $vip as $key => $value) {
	?>
	<?php if ($vip[$key]['switch']): ?>
    <div class="ceo-width-1-1 ceo-width-1-2@s">
        <div class="home-homevip2-boxmk ceo-dongtai ceo-background-default">
            <div class="ceo-flex">
                <div class="title ceo-flex-1">
                    <?php if ($vip[$key]['tags']): ?>
        	        <i><?php echo $vip[$key]['tags']; ?></i>
        	        <?php endif; ?>
                    <span><?php echo $vip[$key]['name']; ?></span>
                    <p>每天可下载<?php echo $vip[$key]['number']; ?>个VIP资源</p>
                </div>
                <i class="i ceofont ceoicon-vip-crown-2-line"></i>
            </div>
            <div class="an ceo-flex">
                <div class="ceo-flex-1">
                    <?php if( is_user_logged_in() ){ ?>
                    <a href="javascript:void(0)" class="btn-ceo-svip" data-vip-id="<?php echo $vip[$key]['id'] ?>" data-style="slide-down">立即开通</a>
        			<?php }else{ ?>
        			<a href="#navbar-login" ceo-toggle>立即开通</a>
        			<?php } ?>
                </div>
                <span class="jg"><?php echo $vip[$key]['price']; ?><em><?php echo _ceo('ceo_shop_currency_name'); ?></em></span>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php } } ?>
</div>