<?php
    if( is_user_logged_in() ){
        global $current_user;
        $user_id = get_current_user_id();
    	$current_user = wp_get_current_user();
    	$authorID = $current_user->ID;
?>
<div class="navbar-user ceo-position-relative">
	<a href="<?php echo home_url(user_trailingslashit('/member/center')); ?>" class="ceo-display-block ceo-border-circle ceo-overflow-hidden ceo-margin-left">
    	<?php echo get_avatar( $user_id , 32 ); ?>
	</a>
	<div class="dropdown ceo-position-right ceo-animation-slide-left-small">
	    <div class="dropdown-box b-r-4 ceo-background-default">
            <div class="user-warp ceo-flex ceo-flex-middle">
                <div class="ceo-border-circle ceo-overflow-hidden"><?php echo get_avatar( $user_id , 45 ); ?></div>
                <div class="user-name ceo-text-bold"><?php echo $current_user->display_name; ?></div>
            </div>
            <?php if (_ceo('ceo_shop_whole')) : ?>
            <div class="ceo-scxx">
                <?php if(_ceo('ceo_user_t_yexf') == true ): ?>
                <div class="ceo-scxx-user-money">
                    <div class="money-left">余额：<?php echo CeoShopCoreUser::getBalance($user_id) ?><t>积分：<?php echo CeoShopCoreUser::getIntegral($user_id) ?></t></div>
                </div>
                <?php endif; ?>
                
                <?php if(_ceo('ceo_user_t_vip') == true ): ?>
                <div class="ceo-scxx-user-vip">
                    <span><?php echo CeoShopCoreUser::getVipGrade($user_id) ?></span>
                    <a href="<?php if(_ceo('ceo_user_t_vip_sz'))echo _ceo('ceo_user_t_vip_sz')['ceo_user_t_vip_link']; ?>"><?php if(_ceo('ceo_user_t_vip_sz'))echo _ceo('ceo_user_t_vip_sz')['ceo_user_t_vip_title']; ?></a>
                    <p><?php if(_ceo('ceo_user_t_vip_sz'))echo _ceo('ceo_user_t_vip_sz')['ceo_user_t_vip_desc']; ?></p>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            <div class="ceo-czgr">
                <div class="ceo-grid-small" ceo-grid>
                    <div class="ceo-width-1-2">
                        <a class="ceo-cz" href="<?php if(_ceo('ceo_user_gr_sz'))echo _ceo('ceo_user_gr_sz')['ceo_user_gr_link']; ?>">
                            <i class="ceofont <?php if(_ceo('ceo_user_gr_sz'))echo _ceo('ceo_user_gr_sz')['ceo_user_gr_icon']; ?>"></i><?php if(_ceo('ceo_user_gr_sz'))echo _ceo('ceo_user_gr_sz')['ceo_user_gr_title']; ?>
                        </a>  
                    </div>
                    <div class="ceo-width-1-2">
                        <a class="ceo-gr" href="<?php if(_ceo('ceo_user_sc_sz'))echo _ceo('ceo_user_sc_sz')['ceo_user_sc_link']; ?>">
                    		<i class="ceofont <?php if(_ceo('ceo_user_sc_sz'))echo _ceo('ceo_user_sc_sz')['ceo_user_sc_icon']; ?>"></i><?php if(_ceo('ceo_user_sc_sz'))echo _ceo('ceo_user_sc_sz')['ceo_user_sc_title']; ?>
                    	</a>
                    </div>
                </div>
                <?php if(current_user_can('level_4')){ ?>
                <a class="ceo-ht" href="<?php echo admin_url(); ?>" target="_blank">
            		后台管理
            	</a>
                <?php } ?>
            </div>
            <div class="user-menu">
                <ul class="ceo-grid-ceossss" ceo-grid>
                    <li class="ceo-width-1-4 ceo-text-center">
                        <a href="/author/<?php echo the_author_meta( 'user_login',$authorID ); ?>">主页</a>
                    </li>
                    <li class="ceo-width-1-4 ceo-text-center">
            			<a href="<?php echo home_url(user_trailingslashit('/user/message')); ?>">私信</a>
            		</li>
            	    <li class="ceo-width-1-4 ceo-text-center">
            			<a href="<?php echo home_url(user_trailingslashit('/user/settings')); ?>">资料</a>
            		</li>
            		<li class="ceo-width-1-4 ceo-text-center">
            			<a href="<?php echo wp_logout_url( home_url() ); ?>">退出</a>
            		</li>
                </ul>
            </div>
        </div>
	</div>
</div>
<?php }else{ ?>

<div class="ceo-margin-left ceo-users-lore">
    <?php if(_ceo('navbar_login') == 1 ){ ?>
	<a class="ceo-users-l" href="#navbar-login" ceo-toggle>登录</a>
    <a class="ceo-users-y ceo-visible@s" href="#navbar-register" ceo-toggle>注册</a>
    <?php }else { ?>
    <a class="ceo-users-l" href="<?php echo home_url(user_trailingslashit('/user/login')); ?>">登录</a>
    <a href="<?php echo home_url(user_trailingslashit('/user/register')); ?>" class="ceo-visible@s ceo-users-y">注册</a>
    <?php } ?>
</div>
<?php } ?>