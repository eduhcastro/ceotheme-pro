<header class="navBar_01 ceo-visible@s top_box" id="headbox">
	<div class="ceo-container ceo-flex ceo-flex-middle">
		<a href="<?php bloginfo('url'); ?>" class="ceo-logo-navBar_01 logo ceo-display-block ceo-flex-1">
			<img src="<?php echo _ceo('head_logo_n'); ?>" alt="<?php bloginfo('name'); ?>"/>
		</a>
		<div class="nav ceo-visible@s">
		    <ul class="ceo-navbar-ul ceo-margin-remove ceo-padding-remove">
		        <?php ceo_menu('main-nav'); ?>
		    </ul>
		</div>
		
		<?php if(_ceo('navbar_search') == true): ?>
		<div class="search ceo-margin-left ceo-visible@s">
		    <a class="ceo-navbar-search-a" ceo-toggle="target: #mobSearch"><i class="ceofont ceoicon-search-2-line"></i></a>
		</div>
		<?php endif; ?>
		
		<?php if(_ceo('navbar_user') == true): ?>
		<div class="ceo-visible@s">
		    <?php get_template_part( 'template-parts/module/top', 'user' ); ?>
		</div>
		<?php endif; ?>
		<?php get_template_part( 'template-parts/navbar/navbar', 'mob' ); ?>
	</div>
</header>
<?php get_template_part( 'template-parts/navbar/navbar', 'app' ); ?>