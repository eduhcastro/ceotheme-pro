<div id="navbar-login" ceo-modal>
    <div class="ceo-modal-dialog ceo-navbar-login">
        <div class="ceo-grid-collapse" ceo-grid>
            <div class="ceo-width-1-1 ceo-width-1-2@s ceo-visible@s">
                <div class="navbar-login-z">
                    <div class="box">
                        <div class="bg ceo-background-cover ceo-position-cover ceo-flex ceo-flex-center ceo-flex-middle" style="background-image: url(<?php echo _ceo('tlogin_bg'); ?>)">
                            <div class="mh ceo-position-cover"></div>
                            <ul class="circles">
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                            </ul>
                        </div>
                        <div class="title">
                            <span>欢迎光临</span>
                            <p><?php echo _ceo('tlogin_notice'); ?></p>
                		    <a href="#navbar-register" class="z" ceo-toggle>我要注册</a>
                		    <a href="/wp-login.php?action=lostpassword" class="w">忘记密码</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="ceo-width-1-1 ceo-width-1-2@s">
                <div class="navbar-login-y ceo-background-default ceo-panel">
                    <button class="ceo-modal-close-default ceo-modal-close" type="button" ceo-close></button>
                    <div class="ceo-login-title">
                        <a href="<?php bloginfo('url'); ?>" alt="<?php bloginfo('name'); ?>">
                            <img src="<?php echo _ceo('head_logo'); ?>" alt="<?php bloginfo('name'); ?>" />
                        </a>
                        <p>Hi~欢迎登录 <?php bloginfo('name'); ?></p>
                    </div>

            		<div class="ceo-login-social">
        	            <div class="bottom">
                            <?php if(_ceo('qq_login')){?>
                        	<a href="javascript:;" class="button mid qq half qq_login_button ceo_qq_login" ceo-tooltip="QQ登录"><i class="ceofont ceoicon-qq-fill"></i></a>
                        	<?php }?>

                            <?php if(_ceo('is_oauth_mpweixin')){?>
                                <a href="<?php echo esc_url(home_url('/oauth/mpweixin')); ?>" class="mpweixin_login_button btn change-color social-login button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="关注微信公众号登录"><i class="ceofont ceoicon-wechat-fill"></i></a>
                            <?php }elseif(_ceo('weixin_login')){?>
                                <a href="<?php echo esc_url(home_url('/oauth/'.'weixin'.'?rurl='.home_url(add_query_arg(array())))); ?>" class="btn change-color social-login button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="微信登录"><i class="ceofont ceoicon-wechat-fill"></i></a>
                            <?php }?>

                        	<?php if(_ceo('weibo_login')){?>
                        	<a href="<?php echo weibo_oauth_url();?>" class="ceo_weibo_login weibo" ceo-tooltip="微博登录"><i class="ceofont ceoicon-weibo-fill"></i></a>
                        	<?php }?>
                    	</div>
                    </div>

            		<?php if(_ceo('ceo_login_txt') == true): ?>
            		<form action="" method="POST" id="login-form" class="login-weixin ceo-margin-top ceo-margin-bottom">
            		    <div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
            		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-user-line"></i></span>
            			    <input type="text" id="username" class="b-r-4 ceo-input ceo-text-13px" name="username" placeholder="请输入您的用户名或邮箱账号" required="required">
            			</div>
            			<div class="ceo-inline ceo-width-1-1">
            			    <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-keyhole-line"></i></span>
            			    <input type="password" id="password" class="b-r-4 ceo-input ceo-text-13px" name="password" placeholder="请输入您的密码..." required="required">
            			</div>

                        <div class="ceotheme-tips ceo-margin ceo-text-danger"></div>
            			<input type="hidden" name="action" value="zongcai_login">
            			<button class="login-button b-r-4 ceo-width-1-1 button mid dark ceo-display-block">立即登录</button>
            		    <div class="login-app-btns ceo-hidden@s">
                		    <a href="#navbar-register" class="z" ceo-toggle>我要注册</a>
                		    <a href="/wp-login.php?action=lostpassword" class="w">忘记密码</a>
            		    </div>
            		</form>
            		<?php endif; ?>
                </div>
            </div>
        </div>
	</div>
</div>

<div id="navbar-register" ceo-modal>
    <div class="ceo-modal-dialog ceo-navbar-login">
        <div class="ceo-grid-collapse" ceo-grid>
            <div class="ceo-width-1-1 ceo-width-1-2@s ceo-visible@s">
                <div class="navbar-login-z">
                    <div class="box zc">
                        <div class="bg ceo-background-cover ceo-position-cover ceo-flex ceo-flex-center ceo-flex-middle" style="background-image: url(<?php echo _ceo('tlogin_bg'); ?>)">
                            <div class="mh ceo-position-cover"></div>
                            <ul class="circles">
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                            </ul>
                        </div>
                        <div class="title">
                            <span>欢迎光临</span>
                            <p><?php echo _ceo('tlogin_notice'); ?></p>
                		    <a href="#navbar-login" class="z" ceo-toggle>立即登录</a>
                		    <a href="/wp-login.php?action=lostpassword" class="w">忘记密码</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="ceo-width-1-1 ceo-width-1-2@s">
                <div class="navbar-login-y ceo-background-default ceo-panel">
                    <button class="ceo-modal-close-default ceo-modal-close" type="button" ceo-close></button>
                    <div class="ceo-login-title">
                        <a href="<?php bloginfo('url'); ?>" alt="<?php bloginfo('name'); ?>">
                            <img src="<?php echo _ceo('head_logo'); ?>" alt="<?php bloginfo('name'); ?>" />
                        </a>
                        <p>Hi~欢迎注册 <?php bloginfo('name'); ?></p>
                    </div>

            		<div class="ceo-login-social">
        	            <div class="bottom">
                            <?php if(_ceo('qq_login')){?>
                        	<a href="javascript:;" class="button mid qq half qq_login_button ceo_qq_login" ceo-tooltip="QQ登录"><i class="ceofont ceoicon-qq-fill"></i></a>
                        	<?php }?>


                            <?php if(_ceo('is_oauth_mpweixin')){?>
                                <a href="<?php echo esc_url(home_url('/oauth/mpweixin')); ?>" class="mpweixin_login_button btn change-color social-login button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="关注微信公众号登录"><i class="ceofont ceoicon-wechat-fill"></i></a>
                            <?php }elseif(_ceo('weixin_login')){?>
                                <a href="<?php echo esc_url(home_url('/oauth/'.'weixin'.'?rurl='.home_url(add_query_arg(array())))); ?>" class="btn change-color social-login button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="微信登录"><i class="ceofont ceoicon-wechat-fill"></i></a>
                            <?php }?>

                        	<?php if(_ceo('weibo_login')){?>
                        	<a href="<?php echo weibo_oauth_url();?>" class="ceo_weibo_login weibo" ceo-tooltip="微博登录"><i class="ceofont ceoicon-weibo-fill"></i></a>
                        	<?php }?>
                    	</div>
                    </div>

            		<?php if(_ceo('ceo_login_txt') == true): ?>
            		<form action="" method="POST" id="register-form" class="login-weixin ceo-margin-medium-top ceo-margin-bottom">
                        <?php if(_ceo('is_invitaion_code')):?>
                        <div class="ceo-inline ceo-width-1-1 ceo-margin-bottom-10">
                            <span class="ceo-form-icon"><i class="ceofont ceoicon-coupon-line"></i></span>
                            <input type="text" name="invitation_code" id="invitation_code" placeholder="请输入邀请码" class="b-r-4 ceo-input ceo-text-small" required="required">
                        </div>
                        <a href="<?php echo _ceo('is_invitaion_link'); ?>" target="_blank" rel="noreferrer nofollow" class="ceo-invitation-btn ceo-margin-bottom-10"><?php echo _ceo('is_invitaion_title'); ?></a>
                        <?php endif;?>
            		    <div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
            		        <span class="ceo-form-icon"><i class="ceofont ceoicon-mail-line"></i></span>
                			<input type="email" id="email_address2" class="b-r-4 ceo-input ceo-text-13px" name="email_address2" placeholder="请输入您的邮箱" required="required">
            			</div>
            			<div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
            		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-user-line"></i></span>
            			    <input type="text" id="username2" class="b-r-4 ceo-input ceo-text-13px" name="username2" placeholder="请输入您的用户名(英文/数字)" required="required">
            			</div>
            			<div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
            		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-keyhole-line"></i></span>
            			    <input type="password" id="password2" class="b-r-4 ceo-input ceo-text-13px" name="password2" placeholder="请输入您的密码" required="required">
            			</div>
            			<div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
            		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-keyhole-line"></i></span>
            			    <input type="password" id="repeat_password2" class="b-r-4 ceo-input ceo-text-13px" name="repeat_password2" placeholder="请再次输入密码..." required="required">
                        </div>
                        <div class="agreen ceo-text-13px">
                            <input id="agreement" name="agreen" type="checkbox" class="agreen_btn" required>
                            <label for="agreen"></label>
                            我已阅读并同意<a href="<?php echo _ceo('ceo_login_zcxy_link'); ?>" target="_blank"><?php echo _ceo('ceo_login_zcxy'); ?></a>
                        </div>
                        <div class="ceotheme-tips ceo-margin ceo-text-danger"></div>
            			<input type="hidden" name="action" value="zongcai_register">
            			<input type="hidden" name="ref" value="<?php echo $_GET['ref'] ?>">
            			<button class="login-button b-r-4 ceo-width-1-1 button mid dark">立即注册</button>
            			<div class="login-app-btns ceo-hidden@s">
                		    <a href="#navbar-login" class="z" ceo-toggle>我要登录</a>
                		    <a href="/wp-login.php?action=lostpassword" class="w">忘记密码</a>
            		    </div>
            		</form>
            		<?php endif; ?>
                </div>
            </div>
        </div>
	</div>
</div>

<script>
    function is_in_weixin() {
        return "micromessenger" == navigator.userAgent.toLowerCase().match(/MicroMessenger/i)
    }

    $(".login-form .mpweixin_login_button,.login-form .mpweixin_login_button").on("click", function(e) {
        setTimeout(function (){
            UIkit.modal('#navbar-login').show();
        },500)
    });
    $(document).on("click", ".mpweixin_login_button", function(e) {
        e.preventDefault();
        var t = $(this)
            , a = t.html();
        if (is_in_weixin())
            return window.location.href = t.attr("href"),
                !0;
        $.post(ceotheme.ajaxurl, {
            action: "get_mpweixin_qr"
        }, function(e) {
            if (1 == e.status) {
                $("#navbar-login").find('form').html('<img class="login-weixin-img" src="' + e.ticket_img + '"><p class="login-weixin-p">请使用微信扫码关注登录</p>');
                $("#navbar-register").find('form').html('<img class="login-weixin-img" src="' + e.ticket_img + '"><p class="login-weixin-p">请使用微信扫码关注登录</p>');
                var n = setInterval(function() {
                    $.post(ceotheme.ajaxurl, {
                        action: "check_mpweixin_qr",
                        scene_id: e.scene_id
                    }, function(e) {
                        1 == e.status && (clearInterval(n),
                            UIkit.notification('扫码成功，即将登录', { status: 'success' }),
                            window.location.reload())
                    })
                }, 5e3)
            } else
                alert(e.ticket_img);
            t.html(a)
        })
    });
</script>