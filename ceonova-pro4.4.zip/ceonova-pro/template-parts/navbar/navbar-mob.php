<div id="mobSearch" ceo-modal>
    <div class="ceo-modal-dialog ceo-modal-body ceo-ss-navbar ceo-margin-t-b-auto ceo-background-default">
		<button class="ceo-modal-close-default ceo-modal-close" type="button" ceo-close></button>
        <h3 class="ceo-modal-search">搜索</h3>
        <div class="search">
			<form method="get" class="ceo-form ceo-flex ceo-overflow-hidden ceo-position-relative" action="<?php bloginfo('url'); ?>">
				<input type="search" placeholder="输入关键字搜索" autocomplete="off" value="" name="s" required="required" class="b-a b-r-4 ceo-input ceo-flex-1">
				<button type="submit" class="ceo-position-center-right"><i class="ceofont ceoicon-search-2-line"></i></button>
			</form>
		</div>
		<?php if(_ceo('navbar_search_h') == true): ?>
		<div class="tags-item ceo-margin-top">
			<p class="ceo-margin-small-bottom ceo-text-small">热门标签：</p>
			    <?php wp_tag_cloud('number=10&orderby=count&order=DESC&smallest=12&largest=12&unit=px'); ?>
		</div>
		<?php endif; ?>
    </div>
</div>