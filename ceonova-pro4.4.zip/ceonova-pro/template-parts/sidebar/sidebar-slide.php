<?php
    $slide = _ceo('sidebar_slide'); 
?>
<div class="ceo-sidebar-slide ceo-background-default ceo-margin-bottom b-a" style="background-image: url(<?php echo _ceo('sidebar_slide_bg'); ?>);">
	<div class="slide ceo-position-relative ceo-visible-toggle" tabindex="-1" ceo-slideshow="autoplay: true">
	    <ul class="ceo-slideshow-items">
	    	<?php 
			if ($slide) { 
				foreach ( $slide as $key => $value) {
			?>
	        <li>
	            <a href="<?php echo $value['url']; ?>" target="_blank" class="ceo-cover-container ceo-display-block ceo-height-1-1">
	            	<img src="<?php echo $value['img']; ?>" alt="<?php echo $value['title']; ?>" ceo-cover>
	            </a>
	        </li>
	        <?php } } ?>
	    </ul>
	    <ul class="slide_dotnav ceo-position-bottom-center ceo-slideshow-nav ceo-dotnav"></ul>
	</div>
</div>