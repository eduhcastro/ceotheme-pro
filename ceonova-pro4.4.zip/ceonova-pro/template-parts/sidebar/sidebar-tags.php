<!--标签模块-->
<div class="ceo-sidebar-tuwen ceo-background-default ceo-margin-bottom b-a">
    <div class="ceo-sidebar-title ceo-flex">
        <div class="ceo-zx-title ceo-imgtext-ioc ceo-flex-1" style="background: url(<?php echo _ceo('side-tag-img') ?>) left center no-repeat;">
            <?php echo _ceo('side-tag-title') ?>
        </div>
        <a href="<?php echo _ceo('side-tag-url') ?>" target="_blank"><i class="ceofont ceoicon-more-line"></i></a>
    </div>
	<ul class="ceo-list ceo-margin-remove ceo-tag-left">
	    <script src='<?php echo get_template_directory_uri();?>/static/js/tagscloud.js' type="text/javascript"></script>
        <div id="ceo-tagscloud">
            <?php
            $side_tag_num =  _ceo('side-tag-num');
            $tags_list = get_tags( array('number' => $side_tag['num'], 'orderby' => '', 'order' => 'DESC', 'hide_empty' => false) );
            $count=0;
            if ($tags_list) {
                foreach($tags_list as $tag) {
                    $count++;
                    echo '<a href="'.get_tag_link($tag->term_id).'" target="_blank" class="tagc'.rand(1,5).'">'.$tag->name.'</a>';
                    if( $count > $side_tag_num ) break;
                }
            }
            ?>
        </div>
	</ul>
</div>