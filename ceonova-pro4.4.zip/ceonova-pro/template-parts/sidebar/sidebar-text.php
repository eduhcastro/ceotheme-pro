<?php
    $cat_id = _ceo('text-cat');
    $args = array(
        'cat'            => $cat_id,
        'ignore_sticky_posts' => true,
        'post_status'         => 'publish',
        'posts_per_page'      => _ceo('text-number'),
        'orderby'      => _ceo('text-orderby'),
        'meta_key' => 'views',
        'order' => 'DESC',
    );
    $data = new WP_Query($args);
    $category = get_category( $cat_id);
?>
<!--文章展示-->
<div class="ceo-sidebar-tuwen ceo-background-default ceo-margin-bottom b-a">
    <div class="ceo-sidebar-text-title ceo-flex">
        <div class="ceo-zx-title ceo-imgtext-ioc ceo-flex-1" style="background: url(<?php echo _ceo('text-title-img') ?>) left center no-repeat;">
            <?php echo _ceo('text-title') ?>
        </div>
        <a href="<?php echo _ceo('text-url') ?>" target="_blank"><i class="ceofont ceoicon-more-line"></i></a>
    </div>
    <div class="ceo-sidebar-text-wen">
        <ul>
            <?php while ( $data->have_posts() ) : $data->the_post(); ?>
            <li class="ceo-catshow">
                <a href="<?php echo get_permalink(); ?>" target="_blank"><?php echo get_the_title(); ?></a>
                <div class="ceo-sidebar-text-winfo ceo-flex">
                    <?php
            	    	$category = get_the_category();
            	    	if($category[0]){
            	    		echo '<a href="'.get_category_link($category[0]->term_id ).'" target="_blank"><i class="ceofont ceoicon-apps-2-line"></i>'.$category[0]->cat_name.'</a>';
            	    	}
            	    ?>
                    <span class="ceo-flex-1"><i class="ceofont ceoicon-eye-line"></i><?php post_views('', ''); ?></span>
                    <span><i class="ceofont ceoicon-discuss-line"></i><?php echo get_comments_number(); ?></span>
                </div>
            </li>
            <?php endwhile; ?>
        </ul>
    </div>
</div>