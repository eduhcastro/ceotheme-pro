<?php
    $zz = _ceo('side_zz');
?>
<!--广告模块-->
<div class="side-zz b-a ceo-background-default ceo-padding-small ceo-margin-bottom">
    <?php
    if ($zz) {
    foreach ( $zz as $key => $value) {
    ?>
	<a href="<?php echo $zz[$key]['link']; ?>" target="_blank" class="ceo-display-block">
	    <img src="<?php echo $zz[$key]['img']; ?>"/>
	</a>
	<?php } } ?>
</div>
