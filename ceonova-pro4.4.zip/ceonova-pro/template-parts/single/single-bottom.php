<?php 
    $post_id =  get_the_ID();
    $xg_num = _ceo('xg_num');
?>
<?php if ($productTypeKey != 'close' && $productTypeKey != '' ) { ?>
<div class="card ceo-background-default ceo-margin-bottom b-a">
	<div class="ceo-single-shopxg b-b ceo-flex ceo-flex-middle ceo-overflow-hidden">
		<span class="ceo-position-relative ceo-zx-title" style="background: url(<?php echo _ceo('xg_title_img'); ?>) left center no-repeat;"><?php echo _ceo('xg_title'); ?></span>
	</div>
	<div class="ceo-single-shopxg ceo-grid-ceosmls" ceo-grid>
    	<?php
    		$cat=get_the_category();
            $cat_id=$cat[0]->cat_ID;
    		$the_query = new WP_Query( 
    			array( 
    				'no_found_rows' => true,
    				'cat' => $cat_id,
    				'posts_per_page' => $xg_num,
    				'post__not_in' => get_option( 'sticky_posts' ) 
    			)
    		);
    		if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post(); 
    	?>
    	<div class="ceo-width-1-1@s ceo-width-1-3@m ceo-width-1-3@l ceo-width-1-3@xl">
    	<?php get_template_part( 'template-parts/loop/loop', 'card' ); ?>
    	</div>
        <?php endwhile; endif; wp_reset_postdata(); ?>
    </div>
</div>
<?php }else{ ?>
<div class="blog ceo-background-default ceo-margin-bottom b-a">
	<div class="module-title b-b ceo-flex ceo-flex-middle ceo-overflow-hidden">
		<span class="ceo-position-relative ceo-zx-title" style="background: url(<?php echo _ceo('xg_title_img'); ?>) left center no-repeat;"><?php echo _ceo('xg_title'); ?></span>
	</div>
	<?php
		$cat=get_the_category();
        $cat_id=$cat[0]->cat_ID;
		$the_query = new WP_Query( 
			array( 
				'no_found_rows' => true,
				'cat' => $cat_id,
				'posts_per_page' => $xg_num,
				'post__not_in' => get_option( 'sticky_posts' ) 
			)
		);
		if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post(); 
	?>
	<?php get_template_part( 'template-parts/loop/loop', 'blog' ); ?>
    <?php endwhile; endif; wp_reset_postdata(); ?>
</div>
<?php } ?>
