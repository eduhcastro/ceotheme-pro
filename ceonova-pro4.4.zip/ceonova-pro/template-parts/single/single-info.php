<?php 
	$post_id =  get_the_ID();
	$author_id = (int)get_post_field( 'post_author', $post_id );
	global $authordata;
	$authordata = get_userdata($author_id);
?>
<div class="single-post-info info ceo-flex ceo-flex-middle ceo-text-small ceo-text-muted ceo-flex ceo-flex-middle ceo-text-truncate">
    <div class="ceo-flex-1 ceo-flex ceo-flex-middle">
		<?php if(_ceo('single_info_tx') == true ): ?>
        <div class="avatar ceo-border-circle ceo-overflow-hidden ceo-user-adminimg">
		<?php echo get_avatar(get_the_author_meta( 'ID' ), 20); ?>
		</div>
		<?php endif; ?>
		<?php if(_ceo('single_info_mc') == true ): ?>
		<span class="ceo-text-small ceo-display-block ceo-user-admin"><?php the_author_posts_link(); ?></span>
		<?php endif; ?>
		<?php if(_ceo('single_info_fl') == true ): ?>
	    <span class="ceo-text-small ceo-margin-ymd ceo-visible@s">
	    <?php
	    	$category = get_the_category();
	    	if($category[0]){
	    		echo '<a class="fl" href="'.get_category_link($category[0]->term_id ).'"><i class="ceofont ceoicon-apps-2-line"></i>'.$category[0]->cat_name.'</a>';
	    	}
	    ?>
	    </span>
	    <?php endif; ?>
        <?php if(_ceo('single_info_rq') == true ): ?>
    	<span class="ceo-margin-ymd"><i class="ceofont ceoicon-time-line"></i><?php echo the_time('Y年m月j日'); ?></span>
    	<?php endif; ?>
    	<?php if(_ceo('single_info_ll') == true ): ?>
    	<span class="ceo-margin-ymd"><i class="ceofont ceoicon-eye-line"></i><?php post_views('', ''); ?> 浏览</span>
    	<?php endif; ?>
    	<span class="ceo-margin-ymd"><?php edit_post_link('<i class="ceofont ceoicon-edit-2-line"></i> 编辑'); ?></span>
	</div>
</div>