<?php

$action = get_query_var('action') ?: 'settings';

get_header();

$action_file = get_template_directory().'/user/action/'.$action.'.php';

$args = array(
    'post_author' => $user_id
);
$author_comments = get_comments($args);
$bg = _ceo('user-bg');
?>
<div class="ceo-tag-bg" style="background: url(<?php echo $bg; ?>) center no-repeat;">
    <div class="ceo-container ceo-containertag">
        <div class="ceo-action-userzx ceo-align-lefts ceo-tag-bgleft">
            <div class="ceo-grid-ceosmls" ceo-grid>
                <div class="ceo-width-auto">
                	<div class="ceo-text-center ceo-author-adminimg">
                	    <div class="ceo-author-imgs">
                		    <?php echo get_avatar( $user_id , 80 ); ?>
                            <?php if(user_can($user_id,'author') || user_can($user_id,'editor') || user_can($user_id,'administrator')){ ?>
                                <i ceo-tooltip="认证作者"></i>
                            <?php }?>
            			</div>
                	</div>
        	    </div>
            	<div class="ceo-width-expand">
            	    <div class="mc ceo-text-left">
            		    <h3 class="ceo-hs">
            		        <a href="<?php echo get_author_posts_url( $user_id, get_userdata($user_id)->user_nicename ); ?>"><?php echo $current_user->display_name; ?></a>
        		        </h3>
                	    <p class="ceo-text-truncate">
                	        <?php
                                if(!get_the_author_meta('user_description', $user_id)){
                                    echo '这家伙很懒，只想把你留下。';
                                }else {
                                    echo the_author_meta('user_description', $user_id);
                                }
                        	?>
                	    </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="user-data ceo-background-default">
    <div class="ceo-container">
        <div class="user-navbox ceo-flex">
            <ul class="user-nav ceo-flex-1">
                <?php if(_ceo('ceo_author_cd1') == true ): ?>
        		<li class="<?php if($action == '' || $action == 'collection') echo 'active';?>">
        			<a href="<?php echo home_url(user_trailingslashit('/user/collection')); ?>">
        	            我的收藏
        			</a>
        		</li>
        		<?php endif; ?>
        		<?php if(_ceo('ceo_author_cd2') == true ): ?>
                <li class="<?php if($action == '' || $action == 'follows') echo 'active';?>">
        			<a href="<?php echo home_url(user_trailingslashit('/user/follows')); ?>">
        	            我的关注
        			</a>
        		</li>
        		<?php endif; ?>
        		<?php if(_ceo('ceo_author_cd3') == true ): ?>
                <li class="<?php if($action == '' || $action == 'message') echo 'active';?>">
        			<a href="<?php echo home_url(user_trailingslashit('/user/message')); ?>">
        	            我的私信
        			</a>
        		</li>
        		<?php endif; ?>
        		<?php if(_ceo('ceo_author_cd4') == true ): ?>
        		<li class="<?php if($action == 'question') echo 'active';?>">
        			<a href="<?php echo home_url(user_trailingslashit('/user/question')); ?>">
        	            我的提问
        			</a>
        		</li>
        		<?php endif; ?>
        		<?php if(_ceo('ceo_author_cd5') == true ): ?>
        		<li class="<?php if($action == 'forum') echo 'active';?>">
        			<a href="<?php echo home_url(user_trailingslashit('/user/forum')); ?>">
        	            我的帖子
        			</a>
        		</li>
        		<?php endif; ?>
        		<?php if(_ceo('ceo_author_cd6') == true ): ?>
        		<li class="<?php if($action == 'comment') echo 'active';?>">
        			<a href="<?php echo home_url(user_trailingslashit('/user/comment')); ?>">
        	            我的评论
        			</a>
        		</li>
        		<?php endif; ?>
        		<?php if(_ceo('ceo_author_cd7') == true ): ?>
        		<li class="<?php if($action == 'site') echo 'active';?>">
        			<a href="<?php echo home_url(user_trailingslashit('/user/site')); ?>">
        	            我的网站
        			</a>
        		</li>
        		<?php endif; ?>
                <li class="<?php if($action == 'settings') echo 'active';?>">
        			<a href="<?php echo home_url(user_trailingslashit('/user/settings')); ?>">
        	            个人资料
        			</a>
        		</li>
        		<li class="<?php if($action == 'security') echo 'active';?>">
        			<a href="<?php echo home_url(user_trailingslashit('/user/security')); ?>">
        	            账号安全
        			</a>
        		</li>
        		<li>
        		    <a href="<?php echo wp_logout_url( home_url() ); ?>" class="ceo-display-inline-block">退出登录</a>
        		</li>
        	</ul>
        	<?php if(_ceo('ceo_author_cdshop') == true ): ?>
        	<a href="<?php echo _ceo('ceo_author_cdshopl'); ?>" class="user-shopan">
        	    <i class="ceofont ceoicon-shopping-cart-line"></i> <?php echo _ceo('ceo_author_cdshopt'); ?>
            </a>
        		<?php endif; ?>
        </div>
    </div>
</div>
<section class="ceo-container user-main">
    <div class="wp-user">
		<div class="user-content ceo-background-default b-a">
			<?php
				if(!is_file($action_file)){
				    include(get_template_directory().'/user/action/settings.php'); //用户中心默认页面
				}else{
					include($action_file);
				}
			?>
		</div>
    </div>
</section>
<style>.foot-link{display:none}</style>
<?php get_footer(); ?>