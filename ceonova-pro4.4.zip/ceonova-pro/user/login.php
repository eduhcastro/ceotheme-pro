<?php
// 登录页面背景图片
add_filter('body_class',function ($classes) {
	$classes[]	= 'joy-login';
	return $classes;
});
get_header();
?>
<section class="ceo-page-login ceo-background-cover ceo-panel ceo-flex ceo-flex-center ceo-flex-middle">
    <div class="background-shape">
        <div class="circle1 wow fadeInRightBig" data-wow-duration="4000ms" style="visibility: visible; animation-duration: 4000ms; animation-name: fadeInRightBig;"></div>
        <div class="circle2 wow fadeInRightBig" data-wow-duration="4000ms" style="visibility: visible; animation-duration: 4000ms; animation-name: fadeInRightBig;"></div>
        <div class="circle3 wow fadeInRightBig" data-wow-duration="4000ms" style="visibility: visible; animation-duration: 4000ms; animation-name: fadeInRightBig;"></div>
        <div class="circle4 wow fadeInRightBig" data-wow-duration="4000ms" style="visibility: visible; animation-duration: 4000ms; animation-name: fadeInRightBig;"></div>
    </div>
    <div class="background-animation">
        <div class="star-ani"></div>
        <div class="cloud-ani"></div>
        <div class="triangle-ani"></div>
        <div class="circle-ani"></div>
        <div class="box-ani"></div>
    </div>
    <div class="page-login ceo-animation-slide-bottom-small">
    <?php include get_template_directory().'/user/login/'.$action.'.php'; ?>
    </div>
</section>
<?php get_footer(); ?>