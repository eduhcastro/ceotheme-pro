<div class="login-main b-r-4 ceo-overflow-hidden ceo-grid-collapse ceo-background-default" ceo-grid>
	<div class="login-bg ceo-width-auto ceo-position-relative ceo-overflow-hidden ceo-visible@s">
	    <p><img src="<?php echo _ceo('login_bg'); ?>" class="ceo-position-center" /></p>
	    <div class="gradient-ver-bw ceo-position-bottom-left ceo-padding ceo-light ceo-width-1-1">
	    <span><?php echo _ceo('login_notice'); ?></span>
	    <p class="ceo-margin-small-top ceo-margin-remove-bottom">— <?php bloginfo('name'); ?></p>
	    </div>
	</div>
	<div class="ceo-width-expand">
	    <div class="login-form">
    	    <div class="login-form-title b-b ceo-flex">
        		<span class="ceo-margin-right">登录</span>
    		</div>
            <?php if(_ceo('ceo_login_txt') == true): ?>
    		<form action="" method="POST" id="login-form" class="ceo-margin-medium-top ceo-margin-bottom">
    		    <div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
    		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-user-line"></i></span>
    			    <input type="text" id="username" class="b-r-4 ceo-input ceo-text-13px" name="username" placeholder="请输入您的用户名或邮箱账号" required="required">
    			</div>
    			<div class="ceo-inline ceo-width-1-1">
    			    <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-keyhole-line"></i></span>
    			    <input type="password" id="password" class="b-r-4 ceo-input ceo-text-13px" name="password" placeholder="请输入您的密码..." required="required">
    			</div>

                <div class="ceotheme-tips ceo-margin ceo-text-danger"></div>
    			<div class="ceo-flex ceo-margin-bottom">
            		<p class="ceo-flex-1 ceo-text-muted ceo-text-13px">没有账号？<a href="<?php echo home_url(user_trailingslashit('/user/register')); ?>" class="ceo-login-btnss">立即注册！</a></p>
            		<p class="ceo-text-muted ceo-text-13px"><a href="/wp-login.php?action=lostpassword">忘记密码？</a></p>
        		</div>
    			<input type="hidden" name="action" value="zongcai_login">
    			<button class="login-button b-r-4 ceo-width-1-1 button mid dark ceo-display-block">立即登录</button>
    		</form>
    		<?php endif; ?>
    		<div class="ceo-login-pages">
    		    <div class="ceo-grid-ceosmls" ceo-grid>
    		        <div class="ceo-width-1-1@s ceo-width-expand@m ceo-width-expand@l ceo-width-expand@xl">
    		            <p class="ceo-flex-1 ceo-text-muted ceo-text-13px">社交账号登录</p>
    	            </div>
    	            <div class="ceo-width-1-1@s ceo-width-auto@m ceo-width-auto@l ceo-width-auto@xl bottom">
                        <?php if(_ceo('qq_login')){?>
                    	<a href="javascript:;" class="button mid qq half qq_login_button ceo_qq_login" ceo-tooltip="QQ登录"><i class="ceofont ceoicon-qq-fill"></i>QQ</a>
                    	<?php }?>

                        <?php if(_ceo('is_oauth_mpweixin')){?>
                            <a href="<?php echo esc_url(home_url('/oauth/mpweixin')); ?>" class="mpweixin_login_button btn change-color social-login button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="关注微信公众号登录"><i class="ceofont ceoicon-wechat-fill"></i>微信</a>
                        <?php }elseif(_ceo('weixin_login')){?>
                            <a href="<?php echo esc_url(home_url('/oauth/'.'weixin'.'?rurl='.home_url(add_query_arg(array())))); ?>" class="btn change-color social-login ceo-margin-top button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="微信登录"><i class="ceofont ceoicon-wechat-fill"></i>微信</a>
                        <?php }?>

                    	<?php if(_ceo('weibo_login')){?>
                    	<a href="<?php echo weibo_oauth_url();?>" class="ceo_weibo_login" ceo-tooltip="微博登录"><i class="ceofont ceoicon-weibo-fill"></i>微博</a>
                    	<?php }?>
                	</div>
            	</div>
            </div>
		</div>
	</div>
</div>