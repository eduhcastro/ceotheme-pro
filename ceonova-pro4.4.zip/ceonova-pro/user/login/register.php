<div class="login-main b-r-4 ceo-overflow-hidden ceo-grid-collapse ceo-background-default" ceo-grid>
	<div class="login-bg ceo-width-auto ceo-position-relative ceo-overflow-hidden ceo-visible@s">
	    <p><img src="<?php echo _ceo('login_bg'); ?>" class="ceo-position-center" /></p>
	    <div class="gradient-ver-bw ceo-position-bottom-left ceo-padding ceo-light ceo-width-1-1">
	    <span><?php echo _ceo('login_notice'); ?></span>
	    <p class="ceo-margin-small-top ceo-margin-remove-bottom">— <?php bloginfo('name'); ?></p>
	    </div>
	</div>
	<div class="ceo-width-expand">
	    <div class="login-form">
    	    <div class="login-form-title b-b ceo-flex">
        		<span class="ceo-margin-right">注册</span>
    		</div>
            <?php if(_ceo('ceo_login_txt') == true): ?>
    		<form action="" method="POST" id="register-form" class="ceo-margin-medium-top ceo-margin-bottom">
                <?php if(_ceo('is_invitaion_code')):?>
                    <div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
                        <span class="ceo-form-icon"><i class="ceofont ceoicon-coupon-line"></i></span>
                        <input type="text" name="invitation_code" id="invitation_code" placeholder="请输入邀请码" class="b-r-4 ceo-input ceo-text-small" required="required">
                    </div>
                    <a href="<?php echo _ceo('is_invitaion_link'); ?>" target="_blank" rel="noreferrer nofollow" class="ceo-invitation-btn ceo-margin-bottom"><?php echo _ceo('is_invitaion_title'); ?></a>
                <?php endif;?>
    		    <div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
    		        <span class="ceo-form-icon"><i class="ceofont ceoicon-mail-line"></i></span>
        			<input type="email" id="email_address2" class="b-r-4 ceo-input ceo-text-13px" name="email_address2" placeholder="请输入您的邮箱" required="required">
    			</div>
    			<div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
    		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-user-line"></i></span>
    			    <input type="text" id="username2" class="b-r-4 ceo-input ceo-text-13px" name="username2" placeholder="请输入您的用户名(英文/数字)" required="required">
    			</div>
    			<div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
    		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-keyhole-line"></i></span>
    			    <input type="password" id="password2" class="b-r-4 ceo-input ceo-text-13px" name="password2" placeholder="请输入您的密码" required="required">
    			</div>
    			<div class="ceo-inline ceo-width-1-1 ceo-margin-bottom">
    		        <span class="ceo-form-icon"><i class="ceofont ceoicon-shield-keyhole-line"></i></span>
    			    <input type="password" id="repeat_password2" class="b-r-4 ceo-input ceo-text-13px" name="repeat_password2" placeholder="请再次输入密码..." required="required">
                </div>
                <div class="ceo-flex ceo-margin-bottom">
                    <div class="agreen ceo-text-13px ceo-flex-1">
                        <input id="agreement" name="agreen" type="checkbox" class="agreen_btn" required>
                        <label for="agreen"></label>
                        我已阅读并同意<a href="<?php echo _ceo('ceo_login_zcxy_link'); ?>" target="_blank"><?php echo _ceo('ceo_login_zcxy'); ?></a>
                    </div>
                    <p class="ceo-text-muted ceo-text-13px ceo-visible@s">已有账号？<a href="<?php echo home_url(user_trailingslashit('/user/login')); ?>" class="ceo-login-btnss">立即登录！</a></p>
                </div>
                <div class="ceotheme-tips ceo-margin ceo-text-danger"></div>
    			<input type="hidden" name="action" value="zongcai_register">
    			<input type="hidden" name="ref" value="<?php echo $_GET['ref'] ?>">
    			<button class="login-button b-r-4 ceo-width-1-1 button mid dark">立即注册</button>
    		</form>
    		<?php endif; ?>
            <div class="ceo-login-pages">
    		    <div class="ceo-grid-ceosmls" ceo-grid>
    		        <div class="ceo-width-1-1@s ceo-width-expand@m ceo-width-expand@l ceo-width-expand@xl">
    		            <p class="ceo-flex-1 ceo-text-muted ceo-text-13px">社交账号登录</p>
    	            </div>
    	            <div class="ceo-width-1-1@s ceo-width-auto@m ceo-width-auto@l ceo-width-auto@xl bottom">
                        <?php if(_ceo('qq_login')){?>
                    	<a href="javascript:;" class="button mid qq half qq_login_button ceo_qq_login" ceo-tooltip="QQ登录"><i class="ceofont ceoicon-qq-fill"></i>QQ</a>
                    	<?php }?>

                    	<?php if(_ceo('weixin_login')){?>
                    	<a href="<?php echo esc_url(home_url('/oauth/'.'weixin'.'?rurl='.home_url(add_query_arg(array())))); ?>" class="btn change-color social-login ceo-margin-top button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="微信登录"><i class="ceofont ceoicon-wechat-fill"></i>微信</a>
                        <?php }?>

                        <?php if(_ceo('is_oauth_mpweixin')){?>
                            <a href="<?php echo esc_url(home_url('/oauth/mpweixin')); ?>" class="mpweixin_login_button btn change-color social-login button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="关注微信公众号登录"><i class="ceofont ceoicon-wechat-fill"></i>微信</a>
                        <?php }elseif(_ceo('weixin_login')){?>
                            <a href="<?php echo esc_url(home_url('/oauth/'.'weixin'.'?rurl='.home_url(add_query_arg(array())))); ?>" class="btn change-color social-login ceo-margin-top button mid weixin half weixin_login_button ceo_weixin_login" ceo-tooltip="微信登录"><i class="ceofont ceoicon-wechat-fill"></i>微信</a>
                        <?php }?>


                        <?php if(_ceo('weibo_login')){?>
                    	<a href="<?php echo weibo_oauth_url();?>" class="ceo_weibo_login" ceo-tooltip="微博登录"><i class="ceofont ceoicon-weibo-fill"></i>微博</a>
                    	<?php }?>
                	</div>
            	</div>
            </div>
            <div class="ceo-margin-top ceo-text-center ceo-hidden@s">
                <p class="ceo-text-muted ceo-text-13px">已有账号？<a href="<?php echo home_url(user_trailingslashit('/user/login')); ?>">立即登录！</a></p>
            </div>
        </div>
    </div>
</div>