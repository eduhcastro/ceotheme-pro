<?php
error_reporting(0);
header('Content-Type: application/json; charset=utf-8');

$license = $_POST['license'];
$item_name = $_POST['item_name'];
$url = $_POST['url'];

$arr = ['success'=>true, 'license'=>'valid', 'item_id'=>false, 'item_name'=>$item_name, 'checksum'=>md5(time()), 'expires'=>'lifetime', 'payment_id'=>1, 'customer_name'=>'', 'customer_email'=>'', 'license_limit'=>0, 'site_count'=>5, 'activations_left'=>'unlimited', 'price_id'=>false];
echo json_encode($arr);